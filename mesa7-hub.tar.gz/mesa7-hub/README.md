# Sistema Mesa7 — Hub de Dados

Painel onde a equipe da Mesa7 envia os relatórios mensais de cada cliente
(PDF, CSV ou XLSX). Os arquivos ficam guardados no servidor e o histórico fica
registrado no banco, com uma API para consultar tudo depois.

Sete áreas: Meta Ads, Google Ads, iFood, Cardápio Digital, Salão,
Google Meu Negócio e Repediu.

Stack: Node 18+ · Express · PostgreSQL · React (Vite).

---

## O que já funciona

- Envio pela interface: escolhe cliente, mês, área e anexa o arquivo
- Validação de formato, tamanho, cliente, usuário e mês antes de aceitar
- Arquivos organizados no disco em `uploads/<cliente>/<ano-mês>/`
- Histórico de uploads por cliente, com quem enviou e quando
- Log de auditoria de cada envio
- API REST para consultar clientes, uploads e dados

## O que ainda NÃO funciona

**Os CSVs são guardados, mas ainda não são lidos.** O conteúdo dos arquivos
não vira número no banco ainda — as tabelas `google_ads_data`, `meta_ads_data`
e companhia estão criadas e vazias, esperando os parsers (Fase 2). Ou seja:
hoje o sistema é um repositório organizado de arquivos com histórico, não um
dashboard de métricas. O endpoint `/data` já existe e responde, mas retorna
listas vazias até os parsers entrarem.

Também não tem login ainda: quem abre o painel escolhe de quem é o envio.
Enquanto estiver atrás de uma URL que só a equipe conhece, funciona; antes de
abrir pra mais gente, vale colocar autenticação.

---

## Instalação

Tem um script que faz tudo. No VPS:

```bash
bash install.sh
```

Ele confere o que falta, pergunta os dados do banco, instala as dependências,
cria o banco, monta o painel e sobe o servidor no PM2. Pode rodar de novo
quando quiser — mantém o `.env` e não apaga o que a equipe já subiu.

Só precisa ter Node 18+ e PostgreSQL na máquina; se faltar algum, o script
diz o comando pra instalar e para.

No fim ele mostra o trecho do Nginx pra colar — é o único passo manual.

### Atualizar depois

```bash
bash update.sh
```

Baixa o código novo, reinstala o que mudou, remonta o painel e reinicia.

### Se preferir fazer na mão

```bash
npm install
cp .env.example .env && nano .env
npm run init-db
npm run build
npm start
```

## Desenvolvimento

Dois terminais:

```bash
npm run dev          # API com reload, porta 3001
npm run client:dev   # painel com hot reload, porta 5173
```

O Vite já faz proxy de `/api` para a porta 3001, então não tem CORS no meio.

---

## Deploy no VPS

```bash
cd /opt
git clone <url-do-seu-repo> mesa7-hub
cd mesa7-hub
npm install
cp .env.example .env && nano .env
npm run init-db
npm run build
pm2 start server.js --name mesa7-hub
pm2 save
```

No `.env` de produção, aponte o `UPLOAD_DIR` para fora do projeto, senão um
`git pull` convive mal com os arquivos da equipe:

```env
UPLOAD_DIR=/var/uploads/mesa7
```

```bash
sudo mkdir -p /var/uploads/mesa7
sudo chown $USER /var/uploads/mesa7
```

Nginx (o bloco do domínio que já existe):

```nginx
location / {
    proxy_pass http://localhost:3001;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    client_max_body_size 50M;   # sem isso, upload grande morre com 413
}
```

```bash
sudo nginx -t && sudo systemctl reload nginx
```

---

## API

| Método | Rota | O que faz |
|--------|------|-----------|
| GET  | `/health` | Checa se o servidor e o banco respondem |
| GET  | `/api/v1/clients` | Lista os clientes ativos |
| POST | `/api/v1/upload` | Recebe um arquivo |
| GET  | `/api/v1/clients/:id/uploads` | Histórico de uploads do cliente |
| GET  | `/api/v1/clients/:id/data` | Dados consolidados (vazio até a Fase 2) |

### Upload

Campos: `file`, `client_id`, `source`, `reference_month` (AAAA-MM), `user_id`, `notes` (opcional).

Áreas aceitas: `meta_ads`, `google_ads`, `ifood`, `cardapio`, `salao`, `gmn`, `repediu`.

Formatos: pdf, csv, xlsx. Máximo 50MB.

```bash
curl -X POST http://localhost:3001/api/v1/upload \
  -F "file=@examples/google-ads.csv" \
  -F "client_id=1" -F "source=google_ads" \
  -F "reference_month=2026-09" -F "user_id=3"
```

### Consulta

```bash
curl "http://localhost:3001/api/v1/clients/1/data?start_date=2026-09-01&end_date=2026-09-30&sources=google_ads,meta_ads"
```

---

## Estrutura

```
mesa7-hub/
├── server.js              API Express
├── db/schema.sql          Tabelas do banco
├── scripts/init-db.js     Cria banco, schema, equipe e clientes
├── examples/              CSV de exemplo
└── client/                Painel React (Vite)
    └── src/
        ├── App.jsx
        └── components/UploadForm.jsx
```

---

## Problemas comuns

**`ECONNREFUSED`** — PostgreSQL não está rodando ou a porta no `.env` está errada.
Confira com `pg_isready -h <host> -p <porta>`.

**`28P01` / senha falhou** — `DB_USER`/`DB_PASSWORD` do `.env` não batem com o banco.

**`413 Request Entity Too Large`** — falta o `client_max_body_size 50M` no Nginx.

**Painel abre em branco** — o build não foi feito. Rode `npm run build`.

**Upload dá "Cliente não encontrado"** — o `client_id` não existe. Veja os IDs
com `curl localhost:3001/api/v1/clients`.

**O mês que a equipe precisa não aparece na lista** — o seletor mostra os 12
meses anteriores ao atual. Para mudar, ajuste `ultimosMeses()` em
`client/src/components/UploadForm.jsx`.
