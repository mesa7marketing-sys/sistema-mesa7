import { useState, useEffect, useRef } from 'react';
import './UploadForm.css';

// As sete areas, na ordem em que a equipe pensa nelas
const AREAS = [
  { id: 'meta_ads', label: 'Meta Ads' },
  { id: 'google_ads', label: 'Google Ads' },
  { id: 'ifood', label: 'iFood' },
  { id: 'cardapio', label: 'Cardápio Digital' },
  { id: 'salao', label: 'Salão' },
  { id: 'gmn', label: 'Google Meu Negócio' },
  { id: 'repediu', label: 'Repediu' },
];

const MESES = [
  'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
  'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro',
];

const EXT_OK = ['pdf', 'csv', 'xlsx'];
const MAX_MB = 50;

// O relatorio de um mes e entregue no mes seguinte, entao o padrao e o mes passado
function mesPadrao() {
  const d = new Date();
  d.setDate(1);
  d.setMonth(d.getMonth() - 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

// Ultimos 12 meses para o seletor
function ultimosMeses(qtd = 12) {
  const lista = [];
  const d = new Date();
  d.setDate(1);
  for (let i = 1; i <= qtd; i++) {
    const m = new Date(d);
    m.setMonth(d.getMonth() - i);
    lista.push({
      valor: `${m.getFullYear()}-${String(m.getMonth() + 1).padStart(2, '0')}`,
      texto: `${MESES[m.getMonth()]} de ${m.getFullYear()}`,
    });
  }
  return lista;
}

export default function UploadForm({ userId }) {
  const [clientes, setClientes] = useState([]);
  const [cliente, setCliente] = useState('');
  const [mes, setMes] = useState(mesPadrao());
  const [area, setArea] = useState('');
  const [arquivo, setArquivo] = useState(null);
  const [arrastando, setArrastando] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [aviso, setAviso] = useState(null);

  const inputArquivo = useRef(null);
  const meses = useRef(ultimosMeses()).current;

  useEffect(() => {
    fetch('/api/v1/clients')
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then(setClientes)
      .catch((e) =>
        setAviso({ tipo: 'erro', texto: 'Não consegui carregar a lista de clientes: ' + e.message })
      );
  }, []);

  function validarEGuardar(f) {
    if (!f) return;
    const ext = f.name.split('.').pop().toLowerCase();
    if (!EXT_OK.includes(ext)) {
      setAviso({ tipo: 'erro', texto: `Esse arquivo é .${ext}. Envie PDF, CSV ou XLSX.` });
      return;
    }
    if (f.size > MAX_MB * 1024 * 1024) {
      setAviso({ tipo: 'erro', texto: `O arquivo tem ${(f.size / 1024 / 1024).toFixed(1)}MB. O limite é ${MAX_MB}MB.` });
      return;
    }
    setArquivo(f);
    setAviso(null);
  }

  function aoSoltar(e) {
    e.preventDefault();
    setArrastando(false);
    validarEGuardar(e.dataTransfer.files?.[0]);
  }

  async function enviar(e) {
    e.preventDefault();
    setEnviando(true);
    setAviso(null);

    const dados = new FormData();
    dados.append('file', arquivo);
    dados.append('client_id', cliente);
    dados.append('source', area);
    dados.append('reference_month', mes);
    dados.append('user_id', userId);

    try {
      const res = await fetch('/api/v1/upload', { method: 'POST', body: dados });
      const corpo = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(corpo.error || `Erro ${res.status}`);

      const nomeCliente = clientes.find((c) => String(c.id) === String(cliente))?.name || '';
      const nomeArea = AREAS.find((a) => a.id === area)?.label || '';
      const nomeMes = meses.find((m) => m.valor === mes)?.texto || mes;

      setAviso({
        tipo: 'ok',
        texto: `Enviado: ${nomeArea} de ${nomeCliente}, ${nomeMes}.`,
      });

      // Limpa so o arquivo e a area: cliente e mes costumam repetir no proximo envio
      setArquivo(null);
      setArea('');
      if (inputArquivo.current) inputArquivo.current.value = '';
    } catch (err) {
      setAviso({ tipo: 'erro', texto: err.message });
    } finally {
      setEnviando(false);
    }
  }

  const pronto = cliente && mes && area && arquivo && !enviando;

  return (
    <div className="envio">
      <div className="envio-card">
        <h1>Enviar relatório</h1>
        <p className="envio-sub">Um arquivo por área. Se tiver mais de uma, envie uma de cada vez.</p>

        <form onSubmit={enviar}>
          <div className="envio-dupla">
            <div className="campo">
              <label htmlFor="cliente">Cliente</label>
              <select
                id="cliente"
                value={cliente}
                onChange={(e) => setCliente(e.target.value)}
                required
              >
                <option value="">Selecione</option>
                {clientes.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div className="campo">
              <label htmlFor="mes">Mês do relatório</label>
              <select id="mes" value={mes} onChange={(e) => setMes(e.target.value)} required>
                {meses.map((m) => (
                  <option key={m.valor} value={m.valor}>{m.texto}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="campo">
            <label>Área do conteúdo</label>
            <div className="areas">
              {AREAS.map((a) => (
                <button
                  type="button"
                  key={a.id}
                  className={`area ${area === a.id ? 'ativa' : ''}`}
                  onClick={() => setArea(a.id)}
                  aria-pressed={area === a.id}
                >
                  {a.label}
                </button>
              ))}
            </div>
          </div>

          <div className="campo">
            <label>Arquivo</label>
            <div
              className={`solta ${arrastando ? 'sobre' : ''} ${arquivo ? 'cheia' : ''}`}
              onDragOver={(e) => { e.preventDefault(); setArrastando(true); }}
              onDragLeave={() => setArrastando(false)}
              onDrop={aoSoltar}
              onClick={() => inputArquivo.current?.click()}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  inputArquivo.current?.click();
                }
              }}
            >
              <input
                ref={inputArquivo}
                type="file"
                accept=".pdf,.csv,.xlsx"
                onChange={(e) => validarEGuardar(e.target.files?.[0])}
                hidden
              />
              {arquivo ? (
                <>
                  <strong className="solta-nome">{arquivo.name}</strong>
                  <span className="solta-dica">
                    {(arquivo.size / 1024).toFixed(0)} KB · toque para trocar
                  </span>
                </>
              ) : (
                <>
                  <strong>
                    <span className="so-desktop">Arraste o arquivo aqui</span>
                    <span className="so-celular">Toque para escolher o arquivo</span>
                  </strong>
                  <span className="solta-dica">
                    <span className="so-desktop">ou clique para escolher · </span>
                    PDF, CSV ou XLSX até {MAX_MB}MB
                  </span>
                </>
              )}
            </div>
          </div>

          {aviso && (
            <div className={`aviso ${aviso.tipo}`} role="status">{aviso.texto}</div>
          )}

          <button type="submit" className="enviar" disabled={!pronto}>
            {enviando ? 'Enviando...' : 'Enviar'}
          </button>
        </form>
      </div>
    </div>
  );
}
