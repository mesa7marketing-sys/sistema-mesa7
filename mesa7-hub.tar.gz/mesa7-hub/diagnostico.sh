#!/usr/bin/env bash
#
# Só OLHA o que existe no servidor. Não altera, não apaga, não para nada.
# Rode e me mande a saída.
#
#   bash diagnostico.sh

AZUL=$'\033[0;36m'; ZERO=$'\033[0m'
titulo() { echo; echo "${AZUL}== $1${ZERO}"; }

echo "Diagnostico do servidor - $(date '+%d/%m/%Y %H:%M')"
echo "Maquina: $(hostname)"

titulo "Aplicacoes rodando no PM2"
if command -v pm2 >/dev/null 2>&1; then
  pm2 list 2>/dev/null || echo "  (pm2 instalado mas sem processos)"
else
  echo "  pm2 nao instalado"
fi

titulo "Onde estao as aplicacoes"
for base in /opt /var/www /srv /root /home; do
  find "$base" -maxdepth 3 -name package.json -not -path '*/node_modules/*' 2>/dev/null |
    while read -r p; do
      d=$(dirname "$p")
      nome=$(grep -oP '"name"\s*:\s*"\K[^"]+' "$p" | head -1)
      echo "  $d  (nome: ${nome:-?})"
    done
done

titulo "Bancos PostgreSQL"
if command -v psql >/dev/null 2>&1; then
  sudo -u postgres psql -tAc "
    SELECT datname || '  |  ' || pg_size_pretty(pg_database_size(datname))
    FROM pg_database WHERE datistemplate = false" 2>/dev/null |
    sed 's/^/  /' || echo "  (nao consegui listar - precisa de sudo)"
else
  echo "  postgres nao instalado"
fi

titulo "Tabelas de cada banco da Mesa7"
if command -v psql >/dev/null 2>&1; then
  for db in $(sudo -u postgres psql -tAc "SELECT datname FROM pg_database WHERE datistemplate = false AND datname NOT IN ('postgres')" 2>/dev/null); do
    echo "  [$db]"
    sudo -u postgres psql -d "$db" -tAc "
      SELECT '    ' || tablename || ' (' ||
             (xpath('/row/c/text()', query_to_xml('SELECT count(*) AS c FROM ' || quote_ident(tablename), false, true, '')))[1]::text
             || ' linhas)'
      FROM pg_tables WHERE schemaname='public' ORDER BY tablename" 2>/dev/null || echo "    (sem acesso)"
  done
fi

titulo "Sites no Nginx"
if [ -d /etc/nginx/sites-enabled ]; then
  for c in /etc/nginx/sites-enabled/*; do
    [ -e "$c" ] || continue
    echo "  $(basename "$c"):"
    grep -E "server_name|proxy_pass|root |client_max_body_size|ssl_certificate " "$c" 2>/dev/null | sed 's/^\s*/    /'
  done
else
  echo "  sem sites-enabled"
fi

titulo "Certificados SSL"
if command -v certbot >/dev/null 2>&1; then
  certbot certificates 2>/dev/null | grep -E "Certificate Name|Domains|Expiry" | sed 's/^\s*/  /'
else
  echo "  certbot nao encontrado"
fi

titulo "Espaco em disco"
df -h / | tail -1 | awk '{print "  " $2 " total, " $4 " livre (" $5 " usado)"}'

titulo "Versoes"
echo "  node: $(node -v 2>/dev/null || echo 'nao instalado')"
echo "  npm:  $(npm -v 2>/dev/null || echo '-')"
echo "  psql: $(psql --version 2>/dev/null | awk '{print $3}' || echo 'nao instalado')"

echo
echo "Fim. Nada foi alterado."
echo
