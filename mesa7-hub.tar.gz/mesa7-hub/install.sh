#!/usr/bin/env bash
#
# Instalador do Sistema Mesa7.
# Roda tudo: dependencias, banco, build e servidor no ar.
#
#   bash install.sh
#
# Pode rodar de novo quando quiser, nao duplica nada.

set -euo pipefail

VERDE=$'\033[0;32m'; VERM=$'\033[0;31m'; AMAR=$'\033[0;33m'; AZUL=$'\033[0;36m'; ZERO=$'\033[0m'
ok()    { echo "${VERDE}  ok${ZERO} $1"; }
erro()  { echo "${VERM}  erro${ZERO} $1" >&2; }
aviso() { echo "${AMAR}  atencao${ZERO} $1"; }
passo() { echo; echo "${AZUL}> $1${ZERO}"; }

cd "$(dirname "$0")"

echo
echo "${AZUL}Sistema Mesa7 - instalacao${ZERO}"

# ---------------------------------------------------------------- 1. requisitos
passo "Conferindo o que ja esta instalado"

if ! command -v node >/dev/null 2>&1; then
  erro "Node.js nao encontrado."
  echo "     Instale com:  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs"
  exit 1
fi

NODE_MAJOR=$(node -v | sed 's/v\([0-9]*\).*/\1/')
if [ "$NODE_MAJOR" -lt 18 ]; then
  erro "Node.js $(node -v) e antigo demais. Precisa ser 18 ou maior."
  exit 1
fi
ok "Node.js $(node -v)"

if ! command -v psql >/dev/null 2>&1; then
  erro "PostgreSQL nao encontrado."
  echo "     Instale com:  sudo apt update && sudo apt install -y postgresql"
  exit 1
fi
ok "PostgreSQL encontrado"

# ---------------------------------------------------------------- 2. .env
passo "Configuracao"

ENV_CRIADO_AGORA=0

if [ -f .env ]; then
  ok ".env ja existe, mantendo o que esta la"
else
  ENV_CRIADO_AGORA=1
  echo "  Preciso dos dados do banco. Enter aceita o valor entre colchetes."
  echo

  read -rp "  Host do PostgreSQL [localhost]: " DB_HOST
  DB_HOST=${DB_HOST:-localhost}

  read -rp "  Porta [5432]: " DB_PORT
  DB_PORT=${DB_PORT:-5432}

  read -rp "  Usuario [postgres]: " DB_USER
  DB_USER=${DB_USER:-postgres}

  read -rsp "  Senha: " DB_PASSWORD
  echo

  read -rp "  Porta do servidor Mesa7 [3001]: " APP_PORT
  APP_PORT=${APP_PORT:-3001}

  read -rp "  Onde guardar os arquivos da equipe [/var/uploads/mesa7]: " UPLOAD_DIR
  UPLOAD_DIR=${UPLOAD_DIR:-/var/uploads/mesa7}

  cat > .env <<ENVEOF
DB_USER=${DB_USER}
DB_PASSWORD=${DB_PASSWORD}
DB_HOST=${DB_HOST}
DB_PORT=${DB_PORT}
DB_NAME=mesa7_hub
PORT=${APP_PORT}
UPLOAD_DIR=${UPLOAD_DIR}
ENVEOF
  chmod 600 .env
  ok ".env criado (so o seu usuario consegue ler, tem senha dentro)"
fi

# Le o .env pra usar daqui pra frente
set -a; . ./.env; set +a

# ---------------------------------------------------------------- 3. conexao
passo "Testando conexao com o banco"

if PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c '\q' >/dev/null 2>&1; then
  ok "Banco respondeu"
else
  erro "Nao consegui conectar em ${DB_HOST}:${DB_PORT} com o usuario ${DB_USER}."
  echo
  echo "     Pode ser a senha, ou o PostgreSQL nao estar no ar."
  echo "     Confira se esta rodando:  sudo systemctl status postgresql"
  if [ "$ENV_CRIADO_AGORA" = "1" ]; then
    rm -f .env
    echo
    echo "     Apaguei o .env com os dados que nao funcionaram."
    echo "     Rode 'bash install.sh' de novo que eu pergunto tudo outra vez."
  else
    echo "     Os dados estao no .env desta pasta. Corrija la, ou apague com"
    echo "     'rm .env' e rode o install de novo pra preencher do zero."
  fi
  exit 1
fi

# ---------------------------------------------------------------- 4. pasta de uploads
passo "Pasta dos arquivos"

if mkdir -p "$UPLOAD_DIR" 2>/dev/null && [ -w "$UPLOAD_DIR" ]; then
  ok "$UPLOAD_DIR pronta"
else
  aviso "Sem permissao para criar $UPLOAD_DIR. Rode isto e depois chame o install de novo:"
  echo "     sudo mkdir -p $UPLOAD_DIR && sudo chown \$USER $UPLOAD_DIR"
  exit 1
fi

# ---------------------------------------------------------------- 5. dependencias
passo "Instalando dependencias (pode demorar um pouco)"
npm install --no-audit --no-fund --silent
ok "Servidor"
npm --prefix client install --no-audit --no-fund --silent
ok "Painel"

# ---------------------------------------------------------------- 6. banco
passo "Preparando o banco"
npm run init-db

# ---------------------------------------------------------------- 7. build
passo "Montando o painel"
npm --prefix client run build --silent >/dev/null
ok "Painel pronto"

# ---------------------------------------------------------------- 8. no ar
passo "Colocando no ar"

if command -v pm2 >/dev/null 2>&1; then
  if pm2 describe mesa7-hub >/dev/null 2>&1; then
    pm2 restart mesa7-hub --update-env >/dev/null
    ok "Servidor reiniciado"
  else
    pm2 start server.js --name mesa7-hub >/dev/null
    pm2 save >/dev/null 2>&1 || true
    ok "Servidor iniciado e salvo no PM2"
  fi
  GERENCIADO_POR_PM2=1
else
  aviso "PM2 nao instalado. Instale com:  sudo npm install -g pm2"
  echo "     Por enquanto voce pode subir manualmente com:  npm start"
  GERENCIADO_POR_PM2=0
fi

# ---------------------------------------------------------------- 9. confere
if [ "$GERENCIADO_POR_PM2" = "1" ]; then
  passo "Conferindo se respondeu"
  sleep 3
  if curl -fsS "http://localhost:${PORT}/health" >/dev/null 2>&1; then
    ok "Respondendo em http://localhost:${PORT}"
  else
    erro "Subiu mas nao respondeu. Veja o que aconteceu com:  pm2 logs mesa7-hub --lines 30"
    exit 1
  fi
fi

# ---------------------------------------------------------------- pronto
echo
echo "${VERDE}Instalado.${ZERO}"
echo
echo "  Painel:  http://localhost:${PORT}"

if [ "$GERENCIADO_POR_PM2" = "1" ]; then
  echo "  Logs:    pm2 logs mesa7-hub"
  echo "  Parar:   pm2 stop mesa7-hub"
else
  echo
  echo "  Instale o PM2 pra deixar rodando sozinho (inclusive apos reiniciar o servidor):"
  echo "     sudo npm install -g pm2 && bash install.sh"
fi

cat <<FIMEOF

Falta so o Nginx, pra abrir no dominio. No bloco do painel.mesa7.tech:

    location / {
        proxy_pass http://localhost:${PORT};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        client_max_body_size 50M;
    }

Depois:  sudo nginx -t && sudo systemctl reload nginx

O client_max_body_size e o que permite upload de arquivo grande.
Sem ele, a equipe leva erro 413 nos relatorios maiores.

FIMEOF
