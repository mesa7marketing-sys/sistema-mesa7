#!/usr/bin/env bash
#
# Tira o sistema antigo do ar e instala o novo.
#
#   bash migrar.sh
#
# Não faz backup. O código antigo é movido para uma pasta com data (em vez de
# apagado) e o banco antigo fica onde está — as duas coisas custam zero e
# deixam caminho de volta caso algo dê errado.

set -euo pipefail

VERDE=$'\033[0;32m'; VERM=$'\033[0;31m'; AMAR=$'\033[0;33m'; AZUL=$'\033[0;36m'; ZERO=$'\033[0m'
ok()    { echo "${VERDE}  ok${ZERO} $1"; }
erro()  { echo "${VERM}  erro${ZERO} $1" >&2; }
aviso() { echo "${AMAR}  atencao${ZERO} $1"; }
passo() { echo; echo "${AZUL}> $1${ZERO}"; }

NOVO_DIR="$(cd "$(dirname "$0")" && pwd)"
DATA=$(date '+%Y-%m-%d_%H%M')
GUARDADO="/opt/mesa7-antigo-${DATA}"

echo
echo "${AZUL}Trocar o Sistema Mesa7${ZERO}"
echo "Sistema novo: ${NOVO_DIR}"

# ------------------------------------------------------- 1. o que existe hoje
passo "Procurando o que esta no ar"

# O PM2 sabe o caminho de cada app que ele roda. E muito mais confiavel do que
# vasculhar /opt, que num servidor costuma ter dezenas de pastas do sistema.
PROC_PM2=""
APP_ANTIGO=""

if command -v pm2 >/dev/null 2>&1; then
  LISTA=$(pm2 jlist 2>/dev/null | node -e '
    let e = "";
    process.stdin.on("data", (d) => (e += d));
    process.stdin.on("end", () => {
      let apps = [];
      try { apps = JSON.parse(e); } catch { process.exit(0); }
      for (const a of apps) {
        if (a.name === "mesa7-hub") continue;
        const dir = (a.pm2_env && a.pm2_env.pm_cwd) || "";
        console.log(a.name + "\t" + dir);
      }
    });
  ' 2>/dev/null)

  if [ -n "$LISTA" ]; then
    echo "  Aplicacoes rodando agora:"
    echo
    printf "%s\n" "$LISTA" | nl -w4 -s'. ' | while IFS=$'\t' read -r n d; do
      printf "   %-28s %s\n" "$n" "$d"
    done
    echo
    PROC_PM2=$(printf "%s\n" "$LISTA" | cut -f1 | tr '\n' ' ')
    APP_ANTIGO=$(printf "%s\n" "$LISTA" | head -1 | cut -f2)
  else
    ok "Nenhuma aplicacao rodando no PM2"
  fi
else
  aviso "PM2 nao instalado"
fi

# Nunca escolhe sozinho: o caminho e sempre confirmado por quem esta rodando.
if [ -n "$APP_ANTIGO" ]; then
  echo "  Vou guardar a pasta:  ${APP_ANTIGO}"
  read -rp "  Enter para aceitar, ou digite outro caminho: " OUTRO
  [ -n "$OUTRO" ] && APP_ANTIGO="$OUTRO"
else
  read -rp "  Caminho da aplicacao antiga (Enter para pular): " APP_ANTIGO
fi

if [ -n "$APP_ANTIGO" ]; then
  if [ ! -d "$APP_ANTIGO" ]; then
    erro "A pasta ${APP_ANTIGO} nao existe."
    exit 1
  fi
  case "$APP_ANTIGO" in
    /|/usr|/usr/*|/etc|/etc/*|/var|/var/lib|/var/lib/*|/bin|/bin/*|/sbin|/sbin/*|/boot|/boot/*|/home|/root)
      erro "Nao vou mexer em ${APP_ANTIGO}, e uma pasta do sistema."
      exit 1;;
  esac
  if [ "$APP_ANTIGO" = "$NOVO_DIR" ]; then
    erro "Esse e o caminho do sistema NOVO. Cancelando."
    exit 1
  fi
fi

# ------------------------------------------------------- 2. confirmacao
passo "O que vai acontecer"
cat <<RESUMO
  1. Parar e remover do PM2: ${PROC_PM2:-(nada rodando)}
  2. Mover ${APP_ANTIGO:-(nada)}
       para ${GUARDADO}
  3. Instalar o sistema novo

  O banco antigo continua no servidor, intacto.
  Nenhum arquivo e apagado.
RESUMO

echo
read -rp "  Digite CONFIRMO para seguir: " RESP
if [ "$RESP" != "CONFIRMO" ]; then
  echo "  Cancelado. Nada foi alterado."
  exit 0
fi

# ------------------------------------------------------- 3. parar o antigo
passo "Tirando do ar"
if [ -n "$PROC_PM2" ]; then
  for proc in $PROC_PM2; do
    pm2 delete "$proc" >/dev/null 2>&1 && ok "Parado: $proc"
  done
  pm2 save >/dev/null 2>&1 || true
else
  ok "Nada rodando para parar"
fi

# ------------------------------------------------------- 4. tirar da frente
passo "Guardando o codigo antigo"
if [ -n "$APP_ANTIGO" ] && [ -d "$APP_ANTIGO" ]; then
  mv "$APP_ANTIGO" "$GUARDADO"
  ok "Movido para $GUARDADO"
  cat > "${GUARDADO}/COMO-VOLTAR.txt" <<VOLTAR
Sistema antigo guardado em ${DATA}, vindo de ${APP_ANTIGO}

Para voltar atras:
  pm2 delete mesa7-hub
  mv ${GUARDADO} ${APP_ANTIGO}
  cd ${APP_ANTIGO} && npm install
  pm2 start <arquivo-principal> --name <nome-antigo>
  pm2 save

O banco antigo nunca foi apagado, entao continua la como estava.
VOLTAR
else
  ok "Nada para mover"
fi

# ------------------------------------------------------- 5. instalar o novo
passo "Instalando o sistema novo"
echo
cd "$NOVO_DIR"
bash install.sh

# ------------------------------------------------------- pronto
echo
echo "${VERDE}Pronto.${ZERO} O sistema novo esta no ar."
echo
if [ -d "$GUARDADO" ]; then
  echo "  Sistema antigo guardado em: ${GUARDADO}"
  echo "  Confira o painel no navegador. Se estiver tudo certo, pode apagar com:"
  echo "      sudo rm -rf ${GUARDADO}"
  echo
fi
