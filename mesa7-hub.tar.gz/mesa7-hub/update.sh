#!/usr/bin/env bash
#
# Atualiza o Sistema Mesa7 com a versao mais nova.
#
#   bash update.sh
#
# Baixa o codigo novo, reinstala o que mudou, remonta o painel e reinicia.
# Nao mexe no .env nem nos arquivos que a equipe ja subiu.

set -euo pipefail

VERDE=$'\033[0;32m'; VERM=$'\033[0;31m'; AZUL=$'\033[0;36m'; ZERO=$'\033[0m'
ok()    { echo "${VERDE}  ok${ZERO} $1"; }
erro()  { echo "${VERM}  erro${ZERO} $1" >&2; }
passo() { echo; echo "${AZUL}> $1${ZERO}"; }

cd "$(dirname "$0")"

echo
echo "${AZUL}Sistema Mesa7 - atualizacao${ZERO}"

if [ ! -f .env ]; then
  erro "Nao achei o .env. Parece que ainda nao foi instalado aqui."
  echo "     Rode primeiro:  bash install.sh"
  exit 1
fi

set -a; . ./.env; set +a

passo "Buscando o codigo novo"
if [ -d .git ]; then
  git pull --ff-only
  ok "Codigo atualizado"
else
  erro "Esta pasta nao veio do Git, entao nao tenho de onde baixar."
  echo "     Substitua os arquivos manualmente e rode este script de novo,"
  echo "     ou instale a partir de um git clone pra poder usar o git pull."
  exit 1
fi

passo "Atualizando dependencias"
npm install --no-audit --no-fund --silent
npm --prefix client install --no-audit --no-fund --silent
ok "Dependencias em dia"

passo "Aplicando mudancas no banco"
npm run init-db >/dev/null
ok "Banco em dia"

passo "Remontando o painel"
npm --prefix client run build --silent >/dev/null
ok "Painel remontado"

passo "Reiniciando"
if command -v pm2 >/dev/null 2>&1 && pm2 describe mesa7-hub >/dev/null 2>&1; then
  pm2 restart mesa7-hub --update-env >/dev/null
  sleep 3
  if curl -fsS "http://localhost:${PORT}/health" >/dev/null 2>&1; then
    ok "No ar de novo em http://localhost:${PORT}"
  else
    erro "Reiniciou mas nao respondeu. Veja:  pm2 logs mesa7-hub --lines 30"
    exit 1
  fi
else
  erro "Nao achei o processo no PM2. Suba com:  pm2 start server.js --name mesa7-hub"
  exit 1
fi

echo
echo "${VERDE}Atualizado.${ZERO}"
echo
