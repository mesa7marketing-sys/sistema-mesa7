# Sistema Mesa7 — Hub de Dados

Painel onde a equipe da Mesa7 sobe os relatórios semanais de cada cliente
(CSV e PDF do Google Ads, Meta Ads, Cardápio, iFood e Repediu). Os arquivos
ficam guardados no servidor e o histórico fica registrado no banco, com uma
API para consultar tudo depois.

Stack: Node 18+ · Express · PostgreSQL · React (Vite).

---

## O que já funciona

- Upload de arquivos pela interface, várias fontes de uma vez
- Validação de formato, cliente, usuário e semana antes de aceitar
- Arquivos organizados no disco em `uploads/<cliente>/<semana>/`
- Histórico de uploads por cliente, com quem enviou e quando
- Log de auditoria de cada envio
- API REST para consultar clientes, uploads e dados

## O que ainda NÃO funciona

**Os CSVs são guardados, mas ainda não são lidos.** O conteúdo dos arquivos
não vira número no banco ainda — as tabelas `google_ads_data`, `meta_ads_data`
e companhia estão criadas e vazias, esperando os parsers (Fase 2). Ou seja:
hoje o sistema é um repositório organizado de arquivos com histórico, não um
dashboard de métricas. O endpoint `/data` já existe e responde, mas retorna
listas vazias até os parsers entrarem.

Também não tem login ainda: quem abre o painel escolhe de quem é o envio.
Enquanto estiver atrás de uma URL que só a equipe conhece, funciona; antes de
abrir pra mais gente, vale colocar autenticação.

---

## Instalação

### 1. Pré-requisitos

```bash
node --version    # precisa ser 18 ou maior
psql --version    # PostgreSQL 12 ou maior
```

### 2. Instalar

```bash
git clone <url-do-seu-repo> mesa7-hub
cd mesa7-hub
npm install
```

### 3. Configurar

```bash
cp .env.example .env
nano .env         # preencher DB_PASSWORD e conferir host/porta
```

### 4. Criar o banco

```bash
npm run init-db
```

Cria o banco, aplica o schema e cadastra a equipe e os clientes. Pode rodar
de novo quando quiser, não duplica nada. No fim ele imprime os IDs dos
usuários — anote, são usados no campo `user_id`.

### 5. Build do painel

```bash
npm run build
```

### 6. Subir

```bash
npm start
```

Abre em `http://localhost:3001`. Se o build do passo 5 foi feito, o próprio
Express serve o painel; senão só a API responde.

---

## Desenvolvimento

Dois terminais:

```bash
npm run dev          # API com reload, porta 3001
npm run client:dev   # painel com hot reload, porta 5173
```

O Vite já faz proxy de `/api` para a porta 3001, então não tem CORS no meio.

---

## Deploy no VPS

```bash
cd /opt
git clone <url-do-seu-repo> mesa7-hub
cd mesa7-hub
npm install
cp .env.example .env && nano .env
npm run init-db
npm run build
pm2 start server.js --name mesa7-hub
pm2 save
```

No `.env` de produção, aponte o `UPLOAD_DIR` para fora do projeto, senão um
`git pull` convive mal com os arquivos da equipe:

```env
UPLOAD_DIR=/var/uploads/mesa7
```

```bash
sudo mkdir -p /var/uploads/mesa7
sudo chown $USER /var/uploads/mesa7
```

Nginx (o bloco do domínio que já existe):

```nginx
location / {
    proxy_pass http://localhost:3001;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    client_max_body_size 50M;   # sem isso, upload grande morre com 413
}
```

```bash
sudo nginx -t && sudo systemctl reload nginx
```

---

## API

| Método | Rota | O que faz |
|--------|------|-----------|
| GET  | `/health` | Checa se o servidor e o banco respondem |
| GET  | `/api/v1/clients` | Lista os clientes ativos |
| POST | `/api/v1/upload` | Recebe um arquivo |
| GET  | `/api/v1/clients/:id/uploads` | Histórico de uploads do cliente |
| GET  | `/api/v1/clients/:id/data` | Dados consolidados (vazio até a Fase 2) |

### Upload

Campos: `file`, `client_id`, `source`, `week_of` (YYYY-MM-DD), `user_id`, `notes` (opcional).
Fontes aceitas: `google_ads`, `meta_ads`, `cardapio`, `ifood`, `repediu`.
Formatos: csv, pdf, xlsx. Máximo 50MB.

```bash
curl -X POST http://localhost:3001/api/v1/upload \
  -F "file=@examples/google-ads.csv" \
  -F "client_id=1" -F "source=google_ads" \
  -F "week_of=2026-09-14" -F "user_id=3"
```

### Consulta

```bash
curl "http://localhost:3001/api/v1/clients/1/data?start_date=2026-09-01&end_date=2026-09-30&sources=google_ads,meta_ads"
```

---

## Estrutura

```
mesa7-hub/
├── server.js              API Express
├── db/schema.sql          Tabelas do banco
├── scripts/init-db.js     Cria banco, schema, equipe e clientes
├── examples/              CSV de exemplo
└── client/                Painel React (Vite)
    └── src/
        ├── App.jsx
        └── components/UploadForm.jsx
```

---

## Problemas comuns

**`ECONNREFUSED`** — PostgreSQL não está rodando ou a porta no `.env` está errada.
Confira com `pg_isready -h <host> -p <porta>`.

**`28P01` / senha falhou** — `DB_USER`/`DB_PASSWORD` do `.env` não batem com o banco.

**`413 Request Entity Too Large`** — falta o `client_max_body_size 50M` no Nginx.

**Painel abre em branco** — o build não foi feito. Rode `npm run build`.

**Upload dá "Cliente não encontrado"** — o `client_id` não existe. Veja os IDs
com `curl localhost:3001/api/v1/clients`.
