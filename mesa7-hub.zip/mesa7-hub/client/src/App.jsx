import React, { useState, useEffect } from 'react';
import UploadForm from './components/UploadForm';
import './App.css';

/**
 * Exemplo de como integrar o UploadForm no seu app
 */

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [activeTab, setActiveTab] = useState('upload');

  // Simular usuario logado (depois vai vir de autenticação real)
  useEffect(() => {
    setCurrentUser({
      id: 2,
      name: 'Manoel',
      email: 'manoel@mesa7.com',
      role: 'trafego'
    });
  }, []);

  return (
    <div className="app">
      {/* Header */}
      <header className="app-header">
        <div className="header-content">
          <h1>Mesa<span>7</span> · Painel de Dados</h1>
          {currentUser && (
            <div className="user-info">
              <span>{currentUser.name}</span>
              <span className="role-badge">{currentUser.role}</span>
            </div>
          )}
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="app-nav">
        <button
          className={`nav-tab ${activeTab === 'upload' ? 'active' : ''}`}
          onClick={() => setActiveTab('upload')}
        >
          Upload Semanal
        </button>
        <button
          className={`nav-tab ${activeTab === 'historico' ? 'active' : ''}`}
          onClick={() => setActiveTab('historico')}
        >
          Histórico
        </button>
        <button
          className={`nav-tab ${activeTab === 'relatorios' ? 'active' : ''}`}
          onClick={() => setActiveTab('relatorios')}
        >
          Relatórios
        </button>
      </nav>

      {/* Main Content */}
      <main className="app-content">
        {/* Tab: Upload */}
        {activeTab === 'upload' && currentUser && (
          <section className="tab-content">
            <UploadForm userId={currentUser.id} />
          </section>
        )}

        {/* Tab: Histórico */}
        {activeTab === 'historico' && (
          <section className="tab-content">
            <HistoricoUploads />
          </section>
        )}

        {/* Tab: Relatórios */}
        {activeTab === 'relatorios' && (
          <section className="tab-content">
            <Relatorios />
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="app-footer">
        <p>Sistema Mesa7 · v1.0</p>
      </footer>
    </div>
  );
}

/**
 * Componente: Historico de uploads
 */
function HistoricoUploads() {
  const [clients, setClients] = useState([]);
  const [selectedClient, setSelectedClient] = useState('');
  const [uploads, setUploads] = useState([]);
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState(null);

  useEffect(() => {
    fetch('/api/v1/clients')
      .then((r) => r.json())
      .then((data) => {
        setClients(data);
        if (data.length > 0) setSelectedClient(String(data[0].id));
      })
      .catch((e) => setErro('Nao consegui carregar os clientes: ' + e.message));
  }, []);

  useEffect(() => {
    if (!selectedClient) return;
    carregarHistorico(selectedClient);
  }, [selectedClient]);

  async function carregarHistorico(clientId) {
    setLoading(true);
    setErro(null);
    try {
      const res = await fetch(`/api/v1/clients/${clientId}/uploads`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setUploads(data.uploads);
    } catch (e) {
      setErro('Erro ao carregar historico: ' + e.message);
      setUploads([]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="historico-container">
      <h2>Histórico de Uploads</h2>

      <div className="filter-group">
        <select value={selectedClient} onChange={(e) => setSelectedClient(e.target.value)}>
          {clients.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <button onClick={() => carregarHistorico(selectedClient)} disabled={loading || !selectedClient}>
          {loading ? 'Carregando...' : 'Atualizar'}
        </button>
      </div>

      {erro && <div className="status-message error">{erro}</div>}

      {uploads.length > 0 ? (
        <table className="uploads-table">
          <thead>
            <tr>
              <th>Semana</th>
              <th>Enviado em</th>
              <th>Usuario</th>
              <th>Fonte</th>
              <th>Arquivo</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {uploads.map((u) => (
              <tr key={u.id}>
                <td>{u.week_of}</td>
                <td>{new Date(u.created_at).toLocaleDateString('pt-BR')}</td>
                <td>{u.user_name}</td>
                <td>{u.source}</td>
                <td>{u.file_name}</td>
                <td><span className={`status-badge ${u.status}`}>{u.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        !loading && <p className="empty-state">Nenhum upload registrado para este cliente ainda.</p>
      )}
    </div>
  );
}

/**
 * Componente: Relatórios
 */
function Relatorios() {
  return (
    <div className="relatorios-container">
      <h2>Relatórios</h2>

      <div className="relatorio-cards">
        <div className="relatorio-card">
          <h3>Performance Semanal</h3>
          <p className="coming-soon">Em construção — Fase 2</p>
        </div>

        <div className="relatorio-card">
          <h3>Metas vs Realizado</h3>
          <p className="coming-soon">Em construção — Fase 2</p>
        </div>

        <div className="relatorio-card">
          <h3>Tendências</h3>
          <p className="coming-soon">Em construção — Fase 2</p>
        </div>
      </div>
    </div>
  );
}
