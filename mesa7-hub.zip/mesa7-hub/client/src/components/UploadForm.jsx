import React, { useState, useEffect } from 'react';
import './UploadForm.css';

const SOURCES = [
  { id: 'google_ads', label: 'Google Ads' },
  { id: 'meta_ads', label: 'Meta Ads' },
  { id: 'cardapio', label: 'Cardápio Digital' },
  { id: 'ifood', label: 'iFood' },
  { id: 'repediu', label: 'Repediu' },
];

export default function UploadForm({ userId }) {
  const [clients, setClients] = useState([]);
  const [selectedClient, setSelectedClient] = useState('');
  const [selectedSources, setSelectedSources] = useState(new Set());
  const [files, setFiles] = useState({});
  const [weekOf, setWeekOf] = useState(getMonday(new Date()).toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null);
  const [progress, setProgress] = useState({});

  // Get Monday of current week
  function getMonday(date) {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(d.setDate(diff));
  }

  // Fetch clients on mount
  useEffect(() => {
    fetchClients();
  }, []);

  async function fetchClients() {
    try {
      const res = await fetch('/api/v1/clients');
      const data = await res.json();
      setClients(data);
    } catch (error) {
      setStatus({ type: 'error', message: 'Erro ao carregar clientes: ' + error.message });
    }
  }

  function handleSourceToggle(sourceId) {
    const newSources = new Set(selectedSources);
    if (newSources.has(sourceId)) {
      newSources.delete(sourceId);
    } else {
      newSources.add(sourceId);
    }
    setSelectedSources(newSources);
  }

  function handleFileChange(sourceId, e) {
    const file = e.target.files?.[0];
    if (file) {
      setFiles(prev => ({
        ...prev,
        [sourceId]: file
      }));
      setProgress(prev => ({
        ...prev,
        [sourceId]: 0
      }));
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();

    if (!selectedClient) {
      setStatus({ type: 'error', message: 'Selecione um cliente' });
      return;
    }

    if (selectedSources.size === 0) {
      setStatus({ type: 'error', message: 'Selecione pelo menos uma fonte' });
      return;
    }

    setLoading(true);
    setStatus(null);

    try {
      const uploadPromises = Array.from(selectedSources).map(sourceId => {
        const file = files[sourceId];
        if (!file) return Promise.resolve(null);

        const formData = new FormData();
        formData.append('file', file);
        formData.append('client_id', selectedClient);
        formData.append('source', sourceId);
        formData.append('week_of', weekOf);
        formData.append('user_id', userId);
        formData.append('notes', notes);

        return fetch('/api/v1/upload', {
          method: 'POST',
          body: formData,
        })
          .then(res => {
            if (!res.ok) throw new Error(`Erro ao fazer upload de ${sourceId}`);
            return res.json();
          })
          .then(data => {
            setProgress(prev => ({
              ...prev,
              [sourceId]: 100
            }));
            return data;
          });
      });

      const results = await Promise.all(uploadPromises);
      const successful = results.filter(r => r !== null).length;

      setStatus({
        type: 'success',
        message: `${successful} arquivo(s) enviado(s) com sucesso.`
      });

      // Reset form
      setTimeout(() => {
        setSelectedSources(new Set());
        setFiles({});
        setNotes('');
        setProgress({});
      }, 2000);

    } catch (error) {
      setStatus({
        type: 'error',
        message: `Erro no upload: ${error.message}`
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="upload-form-container">
      <div className="upload-card">
        <h1>Upload Semanal de Dados</h1>
        <p className="subtitle">Envie os relatórios da semana de seus clientes</p>

        <form onSubmit={handleSubmit}>
          {/* Client Selection */}
          <div className="form-group">
            <label>Cliente</label>
            <select
              value={selectedClient}
              onChange={(e) => setSelectedClient(e.target.value)}
              required
            >
              <option value="">-- Selecione um cliente --</option>
              {clients.map(client => (
                <option key={client.id} value={client.id}>
                  {client.name}
                </option>
              ))}
            </select>
          </div>

          {/* Sources Selection */}
          <div className="form-group">
            <label>Fontes de Dados</label>
            <div className="sources-grid">
              {SOURCES.map(source => (
                <label key={source.id} className="source-checkbox">
                  <input
                    type="checkbox"
                    checked={selectedSources.has(source.id)}
                    onChange={() => handleSourceToggle(source.id)}
                  />
                  <span className="source-label">{source.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Files Upload */}
          <div className="form-group">
            <label>Arquivos</label>
            <div className="files-container">
              {selectedSources.size === 0 && (
                <p className="files-vazio">Selecione uma fonte de dados acima para anexar o arquivo.</p>
              )}
              {SOURCES.map(source =>
                selectedSources.has(source.id) ? (
                  <div key={source.id} className="file-input-group">
                    <label htmlFor={`file-${source.id}`} className="file-label">
                      {source.label}
                      <input
                        id={`file-${source.id}`}
                        type="file"
                        accept=".csv,.pdf,.xlsx"
                        onChange={(e) => handleFileChange(source.id, e)}
                        required
                      />
                      <span className={`file-name ${files[source.id] ? 'preenchido' : ''}`}>
                        {files[source.id]?.name || 'Selecionar arquivo (CSV ou PDF)'}
                      </span>
                    </label>
                    {progress[source.id] !== undefined && progress[source.id] > 0 && (
                      <div className="progress-bar">
                        <div
                          className="progress-fill"
                          style={{ width: `${progress[source.id]}%` }}
                        />
                      </div>
                    )}
                  </div>
                ) : null
              )}
            </div>
          </div>

          {/* Week Selection */}
          <div className="form-group">
            <label>Semana de</label>
            <input
              type="date"
              value={weekOf}
              onChange={(e) => setWeekOf(e.target.value)}
              required
            />
          </div>

          {/* Notes */}
          <div className="form-group">
            <label>Observações (opcional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Adicione qualquer observação sobre o upload..."
              rows="3"
            />
          </div>

          {/* Status Message */}
          {status && (
            <div className={`status-message ${status.type}`}>
              {status.message}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading || selectedSources.size === 0}
            className="submit-btn"
          >
            {loading ? 'Enviando...' : 'Enviar Upload'}
          </button>
        </form>
      </div>
    </div>
  );
}
