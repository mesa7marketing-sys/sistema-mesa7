-- MESA7 HUB DE DADOS - Schema PostgreSQL

-- Tabela de Usuários (equipe)
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL DEFAULT 'user', -- admin, cs, trafego, social, cardapio, design
  password_hash VARCHAR(255),
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de Clientes
CREATE TABLE IF NOT EXISTS clients (
  id SERIAL PRIMARY KEY,
  slug VARCHAR(100) UNIQUE NOT NULL, -- la-pizza-caio, bionatural, pacocas, etc
  name VARCHAR(255) NOT NULL,
  description TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de Uploads (histórico)
CREATE TABLE IF NOT EXISTS uploads (
  id SERIAL PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  source VARCHAR(50) NOT NULL, -- google_ads, meta_ads, cardapio, ifood, repediu
  file_name VARCHAR(255) NOT NULL,
  file_path VARCHAR(500) NOT NULL,
  file_size INTEGER,
  status VARCHAR(20) DEFAULT 'pending', -- pending, validating, success, error
  validation_errors JSON,
  week_of DATE NOT NULL, -- primeira segunda da semana
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de Dados Google Ads (normalizado)
CREATE TABLE IF NOT EXISTS google_ads_data (
  id SERIAL PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id),
  upload_id INTEGER REFERENCES uploads(id),
  date DATE NOT NULL,
  week_of DATE NOT NULL,
  impressions INTEGER,
  clicks INTEGER,
  cost DECIMAL(10,2),
  conversions INTEGER,
  conversion_value DECIMAL(10,2),
  avg_cpc DECIMAL(10,2),
  ctr DECIMAL(5,2),
  roas DECIMAL(5,2),
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(client_id, date, week_of)
);

-- Tabela de Dados Meta Ads (normalizado)
CREATE TABLE IF NOT EXISTS meta_ads_data (
  id SERIAL PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id),
  upload_id INTEGER REFERENCES uploads(id),
  date DATE NOT NULL,
  week_of DATE NOT NULL,
  impressions INTEGER,
  clicks INTEGER,
  spend DECIMAL(10,2),
  conversions INTEGER,
  purchase_value DECIMAL(10,2),
  cpc DECIMAL(10,2),
  ctr DECIMAL(5,2),
  roas DECIMAL(5,2),
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(client_id, date, week_of)
);

-- Tabela de Dados Cardápio Digital (normalizado)
CREATE TABLE IF NOT EXISTS cardapio_data (
  id SERIAL PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id),
  upload_id INTEGER REFERENCES uploads(id),
  date DATE NOT NULL,
  week_of DATE NOT NULL,
  total_orders INTEGER,
  total_revenue DECIMAL(10,2),
  avg_ticket DECIMAL(10,2),
  items_per_order DECIMAL(5,2),
  page_views INTEGER,
  add_to_cart INTEGER,
  conversion_rate DECIMAL(5,2),
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(client_id, date, week_of)
);

-- Tabela de Dados iFood (normalizado)
CREATE TABLE IF NOT EXISTS ifood_data (
  id SERIAL PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id),
  upload_id INTEGER REFERENCES uploads(id),
  date DATE NOT NULL,
  week_of DATE NOT NULL,
  orders INTEGER,
  revenue DECIMAL(10,2),
  avg_ticket DECIMAL(10,2),
  acceptance_rate DECIMAL(5,2),
  avg_delivery_time INTEGER, -- minutos
  rating DECIMAL(3,1),
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(client_id, date, week_of)
);

-- Tabela de Dados Repediu (normalizado)
CREATE TABLE IF NOT EXISTS repediu_data (
  id SERIAL PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id),
  upload_id INTEGER REFERENCES uploads(id),
  date DATE NOT NULL,
  week_of DATE NOT NULL,
  orders INTEGER,
  revenue DECIMAL(10,2),
  avg_ticket DECIMAL(10,2),
  repeat_customers DECIMAL(5,2),
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(client_id, date, week_of)
);

-- Tabela de Auditoria (log de ações)
CREATE TABLE IF NOT EXISTS audit_log (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  action VARCHAR(100) NOT NULL, -- upload, validate, view, edit, delete
  entity_type VARCHAR(50), -- upload, client, user
  entity_id INTEGER,
  details JSON,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_uploads_client ON uploads(client_id);
CREATE INDEX IF NOT EXISTS idx_uploads_week ON uploads(week_of);
CREATE INDEX IF NOT EXISTS idx_uploads_status ON uploads(status);
CREATE INDEX IF NOT EXISTS idx_google_ads_client_week ON google_ads_data(client_id, week_of);
CREATE INDEX IF NOT EXISTS idx_meta_ads_client_week ON meta_ads_data(client_id, week_of);
CREATE INDEX IF NOT EXISTS idx_cardapio_client_week ON cardapio_data(client_id, week_of);
CREATE INDEX IF NOT EXISTS idx_ifood_client_week ON ifood_data(client_id, week_of);
CREATE INDEX IF NOT EXISTS idx_repediu_client_week ON repediu_data(client_id, week_of);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);
