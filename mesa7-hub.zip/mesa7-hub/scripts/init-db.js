/**
 * Cria o banco (se preciso), aplica o schema e insere equipe + clientes.
 * Pode rodar mais de uma vez sem quebrar nada.
 *   node scripts/init-db.js
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import pg from 'pg';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_NAME = process.env.DB_NAME || 'mesa7_hub';

const baseConfig = {
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD,
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 5432,
};

const EQUIPE = [
  ['lucas@mesa7.com', 'Lucas', 'admin'],
  ['samuel@mesa7.com', 'Samuel', 'cs'],
  ['manoel@mesa7.com', 'Manoel', 'trafego'],
  ['julia@mesa7.com', 'Julia Braz', 'social'],
  ['nicole@mesa7.com', 'Nicole', 'design'],
  ['emerson@mesa7.com', 'Emerson', 'cardapio'],
];

const CLIENTES = [
  ['bionatural', 'Bionatural'],
  ['la-pizza-caio', "La Pizza D'Caio"],
  ['pacocas-1', 'Paçocas - Unidade 1'],
  ['pacocas-2', 'Paçocas - Unidade 2'],
  ['garage-84', 'Garage 84'],
  ['gold-hamburgueria', 'Gold Hamburgueria'],
  ['grand-vinea', 'Grand Vinea'],
  ['garagem-espetinhos', 'Garagem Espetinhos'],
  ['bar-abilio', 'Bar Abílio'],
  ['arco-iris-cafe', 'Arco Íris Café'],
];

async function criarBanco() {
  // Conecta no 'postgres' porque nao da pra criar um banco estando dentro dele
  const admin = new pg.Client({ ...baseConfig, database: 'postgres' });
  await admin.connect();
  try {
    const { rows } = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [DB_NAME]);
    if (rows.length > 0) {
      console.log(`- Banco "${DB_NAME}" ja existe`);
    } else {
      await admin.query(`CREATE DATABASE ${DB_NAME}`);
      console.log(`- Banco "${DB_NAME}" criado`);
    }
  } finally {
    await admin.end();
  }
}

async function aplicarSchemaESeed() {
  const db = new pg.Client({ ...baseConfig, database: DB_NAME });
  await db.connect();
  try {
    const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    await db.query(schema);
    console.log('- Schema aplicado');

    for (const [email, name, role] of EQUIPE) {
      await db.query(
        `INSERT INTO users (email, name, role) VALUES ($1, $2, $3)
         ON CONFLICT (email) DO NOTHING`,
        [email, name, role]
      );
    }
    console.log(`- Equipe: ${EQUIPE.length} usuarios`);

    for (const [slug, name] of CLIENTES) {
      await db.query(
        `INSERT INTO clients (slug, name) VALUES ($1, $2)
         ON CONFLICT (slug) DO NOTHING`,
        [slug, name]
      );
    }
    console.log(`- Clientes: ${CLIENTES.length} cadastrados`);

    const { rows } = await db.query('SELECT id, name FROM users ORDER BY id');
    console.log('\nIDs de usuario (use no campo user_id do upload):');
    for (const u of rows) console.log(`  ${u.id} = ${u.name}`);
  } finally {
    await db.end();
  }
}

try {
  console.log(`Inicializando ${DB_NAME} em ${baseConfig.host}:${baseConfig.port}\n`);
  await criarBanco();
  await aplicarSchemaESeed();
  console.log('\nPronto. Suba o servidor com: npm run dev');
} catch (err) {
  console.error('\nFalhou:', err.message);
  if (err.code === 'ECONNREFUSED') {
    console.error('O PostgreSQL nao esta aceitando conexao. Confira DB_HOST/DB_PORT no .env.');
  }
  if (err.code === '28P01') {
    console.error('Senha incorreta. Confira DB_USER/DB_PASSWORD no .env.');
  }
  process.exit(1);
}
