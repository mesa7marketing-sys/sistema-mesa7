import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fileUpload from 'express-fileupload';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3001;
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');
const TMP_DIR = path.join(UPLOAD_DIR, '.tmp');

// Fontes aceitas -> tabela normalizada correspondente
const SOURCES = {
  google_ads: 'google_ads_data',
  meta_ads: 'meta_ads_data',
  cardapio: 'cardapio_data',
  ifood: 'ifood_data',
  repediu: 'repediu_data',
};
const ALLOWED_EXT = ['csv', 'pdf', 'xlsx'];
const MAX_FILE_MB = 50;

// Garante que as pastas de upload existem antes do primeiro POST
for (const dir of [UPLOAD_DIR, TMP_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}

// DATE (oid 1082) volta como Date JS e o fuso empurra o dia pra tras.
// Como week_of/date sao datas puras, devolve a string como esta no banco.
pg.types.setTypeParser(1082, (value) => value);

const pool = new pg.Pool({
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD,
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME || 'mesa7_hub',
});

app.use(cors());
app.use(express.json());
app.use(fileUpload({
  limits: { fileSize: MAX_FILE_MB * 1024 * 1024 },
  abortOnLimit: true,
  responseOnLimit: `Arquivo maior que ${MAX_FILE_MB}MB`,
  useTempFiles: true,
  tempFileDir: TMP_DIR,
}));

// Wrapper para nao precisar de try/catch em toda rota
const route = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

// --- Clientes -------------------------------------------------------------

app.get('/api/v1/clients', route(async (_req, res) => {
  const { rows } = await pool.query(
    'SELECT id, slug, name, description FROM clients WHERE active = true ORDER BY name'
  );
  res.json(rows);
}));

// --- Upload ---------------------------------------------------------------

app.post('/api/v1/upload', route(async (req, res) => {
  const { client_id, source, week_of, user_id, notes } = req.body;

  if (!req.files?.file) {
    return res.status(400).json({ error: 'Nenhum arquivo enviado' });
  }
  if (!SOURCES[source]) {
    return res.status(400).json({
      error: `Fonte invalida. Use uma de: ${Object.keys(SOURCES).join(', ')}`,
    });
  }
  if (!week_of || Number.isNaN(Date.parse(week_of))) {
    return res.status(400).json({ error: 'week_of invalido (use YYYY-MM-DD)' });
  }

  const file = req.files.file;
  const ext = path.extname(file.name).slice(1).toLowerCase();
  if (!ALLOWED_EXT.includes(ext)) {
    return res.status(400).json({
      error: `Formato .${ext} nao suportado. Use: ${ALLOWED_EXT.join(', ')}`,
    });
  }

  // Cliente e usuario precisam existir (senao a FK estoura com erro feio)
  const { rows: clientRows } = await pool.query('SELECT id FROM clients WHERE id = $1', [client_id]);
  if (clientRows.length === 0) {
    return res.status(404).json({ error: `Cliente ${client_id} nao encontrado` });
  }
  const { rows: userRows } = await pool.query('SELECT id FROM users WHERE id = $1', [user_id]);
  if (userRows.length === 0) {
    return res.status(404).json({ error: `Usuario ${user_id} nao encontrado` });
  }

  // Um diretorio por cliente/semana mantem o disco navegavel
  const destDir = path.join(UPLOAD_DIR, String(client_id), week_of);
  fs.mkdirSync(destDir, { recursive: true });

  const safeName = `${source}_${Date.now()}.${ext}`;
  const destPath = path.join(destDir, safeName);
  await file.mv(destPath);

  const { rows } = await pool.query(
    `INSERT INTO uploads
       (client_id, user_id, source, file_name, file_path, file_size, status, week_of, notes)
     VALUES ($1, $2, $3, $4, $5, $6, 'pending', $7, $8)
     RETURNING id, created_at`,
    [client_id, user_id, source, file.name, destPath, file.size, week_of, notes || null]
  );

  await pool.query(
    `INSERT INTO audit_log (user_id, action, entity_type, entity_id, details)
     VALUES ($1, 'upload', 'upload', $2, $3)`,
    [user_id, rows[0].id, JSON.stringify({ source, client_id, week_of, file: file.name })]
  );

  res.status(201).json({
    success: true,
    upload_id: rows[0].id,
    file_name: file.name,
    message: 'Arquivo recebido. Processamento dos dados vem na Fase 2.',
  });
}));

// --- Historico ------------------------------------------------------------

app.get('/api/v1/clients/:client_id/uploads', route(async (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const offset = Number(req.query.offset) || 0;

  const { rows } = await pool.query(
    `SELECT u.id, u.source, u.file_name, u.file_size, u.status, u.week_of,
            u.notes, u.created_at, c.name AS client_name, us.name AS user_name
       FROM uploads u
       JOIN clients c ON c.id = u.client_id
       JOIN users us ON us.id = u.user_id
      WHERE u.client_id = $1
      ORDER BY u.created_at DESC
      LIMIT $2 OFFSET $3`,
    [req.params.client_id, limit, offset]
  );

  res.json({ uploads: rows, count: rows.length, limit, offset });
}));

// --- Dados consolidados (e o que o Claude vai consumir) -------------------

app.get('/api/v1/clients/:client_id/data', route(async (req, res) => {
  const { client_id } = req.params;
  const start = req.query.start_date || '1900-01-01';
  const end = req.query.end_date || '2999-12-31';

  const wanted = req.query.sources
    ? String(req.query.sources).split(',').map((s) => s.trim()).filter((s) => SOURCES[s])
    : Object.keys(SOURCES);

  const data = {};
  for (const source of wanted) {
    const { rows } = await pool.query(
      `SELECT * FROM ${SOURCES[source]}
        WHERE client_id = $1 AND week_of BETWEEN $2 AND $3
        ORDER BY date`,
      [client_id, start, end]
    );
    data[source] = rows;
  }

  res.json({ client_id: Number(client_id), period: { start, end }, data });
}));

// --- Infra ----------------------------------------------------------------

app.get('/health', route(async (_req, res) => {
  await pool.query('SELECT 1');
  res.json({ status: 'ok', db: 'ok', timestamp: new Date().toISOString() });
}));

// Frontend buildado (npm run build). Sem build, so a API responde.
const clientDist = path.join(__dirname, 'client', 'dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api') || req.path === '/health') return next();
    res.sendFile(path.join(clientDist, 'index.html'));
  });
}

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'Erro interno do servidor' });
});

app.listen(PORT, () => {
  console.log(`Sistema Mesa7 rodando na porta ${PORT}`);
  console.log(`API:     http://localhost:${PORT}/api/v1`);
  console.log(`Uploads: ${UPLOAD_DIR}`);
});

export default app;
