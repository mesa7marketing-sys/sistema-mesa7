CREATE TABLE "client_health" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"client_id" uuid NOT NULL,
	"clickup_task_id" varchar(50),
	"saude_conta" varchar(20),
	"risco_churn" varchar(20),
	"percepcao_resultado" varchar(20),
	"percepcao_faturamento" varchar(30),
	"performance_ifood" varchar(20),
	"performance_trafego" varchar(20),
	"performance_repediu" varchar(20),
	"performance_social_media" varchar(20),
	"synced_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "client_health_client_id_unique" UNIQUE("client_id")
);
--> statement-breakpoint
ALTER TABLE "client_health" ADD CONSTRAINT "client_health_client_id_clients_id_fk" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE cascade ON UPDATE no action;