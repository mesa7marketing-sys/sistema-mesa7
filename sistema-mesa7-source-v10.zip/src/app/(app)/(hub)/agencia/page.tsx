import { requireSession } from "@/lib/access";
import { PageHead, Card, Pill } from "@/components/ui";

export default async function AgenciaPage() {
  await requireSession();

  return (
    <div style={{ padding: "40px", maxWidth: 760 }}>
      <PageHead
        kicker="Agência"
        title="Visão da Agência"
        description="Panorama da carteira inteira de clientes Mesa7 — em construção."
      />
      <div style={{ marginTop: 24 }}>
        <Card title="O que vem por aqui">
          <p style={{ color: "var(--text-secondary)", fontSize: 14, lineHeight: 1.6, marginBottom: 14 }}>
            Uma visão consolidada de todos os clientes da Mesa7 — inclusive os
            que ainda não têm relatório no sistema — com faturamento agregado,
            farol de saúde da carteira e distribuição por serviço contratado.
          </p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <Pill>Faturamento agregado</Pill>
            <Pill>Farol da carteira</Pill>
            <Pill>Clientes por serviço</Pill>
            <Pill>Novos vs. churn</Pill>
          </div>
        </Card>
      </div>
    </div>
  );
}
