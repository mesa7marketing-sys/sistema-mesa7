import { requireSession } from "@/lib/access";
import { PageHead, Card, Pill } from "@/components/ui";

export default async function CSPage() {
  await requireSession();

  return (
    <div style={{ padding: "40px", maxWidth: 760 }}>
      <PageHead
        kicker="Time"
        title="Customer Success"
        description="Painel de saúde da carteira, churn, NPS e acompanhamento — em construção."
      />
      <div style={{ marginTop: 24 }}>
        <Card title="O que vem por aqui">
          <p style={{ color: "var(--text-secondary)", fontSize: 14, lineHeight: 1.6, marginBottom: 14 }}>
            Essa área vai reunir os indicadores de Customer Success da Mesa7 num
            só lugar: Farol do Cliente (já sincronizado com o ClickUp e visível
            na tela de Clientes), risco de churn, NPS, renovações, pendências e
            tempo de resposta.
          </p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <Pill>Onboardings realizados</Pill>
            <Pill>Tempo médio de onboarding</Pill>
            <Pill>NPS</Pill>
            <Pill>Churn</Pill>
            <Pill>Renovações</Pill>
            <Pill>Pendências resolvidas</Pill>
            <Pill>Tempo de resposta</Pill>
            <Pill>Clientes ativos</Pill>
          </div>
        </Card>
      </div>
    </div>
  );
}
