import { redirect } from "next/navigation";
import { requireSession } from "@/lib/access";
import { db } from "@/db";
import { clients } from "@/db/schema";
import { eq } from "drizzle-orm";
import { HubSidebar } from "@/components/HubSidebar";

const ROLE_LABEL: Record<string, string> = {
  admin: "Administração",
  cs: "Customer Success",
  trafego: "Tráfego",
  social: "Social Media",
  cardapio: "Gestão de Cardápio",
  crm: "CRM",
  design: "Design",
  google: "Google",
  client: "Cliente",
};

// Área interna da Mesa7 (equipe) — Clientes, Customer Success, Onboarding e
// Visão da Agência vivem aqui, todas atrás do mesmo menu lateral. Login de
// cliente nunca chega aqui: é redirecionado direto pro relatório dele.
export default async function HubLayout({ children }: { children: React.ReactNode }) {
  const session = await requireSession();

  if (session.user.role === "client" && session.user.clientId) {
    const [client] = await db
      .select()
      .from(clients)
      .where(eq(clients.id, session.user.clientId))
      .limit(1);
    if (client) redirect(`/c/${client.slug}/resumo`);
  }

  return (
    <div style={{ display: "grid", gridTemplateColumns: "252px 1fr", minHeight: "100vh" }}>
      <HubSidebar
        userName={session.user.name ?? ""}
        userRole={ROLE_LABEL[session.user.role] ?? session.user.role}
      />
      <main style={{ minWidth: 0 }}>{children}</main>
    </div>
  );
}
