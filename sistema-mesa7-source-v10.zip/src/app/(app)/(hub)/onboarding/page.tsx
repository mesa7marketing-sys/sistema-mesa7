import { requireSession } from "@/lib/access";
import { PageHead, Card, Pill } from "@/components/ui";

export default async function OnboardingPage() {
  await requireSession();

  return (
    <div style={{ padding: "40px", maxWidth: 760 }}>
      <PageHead
        kicker="Time"
        title="Onboarding"
        description="Ficha Técnica digital e checklist de onboarding — em construção."
      />
      <div style={{ marginTop: 24 }}>
        <Card title="O que vem por aqui">
          <p style={{ color: "var(--text-secondary)", fontSize: 14, lineHeight: 1.6, marginBottom: 14 }}>
            Um formulário pra cadastrar cliente novo direto no sistema, no
            formato da Ficha Técnica que o Customer Success já preenche hoje:
            dados do cliente, acessos, briefing, plataformas e financeiro.
          </p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <Pill>Dados do cliente</Pill>
            <Pill>Acessos</Pill>
            <Pill>Briefing</Pill>
            <Pill>Financeiro</Pill>
            <Pill>Plataformas</Pill>
            <Pill>Estratégias</Pill>
          </div>
        </Card>
      </div>
    </div>
  );
}
