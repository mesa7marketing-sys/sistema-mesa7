import { requireSession } from "@/lib/access";
import { db } from "@/db";
import { clients, clientHealth } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { PageHead } from "@/components/ui";
import { FarolBadge } from "@/components/farol-badge";
import Link from "next/link";

export default async function ClientesPage() {
  const session = await requireSession();
  const isTeam = session.user.role !== "client";

  const allClients = await db
    .select()
    .from(clients)
    .where(eq(clients.active, true))
    .orderBy(asc(clients.name));

  // Farol do Cliente (saúde da conta) — uso interno da equipe, essa página só
  // é alcançada por login de time (login de cliente é redirecionado no layout).
  const healthByClient = new Map<string, string | null>();
  if (isTeam && allClients.length > 0) {
    const rows = await db.select().from(clientHealth);
    for (const r of rows) healthByClient.set(r.clientId, r.saudeConta);
  }

  return (
    <div style={{ padding: "40px" }}>
      <PageHead
        kicker="Área"
        title="Clientes"
        description="Selecione um cliente para ver o relatório."
      />
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(220px,1fr))",
          gap: 12,
          maxWidth: 900,
          marginTop: 24,
        }}
      >
        {allClients.map((c) => (
          <Link
            key={c.id}
            href={`/c/${c.slug}/resumo`}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 8,
              background: "var(--surface)",
              border: "1px solid var(--border)",
              borderRadius: 14,
              padding: "18px 16px",
              color: "var(--text-primary)",
              textDecoration: "none",
              fontWeight: 700,
              fontSize: 14.5,
            }}
          >
            <span>{c.name}</span>
            {isTeam && <FarolBadge saudeConta={healthByClient.get(c.id) ?? null} />}
          </Link>
        ))}
        {allClients.length === 0 && (
          <div style={{ color: "var(--text-muted)", fontSize: 13.5 }}>
            Nenhum cliente cadastrado ainda.
          </div>
        )}
      </div>
    </div>
  );
}
