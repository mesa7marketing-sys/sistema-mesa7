"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { IconGlyph } from "@/components/ui";

type HubItem = {
  href: string;
  label: string;
  icon: "store" | "target" | "layers" | "chart";
  badge?: string;
};

type HubGroup = {
  label: string;
  items: HubItem[];
};

const GROUPS: HubGroup[] = [
  {
    label: "Clientes",
    items: [{ href: "/", label: "Todos os clientes", icon: "store" }],
  },
  {
    label: "Time",
    items: [
      { href: "/cs", label: "Customer Success", icon: "target", badge: "Em breve" },
      { href: "/onboarding", label: "Onboarding", icon: "layers", badge: "Em breve" },
    ],
  },
  {
    label: "Agência",
    items: [{ href: "/agencia", label: "Visão da Agência", icon: "chart", badge: "Em breve" }],
  },
];

export function HubNavLinks() {
  const pathname = usePathname();

  return (
    <>
      {GROUPS.map((group) => (
        <div key={group.label} style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <div
            style={{
              fontSize: 10.5,
              textTransform: "uppercase",
              letterSpacing: "0.1em",
              color: "var(--text-muted)",
              padding: "10px 12px 4px",
              fontWeight: 700,
            }}
          >
            {group.label}
          </div>
          {group.items.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "9px 12px",
                  borderRadius: 9,
                  color: active ? "#fff" : "var(--text-secondary)",
                  fontSize: 13.6,
                  fontWeight: 600,
                  border: active ? "1px solid rgba(249,115,22,0.35)" : "1px solid transparent",
                  background: active ? "var(--accent-soft)" : "transparent",
                  textDecoration: "none",
                }}
              >
                <IconGlyph name={item.icon} color={active ? "#fff" : "var(--text-muted)"} />
                <span style={{ flex: 1 }}>{item.label}</span>
                {item.badge && (
                  <span
                    style={{
                      fontSize: 9.5,
                      fontWeight: 800,
                      color: "var(--text-muted)",
                      background: "var(--surface-2)",
                      border: "1px solid var(--border-strong)",
                      borderRadius: 99,
                      padding: "2px 7px",
                      textTransform: "uppercase",
                      letterSpacing: "0.04em",
                    }}
                  >
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </div>
      ))}
    </>
  );
}
