// Farol do Cliente — indicador de saúde da conta (só visível pra equipe
// Mesa7, puxado do ClickUp). Sempre com ponto de cor + rótulo em texto,
// nunca só a cor, pra não depender de percepção de cor pra ler o status.

const FAROL_MAP: Record<string, { label: string; color: string; bg: string }> = {
  excelente: { label: "Excelente", color: "var(--status-good)", bg: "var(--status-good-bg)" },
  boa: { label: "Boa", color: "var(--status-good)", bg: "var(--status-good-bg)" },
  media: { label: "Média", color: "var(--status-warning)", bg: "var(--status-warning-bg)" },
  ruim: { label: "Ruim", color: "var(--status-critical)", bg: "var(--status-critical-bg)" },
};

export function FarolBadge({ saudeConta }: { saudeConta: string | null }) {
  const farol = saudeConta ? FAROL_MAP[saudeConta] : null;
  const label = farol?.label ?? "Sem farol";
  const color = farol?.color ?? "var(--text-muted)";
  const bg = farol?.bg ?? "var(--surface-2)";

  return (
    <span
      title={`Saúde da conta: ${label}`}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
        background: bg,
        borderRadius: 99,
        padding: "3px 9px 3px 7px",
        fontSize: 11,
        fontWeight: 700,
        color,
        whiteSpace: "nowrap",
        flexShrink: 0,
      }}
    >
      <span
        aria-hidden
        style={{
          width: 7,
          height: 7,
          borderRadius: "50%",
          background: color,
          display: "inline-block",
        }}
      />
      {label}
    </span>
  );
}
