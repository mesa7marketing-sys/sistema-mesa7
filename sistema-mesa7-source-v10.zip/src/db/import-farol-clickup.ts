// Importa o "Farol do Cliente" (saúde da conta, risco de churn, percepção de
// resultado, performance por canal) da lista "Clientes Ativos" do ClickUp
// (space "Mesa 7 - Marketing" > folder "Comunicação" > list_id
// 901322836295), tarefas "Farol do Cliente - {Nome}".
//
// Uso interno da equipe Mesa7 (Customer Success) — nunca fica visível pro
// cliente. client_health guarda sempre a última foto (não é série
// histórica); os valores em texto (não numérico) porque são categorias, não
// métricas somáveis.
//
// Rotina: repetir esse processo (puxar via MCP do ClickUp + atualizar os
// valores abaixo) sempre que o time de CS atualizar o farol no ClickUp —
// candidato natural pra virar sincronização automática no futuro.
import "dotenv/config";
import { db } from "./index";
import { clients, clientHealth } from "./schema";
import { eq } from "drizzle-orm";

type Farol = {
  slug: string;
  clickupTaskId: string;
  saudeConta?: string;
  riscoChurn?: string;
  percepcaoResultado?: string;
  percepcaoFaturamento?: string;
  performanceIfood?: string;
  performanceTrafego?: string;
  performanceRepediu?: string;
  performanceSocialMedia?: string;
};

// Puxado do ClickUp em 16/09/2026 via clickup_search + clickup_get_task.
const FAROIS: Farol[] = [
  {
    slug: "bionatural",
    clickupTaskId: "86ae8ne6e",
    saudeConta: "excelente",
    riscoChurn: "baixo",
    percepcaoResultado: "bom",
    percepcaoFaturamento: "percebe",
  },
  {
    slug: "garage-84",
    clickupTaskId: "86adg4wyg",
    saudeConta: "excelente",
    riscoChurn: "baixo",
    percepcaoResultado: "bom",
    percepcaoFaturamento: "percebe",
    performanceIfood: "bom",
  },
  {
    slug: "la-pizza-dcaio",
    clickupTaskId: "86ahrnbba",
    riscoChurn: "baixo",
    percepcaoFaturamento: "percebe_pouco",
  },
  {
    slug: "pacocas-unidade-1",
    clickupTaskId: "86adg4xpg",
    saudeConta: "boa",
    riscoChurn: "baixo",
    percepcaoResultado: "bom",
    percepcaoFaturamento: "percebe",
  },
  {
    slug: "pacocas-unidade-2",
    clickupTaskId: "86ah3h947",
    saudeConta: "boa",
    riscoChurn: "baixo",
    percepcaoResultado: "bom",
    percepcaoFaturamento: "percebe",
  },
  {
    slug: "taverna-dos-pandas",
    clickupTaskId: "86adg4x4w",
    saudeConta: "excelente",
    riscoChurn: "baixo",
    percepcaoResultado: "bom",
    percepcaoFaturamento: "percebe",
  },
  {
    slug: "duana-centro",
    clickupTaskId: "86ajnu14a",
    // Registro em branco no ClickUp — sem farol preenchido ainda.
  },
  {
    slug: "duana-serra",
    clickupTaskId: "86ajntzja",
    // Registro em branco no ClickUp — sem farol preenchido ainda.
  },
  {
    slug: "hattori",
    clickupTaskId: "86ajxhejm",
    // Registro em branco no ClickUp — sem farol preenchido ainda.
  },
  {
    slug: "burguin",
    clickupTaskId: "86adg4z2n",
    saudeConta: "media",
    riscoChurn: "baixo",
    percepcaoResultado: "risco",
    percepcaoFaturamento: "percebe_pouco",
    performanceIfood: "bom",
  },
  {
    slug: "deck-cantareira",
    clickupTaskId: "86ajntfrv",
    // Registro em branco no ClickUp — sem farol preenchido ainda.
  },
];

async function main() {
  for (const f of FAROIS) {
    const [client] = await db.select().from(clients).where(eq(clients.slug, f.slug)).limit(1);
    if (!client) {
      console.log(`${f.slug}: cliente não encontrado no sistema — pulando`);
      continue;
    }

    const values = {
      clientId: client.id,
      clickupTaskId: f.clickupTaskId,
      saudeConta: f.saudeConta ?? null,
      riscoChurn: f.riscoChurn ?? null,
      percepcaoResultado: f.percepcaoResultado ?? null,
      percepcaoFaturamento: f.percepcaoFaturamento ?? null,
      performanceIfood: f.performanceIfood ?? null,
      performanceTrafego: f.performanceTrafego ?? null,
      performanceRepediu: f.performanceRepediu ?? null,
      performanceSocialMedia: f.performanceSocialMedia ?? null,
      syncedAt: new Date(),
    };

    await db
      .insert(clientHealth)
      .values(values)
      .onConflictDoUpdate({
        target: clientHealth.clientId,
        set: { ...values, updatedAt: new Date() },
      });

    console.log(`${f.slug}: farol sincronizado (saúde=${f.saudeConta ?? "—"}).`);
  }

  console.log("Concluído.");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
