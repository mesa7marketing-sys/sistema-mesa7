/* =========================================================
   Mesa7 — Esqueleto de dashboard (padrão Taverna dos Pandas)
   Usado pelos clientes que ainda não têm base de dados.
   Cada HTML define window.CLIENTE = {nome, seg, icone, logo}
   e carrega este arquivo; tudo aparece como "Aguardando dados".
   ========================================================= */
(function () {
  var C = window.CLIENTE || { nome: 'Cliente', seg: '', icone: 'fa-utensils', logo: '' };
  document.title = 'Mesa7 — Dashboard ' + C.nome;

  function addHead(tag, attrs) {
    var el = document.createElement(tag);
    for (var k in attrs) el.setAttribute(k, attrs[k]);
    document.head.appendChild(el);
  }
  addHead('link', { rel: 'preconnect', href: 'https://fonts.googleapis.com' });
  addHead('link', { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap' });
  addHead('link', { rel: 'stylesheet', href: 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css' });

  var css = [
    ':root{--m7-orange:#F98612;--m7-cream:#F4F2EA;--m7-blue:#9BAED9;--m7-navy-deep:#101243;--m7-navy:#1A2361;--bg-main:#0C0E36;--bg-panel:#101243;--bg-card:#1A2361;--bg-hover:#26307E;--border:rgba(155,174,217,.18);--border-strong:rgba(155,174,217,.32);--primary-glow:rgba(249,134,18,.14);--text-muted:#9BAED9;--text-sub:#D6DEF0}',
    '*{box-sizing:border-box;margin:0;padding:0}',
    'body{background:var(--bg-main);color:var(--m7-cream);font-family:Poppins,sans-serif;display:flex;min-height:100vh;overflow-x:hidden;-webkit-font-smoothing:antialiased}',
    'h1,.kpi-value,.brand-title,.chart-title{letter-spacing:-.03em}',
    'aside{width:262px;background:var(--bg-panel);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;height:100vh;z-index:100}',
    '.brand-header{padding:24px 20px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px}',
    '.brand-logo{width:40px;height:40px;background:var(--m7-orange);border-radius:11px;display:flex;align-items:center;justify-content:center;color:var(--m7-navy-deep);font-weight:700;font-size:16px;letter-spacing:-.05em}',
    '.brand-title{font-size:19px;font-weight:600;line-height:1.15}',
    '.brand-title span{color:var(--m7-orange);font-size:10px;display:block;text-transform:uppercase;letter-spacing:1.8px;font-weight:500;margin-top:2px}',
    '.client-block{padding:16px 16px 18px;border-bottom:1px solid var(--border);background:rgba(155,174,217,.04)}',
    '.client-label{font-size:10px;text-transform:uppercase;letter-spacing:1.4px;color:var(--text-muted);font-weight:600;opacity:.75;margin-bottom:10px;display:block}',
    '.client-card{display:flex;align-items:center;gap:11px;background:var(--bg-card);border:1px solid var(--border-strong);border-radius:11px;padding:11px 13px}',
    '.client-mark{width:38px;height:38px;border-radius:9px;background:#232323;display:flex;align-items:center;justify-content:center;flex:0 0 auto;overflow:hidden}',
    '.client-mark i{color:#fff;font-size:15px}.client-mark img{width:100%;height:100%;object-fit:contain}',
    '.client-name{font-size:14px;font-weight:600;line-height:1.2}',
    '.client-seg{font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.9px;margin-top:2px;font-weight:500}',
    '.nav-menu{list-style:none;padding:14px 12px;flex-grow:1;overflow-y:auto}',
    '.nav-label{font-size:10px;text-transform:uppercase;letter-spacing:1.4px;color:var(--text-muted);padding:10px 12px 8px;font-weight:600;opacity:.75}',
    '.nav-item{display:flex;align-items:center;gap:12px;padding:11px 14px;color:var(--text-sub);border-radius:10px;cursor:pointer;font-size:13.5px;font-weight:500;transition:all .2s ease;margin-bottom:3px;border:1px solid transparent}',
    '.nav-item:hover{background:var(--bg-hover);color:var(--m7-cream)}',
    '.nav-item.active{background:var(--primary-glow);color:var(--m7-orange);border-color:rgba(249,134,18,.35);font-weight:600}',
    '.nav-item i{width:18px;font-size:15px;text-align:center}',
    '.sidebar-footer{padding:16px;border-top:1px solid var(--border);font-size:11.5px;color:var(--text-muted);text-align:center}',
    'main{margin-left:262px;flex-grow:1;padding:26px 34px 60px;max-width:calc(100vw - 262px)}',
    'header.top-bar{display:flex;align-items:center;gap:14px;margin-bottom:24px;padding-bottom:18px;border-bottom:1px solid var(--border)}',
    '.page-title h1{font-size:27px;font-weight:600;display:flex;align-items:center;gap:11px}',
    '.page-title p{color:var(--text-muted);font-size:13px;margin-top:3px}',
    '.aviso{display:flex;gap:12px;align-items:flex-start;background:linear-gradient(135deg,rgba(249,134,18,.10),rgba(155,174,217,.06));border:1px solid rgba(249,134,18,.28);border-radius:14px;padding:18px 20px;margin-bottom:22px;font-size:12.5px;color:var(--text-sub);line-height:1.6}',
    '.aviso i{color:var(--m7-orange);font-size:17px;margin-top:2px}.aviso b{color:var(--m7-orange)}',
    '.view-page{display:none}.view-page.active{display:block;animation:fadeIn .28s ease}',
    '@keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}',
    '.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin-bottom:22px}',
    '.kpi-card{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:20px;position:relative;overflow:hidden}',
    '.kpi-card::before{content:"";position:absolute;top:0;left:0;width:100%;height:3px;background:var(--m7-orange)}',
    '.kpi-card:nth-child(2)::before{background:var(--m7-blue)}.kpi-card:nth-child(3)::before{background:var(--m7-cream)}.kpi-card:nth-child(4)::before{background:linear-gradient(90deg,var(--m7-orange),var(--m7-blue))}',
    '.kpi-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:9px;gap:8px}',
    '.kpi-label{font-size:12px;color:var(--text-muted);font-weight:500}.kpi-icon{font-size:15px;color:var(--text-muted);opacity:.7}',
    '.kpi-value{font-size:16px;font-weight:400;font-style:italic;color:var(--text-muted);line-height:1.6}',
    '.grid-2{display:grid;grid-template-columns:repeat(auto-fit,minmax(440px,1fr));gap:18px;margin-bottom:22px}',
    '.chart-card{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:22px}',
    '.chart-title{font-size:16px;font-weight:600;display:flex;align-items:center;gap:9px;margin-bottom:14px}.chart-title i{color:var(--m7-orange);font-size:15px}',
    '.data-table{width:100%;border-collapse:collapse;font-size:13px}',
    '.data-table td{padding:11px 14px;border-bottom:1px solid var(--border);color:var(--text-sub)}',
    '.data-table tr:last-child td{border-bottom:none}',
    '.wait{color:var(--text-muted);font-style:italic}',
    '.menu-toggle{display:none;flex:0 0 auto;width:42px;height:42px;border-radius:11px;background:var(--bg-card);border:1px solid var(--border-strong);color:var(--m7-orange);font-size:17px;cursor:pointer;align-items:center;justify-content:center}',
    '.sidebar-close{display:none;background:transparent;border:none;color:var(--text-muted);font-size:20px;cursor:pointer;margin-left:auto}',
    '.overlay{display:none;position:fixed;inset:0;z-index:99;background:rgba(12,14,54,.72);backdrop-filter:blur(3px)}.overlay.show{display:block}',
    '@media (max-width:1100px){.grid-2{grid-template-columns:1fr}}',
    '@media (max-width:900px){aside{transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1);width:280px}body.nav-open aside{transform:none;box-shadow:0 0 44px rgba(0,0,0,.55)}main{margin-left:0;max-width:100vw;padding:18px 16px 48px}.menu-toggle{display:flex}.sidebar-close{display:block}.page-title h1{font-size:21px}.kpi-grid{grid-template-columns:repeat(auto-fit,minmax(158px,1fr));gap:12px}}',
    '@media (max-width:560px){.kpi-grid{grid-template-columns:1fr 1fr}}'
  ].join('\n');
  var st = document.createElement('style');
  st.textContent = css;
  document.head.appendChild(st);

  var PAGES = [
    { id: 'p1', icon: 'fa-gauge-high', t: 'Resumo Executivo', s: 'Visão rápida de performance e saúde financeira em 30 segundos.',
      kpis: [['Faturamento', 'fa-sack-dollar'], ['Pedidos', 'fa-bag-shopping'], ['Ticket Médio', 'fa-receipt'], ['Mix de Canais', 'fa-layer-group']],
      cards: [['Evolução de Faturamento', 'fa-chart-line', ['Faturamento mensal', 'Comparativo MoM / YoY']], ['Comparativo de Período', 'fa-scale-balanced', ['Faturamento Total', 'Salão / Loja', 'Delivery', 'Invest. Mídia']]] },
    { id: 'p2', icon: 'fa-filter', t: 'Método CVR', s: 'Conversão, Valor e Relacionamento do restaurante.',
      cards: [['1. Conversão', 'fa-filter', ['Investimento em Mídia', 'Alcance (Meta Ads)', 'Cliques no Link', 'Compras Atribuídas']], ['2. Valor · Google Meu Negócio', 'fa-star', ['Visualizações do Perfil', 'Solicitações de Rota', 'Chamadas Telefônicas', 'Nota Média Atual']]] },
    { id: 'p3', icon: 'fa-chart-pie', t: 'Financeiro & Canais', s: 'Composição do faturamento por canal.',
      kpis: [['Salão / Loja', 'fa-utensils'], ['Delivery Próprio', 'fa-motorcycle'], ['Marketplace', 'fa-shop'], ['Faturamento Total', 'fa-chart-simple']] },
    { id: 'p4', icon: 'fa-store', t: 'Plataformas', s: 'Canais próprios versus marketplaces e o impacto no ticket.',
      kpis: [['iFood', 'fa-bowl-food'], ['99Food', 'fa-motorcycle'], ['Site / Cardápio Próprio', 'fa-mobile-screen'], ['Ticket Próprio vs Marketplace', 'fa-arrow-right-arrow-left']] },
    { id: 'p5', icon: 'fa-bullhorn', t: 'Marketing 360°', s: 'Meta Ads, Google Ads e Google Meu Negócio.',
      cards: [['Meta Ads', 'fa-hashtag', ['Investimento', 'Alcance', 'Cliques no Link', 'Seguidores']], ['Google Ads & Meu Negócio', 'fa-magnifying-glass', ['Investimento Google Ads', 'Conversões', 'Visualizações do Perfil', 'Solicitações de Rota']]] },
    { id: 'p6', icon: 'fa-utensils', t: 'Cardápio & ABC', s: 'Engenharia de menu e ranking dos itens mais vendidos.',
      kpis: [['Maior Faturamento', 'fa-crown'], ['Maior Volume', 'fa-ranking-star'], ['Itens com Venda', 'fa-list'], ['Concentração Top 5', 'fa-layer-group']] },
    { id: 'p7', icon: 'fa-clock', t: 'Comportamento', s: 'Quando o cliente compra ao longo da semana e do dia.',
      kpis: [['Melhor Dia', 'fa-star'], ['Melhor Ticket', 'fa-receipt'], ['Horário de Pico', 'fa-clock'], ['Concentração Sex–Dom', 'fa-fire']] },
    { id: 'p8', icon: 'fa-bullseye', t: 'Metas 30/60/90', s: 'Planejamento estratégico organizado pelo Método CVR.',
      cards: [['30 dias · Organização', 'fa-layer-group', ['Conversão', 'Valor', 'Relacionamento']], ['60 dias · Otimização', 'fa-sliders', ['Conversão', 'Valor', 'Relacionamento']], ['90 dias · Escala', 'fa-rocket', ['Conversão', 'Valor', 'Relacionamento']]] }
  ];

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var WAIT = '<span class="wait">Aguardando dados</span>';

  function pageHtml(p, i) {
    var h = '<div id="' + p.id + '" class="view-page' + (i === 0 ? ' active' : '') + '">';
    if (i === 0) h += '<div class="aviso"><i class="fa-solid fa-circle-info"></i><div><b>Dashboard em implantação.</b> Os indicadores de ' + esc(C.nome) + ' aparecem aqui assim que os dados do cliente forem enviados à Mesa7 (faturamento, iFood, Meta Ads, Google e CRM).</div></div>';
    if (p.kpis) {
      h += '<div class="kpi-grid">';
      p.kpis.forEach(function (k) {
        h += '<div class="kpi-card"><div class="kpi-header"><span class="kpi-label">' + esc(k[0]) + '</span><i class="fa-solid ' + k[1] + ' kpi-icon"></i></div><div class="kpi-value">Aguardando dados</div></div>';
      });
      h += '</div>';
    }
    if (p.cards) {
      h += '<div class="grid-2">';
      p.cards.forEach(function (c) {
        h += '<div class="chart-card"><div class="chart-title"><i class="fa-solid ' + c[1] + '"></i> ' + esc(c[0]) + '</div><table class="data-table"><tbody>';
        c[2].forEach(function (r) { h += '<tr><td>' + esc(r) + '</td><td>' + WAIT + '</td></tr>'; });
        h += '</tbody></table></div>';
      });
      h += '</div>';
    }
    return h + '</div>';
  }

  var mark = C.logo
    ? '<img src="' + esc(C.logo) + '" alt="' + esc(C.nome) + '" onerror="this.parentNode.innerHTML=\'<i class=&quot;fa-solid ' + esc(C.icone) + '&quot;></i>\'">'
    : '<i class="fa-solid ' + esc(C.icone || 'fa-utensils') + '"></i>';

  var nav = '<div class="nav-label">Relatório Executivo</div>' + PAGES.map(function (p, i) {
    return '<li class="nav-item' + (i === 0 ? ' active' : '') + '" data-page="' + p.id + '"><i class="fa-solid ' + p.icon + '"></i> ' + (i + 1) + '. ' + esc(p.t) + '</li>';
  }).join('');

  document.body.innerHTML =
    '<div class="overlay" id="overlay"></div>' +
    '<aside id="sidebar"><div class="brand-header"><div class="brand-logo">M7</div><div class="brand-title">Mesa7<span>Intelligence</span></div><button class="sidebar-close" id="btnClose" aria-label="Fechar menu"><i class="fa-solid fa-xmark"></i></button></div>' +
    '<div class="client-block"><span class="client-label">Cliente</span><div class="client-card"><div class="client-mark">' + mark + '</div><div><div class="client-name">' + esc(C.nome) + '</div><div class="client-seg">' + esc(C.seg || '') + '</div></div></div></div>' +
    '<ul class="nav-menu">' + nav + '</ul><div class="sidebar-footer">Desenvolvido por Mesa7 Marketing</div></aside>' +
    '<main><header class="top-bar"><button class="menu-toggle" id="btnMenu" aria-label="Abrir menu"><i class="fa-solid fa-bars"></i></button><div class="page-title"><h1 id="page-heading"></h1><p id="page-subheading"></p></div></header>' +
    PAGES.map(pageHtml).join('') + '</main>';

  function closeNav() { document.body.classList.remove('nav-open'); document.getElementById('overlay').classList.remove('show'); }
  function openNav() { document.body.classList.add('nav-open'); document.getElementById('overlay').classList.add('show'); }
  function show(id) {
    closeNav();
    var p = PAGES.filter(function (x) { return x.id === id; })[0];
    document.querySelectorAll('.view-page').forEach(function (el) { el.classList.toggle('active', el.id === id); });
    document.querySelectorAll('.nav-item').forEach(function (el) { el.classList.toggle('active', el.getAttribute('data-page') === id); });
    document.getElementById('page-heading').innerHTML = '<i class="fa-solid ' + p.icon + '" style="color:var(--m7-orange)"></i> ' + esc(p.t);
    document.getElementById('page-subheading').textContent = p.s;
  }
  window.switchPage = show;
  document.querySelectorAll('.nav-item').forEach(function (el) { el.addEventListener('click', function () { window.switchPage(el.getAttribute('data-page')); }); });
  document.getElementById('btnMenu').addEventListener('click', openNav);
  document.getElementById('btnClose').addEventListener('click', closeNav);
  document.getElementById('overlay').addEventListener('click', closeNav);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeNav(); });
  show('p1');
})();
