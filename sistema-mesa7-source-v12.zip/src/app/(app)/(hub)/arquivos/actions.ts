"use server";

import { revalidatePath } from "next/cache";
import { requireSession } from "@/lib/access";
import {
  FONTES,
  LIMITE_MB,
  extensaoAceita,
  marcarStatus,
  removerArquivo,
  salvarArquivo,
  type FonteId,
} from "@/lib/arquivos";
import { dashboardPorPasta } from "@/lib/dashboards";

export type EstadoEnvio = { ok: boolean; mensagem: string } | null;

async function exigirEquipe() {
  const session = await requireSession();
  if (session.user.role === "client") throw new Error("Apenas a equipe Mesa7 pode enviar arquivos.");
  return { session, quem: session.user.name || session.user.email || "Equipe" };
}

export async function enviarArquivos(_prev: EstadoEnvio, formData: FormData): Promise<EstadoEnvio> {
  const { quem } = await exigirEquipe();

  const pasta = String(formData.get("pasta") || "");
  const fonte = String(formData.get("fonte") || "") as FonteId;
  const mes = String(formData.get("mes") || "");
  const observacao = String(formData.get("observacao") || "").trim().slice(0, 500);
  const arquivos = formData.getAll("arquivos").filter((f): f is File => f instanceof File && f.size > 0);

  const cliente = dashboardPorPasta(pasta);
  if (!cliente) return { ok: false, mensagem: "Escolha o cliente." };
  if (!FONTES.some((f) => f.id === fonte)) return { ok: false, mensagem: "Escolha a fonte dos dados." };
  if (!/^\d{4}-\d{2}$/.test(mes)) return { ok: false, mensagem: "Escolha o mês de referência." };
  if (arquivos.length === 0) return { ok: false, mensagem: "Selecione pelo menos um arquivo." };

  const recusados = arquivos.filter((a) => !extensaoAceita(a.name)).map((a) => a.name);
  if (recusados.length) {
    return { ok: false, mensagem: `Tipo de arquivo não aceito: ${recusados.join(", ")}. Use PDF, CSV, Excel ou imagem.` };
  }
  const total = arquivos.reduce((s, a) => s + a.size, 0);
  if (total > LIMITE_MB * 1024 * 1024) {
    return { ok: false, mensagem: `Os arquivos passam de ${LIMITE_MB} MB juntos. Envie em partes.` };
  }

  for (const arquivo of arquivos) {
    await salvarArquivo({ pasta, fonte, mes, observacao, enviadoPor: quem, arquivo });
  }

  revalidatePath("/arquivos");
  revalidatePath("/dashboards");
  const n = arquivos.length;
  return {
    ok: true,
    mensagem: `${n} arquivo${n > 1 ? "s" : ""} de ${cliente.nome} enviado${n > 1 ? "s" : ""}. Fica como "Pendente" até ser lançado no dashboard.`,
  };
}

export async function alternarStatus(formData: FormData) {
  const { quem } = await exigirEquipe();
  const pasta = String(formData.get("pasta") || "");
  const id = String(formData.get("id") || "");
  const status = formData.get("status") === "lancado" ? "lancado" : "pendente";
  await marcarStatus(pasta, id, status, quem);
  revalidatePath("/arquivos");
  revalidatePath("/dashboards");
}

export async function remover(formData: FormData) {
  await exigirEquipe();
  await removerArquivo(String(formData.get("pasta") || ""), String(formData.get("id") || ""));
  revalidatePath("/arquivos");
  revalidatePath("/dashboards");
}
