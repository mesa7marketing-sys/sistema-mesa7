import { auth } from "@/auth";
import { lerConteudoArquivo } from "@/lib/arquivos";

// Abre/baixa um arquivo enviado pela equipe. Só equipe logada.
export async function GET(_req: Request, ctx: RouteContext<"/arquivos/baixar/[pasta]/[id]">) {
  const session = await auth();
  if (!session?.user || session.user.role === "client") {
    return new Response("Não autorizado", { status: 401 });
  }

  const { pasta, id } = await ctx.params;
  const achado = await lerConteudoArquivo(pasta, id);
  if (!achado) return new Response("Arquivo não encontrado", { status: 404 });

  const nome = encodeURIComponent(achado.info.nomeOriginal);
  return new Response(new Uint8Array(achado.corpo), {
    headers: {
      "Content-Type": achado.tipo,
      "Content-Disposition": `inline; filename*=UTF-8''${nome}`,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
