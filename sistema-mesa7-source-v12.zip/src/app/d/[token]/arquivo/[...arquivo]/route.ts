import { dashboardPorToken, lerArquivoDashboard } from "@/lib/dashboards";

// Serve os arquivos do dashboard (HTML, scripts comuns e logos). Público:
// o token de 24 caracteres no caminho é o que libera o acesso.
export async function GET(_: Request, ctx: RouteContext<"/d/[token]/arquivo/[...arquivo]">) {
  const { token, arquivo } = await ctx.params;
  const dashboard = dashboardPorToken(token);
  if (!dashboard) return new Response("Não encontrado", { status: 404 });

  const lido = await lerArquivoDashboard(dashboard, arquivo);
  if (!lido) return new Response("Não encontrado", { status: 404 });

  return new Response(new Uint8Array(typeof lido.corpo === "string" ? Buffer.from(lido.corpo) : lido.corpo), {
    headers: {
      "Content-Type": lido.tipo,
      "Cache-Control": "no-store",
      "X-Robots-Tag": "noindex, nofollow",
      "Referrer-Policy": "no-referrer",
    },
  });
}
