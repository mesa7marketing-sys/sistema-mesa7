// Arquivos de resultados dos clientes (PDF, CSV, planilhas, prints) que a
// equipe sobe para alimentar os dashboards.
//
// Onde ficam: fora da pasta do app, para sobreviver a qualquer atualização
// de versão. Padrão: pasta irmã do app (na VPS: /opt/sistema-mesa7-arquivos).
// Dá para trocar com ARQUIVOS_DIR no .env.
//
// Estrutura (sem banco de dados, sem migração):
//   <raiz>/<pasta-do-cliente>/<id>/info.json   ← dados do envio
//   <raiz>/<pasta-do-cliente>/<id>/<arquivo>   ← o arquivo original
//   <raiz>/_lixeira/...                        ← envios removidos (nada é apagado de verdade)
import { promises as fs } from "node:fs";
import path from "node:path";
import { randomBytes } from "node:crypto";
import { DASHBOARDS, dashboardPorPasta } from "@/lib/dashboards";

export const FONTES = [
  { id: "ifood", label: "iFood" },
  { id: "meta-ads", label: "Meta Ads" },
  { id: "google-ads", label: "Google Ads" },
  { id: "cardapio-proprio", label: "Cardápio próprio" },
  { id: "pdv", label: "PDV" },
  { id: "google-meu-negocio", label: "Google Meu Negócio" },
  { id: "faturamento", label: "Faturamento" },
] as const;

export type FonteId = (typeof FONTES)[number]["id"];
export type StatusArquivo = "pendente" | "lancado";

export function fonteLabel(id: string) {
  return FONTES.find((f) => f.id === id)?.label ?? id;
}

export const EXTENSOES_ACEITAS = [".pdf", ".csv", ".xlsx", ".xls", ".png", ".jpg", ".jpeg", ".webp"];
export const LIMITE_MB = 25;

const TIPOS: Record<string, string> = {
  ".pdf": "application/pdf",
  ".csv": "text/csv; charset=utf-8",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ".xls": "application/vnd.ms-excel",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
};

export type ArquivoInfo = {
  id: string;
  pasta: string;
  fonte: FonteId;
  /** Mês de referência dos dados, formato AAAA-MM. */
  mes: string;
  observacao: string;
  nomeOriginal: string;
  arquivo: string;
  tamanho: number;
  enviadoPor: string;
  enviadoEm: string;
  status: StatusArquivo;
  lancadoPor?: string;
  lancadoEm?: string;
};

export function raizArquivos() {
  return process.env.ARQUIVOS_DIR || path.resolve(/*turbopackIgnore: true*/ process.cwd(), "..", "sistema-mesa7-arquivos");
}

const ID_OK = /^[0-9]{8}-[0-9]{6}-[a-f0-9]{6}$/;

function pastaValida(pasta: string) {
  return !!dashboardPorPasta(pasta);
}

function nomeSeguro(nome: string) {
  const ext = path.extname(nome).toLowerCase();
  const base = path
    .basename(nome, path.extname(nome))
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/^[-.]+|-+$/g, "")
    .slice(0, 80);
  return `${base || "arquivo"}${ext}`;
}

function novoId(agora: Date) {
  const p = (n: number) => String(n).padStart(2, "0");
  const data = `${agora.getFullYear()}${p(agora.getMonth() + 1)}${p(agora.getDate())}`;
  const hora = `${p(agora.getHours())}${p(agora.getMinutes())}${p(agora.getSeconds())}`;
  return `${data}-${hora}-${randomBytes(3).toString("hex")}`;
}

export function extensaoAceita(nome: string) {
  return EXTENSOES_ACEITAS.includes(path.extname(nome).toLowerCase());
}

export async function salvarArquivo(dados: {
  pasta: string;
  fonte: FonteId;
  mes: string;
  observacao: string;
  enviadoPor: string;
  arquivo: File;
}): Promise<ArquivoInfo> {
  if (!pastaValida(dados.pasta)) throw new Error("Cliente inválido.");
  const id = novoId(new Date());
  const dir = path.join(raizArquivos(), dados.pasta, id);
  await fs.mkdir(dir, { recursive: true });

  const nome = nomeSeguro(dados.arquivo.name);
  await fs.writeFile(path.join(dir, nome), Buffer.from(await dados.arquivo.arrayBuffer()));

  const info: ArquivoInfo = {
    id,
    pasta: dados.pasta,
    fonte: dados.fonte,
    mes: dados.mes,
    observacao: dados.observacao,
    nomeOriginal: dados.arquivo.name,
    arquivo: nome,
    tamanho: dados.arquivo.size,
    enviadoPor: dados.enviadoPor,
    enviadoEm: new Date().toISOString(),
    status: "pendente",
  };
  await fs.writeFile(path.join(dir, "info.json"), JSON.stringify(info, null, 2));
  return info;
}

async function lerInfo(pasta: string, id: string): Promise<ArquivoInfo | null> {
  if (!pastaValida(pasta) || !ID_OK.test(id)) return null;
  try {
    const txt = await fs.readFile(path.join(raizArquivos(), pasta, id, "info.json"), "utf8");
    return JSON.parse(txt) as ArquivoInfo;
  } catch {
    return null;
  }
}

/** Todos os envios (mais recentes primeiro). */
export async function listarArquivos(): Promise<ArquivoInfo[]> {
  const todos: ArquivoInfo[] = [];
  for (const d of DASHBOARDS) {
    let ids: string[] = [];
    try {
      ids = await fs.readdir(path.join(raizArquivos(), d.pasta));
    } catch {
      continue;
    }
    for (const id of ids) {
      const info = await lerInfo(d.pasta, id);
      if (info) todos.push(info);
    }
  }
  return todos.sort((a, b) => b.enviadoEm.localeCompare(a.enviadoEm));
}

export async function marcarStatus(pasta: string, id: string, status: StatusArquivo, quem: string) {
  const info = await lerInfo(pasta, id);
  if (!info) throw new Error("Arquivo não encontrado.");
  info.status = status;
  if (status === "lancado") {
    info.lancadoPor = quem;
    info.lancadoEm = new Date().toISOString();
  } else {
    delete info.lancadoPor;
    delete info.lancadoEm;
  }
  await fs.writeFile(path.join(raizArquivos(), pasta, id, "info.json"), JSON.stringify(info, null, 2));
}

/** Tira o envio da lista movendo para _lixeira (recuperável pelo servidor). */
export async function removerArquivo(pasta: string, id: string) {
  const info = await lerInfo(pasta, id);
  if (!info) throw new Error("Arquivo não encontrado.");
  const lixeira = path.join(raizArquivos(), "_lixeira", pasta);
  await fs.mkdir(lixeira, { recursive: true });
  await fs.rename(path.join(raizArquivos(), pasta, id), path.join(lixeira, id));
}

export async function lerConteudoArquivo(pasta: string, id: string) {
  const info = await lerInfo(pasta, id);
  if (!info) return null;
  const corpo = await fs.readFile(path.join(raizArquivos(), pasta, id, info.arquivo));
  const tipo = TIPOS[path.extname(info.arquivo).toLowerCase()] ?? "application/octet-stream";
  return { info, corpo, tipo };
}

export function formatarTamanho(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1).replace(".", ",")} MB`;
}

const MESES = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];

export function mesLabel(mes: string) {
  const [a, m] = mes.split("-").map(Number);
  return a && m ? `${MESES[m - 1]}/${a}` : mes;
}

/** Últimos N meses no formato AAAA-MM, do mais recente para o mais antigo. */
export function mesesRecentes(n = 13) {
  const hoje = new Date();
  const lista: { value: string; label: string }[] = [];
  for (let i = 0; i < n; i++) {
    const d = new Date(hoje.getFullYear(), hoje.getMonth() - i, 1);
    const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    lista.push({ value, label: mesLabel(value) });
  }
  return lista;
}
