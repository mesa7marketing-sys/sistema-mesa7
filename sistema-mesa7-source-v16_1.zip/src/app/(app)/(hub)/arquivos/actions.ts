"use server";

import { revalidatePath } from "next/cache";
import { requireSession } from "@/lib/access";
import {
  FONTES,
  LIMITE_MB,
  extensaoAceita,
  marcarStatus,
  mesLabel,
  registrarLeitura,
  removerArquivo,
  salvarArquivo,
  type FonteId,
} from "@/lib/arquivos";
import { dashboardPorPasta } from "@/lib/dashboards";
import { lerRelatorioIfood } from "@/lib/leitor-ifood";
import { salvarMeses } from "@/lib/dados-clientes";

const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

/** Lê o relatório quando a fonte tem leitura automática. Nunca impede o envio. */
async function lerAutomatico(pasta: string, fonte: FonteId, arquivo: File) {
  if (fonte !== "ifood" || !/\.(xlsx|csv)$/i.test(arquivo.name)) return null;
  try {
    const meses = await lerRelatorioIfood(arquivo.name, Buffer.from(await arquivo.arrayBuffer()));
    await salvarMeses(pasta, "ifood", Object.fromEntries(meses.map((m) => [m.mes, m])));
    return {
      ok: true,
      resumo: meses.map((m) => `${mesLabel(m.mes)}: ${m.o} pedidos · ${brl(m.r)} · ticket ${brl(m.t)}`).join(" | "),
    };
  } catch (e) {
    return { ok: false, resumo: e instanceof Error ? e.message : "Não consegui ler o arquivo." };
  }
}

export type EstadoEnvio = { ok: boolean; mensagem: string } | null;

async function exigirEquipe() {
  const session = await requireSession();
  if (session.user.role === "client") throw new Error("Apenas a equipe Mesa7 pode enviar arquivos.");
  return { session, quem: session.user.name || session.user.email || "Equipe" };
}

export async function enviarArquivos(_prev: EstadoEnvio, formData: FormData): Promise<EstadoEnvio> {
  const { quem } = await exigirEquipe();

  const pasta = String(formData.get("pasta") || "");
  const fonte = String(formData.get("fonte") || "") as FonteId;
  const mes = String(formData.get("mes") || "");
  const observacao = String(formData.get("observacao") || "").trim().slice(0, 500);
  const arquivos = formData.getAll("arquivos").filter((f): f is File => f instanceof File && f.size > 0);

  const cliente = dashboardPorPasta(pasta);
  if (!cliente) return { ok: false, mensagem: "Escolha o cliente." };
  if (!FONTES.some((f) => f.id === fonte)) return { ok: false, mensagem: "Escolha a fonte dos dados." };
  if (!/^\d{4}-\d{2}$/.test(mes)) return { ok: false, mensagem: "Escolha o mês de referência." };
  if (arquivos.length === 0) return { ok: false, mensagem: "Selecione pelo menos um arquivo." };

  const recusados = arquivos.filter((a) => !extensaoAceita(a.name)).map((a) => a.name);
  if (recusados.length) {
    return { ok: false, mensagem: `Tipo de arquivo não aceito: ${recusados.join(", ")}. Use PDF, CSV, Excel ou imagem.` };
  }
  const total = arquivos.reduce((s, a) => s + a.size, 0);
  if (total > LIMITE_MB * 1024 * 1024) {
    return { ok: false, mensagem: `Os arquivos passam de ${LIMITE_MB} MB juntos. Envie em partes.` };
  }

  // Dashboards "em implantação" leem os dados direto; os completos têm histórico
  // montado pela equipe, então o arquivo lido fica Pendente para conferência.
  const automatico = cliente.status !== "completo";
  let lidos = 0;
  for (const arquivo of arquivos) {
    const info = await salvarArquivo({ pasta, fonte, mes, observacao, enviadoPor: quem, arquivo });
    const leitura = await lerAutomatico(pasta, fonte, arquivo);
    if (leitura) {
      await registrarLeitura(pasta, info.id, leitura, automatico);
      if (leitura.ok) lidos++;
    }
  }

  revalidatePath("/arquivos");
  revalidatePath("/dashboards");
  const n = arquivos.length;
  const enviados = `${n} arquivo${n > 1 ? "s" : ""} de ${cliente.nome} enviado${n > 1 ? "s" : ""}.`;
  if (lidos > 0 && !automatico) {
    return { ok: true, mensagem: `${enviados} Números lidos (veja abaixo). Como esse dashboard já tem histórico completo, fica "Pendente" para a equipe lançar.` };
  }
  if (lidos === n) return { ok: true, mensagem: `${enviados} Lido${n > 1 ? "s" : ""} automaticamente e já no dashboard.` };
  if (lidos > 0) return { ok: true, mensagem: `${enviados} ${lidos} lido(s) automaticamente; o resto fica como "Pendente".` };
  return { ok: true, mensagem: `${enviados} Fica como "Pendente" até ser lançado no dashboard.` };
}

export async function alternarStatus(formData: FormData) {
  const { quem } = await exigirEquipe();
  const pasta = String(formData.get("pasta") || "");
  const id = String(formData.get("id") || "");
  const status = formData.get("status") === "lancado" ? "lancado" : "pendente";
  await marcarStatus(pasta, id, status, quem);
  revalidatePath("/arquivos");
  revalidatePath("/dashboards");
}

export async function remover(formData: FormData) {
  await exigirEquipe();
  await removerArquivo(String(formData.get("pasta") || ""), String(formData.get("id") || ""));
  revalidatePath("/arquivos");
  revalidatePath("/dashboards");
}
