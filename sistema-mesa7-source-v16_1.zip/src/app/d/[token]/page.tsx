import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { dashboardPorToken } from "@/lib/dashboards";

// Link do cliente, sem senha: /d/<token>. Mostra só o dashboard, em tela
// cheia. O botão "Voltar" fica dentro do próprio dashboard.
export async function generateMetadata({ params }: PageProps<"/d/[token]">): Promise<Metadata> {
  const { token } = await params;
  const d = dashboardPorToken(token);
  return {
    title: d ? `Mesa7 — Dashboard ${d.nome}` : "Mesa7",
    robots: { index: false, follow: false },
    referrer: "no-referrer",
  };
}

export default async function DashboardClientePage({ params }: PageProps<"/d/[token]">) {
  const { token } = await params;
  const d = dashboardPorToken(token);
  if (!d) notFound();

  return (
    <iframe
      src={`/d/${d.token}/arquivo/index.html`}
      title={`Dashboard ${d.nome}`}
      style={{ position: "fixed", inset: 0, width: "100%", height: "100%", border: 0, background: "#0C0E36" }}
    />
  );
}
