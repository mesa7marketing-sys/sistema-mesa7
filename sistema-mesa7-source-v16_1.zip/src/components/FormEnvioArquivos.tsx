"use client";

import { useActionState, useRef, useState } from "react";
import { enviarArquivos, type EstadoEnvio } from "@/app/(app)/(hub)/arquivos/actions";

type Opcao = { value: string; label: string };

const campo: React.CSSProperties = {
  background: "var(--surface-2)",
  border: "1px solid var(--border-strong)",
  borderRadius: 9,
  padding: "9px 11px",
  color: "var(--text-primary)",
  fontSize: 14,
  fontFamily: "inherit",
  width: "100%",
};

const rotulo: React.CSSProperties = {
  display: "flex",
  flexDirection: "column",
  gap: 6,
  fontSize: 12,
  fontWeight: 700,
  color: "var(--text-secondary)",
};

export function FormEnvioArquivos({
  clientes,
  fontes,
  meses,
  clienteInicial,
  aceitos,
  limiteMb,
}: {
  clientes: Opcao[];
  fontes: Opcao[];
  meses: Opcao[];
  clienteInicial?: string;
  aceitos: string[];
  limiteMb: number;
}) {
  const [selecionados, setSelecionados] = useState<{ nome: string; tamanho: number }[]>([]);
  const [arrastando, setArrastando] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const [estado, acao, enviando] = useActionState<EstadoEnvio, FormData>(async (prev, fd) => {
    let r: EstadoEnvio;
    try {
      r = await enviarArquivos(prev, fd);
    } catch {
      r = { ok: false, mensagem: "Não consegui enviar. Se o arquivo for grande, tente em partes; se continuar, avise o Lucas." };
    }
    if (r?.ok) {
      setSelecionados([]);
      if (inputRef.current) inputRef.current.value = "";
    }
    return r;
  }, null);

  const total = selecionados.reduce((s, a) => s + a.tamanho, 0);
  const grande = total > limiteMb * 1024 * 1024;

  function atualizar(files: FileList | null) {
    setSelecionados(Array.from(files ?? []).map((f) => ({ nome: f.name, tamanho: f.size })));
  }

  return (
    <form action={acao} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 12 }}>
        <label style={rotulo}>
          Cliente
          <select name="pasta" defaultValue={clienteInicial ?? ""} required style={campo}>
            <option value="" disabled>
              Escolha…
            </option>
            {clientes.map((c) => (
              <option key={c.value} value={c.value}>
                {c.label}
              </option>
            ))}
          </select>
        </label>
        <label style={rotulo}>
          Fonte dos dados
          <select name="fonte" defaultValue="" required style={campo}>
            <option value="" disabled>
              Escolha…
            </option>
            {fontes.map((f) => (
              <option key={f.value} value={f.value}>
                {f.label}
              </option>
            ))}
          </select>
        </label>
        <label style={rotulo}>
          Mês de referência
          <select name="mes" defaultValue={meses[1]?.value ?? meses[0]?.value} required style={campo}>
            {meses.map((m) => (
              <option key={m.value} value={m.value}>
                {m.label}
              </option>
            ))}
          </select>
        </label>
      </div>

      <label
        onDragOver={(e) => {
          e.preventDefault();
          setArrastando(true);
        }}
        onDragLeave={() => setArrastando(false)}
        onDrop={(e) => {
          e.preventDefault();
          setArrastando(false);
          if (inputRef.current && e.dataTransfer.files.length) {
            inputRef.current.files = e.dataTransfer.files;
            atualizar(e.dataTransfer.files);
          }
        }}
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 6,
          padding: "22px 16px",
          borderRadius: 12,
          border: `1.5px dashed ${arrastando ? "var(--accent)" : "var(--border-strong)"}`,
          background: arrastando ? "var(--accent-soft)" : "var(--surface-2)",
          cursor: "pointer",
          textAlign: "center",
          position: "relative",
        }}
      >
        <svg width={26} height={26} viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="M12 16V4M7 9l5-5 5 5M4 16v4h16v-4" />
        </svg>
        <span style={{ fontWeight: 800, fontSize: 14 }}>Clique para escolher ou arraste os arquivos aqui</span>
        <span style={{ fontSize: 12, color: "var(--text-muted)" }}>
          PDF, CSV, Excel ou print (PNG/JPG) · até {limiteMb} MB por envio · pode mandar vários de uma vez
        </span>
        <input
          ref={inputRef}
          type="file"
          name="arquivos"
          multiple
          required
          accept={aceitos.join(",")}
          onChange={(e) => atualizar(e.target.files)}
          style={{ position: "absolute", width: 1, height: 1, opacity: 0 }}
        />
      </label>

      {selecionados.length > 0 && (
        <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 4, fontSize: 13 }}>
          {selecionados.map((a) => (
            <li key={a.nome} style={{ display: "flex", justifyContent: "space-between", gap: 10, color: "var(--text-secondary)" }}>
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.nome}</span>
              <span style={{ color: "var(--text-muted)", flex: "none" }}>{(a.tamanho / 1024 / 1024).toFixed(1).replace(".", ",")} MB</span>
            </li>
          ))}
          {grande && (
            <li style={{ color: "var(--status-critical)", fontWeight: 700 }}>
              Passa de {limiteMb} MB juntos — envie em partes.
            </li>
          )}
        </ul>
      )}

      <label style={rotulo}>
        Observação (opcional)
        <input name="observacao" maxLength={500} placeholder="Ex.: relatório semanal 01–07/09, só delivery" style={campo} />
      </label>

      <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
        <button
          type="submit"
          disabled={enviando || grande}
          style={{
            background: "var(--accent)",
            color: "var(--accent-ink)",
            border: "none",
            borderRadius: 9,
            padding: "11px 22px",
            fontWeight: 800,
            fontSize: 14,
            cursor: enviando ? "wait" : "pointer",
            opacity: enviando || grande ? 0.6 : 1,
            fontFamily: "inherit",
          }}
        >
          {enviando ? "Enviando…" : "Enviar arquivos"}
        </button>
        {estado && (
          <span
            role="status"
            style={{
              fontSize: 13,
              fontWeight: 700,
              color: estado.ok ? "var(--status-good)" : "var(--status-critical)",
            }}
          >
            {estado.ok ? "✓ " : ""}
            {estado.mensagem}
          </span>
        )}
      </div>
    </form>
  );
}
