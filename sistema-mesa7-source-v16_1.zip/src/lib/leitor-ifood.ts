// Leitura automática do relatório de desempenho exportado pelo Portal do
// Parceiro iFood (planilha com as abas "Vendas", "Horário com mais vendas",
// "Formas de pagamento utilizadas" e "Dias com mais vendas"). Aceita o .xlsx
// completo ou o .csv da aba Vendas.
import ExcelJS from "exceljs";

export type IfoodMes = {
  /** AAAA-MM do início do período do relatório. */
  mes: string;
  periodo: string;
  lojas: string[];
  /** Pedidos, faturamento (R$), taxa de entrega (R$), ticket médio (R$), novos clientes. */
  o: number;
  r: number;
  taxa: number;
  t: number;
  novos: number;
  /** Por logística (Entrega própria, Entrega parceira, Retirada...). */
  log: Record<string, { o: number; r: number }>;
  pg: Record<string, number>;
  dias: Record<string, number>;
  horas: { semana: Record<string, number>; fds: Record<string, number> };
};

function norm(s: unknown) {
  return String(s ?? "")
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .trim();
}

/** "R$ 2,863.99", "R$ 2.863,99", "2863.99" ou número → 2863.99 */
export function numero(v: unknown): number {
  if (typeof v === "number") return v;
  let s = String(v ?? "").replace(/[R$\s]/g, "");
  if (!s) return 0;
  const virg = s.lastIndexOf(",");
  const ponto = s.lastIndexOf(".");
  if (virg > -1 && ponto > -1) {
    s = virg > ponto ? s.replace(/\./g, "").replace(",", ".") : s.replace(/,/g, "");
  } else if (virg > -1) {
    s = /,\d{1,2}$/.test(s) ? s.replace(",", ".") : s.replace(/,/g, "");
  }
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}

function mesDoPeriodo(periodo: string) {
  const m = periodo.match(/(\d{2})\/(\d{2})\/(\d{4})/);
  return m ? `${m[3]}-${m[2]}` : null;
}

/** Acha a coluna cujo título contém todos os pedaços (sem acento, minúsculo). */
function col(cab: string[], ...pedacos: string[]) {
  return cab.findIndex((c) => pedacos.every((p) => c.includes(p)));
}

function tabela(linhas: unknown[][]) {
  const iCab = linhas.findIndex((l) => l.some((c) => norm(c) === "periodo"));
  if (iCab < 0) return null;
  const cab = linhas[iCab].map(norm);
  return { cab, dados: linhas.slice(iCab + 1).filter((l) => l.some((c) => String(c ?? "").trim() !== "")) };
}

function valorCelula(v: ExcelJS.CellValue): unknown {
  if (v && typeof v === "object") {
    if ("result" in v) return v.result;
    if ("text" in v) return v.text;
    if ("richText" in v) return v.richText.map((r) => r.text).join("");
  }
  return v;
}

async function abasDoXlsx(buf: Buffer) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buf as unknown as ArrayBuffer);
  const abas: Record<string, unknown[][]> = {};
  wb.eachSheet((ws) => {
    const linhas: unknown[][] = [];
    ws.eachRow({ includeEmpty: false }, (row) => {
      const vals = (row.values as ExcelJS.CellValue[]).slice(1).map(valorCelula);
      linhas.push(vals);
    });
    abas[norm(ws.name)] = linhas;
  });
  return abas;
}

function linhasDoCsv(texto: string): unknown[][] {
  const limpo = texto.replace(/^﻿/, "");
  const primeira = limpo.split(/\r?\n/, 1)[0] ?? "";
  const sep = (primeira.match(/;/g)?.length ?? 0) > (primeira.match(/,/g)?.length ?? 0) ? ";" : ",";
  const linhas: string[][] = [];
  let campo = "";
  let linha: string[] = [];
  let aspas = false;
  for (let i = 0; i < limpo.length; i++) {
    const c = limpo[i];
    if (aspas) {
      if (c === '"' && limpo[i + 1] === '"') {
        campo += '"';
        i++;
      } else if (c === '"') aspas = false;
      else campo += c;
    } else if (c === '"') aspas = true;
    else if (c === sep) {
      linha.push(campo);
      campo = "";
    } else if (c === "\n" || c === "\r") {
      if (c === "\r" && limpo[i + 1] === "\n") i++;
      linha.push(campo);
      linhas.push(linha);
      linha = [];
      campo = "";
    } else campo += c;
  }
  if (campo || linha.length) {
    linha.push(campo);
    linhas.push(linha);
  }
  return linhas;
}

function soma<T extends string>(obj: Record<T, number>, k: T, n: number) {
  obj[k] = (obj[k] ?? 0) + n;
}

/**
 * Lê o relatório e devolve um resumo por mês. Lança erro com mensagem
 * amigável quando o arquivo não está no formato do Portal do Parceiro.
 */
export async function lerRelatorioIfood(nomeArquivo: string, buf: Buffer): Promise<IfoodMes[]> {
  const ext = nomeArquivo.toLowerCase().split(".").pop();
  let abas: Record<string, unknown[][]>;
  if (ext === "xlsx") abas = await abasDoXlsx(buf);
  else if (ext === "csv") abas = { vendas: linhasDoCsv(buf.toString("utf8")) };
  else throw new Error("A leitura automática do iFood aceita .xlsx ou .csv.");

  const vendas = tabela(abas["vendas"] ?? Object.values(abas)[0] ?? []);
  const iPed = vendas ? col(vendas.cab, "total de vendas", "pedidos") : -1;
  const iVal = vendas ? col(vendas.cab, "valor total") : -1;
  if (!vendas || iPed < 0 || iVal < 0) {
    throw new Error('Não reconheci o formato. Use o relatório de desempenho do Portal do Parceiro iFood (aba "Vendas").');
  }
  const c = vendas.cab;
  const iPer = col(c, "periodo");
  const iLog = col(c, "logistica");
  const iLoja = col(c, "nome da loja");
  const iTaxa = col(c, "taxa de entrega");
  const iNovos = col(c, "novos clientes");

  const meses = new Map<string, IfoodMes>();
  const doMes = (periodo: string) => {
    const mes = mesDoPeriodo(periodo);
    if (!mes) return null;
    let m = meses.get(mes);
    if (!m) {
      m = { mes, periodo, lojas: [], o: 0, r: 0, taxa: 0, t: 0, novos: 0, log: {}, pg: {}, dias: {}, horas: { semana: {}, fds: {} } };
      meses.set(mes, m);
    }
    return m;
  };

  for (const l of vendas.dados) {
    const m = doMes(String(l[iPer] ?? ""));
    if (!m) continue;
    const o = numero(l[iPed]);
    const r = numero(l[iVal]);
    m.o += o;
    m.r += r;
    if (iTaxa >= 0) m.taxa += numero(l[iTaxa]);
    if (iNovos >= 0) m.novos += numero(l[iNovos]);
    const log = iLog >= 0 ? String(l[iLog] ?? "").trim() || "Outros" : "Total";
    m.log[log] = { o: (m.log[log]?.o ?? 0) + o, r: (m.log[log]?.r ?? 0) + r };
    const loja = iLoja >= 0 ? String(l[iLoja] ?? "").trim() : "";
    if (loja && !m.lojas.includes(loja)) m.lojas.push(loja);
  }
  if (meses.size === 0) throw new Error("O relatório não tem nenhuma linha de vendas com período.");

  const extra = (nomeAba: string, fn: (m: IfoodMes, l: unknown[], cab: string[]) => void) => {
    const t = abas[nomeAba] ? tabela(abas[nomeAba]) : null;
    if (!t) return;
    const ip = col(t.cab, "periodo");
    for (const l of t.dados) {
      const m = meses.get(mesDoPeriodo(String(l[ip] ?? "")) ?? "");
      if (m) fn(m, l, t.cab);
    }
  };
  extra("formas de pagamento utilizadas", (m, l, cab) => {
    soma(m.pg, String(l[col(cab, "forma de pagamento")] ?? "Outros").trim(), numero(l[col(cab, "total de vendas")]));
  });
  extra("dias com mais vendas", (m, l, cab) => {
    soma(m.dias, String(l[col(cab, "dias")] ?? "").trim(), numero(l[col(cab, "total de vendas")]));
  });
  extra("horario com mais vendas", (m, l, cab) => {
    // Essa aba tem duas colunas "Período": a do relatório e a da semana/fim de semana.
    const iSemana = cab.findIndex((h, i) => h === "periodo" && i > 0);
    const fds = norm(l[iSemana]).includes("final");
    soma(fds ? m.horas.fds : m.horas.semana, String(l[col(cab, "horario")] ?? "").trim(), numero(l[col(cab, "total de vendas")]));
  });

  return [...meses.values()]
    .map((m) => ({
      ...m,
      r: Math.round(m.r * 100) / 100,
      taxa: Math.round(m.taxa * 100) / 100,
      t: m.o ? Math.round((m.r / m.o) * 100) / 100 : 0,
    }))
    .sort((a, b) => a.mes.localeCompare(b.mes));
}
