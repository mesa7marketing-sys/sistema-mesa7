/* =========================================================
   Mesa7 — Esqueleto de dashboard (padrão Taverna dos Pandas)
   Usado pelos clientes que ainda não têm base de dados completa.
   Cada HTML define window.CLIENTE = {nome, seg, icone, logo}
   e carrega este arquivo. O Sistema Mesa7 injeta window.M7_DADOS
   ({ifood:{AAAA-MM:...}, meta:{AAAA-MM:...}}) com o que já chegou
   (uploads da equipe e integrações); o resto aparece como
   "Aguardando dados".
   ========================================================= */
(function () {
  var C = window.CLIENTE || { nome: 'Cliente', seg: '', icone: 'fa-utensils', logo: '' };
  document.title = 'Mesa7 — Dashboard ' + C.nome;

  function addHead(tag, attrs) {
    var el = document.createElement(tag);
    for (var k in attrs) el.setAttribute(k, attrs[k]);
    document.head.appendChild(el);
  }
  addHead('link', { rel: 'preconnect', href: 'https://fonts.googleapis.com' });
  addHead('link', { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap' });
  addHead('link', { rel: 'stylesheet', href: 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css' });

  var css = [
    ':root{--m7-orange:#F98612;--m7-cream:#F4F2EA;--m7-blue:#9BAED9;--m7-navy-deep:#101243;--m7-navy:#1A2361;--bg-main:#0C0E36;--bg-panel:#101243;--bg-card:#1A2361;--bg-hover:#26307E;--border:rgba(155,174,217,.18);--border-strong:rgba(155,174,217,.32);--primary-glow:rgba(249,134,18,.14);--text-muted:#9BAED9;--text-sub:#D6DEF0}',
    '*{box-sizing:border-box;margin:0;padding:0}',
    'body{background:var(--bg-main);color:var(--m7-cream);font-family:Poppins,sans-serif;display:flex;min-height:100vh;overflow-x:hidden;-webkit-font-smoothing:antialiased}',
    'h1,.kpi-value,.brand-title,.chart-title{letter-spacing:-.03em}',
    'aside{width:262px;background:var(--bg-panel);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;height:100vh;z-index:100}',
    '.brand-header{padding:24px 20px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px}',
    '.brand-logo{width:40px;height:40px;background:var(--m7-orange);border-radius:11px;display:flex;align-items:center;justify-content:center;color:var(--m7-navy-deep);font-weight:700;font-size:16px;letter-spacing:-.05em}',
    '.brand-title{font-size:19px;font-weight:600;line-height:1.15}',
    '.brand-title span{color:var(--m7-orange);font-size:10px;display:block;text-transform:uppercase;letter-spacing:1.8px;font-weight:500;margin-top:2px}',
    '.client-block{padding:16px 16px 18px;border-bottom:1px solid var(--border);background:rgba(155,174,217,.04)}',
    '.client-label{font-size:10px;text-transform:uppercase;letter-spacing:1.4px;color:var(--text-muted);font-weight:600;opacity:.75;margin-bottom:10px;display:block}',
    '.client-card{display:flex;align-items:center;gap:11px;background:var(--bg-card);border:1px solid var(--border-strong);border-radius:11px;padding:11px 13px}',
    '.client-mark{width:38px;height:38px;border-radius:9px;background:#232323;display:flex;align-items:center;justify-content:center;flex:0 0 auto;overflow:hidden}',
    '.client-mark i{color:#fff;font-size:15px}.client-mark img{width:100%;height:100%;object-fit:contain}',
    '.client-name{font-size:14px;font-weight:600;line-height:1.2}',
    '.client-seg{font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.9px;margin-top:2px;font-weight:500}',
    '.nav-menu{list-style:none;padding:14px 12px;flex-grow:1;overflow-y:auto}',
    '.nav-label{font-size:10px;text-transform:uppercase;letter-spacing:1.4px;color:var(--text-muted);padding:10px 12px 8px;font-weight:600;opacity:.75}',
    '.nav-item{display:flex;align-items:center;gap:12px;padding:11px 14px;color:var(--text-sub);border-radius:10px;cursor:pointer;font-size:13.5px;font-weight:500;transition:all .2s ease;margin-bottom:3px;border:1px solid transparent}',
    '.nav-item:hover{background:var(--bg-hover);color:var(--m7-cream)}',
    '.nav-item.active{background:var(--primary-glow);color:var(--m7-orange);border-color:rgba(249,134,18,.35);font-weight:600}',
    '.nav-item i{width:18px;font-size:15px;text-align:center}',
    '.sidebar-footer{padding:16px;border-top:1px solid var(--border);font-size:11.5px;color:var(--text-muted);text-align:center}',
    'main{margin-left:262px;flex-grow:1;padding:26px 34px 60px;max-width:calc(100vw - 262px)}',
    'header.top-bar{display:flex;align-items:center;gap:14px;margin-bottom:24px;padding-bottom:18px;border-bottom:1px solid var(--border)}',
    '.page-title h1{font-size:27px;font-weight:600;display:flex;align-items:center;gap:11px}',
    '.page-title p{color:var(--text-muted);font-size:13px;margin-top:3px}',
    '.aviso{display:flex;gap:12px;align-items:flex-start;background:linear-gradient(135deg,rgba(249,134,18,.10),rgba(155,174,217,.06));border:1px solid rgba(249,134,18,.28);border-radius:14px;padding:18px 20px;margin-bottom:22px;font-size:12.5px;color:var(--text-sub);line-height:1.6}',
    '.aviso i{color:var(--m7-orange);font-size:17px;margin-top:2px}.aviso b{color:var(--m7-orange)}',
    '.view-page{display:none}.view-page.active{display:block;animation:fadeIn .28s ease}',
    '@keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}',
    '.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin-bottom:22px}',
    '.kpi-card{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:20px;position:relative;overflow:hidden}',
    '.kpi-card::before{content:"";position:absolute;top:0;left:0;width:100%;height:3px;background:var(--m7-orange)}',
    '.kpi-card:nth-child(2)::before{background:var(--m7-blue)}.kpi-card:nth-child(3)::before{background:var(--m7-cream)}.kpi-card:nth-child(4)::before{background:linear-gradient(90deg,var(--m7-orange),var(--m7-blue))}',
    '.kpi-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:9px;gap:8px}',
    '.kpi-label{font-size:12px;color:var(--text-muted);font-weight:500}.kpi-icon{font-size:15px;color:var(--text-muted);opacity:.7}',
    '.kpi-value{font-size:16px;font-weight:400;font-style:italic;color:var(--text-muted);line-height:1.6}',
    '.grid-2{display:grid;grid-template-columns:repeat(auto-fit,minmax(440px,1fr));gap:18px;margin-bottom:22px}',
    '.chart-card{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:22px}',
    '.chart-title{font-size:16px;font-weight:600;display:flex;align-items:center;gap:9px;margin-bottom:14px}.chart-title i{color:var(--m7-orange);font-size:15px}',
    '.data-table{width:100%;border-collapse:collapse;font-size:13px}',
    '.data-table td{padding:11px 14px;border-bottom:1px solid var(--border);color:var(--text-sub)}',
    '.data-table tr:last-child td{border-bottom:none}',
    '.wait{color:var(--text-muted);font-style:italic}',
    '.menu-toggle{display:none;flex:0 0 auto;width:42px;height:42px;border-radius:11px;background:var(--bg-card);border:1px solid var(--border-strong);color:var(--m7-orange);font-size:17px;cursor:pointer;align-items:center;justify-content:center}',
    '.sidebar-close{display:none;background:transparent;border:none;color:var(--text-muted);font-size:20px;cursor:pointer;margin-left:auto}',
    '.overlay{display:none;position:fixed;inset:0;z-index:99;background:rgba(12,14,54,.72);backdrop-filter:blur(3px)}.overlay.show{display:block}',
    '.kpi-value.ok{font-size:25px;font-weight:600;font-style:normal;color:var(--m7-cream);line-height:1.25}',
    '.kpi-sub{font-size:11.5px;color:var(--text-muted);margin-top:5px}',
    '.data-table td.v{text-align:right;color:var(--m7-cream);font-weight:600;white-space:nowrap}',
    '.data-table th{padding:9px 14px;text-align:left;font-size:10.5px;text-transform:uppercase;letter-spacing:.8px;color:var(--text-muted);font-weight:600;border-bottom:1px solid var(--border-strong)}',
    '.data-table th.v{text-align:right}',
    '.filtro{display:flex;align-items:flex-end;gap:12px;margin-bottom:20px;flex-wrap:wrap}',
    '.filtro label{display:flex;flex-direction:column;gap:6px;font-size:10.5px;text-transform:uppercase;letter-spacing:1.2px;color:var(--text-muted);font-weight:600}',
    '.filtro select{background:var(--bg-card);color:var(--m7-cream);border:1px solid var(--border-strong);border-radius:10px;padding:10px 14px;font-family:inherit;font-size:13.5px;min-width:200px}',
    '.tabela-scroll{overflow-x:auto;-webkit-overflow-scrolling:touch}.chart-card{min-width:0}',
    '@media (max-width:560px){.grid-2{grid-template-columns:minmax(0,1fr)}.chart-card{padding:16px}.data-table td,.data-table th{padding:9px 8px}.filtro select{min-width:0;width:100%}.filtro label{flex:1}}',
    '.fonte{font-size:11px;color:var(--text-muted);margin-top:10px;opacity:.85}',
    '.tag{display:inline-block;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.6px;border-radius:99px;padding:2px 8px;margin-left:6px;background:rgba(155,174,217,.14);color:var(--text-muted);vertical-align:middle}',
    '@media (max-width:1100px){.grid-2{grid-template-columns:1fr}}',
    '@media (max-width:900px){aside{transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1);width:280px}body.nav-open aside{transform:none;box-shadow:0 0 44px rgba(0,0,0,.55)}main{margin-left:0;max-width:100vw;padding:18px 16px 48px}.menu-toggle{display:flex}.sidebar-close{display:block}.page-title h1{font-size:21px}.kpi-grid{grid-template-columns:repeat(auto-fit,minmax(158px,1fr));gap:12px}}',
    '@media (max-width:560px){.kpi-grid{grid-template-columns:1fr 1fr}}'
  ].join('\n');
  var st = document.createElement('style');
  st.textContent = css;
  document.head.appendChild(st);

  // ---------- dados recebidos ----------
  var D = window.M7_DADOS || {};
  var IF = D.ifood || {}, MT = D.meta || {};
  var MESES_N = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  function mesLbl(id) { var p = id.split('-'); return MESES_N[+p[1] - 1] + '/' + p[0]; }
  function mesCurto(id) { var p = id.split('-'); return MESES_N[+p[1] - 1].slice(0, 3) + '/' + p[0].slice(2); }
  var comDados = Object.keys(IF).concat(Object.keys(MT)).filter(function (m, i, a) { return a.indexOf(m) === i; }).sort();
  // O seletor lista todos os meses, do primeiro com dado até o último mês fechado
  // (ou o último com dado, se for mais recente) — assim o mês corrente do calendário
  // já aparece mesmo quando o cliente ainda não tem número lançado.
  function proxMes(id) { var p = id.split('-'); var y = +p[0], m = +p[1] + 1; if (m > 12) { m = 1; y++; } return y + '-' + (m < 10 ? '0' : '') + m; }
  var hoje = new Date(), pm = hoje.getMonth() === 0 ? (hoje.getFullYear() - 1) + '-12' : hoje.getFullYear() + '-' + (hoje.getMonth() < 10 ? '0' : '') + hoje.getMonth();
  var ini = comDados[0] || pm, fim = comDados.length && comDados[comDados.length - 1] > pm ? comDados[comDados.length - 1] : pm;
  var meses = [];
  for (var mm0 = ini; mm0 <= fim && meses.length < 60; mm0 = proxMes(mm0)) meses.push(mm0);
  meses.reverse();
  var comIfood = meses.filter(function (m) { return IF[m]; });
  var mesSel = meses[0] || null;

  function brl(n) { return 'R$ ' + Number(n || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function num(n) { return Number(n || 0).toLocaleString('pt-BR'); }
  function pct(a, b) { return b ? (a / b * 100).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%' : '—'; }
  function maior(obj) { var k = null; for (var x in obj) if (k === null || obj[x] > obj[k]) k = x; return k; }
  function somaHoras(h) { var o = {}; ['semana', 'fds'].forEach(function (g) { var s = (h || {})[g] || {}; for (var k in s) o[k] = (o[k] || 0) + s[k]; }); return o; }
  function ate(m) { return m && m.ate ? ' (até ' + m.ate.split('-').reverse().slice(0, 2).join('/') + ')' : ''; }

  // Cada chave devolve {v, sub} quando há dado no mês, ou null (Aguardando dados).
  var VAL = {
    ifood_r: function (i) { return i && { v: brl(i.r), sub: num(i.o) + ' pedidos · ticket ' + brl(i.t) }; },
    ifood_o: function (i) { return i && { v: num(i.o), sub: num(i.novos) + ' clientes novos' }; },
    ifood_t: function (i) { return i && { v: brl(i.t), sub: 'ticket médio no iFood' }; },
    mkt: function (i) { return i && { v: brl(i.r), sub: 'iFood · ' + num(i.o) + ' pedidos' }; },
    meta_gas: function (i, m) { return m && { v: brl(m.gas), sub: 'Meta Ads' + ate(m) }; },
    meta_alc: function (i, m) { return m && { v: num(m.alc), sub: num(m.imp) + ' impressões' }; },
    meta_clk: function (i, m) { return m && { v: num(m.clk), sub: m.clk ? 'custo por clique ' + brl(m.gas / m.clk) : '' }; },
    meta_cmp: function (i, m) { return m && (m.cmp ? { v: num(m.cmp), sub: 'valor atribuído ' + brl(m.fat) } : { v: '0', sub: 'sem compras rastreadas pelo pixel' }); },
    dia: function (i) { var k = i && maior(i.dias); return k && { v: k, sub: num(i.dias[k]) + ' pedidos no iFood' }; },
    pico: function (i) { var h = i && somaHoras(i.horas), k = h && maior(h); return k && { v: k, sub: num(h[k]) + ' pedidos no iFood' }; },
    fds: function (i) { if (!i || !i.dias) return null; var t = 0, f = 0; for (var k in i.dias) { t += i.dias[k]; if (/sexta|s.bado|domingo/i.test(k)) f += i.dias[k]; } return t ? { v: pct(f, t), sub: 'dos pedidos do iFood' } : null; }
  };

  var PAGES = [
    { id: 'p1', icon: 'fa-gauge-high', t: 'Resumo Executivo', s: 'Visão rápida de performance e saúde financeira em 30 segundos.',
      kpis: [['Faturamento', 'fa-sack-dollar'], ['Pedidos', 'fa-bag-shopping'], ['Ticket Médio', 'fa-receipt'], ['Mix de Canais', 'fa-layer-group']],
      recebidos: true,
      cards: [['Evolução de Faturamento', 'fa-chart-line', [['Faturamento mensal'], ['Comparativo MoM / YoY']]], ['Comparativo de Período', 'fa-scale-balanced', [['Faturamento Total'], ['Salão / Loja'], ['Delivery'], ['Invest. Mídia', 'meta_gas']]]] },
    { id: 'p2', icon: 'fa-filter', t: 'Método CVR', s: 'Conversão, Valor e Relacionamento do restaurante.',
      cards: [['1. Conversão', 'fa-filter', [['Investimento em Mídia', 'meta_gas'], ['Alcance (Meta Ads)', 'meta_alc'], ['Cliques no Link', 'meta_clk'], ['Compras Atribuídas', 'meta_cmp']]], ['2. Valor · Google Meu Negócio', 'fa-star', [['Visualizações do Perfil'], ['Solicitações de Rota'], ['Chamadas Telefônicas'], ['Nota Média Atual']]]] },
    { id: 'p3', icon: 'fa-chart-pie', t: 'Financeiro & Canais', s: 'Composição do faturamento por canal.',
      kpis: [['Salão / Loja', 'fa-utensils'], ['Delivery Próprio', 'fa-motorcycle'], ['Marketplace', 'fa-shop', 'mkt'], ['Faturamento Total', 'fa-chart-simple']] },
    { id: 'p4', icon: 'fa-store', t: 'Plataformas', s: 'Canais próprios versus marketplaces e o impacto no ticket.',
      kpis: [['iFood', 'fa-bowl-food', 'ifood_r'], ['99Food', 'fa-motorcycle'], ['Site / Cardápio Próprio', 'fa-mobile-screen'], ['Ticket Próprio vs Marketplace', 'fa-arrow-right-arrow-left']],
      ifoodDet: true },
    { id: 'p5', icon: 'fa-bullhorn', t: 'Marketing 360°', s: 'Meta Ads, Google Ads e Google Meu Negócio.',
      cards: [['Meta Ads', 'fa-hashtag', [['Investimento', 'meta_gas'], ['Alcance', 'meta_alc'], ['Cliques no Link', 'meta_clk'], ['Compras Atribuídas', 'meta_cmp'], ['Seguidores']]], ['Google Ads & Meu Negócio', 'fa-magnifying-glass', [['Investimento Google Ads'], ['Conversões'], ['Visualizações do Perfil'], ['Solicitações de Rota']]]],
      metaHist: true },
    { id: 'p6', icon: 'fa-utensils', t: 'Cardápio & ABC', s: 'Engenharia de menu e ranking dos itens mais vendidos.',
      kpis: [['Maior Faturamento', 'fa-crown'], ['Maior Volume', 'fa-ranking-star'], ['Itens com Venda', 'fa-list'], ['Concentração Top 5', 'fa-layer-group']] },
    { id: 'p7', icon: 'fa-clock', t: 'Comportamento', s: 'Quando o cliente compra ao longo da semana e do dia.',
      kpis: [['Melhor Dia', 'fa-star', 'dia'], ['Melhor Ticket', 'fa-receipt'], ['Horário de Pico', 'fa-clock', 'pico'], ['Concentração Sex–Dom', 'fa-fire', 'fds']] },
    { id: 'p8', icon: 'fa-bullseye', t: 'Metas 30/60/90', s: 'Planejamento estratégico organizado pelo Método CVR.',
      cards: [['30 dias · Organização', 'fa-layer-group', [['Conversão'], ['Valor'], ['Relacionamento']]], ['60 dias · Otimização', 'fa-sliders', [['Conversão'], ['Valor'], ['Relacionamento']]], ['90 dias · Escala', 'fa-rocket', [['Conversão'], ['Valor'], ['Relacionamento']]]] }
  ];

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var WAIT = '<span class="wait">Aguardando dados</span>';

  function valor(chave) {
    if (!chave || !mesSel || !VAL[chave]) return null;
    return VAL[chave](IF[mesSel], MT[mesSel]) || null;
  }
  function kpi(k) {
    var r = valor(k[2]);
    return '<div class="kpi-card"><div class="kpi-header"><span class="kpi-label">' + esc(k[0]) + '</span><i class="fa-solid ' + k[1] + ' kpi-icon"></i></div>' +
      (r ? '<div class="kpi-value ok">' + esc(r.v) + '</div>' + (r.sub ? '<div class="kpi-sub">' + esc(r.sub) + '</div>' : '') : '<div class="kpi-value">Aguardando dados</div>') + '</div>';
  }
  function linha(r) {
    var x = valor(r[1]);
    return '<tr><td>' + esc(r[0]) + '</td>' + (x ? '<td class="v">' + esc(x.v) + '</td>' : '<td>' + WAIT + '</td>') + '</tr>';
  }
  function card(titulo, icone, corpo, rodape) {
    return '<div class="chart-card"><div class="chart-title"><i class="fa-solid ' + icone + '"></i> ' + titulo + '</div><div class="tabela-scroll">' + corpo + '</div>' + (rodape ? '<div class="fonte">' + esc(rodape) + '</div>' : '') + '</div>';
  }

  function recebidos() {
    var i = IF[mesSel], m = MT[mesSel];
    if (!i && !m) return '';
    return '<div class="kpi-grid">' + [
      ['iFood · Faturamento', 'fa-bowl-food', 'ifood_r'], ['iFood · Pedidos', 'fa-bag-shopping', 'ifood_o'],
      ['Investimento Meta Ads', 'fa-hashtag', 'meta_gas'], ['Alcance Meta Ads', 'fa-users', 'meta_alc']
    ].map(kpi).join('') + '</div>';
  }

  function ifoodDetalhe() {
    var i = IF[mesSel];
    if (!i) return '';
    var log = Object.keys(i.log || {}).map(function (k) { return '<tr><td>' + esc(k) + '</td><td class="v">' + num(i.log[k].o) + '</td><td class="v">' + brl(i.log[k].r) + '</td></tr>'; }).join('');
    var pg = Object.keys(i.pg || {}).sort(function (a, b) { return i.pg[b] - i.pg[a]; }).slice(0, 5)
      .map(function (k) { return '<tr><td>' + esc(k) + '</td><td class="v">' + num(i.pg[k]) + '</td><td class="v">' + pct(i.pg[k], i.o) + '</td></tr>'; }).join('');
    var tab1 = '<table class="data-table"><thead><tr><th>Logística</th><th class="v">Pedidos</th><th class="v">Faturamento</th></tr></thead><tbody>' + log +
      '<tr><td>Clientes novos</td><td class="v">' + num(i.novos) + '</td><td class="v">' + pct(i.novos, i.o) + ' dos pedidos</td></tr>' +
      '<tr><td>Taxa de entrega cobrada</td><td></td><td class="v">' + brl(i.taxa) + '</td></tr></tbody></table>';
    var tab2 = '<table class="data-table"><thead><tr><th>Forma de pagamento</th><th class="v">Pedidos</th><th class="v">%</th></tr></thead><tbody>' + pg + '</tbody></table>';
    var fonte = 'Fonte: relatório do Portal do Parceiro iFood · ' + (i.periodo || mesLbl(mesSel));
    return '<div class="grid-2">' + card('iFood · ' + esc(mesLbl(mesSel)), 'fa-bowl-food', tab1, fonte) + card('iFood · Pagamentos', 'fa-credit-card', tab2, fonte) + '</div>';
  }

  function metaHistorico() {
    var ms = Object.keys(MT).sort().reverse();
    if (!ms.length) return '';
    var linhas = ms.map(function (id) {
      var m = MT[id];
      return '<tr><td>' + esc(mesCurto(id)) + (m.ate ? '<span class="tag">parcial</span>' : '') + '</td><td class="v">' + brl(m.gas) + '</td><td class="v">' + num(m.alc) + '</td><td class="v">' + num(m.clk) + '</td><td class="v">' + (m.clk ? brl(m.gas / m.clk) : '—') + '</td><td class="v">' + num(m.cmp) + '</td></tr>';
    }).join('');
    var t = '<table class="data-table"><thead><tr><th>Mês</th><th class="v">Investimento</th><th class="v">Alcance</th><th class="v">Cliques</th><th class="v">CPC</th><th class="v">Compras</th></tr></thead><tbody>' + linhas + '</tbody></table>';
    return '<div class="grid-2">' + card('Meta Ads · mês a mês', 'fa-calendar', t, 'Fonte: integração Meta Ads da Mesa7') + '</div>';
  }

  function aviso() {
    var tem = [];
    if (comIfood.length) tem.push('iFood (' + comIfood.slice().reverse().map(mesCurto).join(', ') + ')');
    var mm = Object.keys(MT).sort();
    if (mm.length) tem.push('Meta Ads (' + (mm.length > 1 ? mesCurto(mm[0]) + ' a ' + mesCurto(mm[mm.length - 1]) : mesCurto(mm[0])) + ')');
    if (!tem.length) return '<div class="aviso"><i class="fa-solid fa-circle-info"></i><div><b>Dados a caminho.</b> Os indicadores de ' + esc(C.nome) + ' aparecem aqui assim que os dados do cliente forem enviados à Mesa7 (faturamento, iFood, Meta Ads, Google e CRM).</div></div>';
    return '<div class="aviso"><i class="fa-solid fa-circle-info"></i><div><b>Dados recebidos:</b> ' + esc(tem.join(' e ')) + '. Faturamento de salão e delivery próprio, Google e CRM aparecem aqui assim que chegarem.</div></div>';
  }

  function filtro() {
    if (!meses.length) return '';
    return '<div class="filtro"><label>Período<select id="selMes">' + meses.map(function (m) {
      var tags = [IF[m] ? 'iFood' : '', MT[m] ? 'Meta' : ''].filter(Boolean).join(' + ') || 'aguardando dados';
      return '<option value="' + m + '"' + (m === mesSel ? ' selected' : '') + '>' + esc(mesLbl(m)) + ' · ' + tags + '</option>';
    }).join('') + '</select></label></div>';
  }

  function pageHtml(p, i) {
    var h = '<div id="' + p.id + '" class="view-page' + (i === 0 ? ' active' : '') + '">';
    if (i === 0) h += aviso();
    if (p.recebidos) h += recebidos();
    if (p.kpis) h += '<div class="kpi-grid">' + p.kpis.map(kpi).join('') + '</div>';
    if (p.ifoodDet) h += ifoodDetalhe();
    if (p.cards) {
      h += '<div class="grid-2">' + p.cards.map(function (c) {
        return card(esc(c[0]), c[1], '<table class="data-table"><tbody>' + c[2].map(linha).join('') + '</tbody></table>');
      }).join('') + '</div>';
    }
    if (p.metaHist) h += metaHistorico();
    return h + '</div>';
  }

  var mark = C.logo
    ? '<img src="' + esc(C.logo) + '" alt="' + esc(C.nome) + '" onerror="this.parentNode.innerHTML=\'<i class=&quot;fa-solid ' + esc(C.icone) + '&quot;></i>\'">'
    : '<i class="fa-solid ' + esc(C.icone || 'fa-utensils') + '"></i>';

  var nav = '<div class="nav-label">Relatório Executivo</div>' + PAGES.map(function (p, i) {
    return '<li class="nav-item' + (i === 0 ? ' active' : '') + '" data-page="' + p.id + '"><i class="fa-solid ' + p.icon + '"></i> ' + (i + 1) + '. ' + esc(p.t) + '</li>';
  }).join('');

  document.body.innerHTML =
    '<div class="overlay" id="overlay"></div>' +
    '<aside id="sidebar"><div class="brand-header"><div class="brand-logo">M7</div><div class="brand-title">Mesa7<span>Intelligence</span></div><button class="sidebar-close" id="btnClose" aria-label="Fechar menu"><i class="fa-solid fa-xmark"></i></button></div>' +
    '<div class="client-block"><span class="client-label">Cliente</span><div class="client-card"><div class="client-mark">' + mark + '</div><div><div class="client-name">' + esc(C.nome) + '</div><div class="client-seg">' + esc(C.seg || '') + '</div></div></div></div>' +
    '<ul class="nav-menu">' + nav + '</ul><div class="sidebar-footer">Desenvolvido por Mesa7 Marketing</div></aside>' +
    '<main><header class="top-bar"><button class="menu-toggle" id="btnMenu" aria-label="Abrir menu"><i class="fa-solid fa-bars"></i></button><div class="page-title"><h1 id="page-heading"></h1><p id="page-subheading"></p></div></header>' +
    filtro() + '<div id="paginas"></div></main>';

  var atual = 'p1';
  function render() {
    document.getElementById('paginas').innerHTML = PAGES.map(pageHtml).join('');
    document.querySelectorAll('.view-page').forEach(function (el) { el.classList.toggle('active', el.id === atual); });
  }
  function closeNav() { document.body.classList.remove('nav-open'); document.getElementById('overlay').classList.remove('show'); }
  function openNav() { document.body.classList.add('nav-open'); document.getElementById('overlay').classList.add('show'); }
  function show(id) {
    closeNav();
    atual = id;
    var p = PAGES.filter(function (x) { return x.id === id; })[0];
    document.querySelectorAll('.view-page').forEach(function (el) { el.classList.toggle('active', el.id === id); });
    document.querySelectorAll('.nav-item').forEach(function (el) { el.classList.toggle('active', el.getAttribute('data-page') === id); });
    document.getElementById('page-heading').innerHTML = '<i class="fa-solid ' + p.icon + '" style="color:var(--m7-orange)"></i> ' + esc(p.t);
    document.getElementById('page-subheading').textContent = p.s;
  }
  render();
  window.switchPage = show;
  var sel = document.getElementById('selMes');
  if (sel) sel.addEventListener('change', function () { mesSel = sel.value; render(); });
  document.querySelectorAll('.nav-item').forEach(function (el) { el.addEventListener('click', function () { window.switchPage(el.getAttribute('data-page')); }); });
  document.getElementById('btnMenu').addEventListener('click', openNav);
  document.getElementById('btnClose').addEventListener('click', closeNav);
  document.getElementById('overlay').addEventListener('click', closeNav);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeNav(); });
  show('p1');
})();
