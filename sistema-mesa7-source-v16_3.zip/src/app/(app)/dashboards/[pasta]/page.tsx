import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { requireSession } from "@/lib/access";
import { db } from "@/db";
import { clients } from "@/db/schema";
import { eq } from "drizzle-orm";
import { dashboardPorPasta } from "@/lib/dashboards";
import { CopiarLinkDashboard } from "@/components/CopiarLinkDashboard";

// Visualização do dashboard pela equipe: tela cheia (o dashboard tem o
// próprio menu) com uma barra fixa de "Voltar" em cima.
export async function generateMetadata({ params }: PageProps<"/dashboards/[pasta]">): Promise<Metadata> {
  const { pasta } = await params;
  const d = dashboardPorPasta(pasta);
  return { title: d ? `Dashboard ${d.nome} — Sistema Mesa7` : "Sistema Mesa7" };
}

export default async function VerDashboardPage({ params }: PageProps<"/dashboards/[pasta]">) {
  const { pasta } = await params;
  const session = await requireSession();
  const d = dashboardPorPasta(pasta);
  if (!d) notFound();

  // Login de cliente só vê o dashboard do próprio restaurante.
  if (session.user.role === "client") {
    const [c] = session.user.clientId
      ? await db.select().from(clients).where(eq(clients.id, session.user.clientId)).limit(1)
      : [];
    if (!c || c.slug !== d.pasta) notFound();
  }
  const isTeam = session.user.role !== "client";
  const altura = 52;

  return (
    <div style={{ position: "fixed", inset: 0, display: "flex", flexDirection: "column", background: "#0C0E36" }}>
      <div
        style={{
          height: altura,
          flex: "none",
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: "0 14px",
          background: "var(--surface-2)",
          borderBottom: "1px solid var(--border-strong)",
        }}
      >
        <Link
          href={isTeam ? "/dashboards" : "/"}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 6,
            color: "var(--accent)",
            border: "1px solid rgba(249,115,22,0.45)",
            background: "var(--accent-soft)",
            borderRadius: 9,
            padding: "7px 12px",
            fontSize: 13,
            fontWeight: 800,
            textDecoration: "none",
            whiteSpace: "nowrap",
          }}
        >
          ← Voltar{isTeam ? " para Dashboards" : ""}
        </Link>
        <div style={{ minWidth: 0, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          <span style={{ fontWeight: 700, color: "var(--text-primary)", fontSize: 14 }}>{d.nome}</span>
          <span style={{ color: "var(--text-muted)", fontSize: 12.5, marginLeft: 8 }}>
            Dashboard
          </span>
        </div>
        {isTeam && (
          <Link
            href={`/arquivos?cliente=${d.pasta}`}
            style={{
              background: "var(--accent)",
              color: "var(--accent-ink)",
              borderRadius: 9,
              padding: "7px 12px",
              fontSize: 12.5,
              fontWeight: 800,
              textDecoration: "none",
              whiteSpace: "nowrap",
            }}
          >
            ↑ Subir resultados
          </Link>
        )}
        {isTeam && <CopiarLinkDashboard token={d.token} compacto />}
      </div>
      <iframe
        src={`/d/${d.token}/arquivo/index.html${isTeam ? "?m=equipe" : ""}`}
        title={`Dashboard ${d.nome}`}
        style={{ flex: 1, width: "100%", border: 0 }}
      />
    </div>
  );
}
