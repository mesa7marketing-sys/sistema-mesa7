import { requireClientAccess } from "@/lib/access";
import { PageHead, Tiles, Tile, Card } from "@/components/ui";
import { LineChart } from "@/components/charts/LineChart";
import { BarChart } from "@/components/charts/BarChart";
import { latestTwoPeriods, seriesFor, pctDelta, formatBRL, formatDeltaLabel, deltaTone } from "@/lib/metrics";

const KEYS = ["faturamento_total", "ticket_medio"];
const CANAL_KEYS = [
  "fin_delivery_receita",
  "fin_mesa_receita",
  "fin_retirada_receita",
  "fin_ifood_receita",
  "fin_canais_proprios_receita",
];

export default async function FinanceiroPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { client } = await requireClientAccess(slug);

  const m = await latestTwoPeriods(client.id, KEYS);
  const cm = await latestTwoPeriods(client.id, CANAL_KEYS);
  const faturamento = await seriesFor(client.id, "faturamento_total");
  const ticket = await seriesFor(client.id, "ticket_medio");
  const delivery = await seriesFor(client.id, "fin_delivery_receita");
  const mesa = await seriesFor(client.id, "fin_mesa_receita");
  const retirada = await seriesFor(client.id, "fin_retirada_receita");
  const ifood = await seriesFor(client.id, "fin_ifood_receita");
  const proprios = await seriesFor(client.id, "fin_canais_proprios_receita");

  const temQuebraCanal = cm.fin_delivery_receita.current !== undefined;

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Operação"
        title={`Financeiro — ${client.name}`}
        description="Faturamento, ticket médio e demais indicadores financeiros do período."
      />

      <Tiles>
        <Tile
          label="Faturamento total"
          value={formatBRL(m.faturamento_total.current)}
          deltaLabel={formatDeltaLabel(pctDelta(m.faturamento_total.current, m.faturamento_total.previous))}
          deltaTone={deltaTone(pctDelta(m.faturamento_total.current, m.faturamento_total.previous))}
          caption="Período mais recente"
        />
        <Tile
          label="Ticket médio"
          value={formatBRL(m.ticket_medio.current)}
          deltaLabel={formatDeltaLabel(pctDelta(m.ticket_medio.current, m.ticket_medio.previous))}
          deltaTone={deltaTone(pctDelta(m.ticket_medio.current, m.ticket_medio.previous))}
        />
      </Tiles>

      <Card title="Faturamento por período" subtitle="Preenchimento manual ou importado">
        <BarChart
          data={faturamento.xLabels.map((label, i) => ({ label, value: faturamento.values[i], color: "var(--series-3)" }))}
          format="currency-k"
          aria="Faturamento por período"
        />
      </Card>
      <Card title="Ticket médio" subtitle="Últimos períodos">
        <LineChart
          series={[{ name: "Ticket médio", color: "var(--series-4)", values: ticket.values }]}
          xLabels={ticket.xLabels}
          format="currency"
          aria="Ticket médio por período"
        />
      </Card>

      {temQuebraCanal && (
        <>
          <Tiles>
            <Tile
              label="Receita Delivery"
              value={formatBRL(cm.fin_delivery_receita.current)}
              deltaLabel={formatDeltaLabel(pctDelta(cm.fin_delivery_receita.current, cm.fin_delivery_receita.previous))}
              deltaTone={deltaTone(pctDelta(cm.fin_delivery_receita.current, cm.fin_delivery_receita.previous))}
            />
            <Tile
              label="Receita Mesa / Comanda"
              value={formatBRL(cm.fin_mesa_receita.current)}
              deltaLabel={formatDeltaLabel(pctDelta(cm.fin_mesa_receita.current, cm.fin_mesa_receita.previous))}
              deltaTone={deltaTone(pctDelta(cm.fin_mesa_receita.current, cm.fin_mesa_receita.previous))}
            />
            <Tile
              label="Receita Retirada"
              value={formatBRL(cm.fin_retirada_receita.current)}
              deltaLabel={formatDeltaLabel(pctDelta(cm.fin_retirada_receita.current, cm.fin_retirada_receita.previous))}
              deltaTone={deltaTone(pctDelta(cm.fin_retirada_receita.current, cm.fin_retirada_receita.previous))}
            />
          </Tiles>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
            <Card title="Delivery" subtitle="Receita por período · origem: Cardápio Web">
              <LineChart
                series={[{ name: "Delivery", color: "var(--series-1)", values: delivery.values }]}
                xLabels={delivery.xLabels}
                format="currency-k"
                aria="Receita de delivery por período"
              />
            </Card>
            <Card title="Mesa / Comanda" subtitle="Receita por período · origem: Cardápio Web">
              <LineChart
                series={[{ name: "Mesa / Comanda", color: "var(--series-2)", values: mesa.values }]}
                xLabels={mesa.xLabels}
                format="currency-k"
                aria="Receita de mesa e comanda por período"
              />
            </Card>
            <Card title="Retirada" subtitle="Receita por período · origem: Cardápio Web">
              <LineChart
                series={[{ name: "Retirada", color: "var(--series-6)", values: retirada.values }]}
                xLabels={retirada.xLabels}
                format="currency-k"
                aria="Receita de retirada por período"
              />
            </Card>
          </div>

          <Card title="iFood vs. Canais Próprios" subtitle="Receita por período · origem: Cardápio Web">
            <LineChart
              series={[
                { name: "iFood", color: "var(--series-3)", values: ifood.values },
                { name: "Canais Próprios", color: "var(--series-5)", values: proprios.values },
              ]}
              xLabels={ifood.xLabels}
              format="currency-k"
              aria="Receita iFood versus canais próprios por período"
            />
          </Card>
        </>
      )}
    </div>
  );
}
