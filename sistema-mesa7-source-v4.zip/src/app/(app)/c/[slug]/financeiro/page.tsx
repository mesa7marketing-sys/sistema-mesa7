import { requireClientAccess } from "@/lib/access";
import { PageHead, Tiles, Tile, Card } from "@/components/ui";
import { LineChart } from "@/components/charts/LineChart";
import { BarChart } from "@/components/charts/BarChart";
import { latestTwoPeriods, seriesFor, pctDelta, formatBRL, formatDeltaLabel, deltaTone } from "@/lib/metrics";

const KEYS = ["faturamento_total", "ticket_medio"];

// Quebra de faturamento por canal — mesmo padrão pra todos os clientes.
// Cada cliente só mostra os canais que de fato tem dado (uma loja de bairro
// não tem 99Food, por exemplo), então cada tile/gráfico é condicional.
const CANAIS = [
  { key: "fin_salao_receita", label: "Receita Salão", color: "var(--series-1)" },
  { key: "fin_ifood_receita", label: "Receita iFood", color: "var(--series-3)" },
  { key: "fin_cardapio_proprio_receita", label: "Receita Cardápio Próprio", color: "var(--series-5)" },
  { key: "fin_99food_receita", label: "Receita 99Food", color: "var(--series-6)" },
] as const;

export default async function FinanceiroPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { client } = await requireClientAccess(slug);

  const m = await latestTwoPeriods(client.id, KEYS);
  const cm = await latestTwoPeriods(client.id, CANAIS.map((c) => c.key));
  const faturamento = await seriesFor(client.id, "faturamento_total");
  const ticket = await seriesFor(client.id, "ticket_medio");
  const canalSeries = await Promise.all(CANAIS.map((c) => seriesFor(client.id, c.key)));

  const canaisComDado = CANAIS.map((c, i) => ({ ...c, m: cm[c.key], series: canalSeries[i] })).filter(
    (c) => c.m.current !== undefined,
  );

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Operação"
        title={`Financeiro — ${client.name}`}
        description="Faturamento, ticket médio e demais indicadores financeiros do período."
      />

      <Tiles>
        <Tile
          label="Faturamento total"
          value={formatBRL(m.faturamento_total.current)}
          deltaLabel={formatDeltaLabel(pctDelta(m.faturamento_total.current, m.faturamento_total.previous))}
          deltaTone={deltaTone(pctDelta(m.faturamento_total.current, m.faturamento_total.previous))}
          caption="Período mais recente"
        />
        <Tile
          label="Ticket médio"
          value={formatBRL(m.ticket_medio.current)}
          deltaLabel={formatDeltaLabel(pctDelta(m.ticket_medio.current, m.ticket_medio.previous))}
          deltaTone={deltaTone(pctDelta(m.ticket_medio.current, m.ticket_medio.previous))}
        />
      </Tiles>

      <Card title="Faturamento por período" subtitle="Preenchimento manual ou importado">
        <BarChart
          data={faturamento.xLabels.map((label, i) => ({ label, value: faturamento.values[i], color: "var(--series-3)" }))}
          format="currency-k"
          aria="Faturamento por período"
        />
      </Card>
      <Card title="Ticket médio" subtitle="Últimos períodos">
        <LineChart
          series={[{ name: "Ticket médio", color: "var(--series-4)", values: ticket.values }]}
          xLabels={ticket.xLabels}
          format="currency"
          aria="Ticket médio por período"
        />
      </Card>

      {canaisComDado.length > 0 && (
        <>
          <Tiles>
            {canaisComDado.map((c) => (
              <Tile
                key={c.key}
                label={c.label}
                value={formatBRL(c.m.current)}
                deltaLabel={formatDeltaLabel(pctDelta(c.m.current, c.m.previous))}
                deltaTone={deltaTone(pctDelta(c.m.current, c.m.previous))}
              />
            ))}
          </Tiles>

          <Card title="Faturamento por canal" subtitle="Receita por período · Salão / iFood / Cardápio Próprio / 99Food">
            <LineChart
              series={canaisComDado.map((c) => ({ name: c.label.replace("Receita ", ""), color: c.color, values: c.series.values }))}
              xLabels={canaisComDado[0].series.xLabels}
              format="currency-k"
              aria="Faturamento por canal e por período"
            />
          </Card>
        </>
      )}
    </div>
  );
}
