import { requireClientAccess } from "@/lib/access";
import { PageHead, Tiles, Tile, Card } from "@/components/ui";
import { LineChart } from "@/components/charts/LineChart";
import { latestTwoPeriods, seriesFor, pctDelta, formatNumber, formatBRL, formatDeltaLabel, deltaTone } from "@/lib/metrics";

const KEYS = ["clientes_ativos_crm", "taxa_recompra"];
const REPEDIU_KEYS = ["crm_recuperados", "crm_mensagens", "crm_receita_gerada"];

export default async function RelacionamentoPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { client } = await requireClientAccess(slug);

  const m = await latestTwoPeriods(client.id, KEYS);
  const r = await latestTwoPeriods(client.id, REPEDIU_KEYS);
  const ativos = await seriesFor(client.id, "clientes_ativos_crm");
  const recompra = await seriesFor(client.id, "taxa_recompra");
  const recuperados = await seriesFor(client.id, "crm_recuperados");
  const mensagens = await seriesFor(client.id, "crm_mensagens");
  const receitaGerada = await seriesFor(client.id, "crm_receita_gerada");

  const temRepediu = r.crm_mensagens.current !== undefined;

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Método CVR"
        title={`Relacionamento — ${client.name}`}
        description="CRM, RePediu, base de clientes, WhatsApp, SMS, programa de fidelidade e recuperação de clientes — a fidelização."
      />

      <Tiles>
        <Tile
          label="Clientes ativos (CRM)"
          value={formatNumber(m.clientes_ativos_crm.current)}
          deltaLabel={formatDeltaLabel(pctDelta(m.clientes_ativos_crm.current, m.clientes_ativos_crm.previous))}
          deltaTone={deltaTone(pctDelta(m.clientes_ativos_crm.current, m.clientes_ativos_crm.previous))}
          caption="Período mais recente"
        />
        <Tile
          label="Taxa de recompra"
          value={m.taxa_recompra.current ? `${formatNumber(m.taxa_recompra.current, 1)}%` : "—"}
          deltaLabel={formatDeltaLabel(pctDelta(m.taxa_recompra.current, m.taxa_recompra.previous))}
          deltaTone={deltaTone(pctDelta(m.taxa_recompra.current, m.taxa_recompra.previous))}
        />
      </Tiles>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Card title="Clientes ativos na base CRM" subtitle="Últimos períodos · preenchimento manual">
          <LineChart
            series={[{ name: "Clientes ativos", color: "var(--series-1)", values: ativos.values }]}
            xLabels={ativos.xLabels}
            format="number"
            aria="Clientes ativos por período"
          />
        </Card>
        <Card title="Taxa de recompra" subtitle="Últimos períodos · preenchimento manual">
          <LineChart
            series={[{ name: "Recompra", color: "var(--series-5)", values: recompra.values }]}
            xLabels={recompra.xLabels}
            format="percent0"
            aria="Taxa de recompra por período"
          />
        </Card>
      </div>

      {temRepediu && (
        <>
          <Tiles>
            <Tile
              label="Clientes recuperados"
              value={formatNumber(r.crm_recuperados.current)}
              deltaLabel={formatDeltaLabel(pctDelta(r.crm_recuperados.current, r.crm_recuperados.previous))}
              deltaTone={deltaTone(pctDelta(r.crm_recuperados.current, r.crm_recuperados.previous))}
              caption="RePediu"
            />
            <Tile
              label="Mensagens enviadas"
              value={formatNumber(r.crm_mensagens.current)}
              deltaLabel={formatDeltaLabel(pctDelta(r.crm_mensagens.current, r.crm_mensagens.previous))}
              deltaTone={deltaTone(pctDelta(r.crm_mensagens.current, r.crm_mensagens.previous))}
              caption="RePediu"
            />
            <Tile
              label="Receita gerada"
              value={formatBRL(r.crm_receita_gerada.current)}
              deltaLabel={formatDeltaLabel(pctDelta(r.crm_receita_gerada.current, r.crm_receita_gerada.previous))}
              deltaTone={deltaTone(pctDelta(r.crm_receita_gerada.current, r.crm_receita_gerada.previous))}
              caption="RePediu"
            />
          </Tiles>

          <Card title="RePediu — mensagens e receita" subtitle="Últimos períodos · origem: RePediu">
            <LineChart
              series={[{ name: "Receita gerada", color: "var(--series-3)", values: receitaGerada.values }]}
              xLabels={receitaGerada.xLabels}
              format="currency-k"
              aria="Receita gerada pelo RePediu por período"
            />
          </Card>
          <Card title="Mensagens enviadas" subtitle="Últimos períodos · origem: RePediu">
            <LineChart
              series={[{ name: "Mensagens", color: "var(--series-7)", values: mensagens.values }]}
              xLabels={mensagens.xLabels}
              format="number"
              aria="Mensagens enviadas por período via RePediu"
            />
          </Card>
        </>
      )}
    </div>
  );
}
