import { requireClientAccess } from "@/lib/access";
import { PageHead, Tiles, Tile, Card } from "@/components/ui";
import { LineChart } from "@/components/charts/LineChart";
import { latestTwoPeriods, seriesFor, pctDelta, formatNumber, formatDeltaLabel, deltaTone } from "@/lib/metrics";

const KEYS = ["instagram_seguidores", "avaliacoes_google_nota"];
const GMB_KEYS = ["gmb_visualizacoes", "gmb_ligacoes"];

export default async function ValorPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { client } = await requireClientAccess(slug);

  const m = await latestTwoPeriods(client.id, KEYS);
  const g = await latestTwoPeriods(client.id, GMB_KEYS);
  const seguidores = await seriesFor(client.id, "instagram_seguidores");
  const nota = await seriesFor(client.id, "avaliacoes_google_nota");
  const gmbVisualizacoes = await seriesFor(client.id, "gmb_visualizacoes");
  const gmbLigacoes = await seriesFor(client.id, "gmb_ligacoes");

  const temGmb = g.gmb_visualizacoes.current !== undefined;

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Método CVR"
        title={`Valor — ${client.name}`}
        description="Social media, conteúdo, experiência, ambiente, avaliações e posicionamento — a construção da marca."
      />

      <Tiles>
        <Tile
          label="Seguidores Instagram"
          value={formatNumber(m.instagram_seguidores.current)}
          deltaLabel={formatDeltaLabel(pctDelta(m.instagram_seguidores.current, m.instagram_seguidores.previous))}
          deltaTone={deltaTone(pctDelta(m.instagram_seguidores.current, m.instagram_seguidores.previous))}
          caption="Período mais recente"
        />
        <Tile
          label="Nota Google"
          value={m.avaliacoes_google_nota.current ? formatNumber(m.avaliacoes_google_nota.current, 1) : "—"}
          deltaLabel={formatDeltaLabel(pctDelta(m.avaliacoes_google_nota.current, m.avaliacoes_google_nota.previous))}
          deltaTone={deltaTone(pctDelta(m.avaliacoes_google_nota.current, m.avaliacoes_google_nota.previous))}
          caption="Google Meu Negócio"
        />
      </Tiles>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Card title="Seguidores no Instagram" subtitle="Últimos períodos · preenchimento manual">
          <LineChart
            series={[{ name: "Seguidores", color: "var(--series-5)", values: seguidores.values }]}
            xLabels={seguidores.xLabels}
            format="number"
            aria="Seguidores no Instagram por período"
          />
        </Card>
        <Card title="Nota média no Google" subtitle="Últimos períodos · origem: Google Meu Negócio">
          <LineChart
            series={[{ name: "Nota", color: "var(--series-7)", values: nota.values }]}
            xLabels={nota.xLabels}
            format="decimal1"
            aria="Nota média no Google por período"
          />
        </Card>
      </div>

      {temGmb && (
        <>
          <Tiles>
            <Tile
              label="Visualizações no perfil"
              value={formatNumber(g.gmb_visualizacoes.current)}
              deltaLabel={formatDeltaLabel(pctDelta(g.gmb_visualizacoes.current, g.gmb_visualizacoes.previous))}
              deltaTone={deltaTone(pctDelta(g.gmb_visualizacoes.current, g.gmb_visualizacoes.previous))}
              caption="Google Meu Negócio"
            />
            <Tile
              label="Ligações pelo perfil"
              value={formatNumber(g.gmb_ligacoes.current)}
              deltaLabel={formatDeltaLabel(pctDelta(g.gmb_ligacoes.current, g.gmb_ligacoes.previous))}
              deltaTone={deltaTone(pctDelta(g.gmb_ligacoes.current, g.gmb_ligacoes.previous))}
              caption="Google Meu Negócio"
            />
          </Tiles>
          <Card title="Visualizações e ligações — Google Meu Negócio" subtitle="Últimos períodos · origem: GMN">
            <LineChart
              series={[
                { name: "Visualizações", color: "var(--series-2)", values: gmbVisualizacoes.values },
                { name: "Ligações", color: "var(--series-6)", values: gmbLigacoes.values },
              ]}
              xLabels={gmbVisualizacoes.xLabels}
              format="number"
              aria="Visualizações e ligações do perfil no Google Meu Negócio por período"
            />
          </Card>
        </>
      )}
    </div>
  );
}
