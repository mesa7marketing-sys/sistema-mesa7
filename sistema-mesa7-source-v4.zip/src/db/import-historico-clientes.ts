// Importação do histórico dos dashboards avulsos que a Mesa7 já usava antes
// do Sistema Mesa7, pra La Pizza D'Caio (reimportação no padrão novo),
// Bionatural, Garage 84, Paçocas Unidade 1 e Taverna dos Pandas (cliente
// novo, cadastrado aqui).
//
// Padrão único de canal pra todos os clientes, direto do pedido do Lucas:
//   Salão | iFood | Cardápio Próprio | 99Food
// Cada cliente só recebe os canais que de fato existem nos dados dele — os
// outros ficam sem linha (a página mostra "—"/oculta o card, nunca zero
// inventado). Meta Ads e Google Ads seguem o mesmo padrão entre si
// (investimento / leads / ROAS), e só levam ROAS quando existe receita
// atribuída real na fonte.
import "dotenv/config";
import { db } from "./index";
import { clients, weeklyMetrics } from "./schema";
import { and, eq } from "drizzle-orm";

type Pillar = "conversao" | "valor" | "relacionamento" | "financeiro" | "cardapio";
type Origem = "manual" | "meta_ads" | "google_ads" | "gmn" | "ifood" | "cardapio_web" | "repediu";

async function upsertMetric(clientId: string, periodStart: string, pillar: Pillar, metricKey: string, value: number, origem: Origem) {
  await db
    .insert(weeklyMetrics)
    .values({ clientId, periodStart, pillar, metricKey, metricValue: value.toFixed(2), origem })
    .onConflictDoUpdate({
      target: [weeklyMetrics.clientId, weeklyMetrics.periodStart, weeklyMetrics.metricKey],
      set: { metricValue: value.toFixed(2), pillar, origem, updatedAt: new Date() },
    });
}

async function deleteMetric(clientId: string, periodStart: string, metricKey: string) {
  await db
    .delete(weeklyMetrics)
    .where(
      and(
        eq(weeklyMetrics.clientId, clientId),
        eq(weeklyMetrics.periodStart, periodStart),
        eq(weeklyMetrics.metricKey, metricKey),
      ),
    );
}

async function getClient(slug: string) {
  const [client] = await db.select().from(clients).where(eq(clients.slug, slug)).limit(1);
  return client;
}

async function ensureClient(name: string, slug: string) {
  const existing = await getClient(slug);
  if (existing) return existing;
  const [created] = await db.insert(clients).values({ name, slug }).returning();
  console.log(`cliente novo cadastrado: ${name} (${slug})`);
  return created;
}

// Meta/Google Ads e financeiro por canal — helper comum a todos os clientes.
async function importMeta(clientId: string, periodStart: string, meta: { gas: number; cmp: number; fat?: number } | null) {
  if (!meta) return;
  await upsertMetric(clientId, periodStart, "conversao", "meta_investimento", meta.gas, "meta_ads");
  await upsertMetric(clientId, periodStart, "conversao", "meta_leads", meta.cmp, "meta_ads");
  if (meta.gas && meta.fat !== undefined) {
    await upsertMetric(clientId, periodStart, "conversao", "meta_roas", meta.fat / meta.gas, "meta_ads");
  }
}
async function importGoogle(clientId: string, periodStart: string, goo: { i: number; c: number; f?: number } | null) {
  if (!goo) return;
  await upsertMetric(clientId, periodStart, "conversao", "google_investimento", goo.i, "google_ads");
  await upsertMetric(clientId, periodStart, "conversao", "google_leads", goo.c, "google_ads");
  if (goo.i && goo.f !== undefined) {
    await upsertMetric(clientId, periodStart, "conversao", "google_roas", goo.f / goo.i, "google_ads");
  }
}
async function importGmb(clientId: string, periodStart: string, gmb: { v: number; ch: number } | null) {
  if (!gmb) return;
  await upsertMetric(clientId, periodStart, "valor", "gmb_visualizacoes", gmb.v, "gmn");
  await upsertMetric(clientId, periodStart, "valor", "gmb_ligacoes", gmb.ch, "gmn");
}
async function importCrm(clientId: string, periodStart: string, crm: { rec: number | null; msg: number; rev: number } | null) {
  if (!crm) return;
  if (crm.rec !== null) await upsertMetric(clientId, periodStart, "relacionamento", "crm_recuperados", crm.rec, "repediu");
  await upsertMetric(clientId, periodStart, "relacionamento", "crm_mensagens", crm.msg, "repediu");
  await upsertMetric(clientId, periodStart, "relacionamento", "crm_receita_gerada", crm.rev, "repediu");
}
async function importCanais(
  clientId: string,
  periodStart: string,
  canais: { salao?: number; ifood?: number; cardapioProprio?: number; f99?: number },
) {
  if (canais.salao !== undefined) await upsertMetric(clientId, periodStart, "financeiro", "fin_salao_receita", canais.salao, "cardapio_web");
  if (canais.ifood !== undefined) await upsertMetric(clientId, periodStart, "financeiro", "fin_ifood_receita", canais.ifood, "cardapio_web");
  if (canais.cardapioProprio !== undefined)
    await upsertMetric(clientId, periodStart, "financeiro", "fin_cardapio_proprio_receita", canais.cardapioProprio, "cardapio_web");
  if (canais.f99 !== undefined) await upsertMetric(clientId, periodStart, "financeiro", "fin_99food_receita", canais.f99, "cardapio_web");
}

// ===========================================================================
// LA PIZZA D'CAIO — reimportação no padrão novo (substitui a quebra antiga
// de delivery/mesa/retirada pelas categorias únicas de canal).
// ===========================================================================
const LA_PIZZA = [
  { id: "2026-03", tot: 169155.16, ped: 1289, ifood: 42731.82, cardapioProprio: 80004.84 + 34538.70 + 11879.80 },
  { id: "2026-04", tot: 175613.43, ped: 1292, ifood: 43279.47, cardapioProprio: 74905.02 + 43770.90 + 13658.04 },
  { id: "2026-05", tot: 187610.17, ped: 1364, ifood: 50152.38, cardapioProprio: 76439.79 + 46686.30 + 14331.70 },
  { id: "2026-06", tot: 180014.55, ped: 1355, ifood: 53038.44, cardapioProprio: 68849.87 + 46360.24 + 11766.00 },
  { id: "2026-07", tot: 189281.85, ped: 1379, ifood: 51779.72, cardapioProprio: 74519.46 + 48843.07 + 14139.60 },
  { id: "2026-08", tot: 187311.67, ped: 1354, ifood: 47977.03, cardapioProprio: 78088.34 + 49060.90 + 12185.40 },
];

async function importLaPizza() {
  const client = await getClient("la-pizza-dcaio");
  if (!client) return console.log("la-pizza-dcaio não encontrado — pulando");

  for (const m of LA_PIZZA) {
    const periodStart = `${m.id}-01`;
    // Remove as métricas do padrão antigo (delivery/mesa/retirada/canais próprios
    // combinados) — substituídas pelo padrão único de canal.
    for (const old of ["fin_delivery_receita", "fin_mesa_receita", "fin_retirada_receita", "fin_canais_proprios_receita"]) {
      await deleteMetric(client.id, periodStart, old);
    }
    await upsertMetric(client.id, periodStart, "financeiro", "faturamento_total", m.tot, "cardapio_web");
    await upsertMetric(client.id, periodStart, "financeiro", "ticket_medio", m.tot / m.ped, "cardapio_web");
    const salao = m.tot - m.ifood - m.cardapioProprio;
    await importCanais(client.id, periodStart, { salao, ifood: m.ifood, cardapioProprio: m.cardapioProprio });
  }
  console.log("La Pizza D'Caio: reimportado no padrão novo.");
}

// ===========================================================================
// BIONATURAL
// ===========================================================================
const BIONATURAL = [
  { id: "2025-11", sal: 958414.09, del: 3465.75, meta: null, goo: null, gmb: { v: 637, ch: 306 } },
  { id: "2025-12", sal: 1090641.68, del: 2379.10, meta: null, goo: null, gmb: { v: 659, ch: 269 } },
  { id: "2026-01", sal: 1039452.31, del: 2977.20, meta: null, goo: { i: 249, c: 72 }, gmb: { v: 656, ch: 147 } },
  { id: "2026-02", sal: 983109.02, del: 3804.41, meta: { gas: 1387.37, cmp: 0 }, goo: { i: 553, c: 74 }, gmb: { v: 748, ch: 119 } },
  { id: "2026-03", sal: 1149132.05, del: 7244.55, meta: { gas: 396.93, cmp: 0 }, goo: { i: 676, c: 95 }, gmb: { v: 958, ch: 120 } },
  { id: "2026-04", sal: 1104146.55, del: 9412.99, meta: { gas: 1362.77, cmp: 0 }, goo: { i: 675, c: 157 }, gmb: { v: 698, ch: 143 } },
  { id: "2026-05", sal: 1169997.34, del: 16610.82, meta: { gas: 1426.54, cmp: 0 }, goo: { i: 662, c: 146 }, gmb: { v: 709, ch: 123 } },
  { id: "2026-06", sal: 1164035.40, del: 27685.21, meta: { gas: 1359.65, cmp: 0 }, goo: { i: 761, c: 167 }, gmb: { v: 741, ch: 160 } },
  { id: "2026-07", sal: 1247875.97, del: 19124.03, meta: { gas: 1429.90, cmp: 0 }, goo: { i: 752.26, c: 205 }, gmb: { v: 680, ch: 113 } },
  { id: "2026-08", sal: 1143780.32, del: 14151.93, meta: { gas: 1440.50, cmp: 0 }, goo: { i: 770.81, c: 226 }, gmb: { v: 703, ch: 128 } },
] as const;

async function importBionatural() {
  const client = await getClient("bionatural");
  if (!client) return console.log("bionatural não encontrado — pulando");

  for (const m of BIONATURAL) {
    const periodStart = `${m.id}-01`;
    const total = m.sal + m.del;
    await upsertMetric(client.id, periodStart, "financeiro", "faturamento_total", total, "cardapio_web");
    await importCanais(client.id, periodStart, { salao: m.sal, ifood: m.del });
    // Sem "fat" (receita atribuída) na fonte da Bionatural — só investimento,
    // sem leads/ROAS reais (campanha de reconhecimento, não de venda).
    if (m.meta) await upsertMetric(client.id, periodStart, "conversao", "meta_investimento", m.meta.gas, "meta_ads");
    await importGoogle(client.id, periodStart, m.goo);
    await importGmb(client.id, periodStart, m.gmb);
  }
  console.log("Bionatural: importado.");
}

// ===========================================================================
// GARAGE 84 BURGER
// ===========================================================================
const GARAGE84 = [
  { id: "2025-08", tot: 111117.87, ped: 1355, ifood: 13467.79, cardapioProprio: 53070.36 + 44579.72, f99: 0, meta: { gas: 3155.84, cmp: 254, fat: 19761.39 }, goo: { i: 1022.52, c: 73, f: 5487.27 }, gmb: null, crm: { rec: 236, msg: 6332, rev: 45882.80 } },
  { id: "2025-09", tot: 86530.07, ped: 1093, ifood: 10760.28, cardapioProprio: 38063.67 + 37706.12, f99: 0, meta: { gas: 3246.80, cmp: 197, fat: 15802.76 }, goo: { i: 646, c: 46, f: 3745.53 }, gmb: null, crm: { rec: 179, msg: 4204, rev: 31888.51 } },
  { id: "2025-10", tot: 94761.40, ped: 1151, ifood: 9921.29, cardapioProprio: 46454.48 + 38385.63, f99: 0, meta: { gas: 3133.60, cmp: 232, fat: 17830.73 }, goo: { i: 645, c: 73, f: 5258.56 }, gmb: null, crm: { rec: 98, msg: 3381, rev: 17805.32 } },
  { id: "2025-11", tot: 104523.93, ped: 1312, ifood: 13786.57, cardapioProprio: 49698.51 + 41038.85, f99: 0, meta: { gas: 3183.04, cmp: 251, fat: 18906.10 }, goo: { i: 593, c: 85, f: 6197.57 }, gmb: { v: 197, ch: 10 }, crm: { rec: 108, msg: 5981, rev: 18167.83 } },
  { id: "2025-12", tot: 119156.37, ped: 1391, ifood: 17454.46, cardapioProprio: 47895.13 + 53806.78, f99: 0, meta: { gas: 3440.33, cmp: 201, fat: 16914.78 }, goo: { i: 0, c: 0, f: 0 }, gmb: { v: 196, ch: 27 }, crm: { rec: 206, msg: 3252, rev: 24460.90 } },
  { id: "2026-01", tot: 104665.97, ped: 1261, ifood: 19084.20, cardapioProprio: 47277.65 + 38304.12, f99: 0, meta: { gas: 3218.37, cmp: 245, fat: 19701.28 }, goo: { i: 501, c: 24, f: 1736 }, gmb: { v: 186, ch: 26 }, crm: { rec: 145, msg: 3994, rev: 17553.09 } },
  { id: "2026-02", tot: 91944.74, ped: 1055, ifood: 13868.43, cardapioProprio: 42495.47 + 35580.84, f99: 0, meta: { gas: 2392.12, cmp: 148, fat: 12896.81 }, goo: { i: 647, c: 69, f: 5498.87 }, gmb: { v: 139, ch: 12 }, crm: { rec: 144, msg: 3681, rev: 20723.22 } },
  { id: "2026-03", tot: 101972.20, ped: 1298, ifood: 13860.29, cardapioProprio: 31612.99 + 27318.40, f99: 29180.52, meta: { gas: 3067.29, cmp: 102, fat: 9262.54 }, goo: { i: 522, c: 47, f: 3328.25 }, gmb: { v: 151, ch: 13 }, crm: { rec: 77, msg: 3079, rev: 10619.64 } },
  { id: "2026-04", tot: 141602.61, ped: 1894, ifood: 10382.24, cardapioProprio: 30122.94 + 37648.41, f99: 63449.02, meta: { gas: 1832.48, cmp: 61, fat: 5417.69 }, goo: { i: 249, c: 53, f: 2087.91 }, gmb: { v: 176, ch: 31 }, crm: { rec: 28, msg: 1996, rev: 5702.36 } },
  { id: "2026-05", tot: 132511.56, ped: 1730, ifood: 8817.24, cardapioProprio: 35309.05 + 53351.40, f99: 35033.87, meta: { gas: 2064.65, cmp: 102, fat: 7539.51 }, goo: { i: 450, c: 36, f: 2338.82 }, gmb: { v: 284, ch: 22 }, crm: { rec: 19, msg: 1568, rev: 6712.59 } },
  { id: "2026-06", tot: 105034.64, ped: 1231, ifood: 8001.94, cardapioProprio: 28957.80 + 43372.76, f99: 24702.14, meta: { gas: 2029.18, cmp: 61, fat: 5037.50 }, goo: { i: 181, c: 22, f: 1262.58 }, gmb: { v: 184, ch: 19 }, crm: { rec: 19, msg: 1852, rev: 9294.62 } },
  { id: "2026-07", tot: 91919.24, ped: 1127, ifood: 6956.32, cardapioProprio: 26044.66 + 38672.34, f99: 20245.92, meta: { gas: 850.13, cmp: 28, fat: 2836.40 }, goo: { i: 0, c: 0, f: 0 }, gmb: { v: 206, ch: 25 }, crm: { rec: null, msg: 0, rev: 2266.89 } },
  { id: "2026-08", tot: 100308.37, ped: 1187, ifood: 7951.39, cardapioProprio: 29592.79 + 44457.87, f99: 18306.32, meta: { gas: 2008.40, cmp: 78, fat: 7283.56 }, goo: { i: 0, c: 0, f: 0 }, gmb: { v: 154, ch: 19 }, crm: { rec: 12, msg: 700, rev: 3668.49 } },
] as const;

async function importGarage84() {
  const client = await getClient("garage-84");
  if (!client) return console.log("garage-84 não encontrado — pulando");

  for (const m of GARAGE84) {
    const periodStart = `${m.id}-01`;
    await upsertMetric(client.id, periodStart, "financeiro", "faturamento_total", m.tot, "cardapio_web");
    await upsertMetric(client.id, periodStart, "financeiro", "ticket_medio", m.tot / m.ped, "cardapio_web");
    const salao = m.tot - m.ifood - m.cardapioProprio - m.f99;
    await importCanais(client.id, periodStart, { salao, ifood: m.ifood, cardapioProprio: m.cardapioProprio, f99: m.f99 });
    await importMeta(client.id, periodStart, m.meta);
    await importGoogle(client.id, periodStart, m.goo);
    await importGmb(client.id, periodStart, m.gmb);
    await importCrm(client.id, periodStart, m.crm);
  }
  console.log("Garage 84: importado.");
}

// ===========================================================================
// PAÇOCAS UNIDADE 1 — PDV (mesa+balcão+entrega) e plataformas (fonte
// distinta: iFood/Cardápio Próprio vêm de relatórios separados do PDV, então
// não necessariamente somam certinho com o total do caixa).
// ===========================================================================
const PACOCAS1 = [
  { id: "2026-01", mesaR: 870332.54, balcaoR: 0, entregaR: 107530.24, mesaP: 3316, balcaoP: 0, entregaP: 508, tot: 977862.78, car: 31186.81, ifd: 56067.08, meta: { gas: 5627.08, cmp: 17, fat: 2238.23 }, goo: { i: 540, c: 1095, f: 1297.41 }, gmb: { v: 3146, ch: 377 } },
  { id: "2026-02", mesaR: 776429.60, balcaoR: 15594.30, entregaR: 99848.13, mesaP: 3077, balcaoP: 94, entregaP: 609, tot: 891872.03, car: 34447.10, ifd: 48025.46, meta: { gas: 3954.27, cmp: 16, fat: 1793.96 }, goo: { i: 791, c: 1878, f: 0 }, gmb: { v: 3306, ch: 328 } },
  { id: "2026-03", mesaR: 824592.82, balcaoR: 57920.65, entregaR: 71241.39, mesaP: 3152, balcaoP: 378, entregaP: 479, tot: 953754.86, car: 49052.75, ifd: 51697.36, meta: { gas: 3314.75, cmp: 24, fat: 3377.62 }, goo: { i: 785, c: 1905, f: 0 }, gmb: { v: 3336, ch: 319 } },
  { id: "2026-04", mesaR: 721536.77, balcaoR: 50851.99, entregaR: 81620.48, mesaP: 2980, balcaoP: 331, entregaP: 503, tot: 854009.24, car: 38380.91, ifd: 60175.48, meta: { gas: 3367.63, cmp: 17, fat: 2131.82 }, goo: { i: 802, c: 1857, f: 0 }, gmb: { v: 3052, ch: 291 } },
  { id: "2026-05", mesaR: 800854.31, balcaoR: 56966.99, entregaR: 93828.78, mesaP: 3203, balcaoP: 392, entregaP: 557, tot: 951650.08, car: 49556.05, ifd: 68751.76, meta: { gas: 4357.91, cmp: 30, fat: 4279.87 }, goo: { i: 790, c: 1858, f: 917.79 }, gmb: { v: 3760, ch: 417 } },
  { id: "2026-06", mesaR: 673729.70, balcaoR: 54797.95, entregaR: 73438.09, mesaP: 2719, balcaoP: 307, entregaP: 433, tot: 801965.74, car: 38360.97, ifd: 57372.65, meta: { gas: 4956.90, cmp: 27, fat: 3256.65 }, goo: { i: 783, c: 1611, f: 0 }, gmb: { v: 3448, ch: 353 } },
  { id: "2026-07", mesaR: 567115.56, balcaoR: 32692.75, entregaR: 64668.75, mesaP: 2355, balcaoP: 235, entregaP: 363, tot: 664477.06, car: 29514.20, ifd: 50260.16, meta: { gas: 4527.51, cmp: 21, fat: 2559.91 }, goo: { i: 791, c: 1605, f: 468.75 }, gmb: { v: 3114, ch: 273 } },
  { id: "2026-08", mesaR: 0, balcaoR: 0, entregaR: 0, mesaP: 0, balcaoP: 0, entregaP: 0, tot: 0, car: 39552.26, ifd: 0, meta: { gas: 2697.53, cmp: 25, fat: 3114.41 }, goo: null, gmb: null },
] as const;

async function importPacocas1() {
  const client = await getClient("pacocas-unidade-1");
  if (!client) return console.log("pacocas-unidade-1 não encontrado — pulando");

  for (const m of PACOCAS1) {
    const periodStart = `${m.id}-01`;
    if (m.tot > 0) {
      await upsertMetric(client.id, periodStart, "financeiro", "faturamento_total", m.tot, "cardapio_web");
      const pessoas = m.mesaP + m.balcaoP + m.entregaP;
      if (pessoas > 0) await upsertMetric(client.id, periodStart, "financeiro", "ticket_medio", m.tot / pessoas, "cardapio_web");
      await importCanais(client.id, periodStart, { salao: m.mesaR + m.balcaoR, ifood: m.ifd, cardapioProprio: m.car });
    } else if (m.car) {
      // Agosto/26: caixa (PDV) ainda não exportado, só cardápio próprio e mídia disponíveis.
      await importCanais(client.id, periodStart, { cardapioProprio: m.car });
    }
    await importMeta(client.id, periodStart, m.meta);
    await importGoogle(client.id, periodStart, m.goo);
    await importGmb(client.id, periodStart, m.gmb);
  }
  console.log("Paçocas Unidade 1: importado.");
}

// ===========================================================================
// TAVERNA DOS PANDAS — cliente novo, cadastrado agora. Sem CRM ativo.
// ===========================================================================
const TAVERNA = [
  { id: "2025-01", tot: 59650.05, ped: 1219, meta: null, goo: null, gmb: null },
  { id: "2025-02", tot: 43715.51, ped: 947, meta: null, goo: null, gmb: null },
  { id: "2025-03", tot: 53341.31, ped: 1150, meta: null, goo: null, gmb: null },
  { id: "2025-04", tot: 51309.11, ped: 1039, meta: null, goo: null, gmb: null },
  { id: "2025-05", tot: 59538.62, ped: 1213, meta: null, goo: null, gmb: null },
  { id: "2025-06", tot: 61450.25, ped: 1225, meta: { gas: 507.10, cmp: 73, fat: 3255.60 }, goo: null, gmb: null },
  { id: "2025-07", tot: 92288.56, ped: null, meta: { gas: 498.40, cmp: 90, fat: 4365.60 }, goo: null, gmb: null },
  { id: "2025-08", tot: 91879.57, ped: null, meta: { gas: 699.70, cmp: 3, fat: 186.00 }, goo: null, gmb: null },
  { id: "2025-09", tot: 79371.70, ped: null, sal: 73270.36, ifd: 6101.34, meta: { gas: 500.41, cmp: 3, fat: 288.90 }, goo: null, gmb: null },
  { id: "2025-10", tot: 81486.50, ped: null, sal: 58426.15, ifd: 23060.35, meta: { gas: 500.92, cmp: 1, fat: 109.70 }, goo: null, gmb: null },
  { id: "2025-11", tot: 80602.40, ped: null, sal: 64213.70, ifd: 16388.70, meta: { gas: 605.94, cmp: 2, fat: 178.50 }, goo: null, gmb: { v: 539, ch: 40 } },
  { id: "2025-12", tot: 77084.25, ped: null, sal: 64474.29, ifd: 12609.96, meta: { gas: 491.34, cmp: 0, fat: 0 }, goo: null, gmb: { v: 639, ch: 18 } },
  { id: "2026-01", tot: 94950.95, ped: null, sal: 76162.79, ifd: 18788.16, meta: { gas: 509.30, cmp: 0, fat: 0 }, goo: null, gmb: { v: 780, ch: 24 } },
  { id: "2026-02", tot: 79916.35, ped: null, sal: 63314.06, ifd: 16500.00, meta: { gas: 681.18, cmp: 0, fat: 0 }, goo: null, gmb: { v: 644, ch: 32 } },
  { id: "2026-03", tot: 71171.39, ped: null, sal: 51636.40, ifd: 20173.47, car: 1950.91, meta: { gas: 540.90, cmp: 0, fat: 0 }, goo: null, gmb: { v: 522, ch: 13 } },
  { id: "2026-04", tot: 102994.37, ped: null, sal: 60297.34, ifd: 9268.26, car: 1438.61, meta: { gas: 771.38, cmp: 0, fat: 0 }, goo: null, gmb: { v: 871, ch: 20 } },
  { id: "2026-05", tot: 105154.92, ped: null, sal: 66239.62, ifd: 14795.27, car: 1710.24, meta: { gas: 758.54, cmp: 0, fat: 0 }, goo: { i: 207.06, c: 114 }, gmb: { v: 1137, ch: 11 } },
  { id: "2026-06", tot: 85243.27, ped: null, sal: 54604.98, ifd: 13661.50, car: 2260.72, meta: { gas: 480.84, cmp: 0, fat: 0 }, goo: { i: 228.06, c: 134 }, gmb: { v: 875, ch: 11 } },
  { id: "2026-07", tot: 109416.47, ped: 1432, sal: 76532.19, ifd: 14196.50, car: 1936.33, meta: { gas: 685.45, cmp: 0, fat: 0 }, goo: null, gmb: null },
  { id: "2026-08", tot: 90389.97, ped: 1228, sal: 64590.41, ifd: 12526.26, car: 3579.30, f99: 9993.30, meta: { gas: 693.58, cmp: 0, fat: 0 }, goo: null, gmb: null },
] as const;

async function importTaverna() {
  const client = await ensureClient("Taverna dos Pandas", "taverna-dos-pandas");

  for (const m of TAVERNA) {
    const periodStart = `${m.id}-01`;
    await upsertMetric(client.id, periodStart, "financeiro", "faturamento_total", m.tot, "cardapio_web");
    if (m.ped) await upsertMetric(client.id, periodStart, "financeiro", "ticket_medio", m.tot / m.ped, "cardapio_web");
    await importCanais(client.id, periodStart, {
      salao: "sal" in m ? m.sal : undefined,
      ifood: "ifd" in m ? m.ifd : undefined,
      cardapioProprio: "car" in m ? m.car : undefined,
      f99: "f99" in m ? m.f99 : undefined,
    });
    await importMeta(client.id, periodStart, m.meta);
    await importGoogle(client.id, periodStart, m.goo);
    await importGmb(client.id, periodStart, m.gmb);
  }
  console.log("Taverna dos Pandas: cadastrado e importado (sem CRM — cliente não usa RePediu).");
}

async function main() {
  await importLaPizza();
  await importBionatural();
  await importGarage84();
  await importPacocas1();
  await importTaverna();
  console.log("\nConcluído.");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
