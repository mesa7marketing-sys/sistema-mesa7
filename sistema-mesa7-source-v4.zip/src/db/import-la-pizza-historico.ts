// Importação única do histórico Mar/2026–Ago/2026 da La Pizza D'Caio, a
// partir do dashboard avulso (HTML) que a Mesa7 já usava com esse cliente
// antes do Sistema Mesa7. Fonte dos números: Cardápio Web (financeiro/canais),
// Meta Ads (funil de anúncios), Google Meu Negócio e RePediu (CRM).
//
// Cada mês vira um período (period_start = dia 1 do mês) dentro de
// weekly_metrics — a tabela aceita qualquer granularidade de data, não só
// semanal. Meses sem um determinado bloco de dado (meta/gmb/crm = null)
// simplesmente não geram linha pra aquela métrica, então a página mostra
// "—" em vez de um valor inventado.
import "dotenv/config";
import { db } from "./index";
import { clients, weeklyMetrics } from "./schema";
import { and, eq, gte, lte, notInArray } from "drizzle-orm";

type Meta = { alc: number; clk: number; vpd: number; adc: number; chk: number; cmp: number; gas: number; fat: number };
type Gmb = { v: number; ch: number; cd: number; ct: number; or: number; st: number };
type Crm = { rec: number | null; msg: number; conv: number; rev: number };

const MESES: {
  id: string;
  tot: number;
  ped: number;
  ot: { del: { r: number }; mesa: { r: number }; ret: { r: number } };
  sc: { portal: { r: number }; site: { r: number }; ifood: { r: number }; whats: { r: number } };
  meta: Meta | null;
  gmb: Gmb | null;
  crm: Crm | null;
}[] = [
  {
    id: "2026-03", tot: 169155.16, ped: 1289,
    ot: { del: { r: 86682.65 }, mesa: { r: 73258.28 }, ret: { r: 9214.23 } },
    sc: { portal: { r: 80004.84 }, site: { r: 34538.70 }, ifood: { r: 42731.82 }, whats: { r: 11879.80 } },
    meta: null, gmb: { v: 184, ch: 66, cd: 10, ct: 0, or: 60, st: 37 }, crm: null,
  },
  {
    id: "2026-04", tot: 175613.43, ped: 1292,
    ot: { del: { r: 96266.99 }, mesa: { r: 71536.74 }, ret: { r: 7809.70 } },
    sc: { portal: { r: 74905.02 }, site: { r: 43770.90 }, ifood: { r: 43279.47 }, whats: { r: 13658.04 } },
    meta: null, gmb: { v: 196, ch: 81, cd: 5, ct: 5, or: 79, st: 26 }, crm: { rec: 143, msg: 897, conv: 147, rev: 16982.72 },
  },
  {
    id: "2026-05", tot: 187610.17, ped: 1364,
    ot: { del: { r: 105107.35 }, mesa: { r: 73503.55 }, ret: { r: 8999.27 } },
    sc: { portal: { r: 76439.79 }, site: { r: 46686.30 }, ifood: { r: 50152.38 }, whats: { r: 14331.70 } },
    meta: null, gmb: { v: 275, ch: 124, cd: 6, ct: 6, or: 100, st: 39 }, crm: { rec: 7, msg: 0, conv: 7, rev: 762.00 },
  },
  {
    id: "2026-06", tot: 180014.55, ped: 1355,
    ot: { del: { r: 105255.37 }, mesa: { r: 64613.67 }, ret: { r: 10145.51 } },
    sc: { portal: { r: 68849.87 }, site: { r: 46360.24 }, ifood: { r: 53038.44 }, whats: { r: 11766.00 } },
    meta: { alc: 27535, clk: 1028, vpd: 837, adc: 38, chk: 38, cmp: 31, gas: 543.03, fat: 3677.55 },
    gmb: { v: 193, ch: 73, cd: 5, ct: 9, or: 71, st: 35 }, crm: { rec: 13, msg: 837, conv: 82, rev: 7565.82 },
  },
  {
    id: "2026-07", tot: 189281.85, ped: 1379,
    ot: { del: { r: 106136.01 }, mesa: { r: 71484.93 }, ret: { r: 11660.91 } },
    sc: { portal: { r: 74519.46 }, site: { r: 48843.07 }, ifood: { r: 51779.72 }, whats: { r: 14139.60 } },
    meta: { alc: 49084, clk: 4144, vpd: 3384, adc: 223, chk: 146, cmp: 124, gas: 1939.91, fat: 15360.15 },
    gmb: { v: 238, ch: 83, cd: 11, ct: 7, or: 97, st: 40 }, crm: { rec: null, msg: 3206, conv: 240, rev: 26852.65 },
  },
  {
    id: "2026-08", tot: 187311.67, ped: 1354,
    ot: { del: { r: 103961.31 }, mesa: { r: 74758.10 }, ret: { r: 8586.35 } },
    sc: { portal: { r: 78088.34 }, site: { r: 49060.90 }, ifood: { r: 47977.03 }, whats: { r: 12185.40 } },
    meta: { alc: 70066, clk: 6810, vpd: 5571, adc: 191, chk: 159, cmp: 138, gas: 2812.18, fat: 15231.20 },
    gmb: null, crm: null,
  },
];

async function upsertMetric(
  clientId: string,
  periodStart: string,
  pillar: "conversao" | "valor" | "relacionamento" | "financeiro" | "cardapio",
  metricKey: string,
  value: number,
  origem: "manual" | "meta_ads" | "google_ads" | "gmn" | "ifood" | "cardapio_web" | "repediu",
) {
  await db
    .insert(weeklyMetrics)
    .values({ clientId, periodStart, pillar, metricKey, metricValue: value.toFixed(2), origem })
    .onConflictDoUpdate({
      target: [weeklyMetrics.clientId, weeklyMetrics.periodStart, weeklyMetrics.metricKey],
      set: { metricValue: value.toFixed(2), pillar, origem, updatedAt: new Date() },
    });
}

async function main() {
  const [client] = await db.select().from(clients).where(eq(clients.slug, "la-pizza-dcaio")).limit(1);
  if (!client) {
    console.error("cliente la-pizza-dcaio não encontrado — rode o onboarding primeiro");
    process.exit(1);
  }

  // Antes deste import, já existia um pull avulso de "investimento Meta Ads"
  // da semana corrente (period_start = alguma segunda-feira dentro de
  // agosto/2026), feito antes desse histórico mensal existir. Agora que
  // agosto entra completo (dia 1), essa linha avulsa fica redundante e cria
  // uma queda falsa no gráfico — remove qualquer linha de Meta Ads dentro da
  // janela mar–ago/2026 que não seja exatamente o dia 1 de um dos meses.
  const periodosDoImport = MESES.map((m) => `${m.id}-01`);
  await db
    .delete(weeklyMetrics)
    .where(
      and(
        eq(weeklyMetrics.clientId, client.id),
        eq(weeklyMetrics.origem, "meta_ads"),
        gte(weeklyMetrics.periodStart, "2026-03-01"),
        lte(weeklyMetrics.periodStart, "2026-08-31"),
        notInArray(weeklyMetrics.periodStart, periodosDoImport),
      ),
    );

  for (const m of MESES) {
    const periodStart = `${m.id}-01`;

    await upsertMetric(client.id, periodStart, "financeiro", "faturamento_total", m.tot, "cardapio_web");
    await upsertMetric(client.id, periodStart, "financeiro", "ticket_medio", m.ped ? m.tot / m.ped : 0, "cardapio_web");
    await upsertMetric(client.id, periodStart, "financeiro", "fin_delivery_receita", m.ot.del.r, "cardapio_web");
    await upsertMetric(client.id, periodStart, "financeiro", "fin_mesa_receita", m.ot.mesa.r, "cardapio_web");
    await upsertMetric(client.id, periodStart, "financeiro", "fin_retirada_receita", m.ot.ret.r, "cardapio_web");
    await upsertMetric(client.id, periodStart, "financeiro", "fin_ifood_receita", m.sc.ifood.r, "cardapio_web");
    await upsertMetric(
      client.id, periodStart, "financeiro", "fin_canais_proprios_receita",
      m.sc.portal.r + m.sc.site.r + m.sc.whats.r, "cardapio_web",
    );

    if (m.meta) {
      await upsertMetric(client.id, periodStart, "conversao", "meta_investimento", m.meta.gas, "meta_ads");
      await upsertMetric(client.id, periodStart, "conversao", "meta_leads", m.meta.cmp, "meta_ads");
      if (m.meta.gas) {
        await upsertMetric(client.id, periodStart, "conversao", "meta_roas", m.meta.fat / m.meta.gas, "meta_ads");
      }
    }

    if (m.gmb) {
      await upsertMetric(client.id, periodStart, "valor", "gmb_visualizacoes", m.gmb.v, "gmn");
      await upsertMetric(client.id, periodStart, "valor", "gmb_ligacoes", m.gmb.ch, "gmn");
    }

    if (m.crm) {
      if (m.crm.rec !== null) {
        await upsertMetric(client.id, periodStart, "relacionamento", "crm_recuperados", m.crm.rec, "repediu");
      }
      await upsertMetric(client.id, periodStart, "relacionamento", "crm_mensagens", m.crm.msg, "repediu");
      await upsertMetric(client.id, periodStart, "relacionamento", "crm_receita_gerada", m.crm.rev, "repediu");
    }

    console.log(`importado: ${m.id} — faturamento R$ ${m.tot.toFixed(2)}`);
  }

  console.log("\nConcluído.");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
