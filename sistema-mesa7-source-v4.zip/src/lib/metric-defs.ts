export type MetricDef = {
  key: string;
  label: string;
  pillar: "conversao" | "valor" | "relacionamento" | "financeiro" | "cardapio";
  origem: "manual" | "meta_ads" | "google_ads" | "gmn" | "ifood" | "cardapio_web" | "repediu";
  unit?: string;
  /** Se true, esse indicador é alimentado por API e não deve ser digitado manualmente. */
  autoOnly?: boolean;
};

export const METRIC_DEFS: MetricDef[] = [
  { key: "meta_investimento", label: "Investimento Meta Ads", pillar: "conversao", origem: "meta_ads", unit: "R$", autoOnly: true },
  { key: "meta_leads", label: "Leads (Meta Ads)", pillar: "conversao", origem: "meta_ads", autoOnly: true },
  { key: "meta_roas", label: "ROAS (Meta Ads)", pillar: "conversao", origem: "meta_ads", unit: "x", autoOnly: true },
  { key: "instagram_seguidores", label: "Seguidores Instagram", pillar: "valor", origem: "manual" },
  { key: "avaliacoes_google_nota", label: "Nota média Google", pillar: "valor", origem: "gmn" },
  { key: "clientes_ativos_crm", label: "Clientes ativos (CRM)", pillar: "relacionamento", origem: "manual" },
  { key: "taxa_recompra", label: "Taxa de recompra", pillar: "relacionamento", origem: "manual", unit: "%" },
  { key: "faturamento_total", label: "Faturamento total", pillar: "financeiro", origem: "manual", unit: "R$" },
  { key: "ticket_medio", label: "Ticket médio", pillar: "financeiro", origem: "manual", unit: "R$" },
  { key: "cardapio_visualizacoes", label: "Visualizações do cardápio", pillar: "cardapio", origem: "cardapio_web" },
  { key: "cardapio_conversao", label: "Conversão do cardápio", pillar: "cardapio", origem: "cardapio_web", unit: "%" },

  // Quebra de faturamento por canal — padrão único pra todos os clientes
  // (Salão / iFood / Cardápio Próprio / 99Food), alimentado via Cardápio Web,
  // PDV ou planilha/dashboard de cada cliente, dependendo da fonte disponível.
  { key: "fin_salao_receita", label: "Receita Salão", pillar: "financeiro", origem: "cardapio_web", unit: "R$", autoOnly: true },
  { key: "fin_ifood_receita", label: "Receita iFood", pillar: "financeiro", origem: "cardapio_web", unit: "R$", autoOnly: true },
  { key: "fin_cardapio_proprio_receita", label: "Receita Cardápio Próprio", pillar: "financeiro", origem: "cardapio_web", unit: "R$", autoOnly: true },
  { key: "fin_99food_receita", label: "Receita 99Food", pillar: "financeiro", origem: "cardapio_web", unit: "R$", autoOnly: true },

  // RePediu (CRM/recuperação de clientes).
  { key: "crm_recuperados", label: "Clientes recuperados (RePediu)", pillar: "relacionamento", origem: "repediu", autoOnly: true },
  { key: "crm_mensagens", label: "Mensagens enviadas (RePediu)", pillar: "relacionamento", origem: "repediu", autoOnly: true },
  { key: "crm_receita_gerada", label: "Receita gerada (RePediu)", pillar: "relacionamento", origem: "repediu", unit: "R$", autoOnly: true },

  // Google Meu Negócio — parte do pilar Valor (avaliações, posicionamento).
  { key: "gmb_visualizacoes", label: "Visualizações no perfil (GMN)", pillar: "valor", origem: "gmn", autoOnly: true },
  { key: "gmb_ligacoes", label: "Ligações pelo perfil (GMN)", pillar: "valor", origem: "gmn", autoOnly: true },

  // Google Ads — mesmo tratamento do Meta Ads dentro do pilar Conversão.
  { key: "google_investimento", label: "Investimento Google Ads", pillar: "conversao", origem: "google_ads", unit: "R$", autoOnly: true },
  { key: "google_leads", label: "Leads (Google Ads)", pillar: "conversao", origem: "google_ads", autoOnly: true },
  { key: "google_roas", label: "ROAS (Google Ads)", pillar: "conversao", origem: "google_ads", unit: "x", autoOnly: true },
];

export const PILLAR_LABEL: Record<string, string> = {
  conversao: "Conversão",
  valor: "Valor",
  relacionamento: "Relacionamento",
  financeiro: "Financeiro",
  cardapio: "Cardápio",
};

export function manualMetricDefs() {
  return METRIC_DEFS.filter((m) => !m.autoOnly);
}
