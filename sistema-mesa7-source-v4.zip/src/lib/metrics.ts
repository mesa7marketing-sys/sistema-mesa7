import { db } from "@/db";
import { weeklyMetrics } from "@/db/schema";
import { and, eq, desc } from "drizzle-orm";

/** Retorna { [metricKey]: { value, periodStart } } para as duas últimas semanas com dado. */
export async function latestTwoPeriods(clientId: string, metricKeys: string[]) {
  const rows = await db
    .select()
    .from(weeklyMetrics)
    .where(and(eq(weeklyMetrics.clientId, clientId)))
    .orderBy(desc(weeklyMetrics.periodStart));

  const byKey: Record<string, { current?: number; previous?: number; periodStart?: string }> = {};

  for (const key of metricKeys) {
    const forKey = rows.filter((r) => r.metricKey === key);
    byKey[key] = {
      current: forKey[0] ? Number(forKey[0].metricValue) : undefined,
      previous: forKey[1] ? Number(forKey[1].metricValue) : undefined,
      periodStart: forKey[0]?.periodStart ?? undefined,
    };
  }

  return byKey;
}

/** Retorna as últimas `weeks` semanas (mais antiga -> mais recente) para uma metricKey. */
export async function seriesFor(clientId: string, metricKey: string, weeks = 8) {
  const rows = await db
    .select()
    .from(weeklyMetrics)
    .where(and(eq(weeklyMetrics.clientId, clientId), eq(weeklyMetrics.metricKey, metricKey)))
    .orderBy(desc(weeklyMetrics.periodStart))
    .limit(weeks);

  const ordered = rows.reverse();
  return {
    xLabels: ordered.map((r) => formatWeekLabel(r.periodStart)),
    values: ordered.map((r) => Number(r.metricValue)),
  };
}

function formatWeekLabel(periodStart: string) {
  const d = new Date(periodStart + "T00:00:00");
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
}

export function mondayOf(date: Date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d.toISOString().slice(0, 10);
}

/** Valores já lançados para a semana informada (default: semana atual), por metricKey. */
export async function valuesForWeek(clientId: string, metricKeys: string[], periodStart = mondayOf(new Date())) {
  const rows = await db
    .select()
    .from(weeklyMetrics)
    .where(and(eq(weeklyMetrics.clientId, clientId), eq(weeklyMetrics.periodStart, periodStart)));

  const byKey: Record<string, number | undefined> = {};
  for (const key of metricKeys) {
    const row = rows.find((r) => r.metricKey === key);
    byKey[key] = row ? Number(row.metricValue) : undefined;
  }
  return byKey;
}

export function pctDelta(current?: number, previous?: number) {
  if (current === undefined || previous === undefined || previous === 0) return undefined;
  return ((current - previous) / previous) * 100;
}

export function formatBRL(value?: number) {
  if (value === undefined) return "—";
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
}

export function formatNumber(value?: number, decimals = 0) {
  if (value === undefined) return "—";
  return value.toLocaleString("pt-BR", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

export function formatDeltaLabel(delta?: number) {
  if (delta === undefined) return undefined;
  const sign = delta > 0 ? "+" : "";
  return `${sign}${delta.toFixed(1)}% vs. período anterior`;
}

export function deltaTone(delta?: number): "good" | "warn" | "bad" | undefined {
  if (delta === undefined) return undefined;
  if (delta > 0.5) return "good";
  if (delta < -0.5) return "bad";
  return "warn";
}
