export const CVR_PAGES = [
  { slug: "resumo", label: "Resumo Executivo", group: "Visão geral" },
  { slug: "metodo-cvr", label: "Método CVR", group: "Relatório" },
  { slug: "financeiro", label: "Financeiro & Canais", group: "Relatório" },
  { slug: "cardapio", label: "Cardápio", group: "Operação" },
  { slug: "plano-de-acao", label: "Plano de Ação", group: "Operação" },
  { slug: "insights", label: "Insights", group: "Operação" },
] as const;

/** Rotas antigas mantidas como redirect (links salvos, favoritos etc). */
export const LEGACY_REDIRECTS: Record<string, string> = {
  conversao: "metodo-cvr",
  valor: "metodo-cvr",
  relacionamento: "metodo-cvr",
};

export type CvrSlug = (typeof CVR_PAGES)[number]["slug"];
