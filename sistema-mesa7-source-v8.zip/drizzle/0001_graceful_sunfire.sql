ALTER TYPE "public"."pillar" ADD VALUE 'plataformas';--> statement-breakpoint
ALTER TYPE "public"."pillar" ADD VALUE 'comportamento';--> statement-breakpoint
ALTER TYPE "public"."pillar" ADD VALUE 'marketing_360';--> statement-breakpoint
CREATE TABLE "menu_item_sales" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"client_id" uuid NOT NULL,
	"period_start" date NOT NULL,
	"item_name" varchar(300) NOT NULL,
	"quantity" numeric(12, 2) NOT NULL,
	"revenue" numeric(14, 2) NOT NULL,
	"orders_count" numeric(10, 0),
	"origem" "origem" DEFAULT 'cardapio_web' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "menu_item_sales" ADD CONSTRAINT "menu_item_sales_client_id_clients_id_fk" FOREIGN KEY ("client_id") REFERENCES "public"."clients"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "menu_item_sales_client_period_item_idx" ON "menu_item_sales" USING btree ("client_id","period_start","item_name");