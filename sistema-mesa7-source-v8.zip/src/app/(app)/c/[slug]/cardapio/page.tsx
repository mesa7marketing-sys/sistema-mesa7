import { requireClientAccess } from "@/lib/access";
import { PageHead, Tiles, Tile, Card, DataTable } from "@/components/ui";
import { LineChart } from "@/components/charts/LineChart";
import { latestTwoPeriods, seriesFor, pctDelta, formatNumber, formatBRL, formatDeltaLabel, deltaTone } from "@/lib/metrics";
import { db } from "@/db";
import { menuItemSales } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

const KEYS = ["cardapio_visualizacoes", "cardapio_conversao"];

export default async function CardapioPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { client } = await requireClientAccess(slug);

  const m = await latestTwoPeriods(client.id, KEYS);
  const visualizacoes = await seriesFor(client.id, "cardapio_visualizacoes");
  const conversao = await seriesFor(client.id, "cardapio_conversao");

  const itensVendidos = await db
    .select()
    .from(menuItemSales)
    .where(eq(menuItemSales.clientId, client.id))
    .orderBy(desc(menuItemSales.periodStart), desc(menuItemSales.revenue))
    .limit(20);

  const periodoAbc = itensVendidos[0]?.periodStart;
  const itensDoPeriodo = itensVendidos.filter((i) => i.periodStart === periodoAbc);
  const receitaTotalAbc = itensDoPeriodo.reduce((s, i) => s + Number(i.revenue), 0);
  let acumulado = 0;
  const curvaAbc = itensDoPeriodo.map((i) => {
    acumulado += Number(i.revenue);
    const pctAcumulado = receitaTotalAbc > 0 ? (acumulado / receitaTotalAbc) * 100 : 0;
    const classe = pctAcumulado <= 80 ? "A" : pctAcumulado <= 95 ? "B" : "C";
    return { ...i, pctAcumulado, classe };
  });

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Operação"
        title={`Cardápio & Curva ABC — ${client.name}`}
        description="Visualizações e conversão do cardápio digital, e o ranking de itens mais vendidos (Curva ABC) pra quem já tem histórico de vendas por item integrado."
      />

      <Tiles>
        <Tile
          label="Visualizações do cardápio"
          value={formatNumber(m.cardapio_visualizacoes.current)}
          deltaLabel={formatDeltaLabel(pctDelta(m.cardapio_visualizacoes.current, m.cardapio_visualizacoes.previous))}
          deltaTone={deltaTone(pctDelta(m.cardapio_visualizacoes.current, m.cardapio_visualizacoes.previous))}
          caption="Semana atual"
        />
        <Tile
          label="Conversão do cardápio"
          value={m.cardapio_conversao.current ? `${formatNumber(m.cardapio_conversao.current, 1)}%` : "—"}
          deltaLabel={formatDeltaLabel(pctDelta(m.cardapio_conversao.current, m.cardapio_conversao.previous))}
          deltaTone={deltaTone(pctDelta(m.cardapio_conversao.current, m.cardapio_conversao.previous))}
          caption="Visualização → pedido"
        />
      </Tiles>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Card title="Visualizações" subtitle="Últimas 8 semanas · origem: Cardápio Web">
          <LineChart
            series={[{ name: "Visualizações", color: "var(--series-7)", values: visualizacoes.values }]}
            xLabels={visualizacoes.xLabels}
            format="number"
            aria="Visualizações do cardápio por semana"
          />
        </Card>
        <Card title="Conversão" subtitle="Últimas 8 semanas · origem: Cardápio Web">
          <LineChart
            series={[{ name: "Conversão", color: "var(--series-2)", values: conversao.values }]}
            xLabels={conversao.xLabels}
            format="percent0"
            aria="Conversão do cardápio por semana"
          />
        </Card>
      </div>

      <Card
        title="Curva ABC de Itens"
        subtitle={periodoAbc ? `Ranking por receita · ${periodoAbc}` : "Ranking por receita"}
      >
        {curvaAbc.length === 0 ? (
          <div style={{ fontSize: 13.5, color: "var(--text-muted)", lineHeight: 1.6 }}>
            Ainda sem histórico de vendas por item pra este cliente. A Curva ABC é alimentada a partir dos pedidos
            detalhados da API do Cardápio Web (pra clientes conectados) — entra numa próxima rodada de importação.
          </div>
        ) : (
          <DataTable
            columns={["Item", "Classe", "Qtd. vendida", "Receita", "% acumulado"]}
            rows={curvaAbc.map((i) => [
              i.itemName,
              i.classe,
              formatNumber(Number(i.quantity)),
              formatBRL(Number(i.revenue)),
              `${i.pctAcumulado.toFixed(1)}%`,
            ])}
          />
        )}
      </Card>
    </div>
  );
}
