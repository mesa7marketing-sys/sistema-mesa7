import { requireClientAccess } from "@/lib/access";
import { PageHead, KpiCard, Card, Pill, StatList, DataTable } from "@/components/ui";
import { FilterBar } from "@/components/FilterBar";
import {
  formatNumber,
  firstOfMonth,
  periodStartFromMonthValue,
  monthLabel,
  recentMonthOptions,
  snapshotForMonth,
  latestPeriodWithData,
} from "@/lib/metrics";

const KEYS = [
  "comport_hora_pico",
  "comport_pedidos_madrugada",
  "comport_pedidos_manha",
  "comport_pedidos_tarde",
  "comport_pedidos_noite",
  "comport_pedidos_dia_semana",
  "comport_pedidos_fim_semana",
  "plat_pedidos_total",
  "plat_pedidos_cancelados",
  "plat_taxa_cancelamento",
];

export default async function ComportamentoPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ mes?: string }>;
}) {
  const { slug } = await params;
  const { mes } = await searchParams;
  const { client } = await requireClientAccess(slug);

  const periodStart = mes
    ? periodStartFromMonthValue(mes)
    : (await latestPeriodWithData(client.id)) ?? firstOfMonth(new Date());
  const monthOptions = recentMonthOptions(24);

  const m = await snapshotForMonth(client.id, KEYS, periodStart);
  const temDado = m.comport_pedidos_dia_semana.current !== undefined;
  const totalPedidos = m.plat_pedidos_total.current;

  const diaPartes = [
    { label: "Madrugada (00h–06h)", value: m.comport_pedidos_madrugada.current },
    { label: "Manhã (06h–12h)", value: m.comport_pedidos_manha.current },
    { label: "Tarde (12h–18h)", value: m.comport_pedidos_tarde.current },
    { label: "Noite (18h–00h)", value: m.comport_pedidos_noite.current },
  ];

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Comportamento"
        title={`Comportamento de Consumo — ${client.name}`}
        description="Quando os clientes pedem: horário de pico, dia da semana vs. fim de semana e cancelamentos, direto da API do Cardápio Web."
      />

      <FilterBar basePath={`/c/${slug}/comportamento`} monthOptions={monthOptions} month={periodStart} />
      <div style={{ marginBottom: 20 }}>
        <Pill tone="accent">{monthLabel(periodStart)}</Pill>
      </div>

      {!temDado ? (
        <Card>
          <div style={{ fontSize: 13.5, color: "var(--text-muted)", lineHeight: 1.6 }}>
            Este cliente ainda não está conectado à API do Cardápio Web — sem dado de comportamento de pedidos pra{" "}
            {monthLabel(periodStart)}.
          </div>
        </Card>
      ) : (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 12, marginBottom: 22 }}>
            <KpiCard
              icon="clock"
              label="Horário de pico"
              value={m.comport_hora_pico.current !== undefined ? `${formatNumber(m.comport_hora_pico.current)}h` : "—"}
              caption="Hora com mais pedidos"
            />
            <KpiCard
              icon="chart"
              accent="accent-2"
              label="Pedidos no fim de semana"
              value={
                totalPedidos && m.comport_pedidos_fim_semana.current !== undefined
                  ? `${((m.comport_pedidos_fim_semana.current / totalPedidos) * 100).toFixed(0)}%`
                  : "—"
              }
              caption="Sábado e domingo"
            />
            <KpiCard
              icon="percent"
              label="Taxa de cancelamento"
              value={m.plat_taxa_cancelamento.current !== undefined ? `${formatNumber(m.plat_taxa_cancelamento.current, 1)}%` : "—"}
              caption={`${formatNumber(m.plat_pedidos_cancelados.current)} pedidos cancelados`}
            />
          </div>

          <Card title="Pedidos por período do dia" subtitle={monthLabel(periodStart)}>
            <StatList
              rows={diaPartes.map((d) => ({
                label: d.label,
                value: totalPedidos && d.value !== undefined ? `${formatNumber(d.value)} (${((d.value / totalPedidos) * 100).toFixed(0)}%)` : "—",
              }))}
            />
          </Card>

          <Card title="Dia de semana vs. fim de semana" subtitle={monthLabel(periodStart)}>
            <DataTable
              columns={["Período", "Pedidos", "% do total"]}
              rows={[
                [
                  "Segunda a Sexta",
                  formatNumber(m.comport_pedidos_dia_semana.current),
                  totalPedidos && m.comport_pedidos_dia_semana.current !== undefined
                    ? `${((m.comport_pedidos_dia_semana.current / totalPedidos) * 100).toFixed(1)}%`
                    : "—",
                ],
                [
                  "Sábado e Domingo",
                  formatNumber(m.comport_pedidos_fim_semana.current),
                  totalPedidos && m.comport_pedidos_fim_semana.current !== undefined
                    ? `${((m.comport_pedidos_fim_semana.current / totalPedidos) * 100).toFixed(1)}%`
                    : "—",
                ],
              ]}
            />
          </Card>
        </>
      )}
    </div>
  );
}
