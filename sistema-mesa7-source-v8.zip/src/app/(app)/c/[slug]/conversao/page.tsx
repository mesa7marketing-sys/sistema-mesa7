import { redirect } from "next/navigation";

// Conversão foi incorporada à página única "Método CVR" (set/2026).
// Rota mantida como redirect pra não quebrar links salvos.
export default async function ConversaoRedirect({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  redirect(`/c/${slug}/metodo-cvr`);
}
