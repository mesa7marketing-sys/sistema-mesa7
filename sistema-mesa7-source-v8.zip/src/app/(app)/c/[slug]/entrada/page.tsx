import { requireClientAccess } from "@/lib/access";
import { PageHead, Card } from "@/components/ui";
import { MonthSelect } from "@/components/MonthSelect";
import { valuesForWeek, firstOfMonth, periodStartFromMonthValue, monthLabel, recentMonthOptions } from "@/lib/metrics";
import { manualMetricDefs, PILLAR_LABEL } from "@/lib/metric-defs";
import { saveWeeklyEntry } from "./actions";
import { redirect } from "next/navigation";

export default async function EntradaPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ mes?: string }>;
}) {
  const { slug } = await params;
  const { mes } = await searchParams;
  const { session, client } = await requireClientAccess(slug);

  if (session.user.role === "client") {
    redirect(`/c/${slug}/resumo`);
  }

  const defs = manualMetricDefs();
  const periodStart = mes ? periodStartFromMonthValue(mes) : firstOfMonth(new Date());
  const current = await valuesForWeek(client.id, defs.map((d) => d.key), periodStart);
  const monthOptions = recentMonthOptions(24);

  const pillars = Array.from(new Set(defs.map((d) => d.pillar)));

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 900 }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
        <PageHead
          kicker="Preenchimento mensal"
          title={`Lançar dados — ${client.name}`}
          description="Só é preciso preencher o que não vem de API ou de importação automaticamente. Escolha o mês pra ver ou editar o que já foi lançado."
        />
        <MonthSelect options={monthOptions} value={periodStart} basePath={`/c/${slug}/entrada`} />
      </div>

      <div
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 8,
          background: "var(--surface-2)",
          border: "1px solid var(--border-strong)",
          borderRadius: 99,
          padding: "6px 14px",
          fontSize: 12.5,
          fontWeight: 700,
          color: "var(--text-secondary)",
          marginBottom: 20,
        }}
      >
        Mês selecionado: <span style={{ color: "var(--text-primary)" }}>{monthLabel(periodStart)}</span>
      </div>

      <form action={saveWeeklyEntry}>
        <input type="hidden" name="slug" value={slug} />
        <input type="hidden" name="periodStart" value={periodStart} />
        {pillars.map((pillar) => (
          <Card key={pillar} title={PILLAR_LABEL[pillar]}>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                gap: 12,
              }}
            >
              {defs
                .filter((d) => d.pillar === pillar)
                .map((d) => (
                  <label
                    key={d.key}
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: 8,
                      background: "var(--surface)",
                      border: "1px solid var(--border)",
                      borderRadius: 12,
                      padding: "12px 14px 13px",
                    }}
                  >
                    <span style={{ fontSize: 12, color: "var(--text-secondary)", fontWeight: 700 }}>
                      {d.label} {d.unit && <span style={{ color: "var(--text-muted)" }}>({d.unit})</span>}
                    </span>
                    <input
                      name={d.key}
                      type="text"
                      inputMode="decimal"
                      defaultValue={current[d.key] ?? ""}
                      placeholder="—"
                      style={{
                        background: "var(--surface-2)",
                        border: "1px solid var(--border-strong)",
                        borderRadius: 9,
                        padding: "9px 11px",
                        color: "var(--text-primary)",
                        fontSize: 15,
                        fontWeight: 600,
                        fontFamily: "inherit",
                      }}
                    />
                  </label>
                ))}
            </div>
          </Card>
        ))}

        <button
          type="submit"
          style={{
            background: "var(--accent)",
            color: "var(--accent-ink)",
            border: "none",
            borderRadius: 9,
            padding: "11px 20px",
            fontWeight: 700,
            fontSize: 14,
            cursor: "pointer",
            fontFamily: "inherit",
          }}
        >
          Salvar dados de {monthLabel(periodStart)}
        </button>
      </form>
    </div>
  );
}
