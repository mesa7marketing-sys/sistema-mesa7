import { requireClientAccess } from "@/lib/access";
import { PageHead, KpiCard, Card, Pill, DataTable } from "@/components/ui";
import { FilterBar } from "@/components/FilterBar";
import { LineChart } from "@/components/charts/LineChart";
import { BarChart } from "@/components/charts/BarChart";
import { DonutChart } from "@/components/charts/DonutChart";
import {
  seriesFor,
  formatBRL,
  formatDeltaLabel,
  deltaTone,
  firstOfMonth,
  periodStartFromMonthValue,
  monthLabel,
  recentMonthOptions,
  snapshotForMonth,
  latestPeriodWithData,
} from "@/lib/metrics";

const KEYS = ["faturamento_total", "ticket_medio"];

// Quebra de faturamento por canal — mesmo padrão pra todos os clientes
// (Salão / iFood / Cardápio Próprio / 99Food). Cada cliente só mostra os
// canais que de fato tem dado.
const CANAIS = [
  { key: "fin_salao_receita", label: "Salão", color: "var(--series-1)" },
  { key: "fin_ifood_receita", label: "iFood", color: "var(--series-2)" },
  { key: "fin_cardapio_proprio_receita", label: "Cardápio Próprio", color: "var(--series-5)" },
  { key: "fin_99food_receita", label: "99Food", color: "var(--series-6)" },
] as const;

export default async function FinanceiroPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ mes?: string }>;
}) {
  const { slug } = await params;
  const { mes } = await searchParams;
  const { client } = await requireClientAccess(slug);

  const periodStart = mes
    ? periodStartFromMonthValue(mes)
    : (await latestPeriodWithData(client.id)) ?? firstOfMonth(new Date());
  const monthOptions = recentMonthOptions(24);

  const m = await snapshotForMonth(client.id, KEYS, periodStart);
  const cm = await snapshotForMonth(
    client.id,
    CANAIS.map((c) => c.key),
    periodStart,
  );
  const faturamento = await seriesFor(client.id, "faturamento_total");
  const ticket = await seriesFor(client.id, "ticket_medio");
  const canalSeries = await Promise.all(CANAIS.map((c) => seriesFor(client.id, c.key)));

  const canaisComDado = CANAIS.map((c, i) => ({ ...c, m: cm[c.key], series: canalSeries[i] })).filter(
    (c) => c.m.current !== undefined,
  );
  const totalCanais = canaisComDado.reduce((s, c) => s + (c.m.current ?? 0), 0);

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Método CVR"
        title={`Financeiro & Canais — ${client.name}`}
        description="Loja física, iFood, 99Food e site na composição do faturamento."
      />

      <FilterBar basePath={`/c/${slug}/financeiro`} monthOptions={monthOptions} month={periodStart} />
      <div style={{ marginBottom: 20 }}>
        <Pill tone="accent">{monthLabel(periodStart)}</Pill>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 12, marginBottom: 22 }}>
        <KpiCard
          icon="money"
          label="Faturamento total"
          value={formatBRL(m.faturamento_total.current)}
          deltaLabel={formatDeltaLabel(m.faturamento_total.momDelta)}
          deltaTone={deltaTone(m.faturamento_total.momDelta)}
          caption="vs. mês anterior"
        />
        <KpiCard
          icon="receipt"
          label="Ticket médio"
          value={formatBRL(m.ticket_medio.current)}
          deltaLabel={formatDeltaLabel(m.ticket_medio.momDelta)}
          deltaTone={deltaTone(m.ticket_medio.momDelta)}
        />
        {canaisComDado[0] && (
          <KpiCard
            icon="store"
            accent="accent-2"
            label={canaisComDado[0].label}
            value={formatBRL(canaisComDado[0].m.current)}
            deltaLabel={formatDeltaLabel(canaisComDado[0].m.momDelta)}
            deltaTone={deltaTone(canaisComDado[0].m.momDelta)}
          />
        )}
        {canaisComDado.length > 1 && (
          <KpiCard
            icon="bag"
            accent="accent-2"
            label="Canais de delivery"
            value={formatBRL(canaisComDado.slice(1).reduce((s, c) => s + (c.m.current ?? 0), 0))}
            caption={canaisComDado
              .slice(1)
              .map((c) => c.label)
              .join(" + ")}
          />
        )}
      </div>

      {canaisComDado.length > 0 && (
        <Card title="Divisão de Faturamento" subtitle={monthLabel(periodStart)}>
          <DonutChart
            data={canaisComDado.map((c) => ({ label: c.label, value: c.m.current ?? 0, color: c.color }))}
            aria="Divisão de faturamento por canal"
          />
        </Card>
      )}

      {canaisComDado.length > 0 && (
        <Card title="Detalhamento do Período" subtitle={monthLabel(periodStart)}>
          <DataTable
            columns={["Canal", "Faturamento", "% do total"]}
            rows={canaisComDado.map((c) => [
              c.label,
              formatBRL(c.m.current),
              totalCanais > 0 ? `${(((c.m.current ?? 0) / totalCanais) * 100).toFixed(1)}%` : "—",
            ])}
          />
        </Card>
      )}

      <Card title="Faturamento por período" subtitle="Histórico completo · preenchimento manual ou importado">
        <BarChart
          data={faturamento.xLabels.map((label, i) => ({ label, value: faturamento.values[i], color: "var(--accent)" }))}
          format="currency-k"
          aria="Faturamento por período"
        />
      </Card>
      <Card title="Ticket médio" subtitle="Histórico completo">
        <LineChart
          series={[{ name: "Ticket médio", color: "var(--accent-2)", values: ticket.values }]}
          xLabels={ticket.xLabels}
          format="currency"
          aria="Ticket médio por período"
        />
      </Card>

      {canaisComDado.length > 0 && (
        <Card title="Faturamento por canal" subtitle="Histórico completo · Salão / iFood / Cardápio Próprio / 99Food">
          <LineChart
            series={canaisComDado.map((c) => ({ name: c.label, color: c.color, values: c.series.values }))}
            xLabels={canaisComDado[0].series.xLabels}
            format="currency-k"
            aria="Faturamento por canal e por período"
          />
        </Card>
      )}
    </div>
  );
}
