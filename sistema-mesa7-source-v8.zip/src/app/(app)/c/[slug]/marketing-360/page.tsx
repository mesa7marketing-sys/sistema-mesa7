import { requireClientAccess } from "@/lib/access";
import { PageHead, KpiCard, Card, Pill, StatList, DataTable } from "@/components/ui";
import { FilterBar } from "@/components/FilterBar";
import { DonutChart } from "@/components/charts/DonutChart";
import {
  formatBRL,
  formatNumber,
  firstOfMonth,
  periodStartFromMonthValue,
  monthLabel,
  recentMonthOptions,
  snapshotForMonth,
  latestPeriodWithData,
} from "@/lib/metrics";

const KEYS = [
  "meta_investimento",
  "meta_leads",
  "meta_roas",
  "google_investimento",
  "google_leads",
  "google_roas",
  "instagram_seguidores",
  "avaliacoes_google_nota",
  "gmb_visualizacoes",
  "gmb_ligacoes",
];

export default async function Marketing360Page({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ mes?: string }>;
}) {
  const { slug } = await params;
  const { mes } = await searchParams;
  const { client } = await requireClientAccess(slug);

  const periodStart = mes
    ? periodStartFromMonthValue(mes)
    : (await latestPeriodWithData(client.id)) ?? firstOfMonth(new Date());
  const monthOptions = recentMonthOptions(24);
  const m = await snapshotForMonth(client.id, KEYS, periodStart);

  const temMeta = m.meta_investimento.current !== undefined;
  const temGoogle = m.google_investimento.current !== undefined;
  const temGmb = m.gmb_visualizacoes.current !== undefined;
  const temAlgumaMidia = temMeta || temGoogle;

  const canais = [
    temMeta && {
      label: "Meta Ads",
      color: "var(--series-1)",
      investimento: m.meta_investimento.current ?? 0,
      leads: m.meta_leads.current,
      roas: m.meta_roas.current,
    },
    temGoogle && {
      label: "Google Ads",
      color: "var(--series-2)",
      investimento: m.google_investimento.current ?? 0,
      leads: m.google_leads.current,
      roas: m.google_roas.current,
    },
  ].filter(Boolean) as { label: string; color: string; investimento: number; leads?: number; roas?: number }[];

  const investimentoTotal = canais.reduce((s, c) => s + c.investimento, 0);
  const leadsTotal = canais.reduce((s, c) => s + (c.leads ?? 0), 0);
  const roasBlended =
    investimentoTotal > 0 && canais.some((c) => c.roas !== undefined)
      ? canais.reduce((s, c) => s + (c.roas ?? 0) * c.investimento, 0) / investimentoTotal
      : undefined;

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Marketing 360°"
        title={`Marketing 360° — ${client.name}`}
        description="Visão consolidada de mídia paga (Meta Ads e Google Ads) e presença digital (Instagram e Google Meu Negócio)."
      />

      <FilterBar basePath={`/c/${slug}/marketing-360`} monthOptions={monthOptions} month={periodStart} />
      <div style={{ marginBottom: 20 }}>
        <Pill tone="accent">{monthLabel(periodStart)}</Pill>
      </div>

      {!temAlgumaMidia ? (
        <Card>
          <div style={{ fontSize: 13.5, color: "var(--text-muted)", lineHeight: 1.6 }}>
            Nenhum investimento em mídia paga registrado pra {monthLabel(periodStart)}.
          </div>
        </Card>
      ) : (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 12, marginBottom: 22 }}>
            <KpiCard icon="megaphone" label="Investimento total em mídia" value={formatBRL(investimentoTotal)} caption="Meta + Google" />
            <KpiCard icon="target" label="Leads gerados" value={formatNumber(leadsTotal)} />
            <KpiCard
              icon="chart"
              accent="accent-2"
              label="ROAS combinado"
              value={roasBlended !== undefined ? `${formatNumber(roasBlended, 1)}x` : "—"}
              caption="Ponderado por investimento"
            />
            <KpiCard
              icon="layers"
              accent="accent-2"
              label="Seguidores Instagram"
              value={formatNumber(m.instagram_seguidores.current)}
              deltaLabel={m.instagram_seguidores.momDelta !== undefined ? `${m.instagram_seguidores.momDelta > 0 ? "+" : ""}${m.instagram_seguidores.momDelta.toFixed(1)}%` : undefined}
            />
          </div>

          {canais.length > 1 && (
            <Card title="Divisão de Investimento" subtitle={monthLabel(periodStart)}>
              <DonutChart data={canais.map((c) => ({ label: c.label, value: c.investimento, color: c.color }))} aria="Divisão de investimento em mídia" />
            </Card>
          )}

          <Card title="Desempenho por Canal" subtitle={monthLabel(periodStart)}>
            <DataTable
              columns={["Canal", "Investimento", "Leads", "Custo por lead", "ROAS"]}
              rows={canais.map((c) => [
                c.label,
                formatBRL(c.investimento),
                formatNumber(c.leads),
                formatBRL(c.leads ? c.investimento / c.leads : undefined),
                c.roas !== undefined ? `${formatNumber(c.roas, 1)}x` : "—",
              ])}
            />
          </Card>

          <Card title="Presença Digital" subtitle="Google Meu Negócio e redes sociais">
            <StatList
              rows={[
                { label: "Nota média no Google", value: m.avaliacoes_google_nota.current ? formatNumber(m.avaliacoes_google_nota.current, 1) : "—" },
                { label: "Seguidores Instagram", value: formatNumber(m.instagram_seguidores.current) },
                ...(temGmb
                  ? [
                      { label: "Visualizações do Perfil (GMB)", value: formatNumber(m.gmb_visualizacoes.current) },
                      { label: "Ligações pelo Perfil (GMB)", value: formatNumber(m.gmb_ligacoes.current) },
                    ]
                  : []),
              ]}
            />
          </Card>
        </>
      )}
    </div>
  );
}
