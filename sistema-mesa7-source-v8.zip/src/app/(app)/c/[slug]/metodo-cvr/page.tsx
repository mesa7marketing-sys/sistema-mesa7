import { requireClientAccess } from "@/lib/access";
import { PageHead, SectionCard, StatList, Card, Pill } from "@/components/ui";
import { FilterBar } from "@/components/FilterBar";
import { LineChart } from "@/components/charts/LineChart";
import {
  seriesFor,
  formatBRL,
  formatNumber,
  firstOfMonth,
  periodStartFromMonthValue,
  monthLabel,
  recentMonthOptions,
  snapshotForMonth,
  latestPeriodWithData,
} from "@/lib/metrics";

const CONVERSAO_KEYS = ["meta_investimento", "meta_leads", "meta_roas", "google_investimento", "google_leads", "google_roas"];
const VALOR_KEYS = ["instagram_seguidores", "avaliacoes_google_nota", "gmb_visualizacoes", "gmb_ligacoes"];
const RELACIONAMENTO_KEYS = ["clientes_ativos_crm", "taxa_recompra", "crm_recuperados", "crm_mensagens", "crm_receita_gerada"];

export default async function MetodoCvrPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ mes?: string }>;
}) {
  const { slug } = await params;
  const { mes } = await searchParams;
  const { client } = await requireClientAccess(slug);

  const periodStart = mes
    ? periodStartFromMonthValue(mes)
    : (await latestPeriodWithData(client.id)) ?? firstOfMonth(new Date());
  const monthOptions = recentMonthOptions(24);

  const c = await snapshotForMonth(client.id, CONVERSAO_KEYS, periodStart);
  const v = await snapshotForMonth(client.id, VALOR_KEYS, periodStart);
  const r = await snapshotForMonth(client.id, RELACIONAMENTO_KEYS, periodStart);

  const temGoogle = c.google_investimento.current !== undefined;
  const temGmb = v.gmb_visualizacoes.current !== undefined;
  const temRepediu = r.crm_mensagens.current !== undefined;
  const temCrmAtivo = temRepediu || r.clientes_ativos_crm.current !== undefined;

  const [investimento, leads, roas, seguidores, nota, ativos, recompra, receitaGerada] = await Promise.all([
    seriesFor(client.id, "meta_investimento"),
    seriesFor(client.id, "meta_leads"),
    seriesFor(client.id, "meta_roas"),
    seriesFor(client.id, "instagram_seguidores"),
    seriesFor(client.id, "avaliacoes_google_nota"),
    seriesFor(client.id, "clientes_ativos_crm"),
    seriesFor(client.id, "taxa_recompra"),
    seriesFor(client.id, "crm_receita_gerada"),
  ]);

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Método CVR"
        title={`Método CVR — ${client.name}`}
        description={`Conversão, Valor e Relacionamento${temCrmAtivo ? "" : " — sem CRM ativo neste cliente"}.`}
      />

      <FilterBar basePath={`/c/${slug}/metodo-cvr`} monthOptions={monthOptions} month={periodStart} />
      <div style={{ marginBottom: 20 }}>
        <Pill tone="accent">{monthLabel(periodStart)}</Pill>
      </div>

      <SectionCard icon="megaphone" title="1. Conversão" subtitle="Meta Ads, Google Ads e cardápio digital">
        <StatList
          rows={[
            { label: "Investimento em Mídia (Meta Ads)", value: formatBRL(c.meta_investimento.current) },
            { label: "Leads (Meta Ads)", value: formatNumber(c.meta_leads.current) },
            { label: "ROAS (Meta Ads)", value: c.meta_roas.current ? `${formatNumber(c.meta_roas.current, 1)}x` : "—" },
            ...(temGoogle
              ? [
                  { label: "Investimento em Mídia (Google Ads)", value: formatBRL(c.google_investimento.current) },
                  { label: "Leads (Google Ads)", value: formatNumber(c.google_leads.current) },
                  {
                    label: "ROAS (Google Ads)",
                    value: c.google_roas.current ? `${formatNumber(c.google_roas.current, 1)}x` : "—",
                  },
                ]
              : []),
          ]}
        />
      </SectionCard>

      <SectionCard icon="store" accent="var(--accent-2)" title="2. Valor" subtitle="Marca, avaliações e Google Meu Negócio">
        <StatList
          rows={[
            { label: "Seguidores Instagram", value: formatNumber(v.instagram_seguidores.current) },
            {
              label: "Nota média Google",
              value: v.avaliacoes_google_nota.current ? formatNumber(v.avaliacoes_google_nota.current, 1) : "—",
            },
            ...(temGmb
              ? [
                  { label: "Visualizações do Perfil (GMB)", value: formatNumber(v.gmb_visualizacoes.current) },
                  { label: "Ligações pelo Perfil (GMB)", value: formatNumber(v.gmb_ligacoes.current) },
                ]
              : []),
          ]}
        />
      </SectionCard>

      <SectionCard icon="bag" accent="var(--accent-2)" title="3. Relacionamento" subtitle="CRM, fidelização e recuperação de clientes">
        {temCrmAtivo ? (
          <StatList
            rows={[
              { label: "Clientes ativos (CRM)", value: formatNumber(r.clientes_ativos_crm.current) },
              { label: "Taxa de recompra", value: r.taxa_recompra.current ? `${formatNumber(r.taxa_recompra.current, 1)}%` : "—" },
              ...(temRepediu
                ? [
                    { label: "Clientes recuperados (RePediu)", value: formatNumber(r.crm_recuperados.current) },
                    { label: "Mensagens enviadas (RePediu)", value: formatNumber(r.crm_mensagens.current) },
                    { label: "Receita gerada (RePediu)", value: formatBRL(r.crm_receita_gerada.current) },
                  ]
                : []),
            ]}
          />
        ) : (
          <div style={{ fontSize: 13, color: "var(--text-muted)" }}>Cliente ainda não tem CRM ativo.</div>
        )}
      </SectionCard>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 8 }}>
        <Card title="Investimento em Meta Ads" subtitle="Histórico completo">
          <LineChart
            series={[{ name: "Investimento", color: "var(--accent)", values: investimento.values }]}
            xLabels={investimento.xLabels}
            format="currency-k"
            aria="Investimento em Meta Ads por período"
          />
        </Card>
        <Card title="Leads gerados (Meta Ads)" subtitle="Histórico completo">
          <LineChart
            series={[{ name: "Leads", color: "var(--accent-2)", values: leads.values }]}
            xLabels={leads.xLabels}
            format="number"
            aria="Leads gerados por período"
          />
        </Card>
      </div>
      <Card title="ROAS Meta Ads" subtitle="Retorno sobre investimento em anúncios · histórico completo">
        <LineChart
          series={[{ name: "ROAS", color: "var(--series-3)", values: roas.values }]}
          xLabels={roas.xLabels}
          format="multiplier1"
          aria="ROAS Meta Ads por período"
        />
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Card title="Seguidores no Instagram" subtitle="Histórico completo">
          <LineChart
            series={[{ name: "Seguidores", color: "var(--series-5)", values: seguidores.values }]}
            xLabels={seguidores.xLabels}
            format="number"
            aria="Seguidores no Instagram por período"
          />
        </Card>
        <Card title="Nota média no Google" subtitle="Histórico completo">
          <LineChart
            series={[{ name: "Nota", color: "var(--series-7)", values: nota.values }]}
            xLabels={nota.xLabels}
            format="decimal1"
            aria="Nota média no Google por período"
          />
        </Card>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        <Card title="Clientes ativos na base CRM" subtitle="Histórico completo">
          <LineChart
            series={[{ name: "Clientes ativos", color: "var(--series-1)", values: ativos.values }]}
            xLabels={ativos.xLabels}
            format="number"
            aria="Clientes ativos por período"
          />
        </Card>
        <Card title="Taxa de recompra" subtitle="Histórico completo">
          <LineChart
            series={[{ name: "Recompra", color: "var(--series-5)", values: recompra.values }]}
            xLabels={recompra.xLabels}
            format="percent0"
            aria="Taxa de recompra por período"
          />
        </Card>
      </div>

      {temRepediu && (
        <Card title="RePediu — receita gerada" subtitle="Histórico completo">
          <LineChart
            series={[{ name: "Receita gerada", color: "var(--series-3)", values: receitaGerada.values }]}
            xLabels={receitaGerada.xLabels}
            format="currency-k"
            aria="Receita gerada pelo RePediu por período"
          />
        </Card>
      )}
    </div>
  );
}
