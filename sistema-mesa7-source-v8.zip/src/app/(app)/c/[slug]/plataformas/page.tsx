import { requireClientAccess } from "@/lib/access";
import { PageHead, KpiCard, Card, Pill, DataTable } from "@/components/ui";
import { FilterBar } from "@/components/FilterBar";
import { DonutChart } from "@/components/charts/DonutChart";
import {
  formatBRL,
  formatNumber,
  firstOfMonth,
  periodStartFromMonthValue,
  monthLabel,
  recentMonthOptions,
  snapshotForMonth,
  latestPeriodWithData,
} from "@/lib/metrics";
import { PLATAFORMA_CANAIS } from "@/lib/cardapio-web-channels";

const BASE_KEYS = ["plat_pedidos_total", "plat_faturamento_total", "plat_pedidos_cancelados", "plat_taxa_cancelamento"];
const CANAL_KEYS = PLATAFORMA_CANAIS.flatMap((c) => [`plat_${c.key}_pedidos`, `plat_${c.key}_faturamento`]);

export default async function PlataformasPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ mes?: string }>;
}) {
  const { slug } = await params;
  const { mes } = await searchParams;
  const { client } = await requireClientAccess(slug);

  const periodStart = mes
    ? periodStartFromMonthValue(mes)
    : (await latestPeriodWithData(client.id)) ?? firstOfMonth(new Date());
  const monthOptions = recentMonthOptions(24);

  const m = await snapshotForMonth(client.id, BASE_KEYS, periodStart);
  const cm = await snapshotForMonth(client.id, CANAL_KEYS, periodStart);

  const temCardapioWeb = m.plat_pedidos_total.current !== undefined;

  const canais = PLATAFORMA_CANAIS.map((c) => ({
    ...c,
    pedidos: cm[`plat_${c.key}_pedidos`]?.current,
    faturamento: cm[`plat_${c.key}_faturamento`]?.current,
  })).filter((c) => c.pedidos !== undefined);

  const ticketMedioGeral =
    m.plat_pedidos_total.current && m.plat_faturamento_total.current
      ? m.plat_faturamento_total.current / m.plat_pedidos_total.current
      : undefined;

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Plataformas"
        title={`Plataformas — ${client.name}`}
        description="Pedidos e faturamento por canal de venda (Portal, Site Próprio, iFood, 99Food, WhatsApp), direto da API do Cardápio Web."
      />

      <FilterBar basePath={`/c/${slug}/plataformas`} monthOptions={monthOptions} month={periodStart} />
      <div style={{ marginBottom: 20 }}>
        <Pill tone="accent">{monthLabel(periodStart)}</Pill>
      </div>

      {!temCardapioWeb ? (
        <Card>
          <div style={{ fontSize: 13.5, color: "var(--text-muted)", lineHeight: 1.6 }}>
            Este cliente ainda não está conectado à API do Cardápio Web — sem dado de pedidos por canal pra{" "}
            {monthLabel(periodStart)}. Assim que a integração for feita, os dados aparecem aqui automaticamente.
          </div>
        </Card>
      ) : (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 12, marginBottom: 22 }}>
            <KpiCard icon="bag" label="Pedidos no período" value={formatNumber(m.plat_pedidos_total.current)} caption="Todos os canais" />
            <KpiCard icon="money" label="Faturamento (canais)" value={formatBRL(m.plat_faturamento_total.current)} />
            <KpiCard icon="receipt" accent="accent-2" label="Ticket médio geral" value={formatBRL(ticketMedioGeral)} />
            <KpiCard
              icon="percent"
              accent="accent-2"
              label="Taxa de cancelamento"
              value={m.plat_taxa_cancelamento.current !== undefined ? `${formatNumber(m.plat_taxa_cancelamento.current, 1)}%` : "—"}
              caption={`${formatNumber(m.plat_pedidos_cancelados.current)} pedidos cancelados`}
            />
          </div>

          <Card title="Divisão de Pedidos por Canal" subtitle={monthLabel(periodStart)}>
            <DonutChart
              data={canais.map((c) => ({ label: c.label, value: c.pedidos ?? 0, color: c.color }))}
              aria="Divisão de pedidos por canal"
            />
          </Card>

          <Card title="Detalhamento por Canal" subtitle={monthLabel(periodStart)}>
            <DataTable
              columns={["Canal", "Pedidos", "Faturamento", "Ticket médio", "% dos pedidos"]}
              rows={canais.map((c) => [
                c.label,
                formatNumber(c.pedidos),
                formatBRL(c.faturamento),
                formatBRL(c.pedidos && c.faturamento ? c.faturamento / c.pedidos : undefined),
                m.plat_pedidos_total.current && c.pedidos
                  ? `${((c.pedidos / m.plat_pedidos_total.current) * 100).toFixed(1)}%`
                  : "—",
              ])}
            />
          </Card>
        </>
      )}
    </div>
  );
}
