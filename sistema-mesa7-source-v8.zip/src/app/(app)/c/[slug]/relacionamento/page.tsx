import { redirect } from "next/navigation";

// Relacionamento foi incorporado à página única "Método CVR" (set/2026).
// Rota mantida como redirect pra não quebrar links salvos.
export default async function RelacionamentoRedirect({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  redirect(`/c/${slug}/metodo-cvr`);
}
