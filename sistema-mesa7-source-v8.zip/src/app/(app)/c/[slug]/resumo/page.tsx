import { requireClientAccess } from "@/lib/access";
import { PageHead, KpiCard, Card, Pill } from "@/components/ui";
import { FilterBar } from "@/components/FilterBar";
import { LineChart } from "@/components/charts/LineChart";
import {
  seriesFor,
  formatBRL,
  formatNumber,
  formatDeltaLabel,
  deltaTone,
  firstOfMonth,
  periodStartFromMonthValue,
  monthLabel,
  recentMonthOptions,
  snapshotForMonth,
  latestPeriodWithData,
} from "@/lib/metrics";
import { db } from "@/db";
import { actionItems, insights } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

const KEYS = [
  "faturamento_total",
  "ticket_medio",
  "meta_investimento",
  "meta_roas",
  "instagram_seguidores",
  "avaliacoes_google_nota",
  "taxa_recompra",
  "clientes_ativos_crm",
];

export default async function ResumoPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ mes?: string }>;
}) {
  const { slug } = await params;
  const { mes } = await searchParams;
  const { client } = await requireClientAccess(slug);

  const periodStart = mes
    ? periodStartFromMonthValue(mes)
    : (await latestPeriodWithData(client.id)) ?? firstOfMonth(new Date());
  const monthOptions = recentMonthOptions(24);
  const m = await snapshotForMonth(client.id, KEYS, periodStart);
  const faturamento = await seriesFor(client.id, "faturamento_total");

  const openActions = await db
    .select()
    .from(actionItems)
    .where(eq(actionItems.clientId, client.id))
    .orderBy(desc(actionItems.createdAt))
    .limit(5);

  const recentInsights = await db
    .select()
    .from(insights)
    .where(eq(insights.clientId, client.id))
    .orderBy(desc(insights.periodStart))
    .limit(3);

  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead
        kicker="Visão geral"
        title={`Resumo Executivo — ${client.name}`}
        description="Visão rápida de performance e saúde financeira do período selecionado."
      />

      <FilterBar basePath={`/c/${slug}/resumo`} monthOptions={monthOptions} month={periodStart} />
      <div style={{ marginBottom: 20 }}>
        <Pill tone="accent">{monthLabel(periodStart)}</Pill>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 12, marginBottom: 22 }}>
        <KpiCard
          icon="money"
          label="Faturamento total"
          value={formatBRL(m.faturamento_total.current)}
          deltaLabel={formatDeltaLabel(m.faturamento_total.momDelta)}
          deltaTone={deltaTone(m.faturamento_total.momDelta)}
          caption="vs. mês anterior"
        />
        <KpiCard
          icon="receipt"
          label="Ticket médio"
          value={formatBRL(m.ticket_medio.current)}
          deltaLabel={formatDeltaLabel(m.ticket_medio.momDelta)}
          deltaTone={deltaTone(m.ticket_medio.momDelta)}
        />
        <KpiCard
          icon="megaphone"
          accent="accent-2"
          label="Investimento Meta Ads"
          value={formatBRL(m.meta_investimento.current)}
          deltaLabel={formatDeltaLabel(m.meta_investimento.momDelta)}
          deltaTone={deltaTone(m.meta_investimento.momDelta)}
        />
        <KpiCard
          icon="target"
          accent="accent-2"
          label="ROAS"
          value={m.meta_roas.current ? `${formatNumber(m.meta_roas.current, 1)}x` : "—"}
          deltaLabel={formatDeltaLabel(m.meta_roas.momDelta)}
          deltaTone={deltaTone(m.meta_roas.momDelta)}
        />
        <KpiCard
          icon="layers"
          accent="accent-2"
          label="Seguidores Instagram"
          value={formatNumber(m.instagram_seguidores.current)}
          deltaLabel={formatDeltaLabel(m.instagram_seguidores.momDelta)}
          deltaTone={deltaTone(m.instagram_seguidores.momDelta)}
        />
        <KpiCard
          icon="store"
          accent="accent-2"
          label="Nota Google"
          value={m.avaliacoes_google_nota.current ? formatNumber(m.avaliacoes_google_nota.current, 1) : "—"}
          caption="Google Meu Negócio"
        />
        <KpiCard
          icon="percent"
          label="Taxa de recompra"
          value={m.taxa_recompra.current ? `${formatNumber(m.taxa_recompra.current, 1)}%` : "—"}
          deltaLabel={formatDeltaLabel(m.taxa_recompra.momDelta)}
          deltaTone={deltaTone(m.taxa_recompra.momDelta)}
        />
        <KpiCard
          icon="bag"
          label="Clientes ativos (CRM)"
          value={formatNumber(m.clientes_ativos_crm.current)}
          deltaLabel={formatDeltaLabel(m.clientes_ativos_crm.momDelta)}
          deltaTone={deltaTone(m.clientes_ativos_crm.momDelta)}
        />
      </div>

      <Card title="Evolução de Faturamento" subtitle="Histórico completo · preenchimento manual ou importado">
        <LineChart
          series={[{ name: "Faturamento", color: "var(--accent)", values: faturamento.values }]}
          xLabels={faturamento.xLabels}
          format="currency-k"
          aria="Evolução de faturamento"
        />
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 14, alignItems: "start" }}>
        <Card title="Plano de ação — em aberto" subtitle="Itens mais recentes">
          {openActions.length === 0 ? (
            <div style={{ color: "var(--text-muted)", fontSize: 13 }}>Nenhum item cadastrado ainda.</div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.8 }}>
              <tbody>
                {openActions.map((a) => (
                  <tr key={a.id} style={{ borderBottom: "1px solid var(--border)" }}>
                    <td style={{ padding: "9px 6px", color: "var(--text-primary)" }}>{a.title}</td>
                    <td style={{ padding: "9px 6px", color: "var(--text-muted)", whiteSpace: "nowrap" }}>
                      {a.responsible}
                    </td>
                    <td style={{ padding: "9px 6px", whiteSpace: "nowrap" }}>
                      <span
                        style={{
                          fontSize: 11,
                          fontWeight: 800,
                          padding: "4px 9px",
                          borderRadius: 99,
                          color:
                            a.status === "concluido"
                              ? "var(--status-good)"
                              : a.status === "atrasado"
                                ? "var(--status-critical)"
                                : "var(--accent-2)",
                          background:
                            a.status === "concluido"
                              ? "var(--status-good-bg)"
                              : a.status === "atrasado"
                                ? "var(--status-critical-bg)"
                                : "var(--accent-2-soft)",
                        }}
                      >
                        {a.status.replace("_", " ")}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>

        <Card title="Insights" subtitle="Observações recentes">
          {recentInsights.length === 0 ? (
            <div style={{ color: "var(--text-muted)", fontSize: 13 }}>Nenhum insight registrado ainda.</div>
          ) : (
            recentInsights.map((i) => (
              <p key={i.id} style={{ fontSize: 13, color: "var(--text-secondary)", lineHeight: 1.55, margin: "0 0 10px" }}>
                {i.text}
              </p>
            ))
          )}
        </Card>
      </div>
    </div>
  );
}
