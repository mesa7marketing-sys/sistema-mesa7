"use client";

function buildUrl(basePath: string, params: Record<string, string | undefined>) {
  const qs = Object.entries(params)
    .filter(([, v]) => v && v !== "")
    .map(([k, v]) => `${k}=${encodeURIComponent(v as string)}`)
    .join("&");
  return qs ? `${basePath}?${qs}` : basePath;
}

const selectStyle: React.CSSProperties = {
  background: "var(--surface-2)",
  border: "1px solid var(--border-strong)",
  borderRadius: 9,
  padding: "10px 14px",
  color: "var(--text-primary)",
  fontSize: 13.5,
  fontWeight: 700,
  fontFamily: "inherit",
  cursor: "pointer",
  width: "100%",
};

export function FilterBar({
  basePath,
  monthOptions,
  month,
  channelOptions,
  channel,
}: {
  basePath: string;
  monthOptions: { value: string; label: string }[];
  month: string;
  channelOptions?: { value: string; label: string }[];
  channel?: string;
}) {
  return (
    <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 18 }}>
      <div style={{ minWidth: 200, flex: "1 1 200px" }}>
        <div style={{ fontSize: 11, fontWeight: 800, color: "var(--text-muted)", letterSpacing: "0.07em", marginBottom: 6 }}>
          PERÍODO
        </div>
        <select
          value={month}
          onChange={(e) => {
            window.location.href = buildUrl(basePath, { mes: e.target.value, canal: channel });
          }}
          style={selectStyle}
        >
          {monthOptions.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      </div>

      {channelOptions && (
        <div style={{ minWidth: 200, flex: "1 1 200px" }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: "var(--text-muted)", letterSpacing: "0.07em", marginBottom: 6 }}>
            CANAL
          </div>
          <select
            value={channel || ""}
            onChange={(e) => {
              window.location.href = buildUrl(basePath, { mes: month, canal: e.target.value });
            }}
            style={selectStyle}
          >
            {channelOptions.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        </div>
      )}

      <div style={{ display: "flex", alignItems: "flex-end" }}>
        <a
          href={basePath}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 6,
            background: "var(--surface-2)",
            border: "1px solid var(--border-strong)",
            borderRadius: 9,
            padding: "10px 16px",
            color: "var(--text-secondary)",
            fontSize: 13,
            fontWeight: 700,
            textDecoration: "none",
            whiteSpace: "nowrap",
          }}
        >
          ↺ Limpar
        </a>
      </div>
    </div>
  );
}
