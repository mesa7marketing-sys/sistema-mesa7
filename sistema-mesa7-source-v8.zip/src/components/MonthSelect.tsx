"use client";

export function MonthSelect({
  options,
  value,
  basePath,
}: {
  options: { value: string; label: string }[];
  value: string;
  basePath: string;
}) {
  return (
    <select
      defaultValue={value}
      onChange={(e) => {
        window.location.href = `${basePath}?mes=${e.target.value}`;
      }}
      style={{
        background: "var(--surface-2)",
        border: "1px solid var(--border-strong)",
        borderRadius: 9,
        padding: "9px 14px",
        color: "var(--text-primary)",
        fontSize: 13.5,
        fontWeight: 700,
        fontFamily: "inherit",
        cursor: "pointer",
      }}
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}
