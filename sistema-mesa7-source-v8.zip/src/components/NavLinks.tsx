"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { CVR_PAGES } from "@/lib/nav";

const GROUPS = ["Visão geral", "Relatório", "Operação"] as const;

export function NavLinks({ clientSlug }: { clientSlug: string }) {
  const pathname = usePathname();

  return (
    <>
      {GROUPS.map((group) => {
        const items = CVR_PAGES.filter((p) => p.group === group);
        return (
          <div key={group} style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            <div
              style={{
                fontSize: 10.5,
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                color: "var(--text-muted)",
                padding: "10px 12px 4px",
                fontWeight: 700,
              }}
            >
              {group}
            </div>
            {items.map((item) => {
              const href = `/c/${clientSlug}/${item.slug}`;
              const active = pathname === href;
              return (
                <Link
                  key={item.slug}
                  href={href}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    padding: "9px 12px",
                    borderRadius: 9,
                    color: active ? "#fff" : "var(--text-secondary)",
                    fontSize: 13.6,
                    fontWeight: 600,
                    border: active ? "1px solid rgba(249,115,22,0.35)" : "1px solid transparent",
                    background: active ? "var(--accent-soft)" : "transparent",
                    textDecoration: "none",
                  }}
                >
                  {item.label}
                </Link>
              );
            })}
          </div>
        );
      })}
    </>
  );
}
