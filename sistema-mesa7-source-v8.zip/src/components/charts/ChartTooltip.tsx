"use client";

import { useState, useCallback } from "react";

export function useChartTooltip() {
  const [tip, setTip] = useState<{ x: number; y: number; label: string } | null>(null);

  const onMove = useCallback((e: React.MouseEvent, label: string) => {
    setTip({ x: e.clientX + 14, y: e.clientY + 14, label });
  }, []);
  const onLeave = useCallback(() => setTip(null), []);

  const tooltipEl = tip ? (
    <div
      style={{
        position: "fixed",
        left: tip.x,
        top: tip.y,
        zIndex: 60,
        pointerEvents: "none",
        background: "var(--surface-raised)",
        color: "#fff",
        border: "1px solid rgba(255,255,255,0.16)",
        borderRadius: 9,
        padding: "7px 10px",
        fontSize: 12,
        boxShadow: "0 12px 28px rgba(0,0,0,0.5)",
        maxWidth: 240,
        lineHeight: 1.4,
      }}
    >
      {tip.label}
    </div>
  ) : null;

  return { onMove, onLeave, tooltipEl };
}
