"use client";

import { useChartTooltip } from "./ChartTooltip";

export type DonutSlice = { label: string; value: number; color: string };

export function DonutChart({
  data,
  size = 220,
  thickness = 34,
  aria,
}: {
  data: DonutSlice[];
  size?: number;
  thickness?: number;
  aria?: string;
}) {
  const { onMove, onLeave, tooltipEl } = useChartTooltip();
  const total = data.reduce((s, d) => s + Math.max(0, d.value), 0);
  const r = size / 2;
  const inner = r - thickness;
  const cx = r;
  const cy = r;

  let angle = -90;
  const arcs = data
    .filter((d) => d.value > 0)
    .map((d) => {
      const frac = total > 0 ? d.value / total : 0;
      const sweep = frac * 360;
      const start = angle;
      const end = angle + sweep;
      angle = end;
      return { ...d, start, end, pct: frac * 100 };
    });

  function arcPath(startDeg: number, endDeg: number) {
    const toRad = (deg: number) => (deg * Math.PI) / 180;
    const x0 = cx + r * Math.cos(toRad(startDeg));
    const y0 = cy + r * Math.sin(toRad(startDeg));
    const x1 = cx + r * Math.cos(toRad(endDeg));
    const y1 = cy + r * Math.sin(toRad(endDeg));
    const xi0 = cx + inner * Math.cos(toRad(endDeg));
    const yi0 = cy + inner * Math.sin(toRad(endDeg));
    const xi1 = cx + inner * Math.cos(toRad(startDeg));
    const yi1 = cy + inner * Math.sin(toRad(startDeg));
    const large = endDeg - startDeg > 180 ? 1 : 0;
    return `M${x0.toFixed(2)},${y0.toFixed(2)} A${r},${r} 0 ${large} 1 ${x1.toFixed(2)},${y1.toFixed(2)} L${xi0.toFixed(2)},${yi0.toFixed(2)} A${inner},${inner} 0 ${large} 0 ${xi1.toFixed(2)},${yi1.toFixed(2)} Z`;
  }

  return (
    <div style={{ position: "relative", display: "flex", flexWrap: "wrap", alignItems: "center", gap: 24 }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} role="img" aria-label={aria || "gráfico de pizza"}>
        {arcs.length === 0 ? (
          <circle cx={cx} cy={cy} r={(r + inner) / 2} fill="none" stroke="var(--chart-grid)" strokeWidth={thickness} />
        ) : (
          arcs.map((a, i) => (
            <path
              key={i}
              d={arcPath(a.start, a.end)}
              fill={a.color}
              stroke="var(--chart-surface)"
              strokeWidth={2}
              style={{ cursor: "pointer" }}
              onMouseMove={(e) => onMove(e, `${a.label}: ${a.pct.toFixed(1)}%`)}
              onMouseLeave={onLeave}
            />
          ))
        )}
      </svg>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {data.map((d) => {
          const pct = total > 0 ? (d.value / total) * 100 : 0;
          return (
            <div key={d.label} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: 700 }}>
              <span style={{ width: 10, height: 10, borderRadius: 3, background: d.color, display: "inline-block", flexShrink: 0 }} />
              <span style={{ color: "var(--text-secondary)" }}>{d.label}</span>
              <span style={{ color: "var(--text-primary)" }}>{pct.toFixed(1)}%</span>
            </div>
          );
        })}
      </div>
      {tooltipEl}
    </div>
  );
}
