export function Tile({
  label,
  value,
  deltaLabel,
  deltaTone,
  caption,
}: {
  label: string;
  value: string;
  deltaLabel?: string;
  deltaTone?: "good" | "warn" | "bad";
  caption?: string;
}) {
  const toneColor =
    deltaTone === "good"
      ? "var(--status-good)"
      : deltaTone === "bad"
        ? "var(--status-critical)"
        : "var(--status-warning)";
  const toneBg =
    deltaTone === "good"
      ? "var(--status-good-bg)"
      : deltaTone === "bad"
        ? "var(--status-critical-bg)"
        : "var(--status-warning-bg)";

  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: 14,
        padding: "16px 16px 14px",
        boxShadow: "var(--shadow)",
      }}
    >
      <div style={{ fontSize: 12, color: "var(--text-secondary)", fontWeight: 700 }}>{label}</div>
      <div
        className="num"
        style={{ fontSize: 26, fontWeight: 600, margin: "8px 0 6px", letterSpacing: "-0.01em" }}
      >
        {value}
      </div>
      {deltaLabel && (
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 4,
            fontSize: 11.5,
            fontWeight: 800,
            padding: "3px 8px 3px 6px",
            borderRadius: 99,
            color: toneColor,
            background: toneBg,
          }}
        >
          {deltaLabel}
        </span>
      )}
      {caption && (
        <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 6 }}>{caption}</div>
      )}
    </div>
  );
}

/** Ícones simples e planos (sem libs externas) usados nos KpiCards. */
const ICONS: Record<string, React.ReactNode> = {
  money: (
    <path d="M3 7h18v10H3V7Zm3 2.5V14.5M18 9.5V14.5M12 8.2a3.8 3.8 0 1 0 0 7.6 3.8 3.8 0 0 0 0-7.6Z" />
  ),
  bag: <path d="M6 8h12l-1 12H7L6 8Zm3 0V6a3 3 0 0 1 6 0v2" />,
  receipt: <path d="M6 3h12v18l-2-1.4L14 21l-2-1.4L10 21l-2-1.4L6 21V3Zm2.5 5h7M8.5 11h7M8.5 14h4" />,
  layers: <path d="M12 3 3 8l9 5 9-5-9-5ZM3 13l9 5 9-5M3 8v0" />,
  percent: <path d="M6 18 18 6M7.5 9.5A2 2 0 1 0 7.5 5.5a2 2 0 0 0 0 4Zm9 9a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />,
  chart: <path d="M4 20V10M11 20V4M18 20v-7" />,
  target: <path d="M12 3v4M12 17v4M3 12h4M17 12h4M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z" />,
  megaphone: <path d="M3 10v4l4 1 8 4V5l-8 4-4 1Zm11-2.5c1.5.8 1.5 5.2 0 6" />,
  clock: <path d="M12 7v5l3.5 2M20 12a8 8 0 1 1-16 0 8 8 0 0 1 16 0Z" />,
  store: <path d="M4 9 5 4h14l1 5M4 9h16M4 9v11h16V9M9 20v-6h6v6" />,
};

export function IconGlyph({ name, color }: { name: keyof typeof ICONS; color: string }) {
  return (
    <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      {ICONS[name] || ICONS.chart}
    </svg>
  );
}

export function KpiCard({
  icon,
  accent = "accent",
  label,
  value,
  deltaLabel,
  deltaTone,
  caption,
}: {
  icon?: keyof typeof ICONS;
  accent?: "accent" | "accent-2";
  label: string;
  value: string;
  deltaLabel?: string;
  deltaTone?: "good" | "warn" | "bad";
  caption?: string;
}) {
  const toneColor =
    deltaTone === "good" ? "var(--status-good)" : deltaTone === "bad" ? "var(--status-critical)" : "var(--status-warning)";
  const toneBg =
    deltaTone === "good" ? "var(--status-good-bg)" : deltaTone === "bad" ? "var(--status-critical-bg)" : "var(--status-warning-bg)";
  const accentColor = accent === "accent-2" ? "var(--accent-2)" : "var(--accent)";

  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderTop: `3px solid ${accentColor}`,
        borderRadius: 14,
        padding: "16px 16px 14px",
        boxShadow: "var(--shadow)",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ fontSize: 12, color: "var(--text-secondary)", fontWeight: 700 }}>{label}</div>
        {icon && <IconGlyph name={icon} color={accentColor} />}
      </div>
      <div className="num" style={{ fontSize: 25, fontWeight: 600, margin: "8px 0 6px", letterSpacing: "-0.01em" }}>
        {value}
      </div>
      {deltaLabel && (
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 4,
            fontSize: 11.5,
            fontWeight: 800,
            padding: "3px 8px 3px 6px",
            borderRadius: 99,
            color: toneColor,
            background: toneBg,
          }}
        >
          {deltaLabel}
        </span>
      )}
      {caption && <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 6 }}>{caption}</div>}
    </div>
  );
}

export function Pill({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "accent" }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        background: tone === "accent" ? "var(--accent-soft)" : "var(--surface-2)",
        border: `1px solid ${tone === "accent" ? "rgba(249,115,22,0.35)" : "var(--border-strong)"}`,
        color: tone === "accent" ? "var(--accent)" : "var(--text-secondary)",
        borderRadius: 99,
        padding: "6px 13px",
        fontSize: 12.5,
        fontWeight: 700,
      }}
    >
      {children}
    </span>
  );
}

/** Lista de linhas rótulo → valor, no estilo "1. Conversão" dos relatórios mensais. */
export function StatList({ rows }: { rows: { label: string; value: string }[] }) {
  return (
    <div>
      {rows.map((r, i) => (
        <div
          key={i}
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "baseline",
            gap: 12,
            padding: "11px 0",
            borderBottom: i < rows.length - 1 ? "1px solid var(--border)" : "none",
          }}
        >
          <span style={{ fontSize: 13.5, color: "var(--text-secondary)" }}>{r.label}</span>
          <span className="num" style={{ fontSize: 14.5, fontWeight: 700, color: "var(--text-primary)", whiteSpace: "nowrap" }}>
            {r.value}
          </span>
        </div>
      ))}
    </div>
  );
}

export function SectionCard({
  icon,
  accent = "var(--accent)",
  title,
  subtitle,
  children,
}: {
  icon?: keyof typeof ICONS;
  accent?: string;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderTop: `3px solid ${accent}`,
        borderRadius: 16,
        padding: "18px 20px 16px",
        boxShadow: "var(--shadow)",
        marginBottom: 14,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: subtitle ? 2 : 10 }}>
        {icon && <IconGlyph name={icon} color={accent} />}
        <div style={{ fontSize: 15, fontWeight: 800 }}>{title}</div>
      </div>
      {subtitle && <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginBottom: 10 }}>{subtitle}</div>}
      {children}
    </div>
  );
}

export function DataTable({
  columns,
  rows,
}: {
  columns: string[];
  rows: (string | number)[][];
}) {
  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
        <thead>
          <tr>
            {columns.map((c, i) => (
              <th
                key={i}
                style={{
                  textAlign: i === 0 ? "left" : "right",
                  fontSize: 11,
                  textTransform: "uppercase",
                  letterSpacing: "0.06em",
                  color: "var(--text-muted)",
                  fontWeight: 800,
                  padding: "0 10px 10px",
                  borderBottom: "1px solid var(--border-strong)",
                  whiteSpace: "nowrap",
                }}
              >
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, ri) => (
            <tr key={ri} style={{ borderBottom: ri < rows.length - 1 ? "1px solid var(--border)" : "none" }}>
              {row.map((cell, ci) => (
                <td
                  key={ci}
                  className={ci > 0 ? "num" : undefined}
                  style={{
                    textAlign: ci === 0 ? "left" : "right",
                    padding: "11px 10px",
                    fontWeight: ci === 0 ? 700 : 600,
                    color: ci === 0 ? "var(--text-primary)" : "var(--text-secondary)",
                    whiteSpace: "nowrap",
                  }}
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Tiles({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(178px, 1fr))",
        gap: 12,
        marginBottom: 22,
      }}
    >
      {children}
    </div>
  );
}

export function Card({
  title,
  subtitle,
  children,
}: {
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: 16,
        padding: "18px 20px 16px",
        boxShadow: "var(--shadow)",
        marginBottom: 14,
      }}
    >
      {title && (
        <div style={{ marginBottom: 10 }}>
          <div style={{ fontSize: 14.5, fontWeight: 800 }}>{title}</div>
          {subtitle && (
            <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 2 }}>
              {subtitle}
            </div>
          )}
        </div>
      )}
      {children}
    </div>
  );
}

export function PageHead({ kicker, title, description }: { kicker: string; title: string; description?: string }) {
  return (
    <div style={{ marginBottom: 4 }}>
      <span
        style={{
          fontSize: 11.5,
          textTransform: "uppercase",
          letterSpacing: "0.11em",
          color: "var(--accent)",
          fontWeight: 800,
          display: "block",
          marginBottom: 6,
        }}
      >
        {kicker}
      </span>
      <h1 style={{ fontSize: 27 }}>{title}</h1>
      {description && (
        <p
          style={{
            color: "var(--text-secondary)",
            fontSize: 14,
            maxWidth: "62ch",
            margin: "8px 0 26px",
            lineHeight: 1.55,
          }}
        >
          {description}
        </p>
      )}
    </div>
  );
}
