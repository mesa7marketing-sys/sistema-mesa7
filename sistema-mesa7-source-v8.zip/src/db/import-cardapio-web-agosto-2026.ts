// Importa os dados de Plataformas e Comportamento de Agosto/2026 pra Garage 84
// e La Pizza D'Caio, puxados via API do Cardápio Web (get_orders_grouped_summary,
// group_by: sales_channel / status / hour / day_of_week).
//
// Só números agregados (pedidos, faturamento) — nunca dado de cliente
// (nome/telefone/endereço não são retornados por esse endpoint, só pelo
// get_order individual, que é usado exclusivamente pra Curva ABC e cujos
// campos de cliente nunca são persistidos).
//
// Rotina mensal: repetir esse processo (puxar via MCP + gerar um script como
// esse com os números do mês) pra manter Plataformas/Comportamento em dia
// pros clientes conectados ao Cardápio Web.
import "dotenv/config";
import { db } from "./index";
import { clients, weeklyMetrics } from "./schema";
import { and, eq } from "drizzle-orm";

type Pillar = "plataformas" | "comportamento";
const ORIGEM = "cardapio_web" as const;
const PERIOD = "2026-08-01";

async function upsertMetric(clientId: string, pillar: Pillar, metricKey: string, value: number) {
  await db
    .insert(weeklyMetrics)
    .values({ clientId, periodStart: PERIOD, pillar, metricKey, metricValue: value.toFixed(2), origem: ORIGEM })
    .onConflictDoUpdate({
      target: [weeklyMetrics.clientId, weeklyMetrics.periodStart, weeklyMetrics.metricKey],
      set: { metricValue: value.toFixed(2), pillar, origem: ORIGEM, updatedAt: new Date() },
    });
}

async function getClient(slug: string) {
  const [client] = await db.select().from(clients).where(eq(clients.slug, slug)).limit(1);
  return client;
}

type ChannelData = { key: string; pedidos: number; faturamento: number };

async function importLoja(
  slug: string,
  channels: ChannelData[],
  status: { closed: { pedidos: number; faturamento: number }; canceled: { pedidos: number; faturamento: number } },
  horaPico: number,
  diaParte: { madrugada: number; manha: number; tarde: number; noite: number },
  semana: { diaSemana: number; fimSemana: number },
) {
  const client = await getClient(slug);
  if (!client) {
    console.log(`${slug} não encontrado — pulando`);
    return;
  }

  const pedidosTotal = status.closed.pedidos + status.canceled.pedidos;
  const faturamentoTotal = channels.reduce((s, c) => s + c.faturamento, 0);

  // --- Plataformas ---
  await upsertMetric(client.id, "plataformas", "plat_pedidos_total", pedidosTotal);
  await upsertMetric(client.id, "plataformas", "plat_faturamento_total", faturamentoTotal);
  await upsertMetric(client.id, "plataformas", "plat_pedidos_cancelados", status.canceled.pedidos);
  await upsertMetric(client.id, "plataformas", "plat_taxa_cancelamento", (status.canceled.pedidos / pedidosTotal) * 100);
  for (const c of channels) {
    await upsertMetric(client.id, "plataformas", `plat_${c.key}_pedidos`, c.pedidos);
    await upsertMetric(client.id, "plataformas", `plat_${c.key}_faturamento`, c.faturamento);
  }

  // --- Comportamento ---
  await upsertMetric(client.id, "comportamento", "comport_hora_pico", horaPico);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_madrugada", diaParte.madrugada);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_manha", diaParte.manha);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_tarde", diaParte.tarde);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_noite", diaParte.noite);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_dia_semana", semana.diaSemana);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_fim_semana", semana.fimSemana);

  console.log(`${slug}: Plataformas + Comportamento de Agosto/2026 importados (${pedidosTotal} pedidos).`);
}

async function main() {
  await importLoja(
    "garage-84",
    [
      { key: "portal", pedidos: 524, faturamento: 47424.62 },
      { key: "catalog", pedidos: 335, faturamento: 30174.69 },
      { key: "food99", pedidos: 322, faturamento: 18306.32 },
      { key: "ifood", pedidos: 108, faturamento: 7951.39 },
    ],
    {
      closed: { pedidos: 1187, faturamento: 100308.37 },
      canceled: { pedidos: 102, faturamento: 3548.65 },
    },
    20,
    { madrugada: 8, manha: 0, tarde: 9, noite: 1272 },
    { diaSemana: 662, fimSemana: 627 },
  );

  await importLoja(
    "la-pizza-dcaio",
    [
      { key: "portal", pedidos: 463, faturamento: 86838.76 },
      { key: "catalog", pedidos: 426, faturamento: 49848.9 },
      { key: "ifood", pedidos: 413, faturamento: 48251.04 },
      { key: "whatsapp", pedidos: 94, faturamento: 12185.4 },
    ],
    {
      closed: { pedidos: 1354, faturamento: 187311.67 },
      canceled: { pedidos: 42, faturamento: 9812.43 },
    },
    19,
    { madrugada: 0, manha: 0, tarde: 0, noite: 1396 },
    { diaSemana: 666, fimSemana: 730 },
  );

  console.log("Concluído.");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
