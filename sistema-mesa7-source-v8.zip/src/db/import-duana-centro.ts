// Onboarding da Pizzaria Duana Centro (cliente novo, confirmado por Lucas em
// 15/09/2026) + Plataformas e Comportamento de Agosto/2026, puxados via API
// do Cardápio Web (merchant_uuid 7ff9e877-0783-4d1d-bd39-efc0f481e196).
//
// Só números agregados — nunca dado de cliente (nome/telefone/endereço).
import "dotenv/config";
import { db } from "./index";
import { clients, weeklyMetrics } from "./schema";
import { eq } from "drizzle-orm";

type Pillar = "plataformas" | "comportamento";
const ORIGEM = "cardapio_web" as const;
const PERIOD = "2026-08-01";

async function upsertMetric(clientId: string, pillar: Pillar, metricKey: string, value: number) {
  await db
    .insert(weeklyMetrics)
    .values({ clientId, periodStart: PERIOD, pillar, metricKey, metricValue: value.toFixed(2), origem: ORIGEM })
    .onConflictDoUpdate({
      target: [weeklyMetrics.clientId, weeklyMetrics.periodStart, weeklyMetrics.metricKey],
      set: { metricValue: value.toFixed(2), pillar, origem: ORIGEM, updatedAt: new Date() },
    });
}

async function ensureClient(name: string, slug: string) {
  const [existing] = await db.select().from(clients).where(eq(clients.slug, slug)).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(clients).values({ name, slug }).returning();
  console.log(`cliente novo cadastrado: ${name} (${slug})`);
  return created;
}

async function main() {
  const client = await ensureClient("Pizzaria Duana - Centro", "duana-centro");

  // --- Plataformas (canal único: Site Próprio / catalog) ---
  await upsertMetric(client.id, "plataformas", "plat_pedidos_total", 53);
  await upsertMetric(client.id, "plataformas", "plat_faturamento_total", 6022.15);
  await upsertMetric(client.id, "plataformas", "plat_pedidos_cancelados", 1);
  await upsertMetric(client.id, "plataformas", "plat_taxa_cancelamento", (1 / 53) * 100);
  await upsertMetric(client.id, "plataformas", "plat_catalog_pedidos", 53);
  await upsertMetric(client.id, "plataformas", "plat_catalog_faturamento", 6022.15);

  // --- Comportamento ---
  await upsertMetric(client.id, "comportamento", "comport_hora_pico", 18);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_madrugada", 0);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_manha", 0);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_tarde", 1);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_noite", 52);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_dia_semana", 29);
  await upsertMetric(client.id, "comportamento", "comport_pedidos_fim_semana", 24);

  console.log(`${client.slug}: Plataformas + Comportamento de Agosto/2026 importados (53 pedidos).`);
  console.log("Concluído.");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
