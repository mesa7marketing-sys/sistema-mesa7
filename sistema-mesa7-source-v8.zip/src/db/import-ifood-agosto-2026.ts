// Importa a receita de iFood de Agosto/2026 direto dos relatórios exportados
// pelo Portal do Parceiro iFood (planilha "Vendas": pedidos, valor total,
// taxa de entrega e ticket médio por tipo de logística — Entrega própria,
// Retirada, Entrega parceira — somados aqui por loja).
//
// Fonte oficial da receita de iFood no Financeiro & Canais pra quem tem
// esse relatório disponível (mais preciso que o canal "iFood" do Cardápio
// Web, que é feito pela tag do pedido, não pelo extrato do próprio iFood).
//
// Cadastra como clientes novos: Hattori, Burguin, Deck Cantareira e
// Pizzaria Duana - Serra (confirmado por Lucas em 16/09/2026).
//
// Rotina mensal: repetir com os relatórios do iFood de cada mês.
import "dotenv/config";
import { db } from "./index";
import { clients, weeklyMetrics } from "./schema";
import { eq } from "drizzle-orm";

const PERIOD = "2026-08-01";
const ORIGEM = "ifood" as const;

async function upsertMetric(clientId: string, metricKey: string, value: number) {
  await db
    .insert(weeklyMetrics)
    .values({ clientId, periodStart: PERIOD, pillar: "financeiro", metricKey, metricValue: value.toFixed(2), origem: ORIGEM })
    .onConflictDoUpdate({
      target: [weeklyMetrics.clientId, weeklyMetrics.periodStart, weeklyMetrics.metricKey],
      set: { metricValue: value.toFixed(2), pillar: "financeiro", origem: ORIGEM, updatedAt: new Date() },
    });
}

async function ensureClient(name: string, slug: string) {
  const [existing] = await db.select().from(clients).where(eq(clients.slug, slug)).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(clients).values({ name, slug }).returning();
  console.log(`cliente novo cadastrado: ${name} (${slug})`);
  return created;
}

type Loja = { slug: string; name: string; pedidos: number; faturamento: number };

// Somado a partir da aba "Vendas" de cada relatório (Entrega própria + Retirada + Entrega parceira).
const LOJAS: Loja[] = [
  { slug: "la-pizza-dcaio", name: "La Pizza D'Caio", pedidos: 410, faturamento: 47029.62 },
  { slug: "bionatural", name: "Bionatural", pedidos: 240, faturamento: 14151.93 },
  { slug: "pacocas-unidade-1", name: "Paçocas - Unidade 1", pedidos: 311, faturamento: 55450.39 },
  { slug: "duana-centro", name: "Pizzaria Duana - Centro", pedidos: 246, faturamento: 27872.93 },
  { slug: "hattori", name: "Hattori", pedidos: 325, faturamento: 32717.47 },
  { slug: "burguin", name: "Burguin", pedidos: 534, faturamento: 37024.95 },
  { slug: "deck-cantareira", name: "Deck Cantareira", pedidos: 469, faturamento: 60327.48 },
  { slug: "duana-serra", name: "Pizzaria Duana - Serra", pedidos: 171, faturamento: 28854.58 },
];

async function main() {
  for (const loja of LOJAS) {
    const client = await ensureClient(loja.name, loja.slug);
    await upsertMetric(client.id, "fin_ifood_receita", loja.faturamento);
    console.log(
      `${loja.slug}: iFood de Agosto/2026 importado (${loja.pedidos} pedidos, R$ ${loja.faturamento.toFixed(2)}).`,
    );
  }
  console.log("Concluído.");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
