import {
  pgTable,
  uuid,
  text,
  varchar,
  timestamp,
  numeric,
  date,
  boolean,
  pgEnum,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// ---------------------------------------------------------------------------
// Enums
// ---------------------------------------------------------------------------

export const userRoleEnum = pgEnum("user_role", [
  "admin",
  "cs",
  "trafego",
  "social",
  "cardapio",
  "crm",
  "design",
  "google",
  "client",
]);

export const pillarEnum = pgEnum("pillar", [
  "conversao",
  "valor",
  "relacionamento",
  "financeiro",
  "cardapio",
  "plataformas",
  "comportamento",
  "marketing_360",
]);

export const origemEnum = pgEnum("origem", [
  "manual",
  "meta_ads",
  "google_ads",
  "gmn",
  "ifood",
  "cardapio_web",
  "repediu",
]);

export const actionStatusEnum = pgEnum("action_status", [
  "pendente",
  "em_andamento",
  "concluido",
  "atrasado",
]);

// ---------------------------------------------------------------------------
// Clients (contas dos restaurantes atendidos pela Mesa7)
// ---------------------------------------------------------------------------

export const clients = pgTable("clients", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const clientsRelations = relations(clients, ({ many }) => ({
  users: many(users),
  weeklyMetrics: many(weeklyMetrics),
  actionItems: many(actionItems),
  insights: many(insights),
  metaAdsAccounts: many(metaAdsAccounts),
}));

// ---------------------------------------------------------------------------
// Users (equipe Mesa7 + logins de clientes)
// ---------------------------------------------------------------------------

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: userRoleEnum("role").notNull(),
  // Somente preenchido quando role = 'client' — restringe o acesso a esse cliente.
  clientId: uuid("client_id").references(() => clients.id, { onDelete: "cascade" }),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const usersRelations = relations(users, ({ one }) => ({
  client: one(clients, { fields: [users.clientId], references: [clients.id] }),
}));

// ---------------------------------------------------------------------------
// Weekly metrics — tabela flexível que alimenta todas as páginas do CVR.
// Cada linha é uma métrica (metricKey) de um cliente numa semana, com a
// origem de onde o dado veio (preenchimento manual ou puxado via API).
// ---------------------------------------------------------------------------

export const weeklyMetrics = pgTable(
  "weekly_metrics",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    clientId: uuid("client_id")
      .notNull()
      .references(() => clients.id, { onDelete: "cascade" }),
    periodStart: date("period_start").notNull(), // segunda-feira da semana de referência
    pillar: pillarEnum("pillar").notNull(),
    metricKey: varchar("metric_key", { length: 100 }).notNull(),
    metricValue: numeric("metric_value", { precision: 14, scale: 2 }).notNull(),
    origem: origemEnum("origem").notNull(),
    createdBy: uuid("created_by").references(() => users.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("weekly_metrics_client_period_key_idx").on(
      t.clientId,
      t.periodStart,
      t.metricKey,
    ),
  ],
);

export const weeklyMetricsRelations = relations(weeklyMetrics, ({ one }) => ({
  client: one(clients, { fields: [weeklyMetrics.clientId], references: [clients.id] }),
  author: one(users, { fields: [weeklyMetrics.createdBy], references: [users.id] }),
}));

// ---------------------------------------------------------------------------
// Plano de Ação
// ---------------------------------------------------------------------------

export const actionItems = pgTable("action_items", {
  id: uuid("id").defaultRandom().primaryKey(),
  clientId: uuid("client_id")
    .notNull()
    .references(() => clients.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 300 }).notNull(),
  description: text("description"),
  responsible: varchar("responsible", { length: 200 }),
  status: actionStatusEnum("status").notNull().default("pendente"),
  dueDate: date("due_date"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const actionItemsRelations = relations(actionItems, ({ one }) => ({
  client: one(clients, { fields: [actionItems.clientId], references: [clients.id] }),
}));

// ---------------------------------------------------------------------------
// Insights (observações qualitativas por período)
// ---------------------------------------------------------------------------

export const insights = pgTable("insights", {
  id: uuid("id").defaultRandom().primaryKey(),
  clientId: uuid("client_id")
    .notNull()
    .references(() => clients.id, { onDelete: "cascade" }),
  periodStart: date("period_start").notNull(),
  text: text("text").notNull(),
  createdBy: uuid("created_by").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insightsRelations = relations(insights, ({ one }) => ({
  client: one(clients, { fields: [insights.clientId], references: [clients.id] }),
  author: one(users, { fields: [insights.createdBy], references: [users.id] }),
}));

// ---------------------------------------------------------------------------
// Meta Ads accounts — mapeia cada cliente pra sua conta de anúncios,
// usado pelo job de ingestão automática (origem = 'meta_ads').
// ---------------------------------------------------------------------------

export const metaAdsAccounts = pgTable("meta_ads_accounts", {
  id: uuid("id").defaultRandom().primaryKey(),
  clientId: uuid("client_id")
    .notNull()
    .references(() => clients.id, { onDelete: "cascade" }),
  adAccountId: varchar("ad_account_id", { length: 100 }).notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const metaAdsAccountsRelations = relations(metaAdsAccounts, ({ one }) => ({
  client: one(clients, { fields: [metaAdsAccounts.clientId], references: [clients.id] }),
}));

// ---------------------------------------------------------------------------
// Menu item sales — vendas por item de cardápio, usado na Curva ABC.
// Uma linha por item vendido num período (mensal). Alimentado hoje via
// importação manual dos dados de pedidos da API do Cardápio Web (o item a
// item vem de get_order, que também retorna dados do cliente — por isso
// nunca importamos nome/telefone/endereço, só item, quantidade e receita).
// ---------------------------------------------------------------------------

export const menuItemSales = pgTable(
  "menu_item_sales",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    clientId: uuid("client_id")
      .notNull()
      .references(() => clients.id, { onDelete: "cascade" }),
    periodStart: date("period_start").notNull(),
    itemName: varchar("item_name", { length: 300 }).notNull(),
    quantity: numeric("quantity", { precision: 12, scale: 2 }).notNull(),
    revenue: numeric("revenue", { precision: 14, scale: 2 }).notNull(),
    ordersCount: numeric("orders_count", { precision: 10, scale: 0 }),
    origem: origemEnum("origem").notNull().default("cardapio_web"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("menu_item_sales_client_period_item_idx").on(
      t.clientId,
      t.periodStart,
      t.itemName,
    ),
  ],
);

export const menuItemSalesRelations = relations(menuItemSales, ({ one }) => ({
  client: one(clients, { fields: [menuItemSales.clientId], references: [clients.id] }),
}));
