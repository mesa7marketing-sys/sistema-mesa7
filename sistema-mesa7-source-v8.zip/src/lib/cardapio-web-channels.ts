/**
 * Canais de venda reportados pela API do Cardápio Web (get_orders_grouped_summary,
 * group_by: sales_channel). Usado tanto pelo import (metricKey) quanto pela
 * página de Plataformas (label + cor). Só existe pra clientes conectados ao
 * Cardápio Web (hoje: Garage 84 e La Pizza D'Caio).
 */
export const PLATAFORMA_CANAIS = [
  { key: "portal", label: "Portal (marketplaces)", color: "var(--series-1)" },
  { key: "catalog", label: "Site Próprio", color: "var(--series-2)" },
  { key: "ifood", label: "iFood", color: "var(--series-5)" },
  { key: "food99", label: "99Food", color: "var(--series-6)" },
  { key: "whatsapp", label: "WhatsApp", color: "var(--series-7)" },
] as const;

export type PlataformaCanalKey = (typeof PLATAFORMA_CANAIS)[number]["key"];
