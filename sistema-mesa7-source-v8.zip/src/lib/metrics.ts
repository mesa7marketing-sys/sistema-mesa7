import { db } from "@/db";
import { weeklyMetrics } from "@/db/schema";
import { and, eq, desc, sql } from "drizzle-orm";

/**
 * Período mais recente com algum dado lançado pro cliente, ou `undefined` se
 * não houver nenhum ainda. Usado como padrão do seletor de mês — melhor do
 * que sempre cair no mês corrente do calendário, que costuma estar vazio até
 * o relatório daquele mês ser lançado.
 *
 * Só considera períodos alinhados ao primeiro dia do mês (YYYY-MM-01) — as
 * páginas de relatório mensal (Resumo, Financeiro, Método CVR, Plataformas,
 * Marketing 360°, Comportamento) trabalham só nesse formato. Isso evita que
 * uma carga pontual de dado semanal (ex: sync manual de Meta Ads numa
 * segunda-feira qualquer) "vaze" pra frente do mês fechado mais recente e
 * quebre o snapshot do mês.
 */
export async function latestPeriodWithData(clientId: string) {
  const [row] = await db
    .select({ periodStart: weeklyMetrics.periodStart })
    .from(weeklyMetrics)
    .where(and(eq(weeklyMetrics.clientId, clientId), sql`extract(day from ${weeklyMetrics.periodStart}) = 1`))
    .orderBy(desc(weeklyMetrics.periodStart))
    .limit(1);
  return row?.periodStart;
}

/** Retorna { [metricKey]: { value, periodStart } } para as duas últimas semanas com dado. */
export async function latestTwoPeriods(clientId: string, metricKeys: string[]) {
  const rows = await db
    .select()
    .from(weeklyMetrics)
    .where(and(eq(weeklyMetrics.clientId, clientId)))
    .orderBy(desc(weeklyMetrics.periodStart));

  const byKey: Record<string, { current?: number; previous?: number; periodStart?: string }> = {};

  for (const key of metricKeys) {
    const forKey = rows.filter((r) => r.metricKey === key);
    byKey[key] = {
      current: forKey[0] ? Number(forKey[0].metricValue) : undefined,
      previous: forKey[1] ? Number(forKey[1].metricValue) : undefined,
      periodStart: forKey[0]?.periodStart ?? undefined,
    };
  }

  return byKey;
}

/** Retorna as últimas `weeks` semanas (mais antiga -> mais recente) para uma metricKey. */
export async function seriesFor(clientId: string, metricKey: string, weeks = 8) {
  const rows = await db
    .select()
    .from(weeklyMetrics)
    .where(and(eq(weeklyMetrics.clientId, clientId), eq(weeklyMetrics.metricKey, metricKey)))
    .orderBy(desc(weeklyMetrics.periodStart))
    .limit(weeks);

  const ordered = rows.reverse();
  return {
    xLabels: ordered.map((r) => formatWeekLabel(r.periodStart)),
    values: ordered.map((r) => Number(r.metricValue)),
  };
}

function formatWeekLabel(periodStart: string) {
  const d = new Date(periodStart + "T00:00:00");
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
}

export function mondayOf(date: Date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d.toISOString().slice(0, 10);
}

/** Primeiro dia do mês da data informada, no formato YYYY-MM-01. */
export function firstOfMonth(date: Date) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
}

/** "YYYY-MM" -> "YYYY-MM-01". Aceita também "YYYY-MM-01" (idempotente). */
export function periodStartFromMonthValue(monthValue: string) {
  const [y, m] = monthValue.split("-");
  return `${y}-${m}-01`;
}

const MONTH_LABELS = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
];

/** Rótulo "Setembro/2026" a partir de um periodStart "YYYY-MM-DD". */
export function monthLabel(periodStart: string) {
  const [y, m] = periodStart.split("-");
  return `${MONTH_LABELS[Number(m) - 1]}/${y}`;
}

/** Últimos `count` meses (mais recente primeiro), como { value: "YYYY-MM-01", label: "Mês/Ano" }. */
export function recentMonthOptions(count = 24, from = new Date()) {
  const out: { value: string; label: string }[] = [];
  for (let i = 0; i < count; i++) {
    const d = new Date(from.getFullYear(), from.getMonth() - i, 1);
    const value = firstOfMonth(d);
    out.push({ value, label: monthLabel(value) });
  }
  return out;
}

/** periodStart deslocado em `delta` meses (pode ser negativo). */
export function shiftMonth(periodStart: string, delta: number) {
  const [y, m] = periodStart.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return firstOfMonth(d);
}

/**
 * Snapshot de um mês específico com comparativo vs. mês anterior (MoM) e
 * mesmo mês do ano anterior (YoY) — usado nas páginas no estilo "relatório
 * do mês selecionado" (Resumo Executivo, Financeiro & Canais).
 */
export async function snapshotForMonth(clientId: string, metricKeys: string[], periodStart: string) {
  const prevMonth = shiftMonth(periodStart, -1);
  const prevYear = shiftMonth(periodStart, -12);

  const [current, mom, yoy] = await Promise.all([
    valuesForWeek(clientId, metricKeys, periodStart),
    valuesForWeek(clientId, metricKeys, prevMonth),
    valuesForWeek(clientId, metricKeys, prevYear),
  ]);

  const byKey: Record<string, { current?: number; mom?: number; yoy?: number; momDelta?: number; yoyDelta?: number }> = {};
  for (const key of metricKeys) {
    byKey[key] = {
      current: current[key],
      mom: mom[key],
      yoy: yoy[key],
      momDelta: pctDelta(current[key], mom[key]),
      yoyDelta: pctDelta(current[key], yoy[key]),
    };
  }
  return byKey;
}

/** Valores já lançados para a semana informada (default: semana atual), por metricKey. */
export async function valuesForWeek(clientId: string, metricKeys: string[], periodStart = mondayOf(new Date())) {
  const rows = await db
    .select()
    .from(weeklyMetrics)
    .where(and(eq(weeklyMetrics.clientId, clientId), eq(weeklyMetrics.periodStart, periodStart)));

  const byKey: Record<string, number | undefined> = {};
  for (const key of metricKeys) {
    const row = rows.find((r) => r.metricKey === key);
    byKey[key] = row ? Number(row.metricValue) : undefined;
  }
  return byKey;
}

export function pctDelta(current?: number, previous?: number) {
  if (current === undefined || previous === undefined || previous === 0) return undefined;
  return ((current - previous) / previous) * 100;
}

export function formatBRL(value?: number) {
  if (value === undefined) return "—";
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
}

export function formatNumber(value?: number, decimals = 0) {
  if (value === undefined) return "—";
  return value.toLocaleString("pt-BR", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

export function formatDeltaLabel(delta?: number) {
  if (delta === undefined) return undefined;
  const sign = delta > 0 ? "+" : "";
  return `${sign}${delta.toFixed(1)}% vs. período anterior`;
}

export function deltaTone(delta?: number): "good" | "warn" | "bad" | undefined {
  if (delta === undefined) return undefined;
  if (delta > 0.5) return "good";
  if (delta < -0.5) return "bad";
  return "warn";
}
