import { redirect } from "next/navigation";
import Link from "next/link";
import { requireSession } from "@/lib/access";
import { db } from "@/db";
import { clients, clientHealth } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { FarolBadge } from "@/components/farol-badge";

export default async function HomePage() {
  const session = await requireSession();

  if (session.user.role === "client" && session.user.clientId) {
    const [client] = await db
      .select()
      .from(clients)
      .where(eq(clients.id, session.user.clientId))
      .limit(1);
    if (client) redirect(`/c/${client.slug}/resumo`);
  }

  const allClients = await db
    .select()
    .from(clients)
    .where(eq(clients.active, true))
    .orderBy(asc(clients.name));

  // Farol do Cliente (saúde da conta) — uso interno da equipe, nunca some
  // pro cliente porque essa home só é a página inicial de logins de time
  // (login de cliente já é redirecionado acima antes de chegar aqui).
  const isTeam = session.user.role !== "client";
  const healthByClient = new Map<string, string | null>();
  if (isTeam && allClients.length > 0) {
    const rows = await db.select().from(clientHealth);
    for (const r of rows) healthByClient.set(r.clientId, r.saudeConta);
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "var(--page)",
        color: "var(--text-primary)",
        padding: "40px",
      }}
    >
      <h1 style={{ fontSize: 26, marginBottom: 4 }}>Clientes</h1>
      <p style={{ color: "var(--text-secondary)", fontSize: 14, marginBottom: 24 }}>
        Selecione um cliente para ver o relatório.
      </p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px,1fr))", gap: 12, maxWidth: 900 }}>
        {allClients.map((c) => (
          <Link
            key={c.id}
            href={`/c/${c.slug}/resumo`}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 8,
              background: "var(--surface)",
              border: "1px solid var(--border)",
              borderRadius: 14,
              padding: "18px 16px",
              color: "var(--text-primary)",
              textDecoration: "none",
              fontWeight: 700,
              fontSize: 14.5,
            }}
          >
            <span>{c.name}</span>
            {isTeam && <FarolBadge saudeConta={healthByClient.get(c.id) ?? null} />}
          </Link>
        ))}
        {allClients.length === 0 && (
          <div style={{ color: "var(--text-muted)", fontSize: 13.5 }}>
            Nenhum cliente cadastrado ainda.
          </div>
        )}
      </div>
    </main>
  );
}
