import { PageHead, Card } from "@/components/ui";

export function ComingSoon({
  kicker,
  title,
  description,
  clientName,
}: {
  kicker: string;
  title: string;
  description: string;
  clientName: string;
}) {
  return (
    <div style={{ padding: "26px 28px 60px", maxWidth: 1180 }}>
      <PageHead kicker={kicker} title={`${title} — ${clientName}`} description={description} />
      <Card>
        <div style={{ color: "var(--text-muted)", fontSize: 13.5 }}>
          Esta página está em construção — os dados vão aparecer aqui assim que essa parte do
          sistema for implementada.
        </div>
      </Card>
    </div>
  );
}
