import { SignOutButton } from "@/components/SignOutButton";
import { NavLinks } from "@/components/NavLinks";

export function Sidebar({
  clientSlug,
  userName,
  userRole,
  showEntrada,
}: {
  clientSlug: string;
  userName: string;
  userRole: string;
  showEntrada?: boolean;
}) {
  return (
    <aside
      style={{
        background: "var(--surface)",
        borderRight: "1px solid var(--border)",
        padding: "22px 14px 18px",
        display: "flex",
        flexDirection: "column",
        gap: 20,
        position: "sticky",
        top: 0,
        height: "100vh",
        overflowY: "auto",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "2px 8px 4px" }}>
        <div
          style={{
            width: 30,
            height: 30,
            borderRadius: 8,
            background: "var(--accent)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "var(--accent-ink)",
            fontFamily: '"Bodoni Moda", serif',
            fontWeight: 700,
            fontSize: 16,
            flex: "none",
          }}
        >
          M7
        </div>
        <div>
          <div style={{ fontFamily: '"Bodoni Moda", serif', fontSize: 19, color: "#fff" }}>
            Mesa7
          </div>
          <div
            style={{
              fontSize: 10.5,
              color: "var(--text-muted)",
              textTransform: "uppercase",
              letterSpacing: "0.09em",
              marginTop: 1,
            }}
          >
            Sistema de relatórios
          </div>
        </div>
      </div>

      <NavLinks clientSlug={clientSlug} />

      {showEntrada && (
        <div style={{ padding: "0 2px" }}>
          <a
            href={`/c/${clientSlug}/entrada`}
            style={{
              display: "block",
              textAlign: "center",
              background: "var(--accent-soft)",
              color: "var(--accent)",
              border: "1px solid rgba(249,134,18,0.35)",
              borderRadius: 9,
              padding: "9px 12px",
              fontSize: 13,
              fontWeight: 700,
              textDecoration: "none",
            }}
          >
            + Lançar dados da semana
          </a>
        </div>
      )}

      <div
        style={{
          marginTop: "auto",
          padding: 12,
          borderTop: "1px solid var(--border)",
          fontSize: 11,
          color: "var(--text-muted)",
          lineHeight: 1.5,
        }}
      >
        <div style={{ color: "var(--text-secondary)", fontWeight: 700 }}>{userName}</div>
        <div>{userRole}</div>
        <SignOutButton />
      </div>
    </aside>
  );
}
