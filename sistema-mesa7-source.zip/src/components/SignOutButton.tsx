import { signOut } from "@/auth";

export function SignOutButton() {
  return (
    <form
      action={async () => {
        "use server";
        await signOut({ redirectTo: "/login" });
      }}
      style={{ marginTop: 8 }}
    >
      <button
        type="submit"
        style={{
          background: "none",
          border: "none",
          padding: 0,
          color: "var(--text-muted)",
          fontSize: 11,
          cursor: "pointer",
          textDecoration: "underline",
          fontFamily: "inherit",
        }}
      >
        Sair
      </button>
    </form>
  );
}
