"use client";

import { niceMax, formatByKind, type FormatKind } from "./format";
import { useChartTooltip } from "./ChartTooltip";

export type BarDatum = { label: string; value: number; color: string };

function roundedTopRect(x: number, y: number, w: number, h: number, r: number) {
  if (h < r) r = h;
  if (r < 0) r = 0;
  return (
    `M${x},${y + h} L${x},${y + r} Q${x},${y} ${x + r},${y}` +
    ` L${x + w - r},${y} Q${x + w},${y} ${x + w},${y + r}` +
    ` L${x + w},${y + h} Z`
  );
}

export function BarChart({
  data,
  format,
  width = 620,
  height = 240,
  aria,
}: {
  data: BarDatum[];
  format?: FormatKind;
  width?: number;
  height?: number;
  aria?: string;
}) {
  const { onMove, onLeave, tooltipEl } = useChartTooltip();
  const yFmt = (v: number) => formatByKind(format, v);

  const pad = { t: 16, r: 14, b: 30, l: 46 };
  const yMax = niceMax(Math.max(...data.map((d) => d.value)) * 1.18);
  const innerW = width - pad.l - pad.r;
  const innerH = height - pad.t - pad.b;
  const n = data.length;
  const gap = Math.min(16, (innerW / n) * 0.28);
  const bw = innerW / n - gap;
  const y = (v: number) => pad.t + innerH - (v / yMax) * innerH;

  const steps = 4;
  const gridLines = Array.from({ length: steps + 1 }, (_, g) => {
    const gv = (yMax * g) / steps;
    return { gy: y(gv), label: yFmt(gv) };
  });

  return (
    <div style={{ position: "relative" }}>
      <svg
        viewBox={`0 0 ${width} ${height}`}
        style={{ width: "100%", height: "auto", display: "block", overflow: "visible" }}
        role="img"
        aria-label={aria || "gráfico de barras"}
      >
        {gridLines.map((g, i) => (
          <g key={i}>
            <line x1={pad.l} x2={width - pad.r} y1={g.gy} y2={g.gy} stroke="var(--chart-grid)" strokeWidth={1} />
            <text x={pad.l - 8} y={g.gy + 3.5} textAnchor="end" fontSize={10.5} fill="var(--text-muted)">
              {g.label}
            </text>
          </g>
        ))}
        <line x1={pad.l} x2={width - pad.r} y1={y(0)} y2={y(0)} stroke="var(--chart-baseline)" strokeWidth={1.2} />

        {data.map((d, i) => {
          const bx = pad.l + i * (innerW / n) + gap / 2;
          const by = y(d.value);
          const bh = y(0) - by;
          const label = `${d.label}: ${yFmt(d.value)}`;
          return (
            <g key={i}>
              <path
                d={roundedTopRect(bx, by, bw, bh, Math.min(5, bw / 2))}
                fill={d.color}
                style={{ cursor: "pointer" }}
                onMouseMove={(e) => onMove(e, label)}
                onMouseLeave={onLeave}
              />
              <text x={bx + bw / 2} y={by - 6} textAnchor="middle" fontSize={10.5} fontWeight={700} fill="var(--text-secondary)">
                {yFmt(d.value)}
              </text>
              <text x={bx + bw / 2} y={height - 10} textAnchor="middle" fontSize={10.3} fill="var(--text-muted)">
                {d.label}
              </text>
            </g>
          );
        })}
      </svg>
      {tooltipEl}
    </div>
  );
}
