"use client";

import { niceMax, formatByKind, type FormatKind } from "./format";
import { useChartTooltip } from "./ChartTooltip";

export type Series = { name: string; color: string; values: number[] };

export function LineChart({
  series,
  xLabels,
  format,
  width = 620,
  height = 240,
  aria,
}: {
  series: Series[];
  xLabels: string[];
  format?: FormatKind;
  width?: number;
  height?: number;
  aria?: string;
}) {
  const { onMove, onLeave, tooltipEl } = useChartTooltip();
  const yFmt = (v: number) => formatByKind(format, v);

  const pad = { t: 16, r: 18, b: 28, l: 46 };
  const allVals = series.flatMap((s) => s.values).concat([0]);
  const yMax = niceMax(Math.max(...allVals) * 1.12);
  const innerW = width - pad.l - pad.r;
  const innerH = height - pad.t - pad.b;
  const n = xLabels.length;
  const x = (i: number) => pad.l + (n <= 1 ? 0 : (i / (n - 1)) * innerW);
  const y = (v: number) => pad.t + innerH - (v / yMax) * innerH;

  const steps = 4;
  const gridLines = Array.from({ length: steps + 1 }, (_, g) => {
    const gv = (yMax * g) / steps;
    return { gy: y(gv), label: yFmt(gv) };
  });

  return (
    <div style={{ position: "relative" }}>
      <svg
        viewBox={`0 0 ${width} ${height}`}
        style={{ width: "100%", height: "auto", display: "block", overflow: "visible" }}
        role="img"
        aria-label={aria || "gráfico de linha"}
      >
        {gridLines.map((g, i) => (
          <g key={i}>
            <line x1={pad.l} x2={width - pad.r} y1={g.gy} y2={g.gy} stroke="var(--chart-grid)" strokeWidth={1} />
            <text x={pad.l - 8} y={g.gy + 3.5} textAnchor="end" fontSize={10.5} fill="var(--text-muted)">
              {g.label}
            </text>
          </g>
        ))}
        <line x1={pad.l} x2={width - pad.r} y1={y(0)} y2={y(0)} stroke="var(--chart-baseline)" strokeWidth={1.2} />

        {xLabels.map((lb, i) => (
          <text key={i} x={x(i)} y={height - 8} textAnchor="middle" fontSize={10.5} fill="var(--text-muted)">
            {lb}
          </text>
        ))}

        {series.map((s, si) => {
          const pts = s.values.map((v, i) => [x(i), y(v)] as const);
          const d = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
          const gid = `area-${si}-${s.name.replace(/\s+/g, "")}`;
          const showArea = series.length === 1;
          const area = showArea
            ? `${d} L${x(n - 1).toFixed(1)},${y(0)} L${x(0).toFixed(1)},${y(0)} Z`
            : "";

          return (
            <g key={s.name}>
              {showArea && (
                <>
                  <defs>
                    <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={s.color} stopOpacity={0.32} />
                      <stop offset="100%" stopColor={s.color} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <path d={area} fill={`url(#${gid})`} stroke="none" />
                </>
              )}
              <path d={d} fill="none" stroke={s.color} strokeWidth={2.25} strokeLinecap="round" strokeLinejoin="round" />
              {pts.map((p, i) => (
                <circle
                  key={i}
                  cx={p[0].toFixed(1)}
                  cy={p[1].toFixed(1)}
                  r={3.6}
                  fill="var(--chart-surface)"
                  stroke={s.color}
                  strokeWidth={2.1}
                  style={{ cursor: "pointer" }}
                  onMouseMove={(e) => onMove(e, `${xLabels[i]} · ${s.name}: ${yFmt(s.values[i])}`)}
                  onMouseLeave={onLeave}
                />
              ))}
              {series.length > 1 && (
                <text
                  x={pts[pts.length - 1][0] + 7}
                  y={pts[pts.length - 1][1] - 8}
                  fontSize={11}
                  fontWeight={700}
                  fill={s.color}
                  textAnchor="start"
                >
                  {s.name}
                </text>
              )}
              {series.length === 1 && (
                <text
                  x={pts[pts.length - 1][0] + 7}
                  y={pts[pts.length - 1][1] - 8}
                  fontSize={11}
                  fontWeight={700}
                  fill={s.color}
                  textAnchor="start"
                >
                  {yFmt(s.values[s.values.length - 1])}
                </text>
              )}
            </g>
          );
        })}
      </svg>
      {series.length > 1 && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 12, marginTop: 10, fontSize: 12, color: "var(--text-secondary)", fontWeight: 600 }}>
          {series.map((s) => (
            <div key={s.name} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ width: 9, height: 9, borderRadius: 3, background: s.color, display: "inline-block" }} />
              {s.name}
            </div>
          ))}
        </div>
      )}
      {tooltipEl}
    </div>
  );
}
