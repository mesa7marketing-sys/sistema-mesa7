export function niceMax(v: number) {
  if (v <= 0) return 10;
  const mag = Math.pow(10, Math.floor(Math.log10(v)));
  const n = v / mag;
  const step = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
  return step * mag;
}

export function fmtR$(v: number) {
  return "R$ " + Math.round(v).toLocaleString("pt-BR");
}

export function fmtInt(v: number) {
  return Math.round(v).toLocaleString("pt-BR");
}

export function fmtPct(v: number, d = 1) {
  return v.toFixed(d).replace(".", ",") + "%";
}

/**
 * Chaves de formatação — usadas em vez de passar funções como prop, porque
 * funções não podem atravessar a fronteira Server -> Client Component.
 */
export type FormatKind =
  | "number"
  | "currency"
  | "currency-k"
  | "percent0"
  | "percent1"
  | "decimal1"
  | "multiplier1";

export function formatByKind(kind: FormatKind | undefined, v: number): string {
  switch (kind) {
    case "currency":
      return fmtR$(v);
    case "currency-k":
      return `R$${Math.round(v / 1000)}k`;
    case "percent0":
      return `${v.toFixed(0)}%`;
    case "percent1":
      return fmtPct(v, 1);
    case "decimal1":
      return v.toFixed(1);
    case "multiplier1":
      return `${v.toFixed(1)}x`;
    case "number":
    default:
      return fmtInt(v);
  }
}
