export function Tile({
  label,
  value,
  deltaLabel,
  deltaTone,
  caption,
}: {
  label: string;
  value: string;
  deltaLabel?: string;
  deltaTone?: "good" | "warn" | "bad";
  caption?: string;
}) {
  const toneColor =
    deltaTone === "good"
      ? "var(--status-good)"
      : deltaTone === "bad"
        ? "var(--status-critical)"
        : "var(--status-warning)";
  const toneBg =
    deltaTone === "good"
      ? "var(--status-good-bg)"
      : deltaTone === "bad"
        ? "var(--status-critical-bg)"
        : "var(--status-warning-bg)";

  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: 14,
        padding: "16px 16px 14px",
        boxShadow: "var(--shadow)",
      }}
    >
      <div style={{ fontSize: 12, color: "var(--text-secondary)", fontWeight: 700 }}>{label}</div>
      <div
        className="num"
        style={{ fontSize: 26, fontWeight: 600, margin: "8px 0 6px", letterSpacing: "-0.01em" }}
      >
        {value}
      </div>
      {deltaLabel && (
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 4,
            fontSize: 11.5,
            fontWeight: 800,
            padding: "3px 8px 3px 6px",
            borderRadius: 99,
            color: toneColor,
            background: toneBg,
          }}
        >
          {deltaLabel}
        </span>
      )}
      {caption && (
        <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 6 }}>{caption}</div>
      )}
    </div>
  );
}

export function Tiles({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(178px, 1fr))",
        gap: 12,
        marginBottom: 22,
      }}
    >
      {children}
    </div>
  );
}

export function Card({
  title,
  subtitle,
  children,
}: {
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: 16,
        padding: "18px 20px 16px",
        boxShadow: "var(--shadow)",
        marginBottom: 14,
      }}
    >
      {title && (
        <div style={{ marginBottom: 10 }}>
          <div style={{ fontSize: 14.5, fontWeight: 800 }}>{title}</div>
          {subtitle && (
            <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 2 }}>
              {subtitle}
            </div>
          )}
        </div>
      )}
      {children}
    </div>
  );
}

export function PageHead({ kicker, title, description }: { kicker: string; title: string; description?: string }) {
  return (
    <div style={{ marginBottom: 4 }}>
      <span
        style={{
          fontSize: 11.5,
          textTransform: "uppercase",
          letterSpacing: "0.11em",
          color: "var(--accent)",
          fontWeight: 800,
          display: "block",
          marginBottom: 6,
        }}
      >
        {kicker}
      </span>
      <h1 style={{ fontSize: 27 }}>{title}</h1>
      {description && (
        <p
          style={{
            color: "var(--text-secondary)",
            fontSize: 14,
            maxWidth: "62ch",
            margin: "8px 0 26px",
            lineHeight: 1.55,
          }}
        >
          {description}
        </p>
      )}
    </div>
  );
}
