import "dotenv/config";
import { db } from "./index";
import { clients, users, weeklyMetrics, actionItems, insights } from "./schema";
import bcrypt from "bcryptjs";

function mondayOf(date: Date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d.toISOString().slice(0, 10);
}

function weeksAgo(n: number) {
  const d = new Date();
  d.setDate(d.getDate() - n * 7);
  return mondayOf(d);
}

type Pillar = "conversao" | "valor" | "relacionamento" | "financeiro" | "cardapio";
type Origem = "manual" | "meta_ads" | "google_ads" | "gmn" | "ifood" | "cardapio_web" | "repediu";

/** Gera uma série de N semanas com uma tendência + ruído leve, mais recente primeiro na chamada mas gravada em ordem cronológica. */
function series(weeksCount: number, start: number, growthPerWeek: number, noise: number) {
  const out: number[] = [];
  let v = start;
  for (let i = 0; i < weeksCount; i++) {
    out.push(Math.max(0, v + (Math.random() - 0.5) * noise));
    v += growthPerWeek;
  }
  return out;
}

async function main() {
  console.log("Seeding banco de desenvolvimento...");

  const [demoClient] = await db
    .insert(clients)
    .values({ name: "Sabor & Brasa (exemplo)", slug: "sabor-e-brasa" })
    .onConflictDoNothing({ target: clients.slug })
    .returning();

  const client =
    demoClient ??
    (await db.query.clients.findFirst({ where: (c, { eq }) => eq(c.slug, "sabor-e-brasa") }))!;

  const adminHash = await bcrypt.hash("mesa7admin", 10);
  await db
    .insert(users)
    .values({
      name: "Lucas (Mesa7)",
      email: "lucas@mesa7.com.br",
      passwordHash: adminHash,
      role: "admin",
    })
    .onConflictDoNothing({ target: users.email });

  const clientHash = await bcrypt.hash("saborebrasa123", 10);
  await db
    .insert(users)
    .values({
      name: "Sabor & Brasa",
      email: "contato@saborebrasa.com.br",
      passwordHash: clientHash,
      role: "client",
      clientId: client.id,
    })
    .onConflictDoNothing({ target: users.email });

  const WEEKS = 8;
  const weekDates = Array.from({ length: WEEKS }, (_, i) => weeksAgo(WEEKS - 1 - i)); // mais antiga -> mais recente

  const seriesDefs: { pillar: Pillar; metricKey: string; origem: Origem; values: number[] }[] = [
    { pillar: "conversao", metricKey: "meta_investimento", origem: "meta_ads", values: series(WEEKS, 1700, 55, 120) },
    { pillar: "conversao", metricKey: "meta_leads", origem: "meta_ads", values: series(WEEKS, 130, 8, 14) },
    { pillar: "conversao", metricKey: "meta_roas", origem: "meta_ads", values: series(WEEKS, 3.2, 0.14, 0.3) },
    { pillar: "valor", metricKey: "instagram_seguidores", origem: "manual", values: series(WEEKS, 7600, 110, 40) },
    { pillar: "valor", metricKey: "avaliacoes_google_nota", origem: "gmn", values: series(WEEKS, 4.5, 0.02, 0.05) },
    { pillar: "relacionamento", metricKey: "clientes_ativos_crm", origem: "manual", values: series(WEEKS, 1020, 32, 25) },
    { pillar: "relacionamento", metricKey: "taxa_recompra", origem: "manual", values: series(WEEKS, 24, 1.0, 1.5) },
    { pillar: "financeiro", metricKey: "faturamento_total", origem: "manual", values: series(WEEKS, 54000, 2000, 3000) },
    { pillar: "financeiro", metricKey: "ticket_medio", origem: "manual", values: series(WEEKS, 78, 1.3, 3) },
    { pillar: "cardapio", metricKey: "cardapio_visualizacoes", origem: "cardapio_web", values: series(WEEKS, 3200, 90, 150) },
    { pillar: "cardapio", metricKey: "cardapio_conversao", origem: "cardapio_web", values: series(WEEKS, 18, 0.4, 1.2) },
  ];

  for (const def of seriesDefs) {
    for (let i = 0; i < WEEKS; i++) {
      const value = def.values[i].toFixed(2);
      await db
        .insert(weeklyMetrics)
        .values({
          clientId: client.id,
          periodStart: weekDates[i],
          pillar: def.pillar,
          metricKey: def.metricKey,
          metricValue: value,
          origem: def.origem,
        })
        .onConflictDoUpdate({
          target: [weeklyMetrics.clientId, weeklyMetrics.periodStart, weeklyMetrics.metricKey],
          set: { metricValue: value, origem: def.origem },
        });
    }
  }

  await db.insert(actionItems).values([
    {
      clientId: client.id,
      title: "Testar novo criativo de vídeo no Meta Ads",
      responsible: "Tráfego",
      status: "em_andamento",
    },
    {
      clientId: client.id,
      title: "Atualizar fotos do cardápio digital",
      responsible: "Gestão de Cardápio",
      status: "pendente",
    },
  ]);

  await db.insert(insights).values([
    {
      clientId: client.id,
      periodStart: weekDates[WEEKS - 1],
      text: "ROAS em tendência de alta nas últimas semanas — campanha de fim de semana performando acima da média.",
    },
  ]);

  console.log("Seed concluído. Cliente de exemplo:", client.slug);
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
