import { auth } from "@/auth";
import { db } from "@/db";
import { clients } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound, redirect } from "next/navigation";

export const TEAM_ROLES = [
  "admin",
  "cs",
  "trafego",
  "social",
  "cardapio",
  "crm",
  "design",
  "google",
] as const;

export type Role = (typeof TEAM_ROLES)[number] | "client";

export async function requireSession() {
  const session = await auth();
  if (!session?.user) redirect("/login");
  return session;
}

/**
 * Garante que o usuário logado pode ver o cliente identificado por `slug`.
 * Equipe Mesa7 (qualquer role != 'client') pode ver qualquer cliente ativo.
 * Usuário de cliente só pode ver o próprio cliente.
 */
export async function requireClientAccess(slug: string) {
  const session = await requireSession();

  const [client] = await db.select().from(clients).where(eq(clients.slug, slug)).limit(1);
  if (!client || !client.active) notFound();

  const isTeam = session.user.role !== "client";
  const ownsClient = session.user.clientId === client.id;

  if (!isTeam && !ownsClient) {
    notFound();
  }

  return { session, client };
}
