export type MetricDef = {
  key: string;
  label: string;
  pillar: "conversao" | "valor" | "relacionamento" | "financeiro" | "cardapio";
  origem: "manual" | "meta_ads" | "google_ads" | "gmn" | "ifood" | "cardapio_web" | "repediu";
  unit?: string;
  /** Se true, esse indicador é alimentado por API e não deve ser digitado manualmente. */
  autoOnly?: boolean;
};

export const METRIC_DEFS: MetricDef[] = [
  { key: "meta_investimento", label: "Investimento Meta Ads", pillar: "conversao", origem: "meta_ads", unit: "R$", autoOnly: true },
  { key: "meta_leads", label: "Leads (Meta Ads)", pillar: "conversao", origem: "meta_ads", autoOnly: true },
  { key: "meta_roas", label: "ROAS (Meta Ads)", pillar: "conversao", origem: "meta_ads", unit: "x", autoOnly: true },
  { key: "instagram_seguidores", label: "Seguidores Instagram", pillar: "valor", origem: "manual" },
  { key: "avaliacoes_google_nota", label: "Nota média Google", pillar: "valor", origem: "gmn" },
  { key: "clientes_ativos_crm", label: "Clientes ativos (CRM)", pillar: "relacionamento", origem: "manual" },
  { key: "taxa_recompra", label: "Taxa de recompra", pillar: "relacionamento", origem: "manual", unit: "%" },
  { key: "faturamento_total", label: "Faturamento total", pillar: "financeiro", origem: "manual", unit: "R$" },
  { key: "ticket_medio", label: "Ticket médio", pillar: "financeiro", origem: "manual", unit: "R$" },
  { key: "cardapio_visualizacoes", label: "Visualizações do cardápio", pillar: "cardapio", origem: "cardapio_web" },
  { key: "cardapio_conversao", label: "Conversão do cardápio", pillar: "cardapio", origem: "cardapio_web", unit: "%" },
];

export const PILLAR_LABEL: Record<string, string> = {
  conversao: "Conversão",
  valor: "Valor",
  relacionamento: "Relacionamento",
  financeiro: "Financeiro",
  cardapio: "Cardápio",
};

export function manualMetricDefs() {
  return METRIC_DEFS.filter((m) => !m.autoOnly);
}
