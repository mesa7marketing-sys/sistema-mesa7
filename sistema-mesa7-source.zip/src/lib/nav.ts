export const CVR_PAGES = [
  { slug: "resumo", label: "Resumo Executivo", group: "Visão geral" },
  { slug: "conversao", label: "Conversão", group: "Método CVR" },
  { slug: "valor", label: "Valor", group: "Método CVR" },
  { slug: "relacionamento", label: "Relacionamento", group: "Método CVR" },
  { slug: "financeiro", label: "Financeiro", group: "Método CVR" },
  { slug: "cardapio", label: "Cardápio", group: "Operação" },
  { slug: "plano-de-acao", label: "Plano de Ação", group: "Operação" },
  { slug: "insights", label: "Insights", group: "Operação" },
] as const;

export type CvrSlug = (typeof CVR_PAGES)[number]["slug"];
