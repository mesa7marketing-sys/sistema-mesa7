import type { Metadata } from "next";
import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { dashboardPorPasta } from "@/lib/dashboards";
import { acessoLiberado } from "@/lib/acesso-cliente";
import { FormSenhaCliente } from "@/components/FormSenhaCliente";
import { clientesLiberados } from "@/lib/live-acesso";

// Link do cliente: painel.mesa7.tech/<pasta>/dashboard, protegido pela senha do cliente
// (src/lib/acesso-cliente.ts). Mostra só o dashboard, em tela cheia.
export async function generateMetadata({ params }: PageProps<"/[cliente]/dashboard">): Promise<Metadata> {
  const { cliente } = await params;
  const d = dashboardPorPasta(cliente);
  if (!d) return { title: "Mesa7" };
  // Prévia do link no WhatsApp: precisa de URL absoluta da imagem.
  const h = await headers();
  // Atrás do proxy o host pode chegar como localhost/IP: aí usa o endereço público.
  const recebido = h.get("x-forwarded-host") ?? h.get("host") ?? "";
  const local = !recebido || /^(localhost|127\.|0\.0\.0\.0|\d+\.\d+\.\d+\.\d+)/.test(recebido);
  const base = local ? "https://painel.mesa7.tech" : `${h.get("x-forwarded-proto") ?? "https"}://${recebido}`;
  const titulo = `Mesa7 — Dashboard ${d.nome}`;
  const capa = { url: `${base}/${d.pasta}/dashboard/capa`, width: 600, height: 600, alt: `Dashboard ${d.nome}` };
  return {
    title: titulo,
    robots: { index: false, follow: false },
    referrer: "no-referrer",
    openGraph: { title: titulo, description: "Painel de relatórios Mesa7 — Método CVR", siteName: "Mesa7", type: "website", images: [capa] },
    twitter: { card: "summary", title: titulo, images: [capa.url] },
  };
}

export default async function DashboardClientePage({ params }: PageProps<"/[cliente]/dashboard">) {
  const { cliente } = await params;
  const d = dashboardPorPasta(cliente);
  if (!d) notFound();
  if (!(await acessoLiberado(d.pasta))) return <FormSenhaCliente cliente={d.pasta} nome={d.nome} />;

  const comLive = (await clientesLiberados()).includes(d.pasta);
  return (
    <>
      <iframe
        src={`/${d.pasta}/dashboard/arquivo/index.html`}
        title={`Dashboard ${d.nome}`}
        style={{ position: "fixed", inset: 0, width: "100%", height: "100%", border: 0, background: "#000" }}
      />
      {comLive && (
        <a
          href={`/${d.pasta}/dashboard/live`}
          style={{ position: "fixed", right: 14, bottom: 14, zIndex: 5, background: "#e1306c", color: "#fff", borderRadius: 999, padding: "9px 16px", fontSize: 13, fontWeight: 800, textDecoration: "none", boxShadow: "0 4px 14px rgba(0,0,0,.35)" }}
        >
          ● Fazer uma live
        </a>
      )}
    </>
  );
}
