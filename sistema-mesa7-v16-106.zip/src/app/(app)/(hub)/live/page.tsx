import { requireSession } from "@/lib/access";
import { PageHead } from "@/components/ui";
import { DASHBOARDS } from "@/lib/dashboards";
import { LiveEstudio } from "@/components/LiveEstudio";

export const dynamic = "force-dynamic";

// Live no Instagram pelo painel: sobe um vídeo/imagem e a VPS transmite para a chave do Instagram.
export default async function LivePage() {
  const session = await requireSession();
  if (session.user.role === "client") return null;
  const clientes = DASHBOARDS.map((d) => ({ pasta: d.pasta, nome: d.nome })).sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"));
  return (
    <div style={{ padding: "28px 32px 40px", maxWidth: 1240 }}>
      <PageHead kicker="Conteúdo" title="Live no Instagram" description="Um vídeo ou uma imagem no formato Stories, com logo e letreiro do cliente, transmitidos pela VPS com a chave de transmissão do Instagram (e do Facebook, se quiser ao mesmo tempo). Sem câmera e sem microfone." />
      <div style={{ marginTop: 18 }}>
        <LiveEstudio clientes={clientes} />
      </div>
    </div>
  );
}
