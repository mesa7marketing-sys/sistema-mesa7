import { revalidatePath } from "next/cache";
import { requireSession } from "@/lib/access";
import { PageHead } from "@/components/ui";
import { novoTokenToqan, tokenToqan } from "@/lib/toqan";

export const dynamic = "force-dynamic";

async function gerarNovo() {
  "use server";
  const s = await requireSession();
  if (s.user.role === "client") return;
  await novoTokenToqan();
  revalidatePath("/toqan");
}

const caixa: React.CSSProperties = { background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, padding: 18 };
const cod: React.CSSProperties = { display: "block", background: "var(--page)", border: "1px solid var(--border-strong)", borderRadius: 9, padding: "10px 12px", fontSize: 13, fontFamily: "monospace", wordBreak: "break-all", userSelect: "all" };

// Conexão do Toqan com os dados dos clientes (API só de leitura em /api/toqan).
export default async function ToqanPage() {
  const s = await requireSession();
  if (s.user.role === "client") return null;
  const token = await tokenToqan();
  const url = "https://painel.mesa7.tech/api/toqan";
  return (
    <div style={{ padding: "28px 32px 40px", maxWidth: 900 }}>
      <PageHead kicker="Integrações" title="Toqan" description="O Toqan lê os dados dos dashboards dos clientes por uma API só de leitura (iFood, Cardápio Web, Meta Ads, SAIPOS, Google Meu Negócio, Instagram, promoções…)." />
      <div style={{ display: "flex", flexDirection: "column", gap: 14, marginTop: 18 }}>
        <div style={caixa}>
          <div style={{ fontWeight: 800, marginBottom: 8 }}>1. Endereço e token</div>
          <label style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--text-muted)", fontWeight: 700 }}>Endereço (GET)</label>
          <code style={{ ...cod, margin: "5px 0 12px" }}>{url}</code>
          <label style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--text-muted)", fontWeight: 700 }}>Token (vai no cabeçalho Authorization: Bearer …)</label>
          <code style={{ ...cod, margin: "5px 0 12px" }}>{token}</code>
          <form action={gerarNovo}>
            <button type="submit" style={{ background: "var(--surface-raised)", color: "var(--text-primary)", border: "1px solid var(--border-strong)", borderRadius: 9, padding: "8px 14px", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>Gerar novo token</button>
            <span style={{ fontSize: 12, color: "var(--text-muted)", marginLeft: 10 }}>derruba o token atual — o Toqan precisa receber o novo</span>
          </form>
        </div>
        <div style={caixa}>
          <div style={{ fontWeight: 800, marginBottom: 8 }}>2. Cadastrar a ferramenta no Toqan</div>
          <ol style={{ margin: "0 0 0 18px", padding: 0, fontSize: 13.5, lineHeight: 1.7, color: "var(--text-secondary)" }}>
            <li>No Space do Toqan, aba <b>Tools</b> → nova ferramenta customizada (HTTP / GET).</li>
            <li>Nome: <b>Dados dos clientes Mesa7</b>. URL: o endereço acima. Cabeçalho <b>Authorization</b> = <b>Bearer</b> + o token.</li>
            <li>Parâmetros (todos opcionais): <b>cliente</b> (pasta, ex.: bionatural), <b>fonte</b> (ifood, cardapio, meta, saipos, gmb, instagram, promocoes, google, salao, comportamento, itens…), <b>mes</b> (AAAA-MM) e <b>todos</b> (1 = todos os meses).</li>
            <li>Descrição para o Toqan: “Sem parâmetros, lista os clientes e os meses disponíveis de cada fonte. Com <i>cliente</i>, devolve os dados dele (últimos 3 meses por padrão).”</li>
          </ol>
        </div>
        <div style={{ ...caixa, fontSize: 13, color: "var(--text-secondary)", lineHeight: 1.6 }}>
          <b style={{ color: "var(--text-primary)" }}>O que a API não traz:</b> nos dashboards completos (Bionatural, Burguin, Duana Centro, La Pizza, Paçocas 1, Taverna) parte dos números fica escrita no próprio dashboard e ainda não está na API. Os dados que entram por <i>dados.json</i> e pelos relatórios subidos em Arquivos estão todos nela. Para o iFood, a API entrega o que já foi carregado nos dashboards — não consulta o iFood ao vivo.
        </div>
      </div>
    </div>
  );
}
