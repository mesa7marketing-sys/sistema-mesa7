import { quemTransmite } from "@/lib/live-acesso";
import { arquivoDelete, arquivoGet, arquivoPost } from "@/lib/live-api";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ cliente: string }> };
export async function POST(req: Request, ctx: Ctx) { return arquivoPost(req, await quemTransmite((await ctx.params).cliente)); }
export async function GET(req: Request, ctx: Ctx) { return arquivoGet(req, await quemTransmite((await ctx.params).cliente)); }
export async function DELETE(req: Request, ctx: Ctx) { return arquivoDelete(req, await quemTransmite((await ctx.params).cliente)); }
