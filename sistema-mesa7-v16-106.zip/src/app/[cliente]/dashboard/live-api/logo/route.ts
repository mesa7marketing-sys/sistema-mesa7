import { promises as fs } from "node:fs";
import path from "node:path";
import { NextResponse } from "next/server";
import { quemTransmite } from "@/lib/live-acesso";

// Logo do próprio cliente (o *-logo.png/jpg da pasta do dashboard), para o canto da live.
export async function GET(_req: Request, ctx: { params: Promise<{ cliente: string }> }) {
  const { cliente } = await ctx.params;
  const q = await quemTransmite(cliente);
  if (!q?.pastaFixa) return new NextResponse(null, { status: 401 });
  const dir = path.join(process.cwd(), "dashboards", q.pastaFixa);
  const nome = (await fs.readdir(dir).catch(() => [] as string[])).find((n) => /logo\.(png|jpe?g)$/i.test(n) && !/mesa7/i.test(n));
  if (!nome) return new NextResponse(null, { status: 404 });
  const buf = await fs.readFile(path.join(dir, nome));
  return new NextResponse(new Uint8Array(buf), { headers: { "content-type": /\.png$/i.test(nome) ? "image/png" : "image/jpeg", "cache-control": "private, max-age=600" } });
}
