import { quemTransmite } from "@/lib/live-acesso";
import { liveGet, livePost } from "@/lib/live-api";

export const dynamic = "force-dynamic";

// Live pelo link do cliente: mesmas regras de /api/live, mas só a live e os arquivos do próprio cliente.
export async function GET(req: Request, ctx: { params: Promise<{ cliente: string }> }) {
  return liveGet(req, await quemTransmite((await ctx.params).cliente));
}
export async function POST(req: Request, ctx: { params: Promise<{ cliente: string }> }) {
  return livePost(req, await quemTransmite((await ctx.params).cliente));
}
