import { NextResponse } from "next/server";

// Rota da primeira versão da live (câmera do navegador), desativada: a live agora sai de um
// vídeo/imagem enviado em /api/live/arquivo. Fica aqui só para a atualização da VPS não deixar
// a versão antiga deste arquivo (que copiava por cima) quebrando o build.
export async function POST() {
  return NextResponse.json({ erro: "Esta forma de live foi desativada. Atualize a página." }, { status: 410 });
}
