import { quemTransmite } from "@/lib/live-acesso";
import { arquivoDelete, arquivoGet, arquivoPost } from "@/lib/live-api";

export const dynamic = "force-dynamic";

// POST (corpo = pedaço do arquivo): ?id=&nome=&pos=&total=&fim=0|1&enquadramento=auto|cobrir|inteiro
export async function POST(req: Request) { return arquivoPost(req, await quemTransmite()); }
// GET ?id= : situação do arquivo (analisando, convertendo x%, pronto, erro)
export async function GET(req: Request) { return arquivoGet(req, await quemTransmite()); }
// DELETE ?id= : descarta o arquivo (trocar de arquivo / desistir da live)
export async function DELETE(req: Request) { return arquivoDelete(req, await quemTransmite()); }
