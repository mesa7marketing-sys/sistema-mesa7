import { promises as fs } from "node:fs";
import path from "node:path";
import { NextResponse } from "next/server";
import { dashboardPorPasta } from "@/lib/dashboards";
import { usuarioEquipe } from "@/lib/live-acesso";

// Logo do cliente (o *-logo.png/jpg da pasta do dashboard), para o canto da live.
export async function GET(_req: Request, ctx: { params: Promise<{ pasta: string }> }) {
  if (!(await usuarioEquipe())) return new NextResponse(null, { status: 401 });
  const { pasta } = await ctx.params;
  if (!dashboardPorPasta(pasta)) return new NextResponse(null, { status: 404 });
  const dir = path.join(process.cwd(), "dashboards", pasta);
  const nome = (await fs.readdir(dir).catch(() => [] as string[])).find((n) => /logo\.(png|jpe?g)$/i.test(n) && !/mesa7/i.test(n));
  if (!nome) return new NextResponse(null, { status: 404 });
  const buf = await fs.readFile(path.join(dir, nome));
  return new NextResponse(new Uint8Array(buf), { headers: { "content-type": /\.png$/i.test(nome) ? "image/png" : "image/jpeg", "cache-control": "private, max-age=600" } });
}
