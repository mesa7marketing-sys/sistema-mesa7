import { NextResponse } from "next/server";
import { clientesLiberados, liberarCliente, quemTransmite, usuarioEquipe } from "@/lib/live-acesso";
import { liveGet, livePost } from "@/lib/live-api";

export const dynamic = "force-dynamic";

// GET: a live que estiver no ar (ou ?id=…); ?verificar=1 diz se a VPS tem o ffmpeg e quanto espaço sobra;
// ?liberados=1 lista os clientes que a equipe liberou para transmitir pelo próprio link.
export async function GET(req: Request) {
  if (new URL(req.url).searchParams.has("liberados")) {
    if (!(await usuarioEquipe())) return NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
    return NextResponse.json({ liberados: await clientesLiberados() });
  }
  return liveGet(req, await quemTransmite());
}

// POST { acao: "iniciar", pasta, arquivo, modo, logo (PNG em data URL ou null), letreiro, destinos }
//      { acao: "letreiro", id, texto } | { acao: "encerrar", id } | { acao: "liberar", pasta, ligado }
export async function POST(req: Request) {
  const q = await quemTransmite();
  const copia = req.clone();
  const b = await copia.json().catch(() => null);
  if (b?.acao === "liberar") {
    if (!q) return NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
    try {
      await liberarCliente(String(b.pasta || ""), !!b.ligado);
      return NextResponse.json({ liberados: await clientesLiberados() });
    } catch (e) {
      return NextResponse.json({ erro: e instanceof Error ? e.message : String(e) }, { status: 400 });
    }
  }
  return livePost(req, q);
}
