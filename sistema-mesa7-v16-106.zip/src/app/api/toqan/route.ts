import { NextResponse } from "next/server";
import { DASHBOARDS, dashboardPorPasta } from "@/lib/dashboards";
import { dadosDoCliente, perfilDoCliente } from "@/lib/dados-clientes";
import { pedidoAutorizado } from "@/lib/toqan";

export const dynamic = "force-dynamic";

const nega = (status: number, erro: string) => NextResponse.json({ erro }, { status, headers: { "cache-control": "no-store" } });

/**
 * Dados dos clientes para o Toqan (só leitura).
 *  GET /api/toqan                      → lista de clientes e o que existe de cada fonte (meses)
 *  GET /api/toqan?cliente=<pasta>      → dados do cliente, últimos 3 meses de cada fonte
 *      &fonte=ifood|ifood_funil|cardapio|itens|meta|saipos|gmb|instagram|anuncios|promocoes|google|salao|comportamento
 *      &mes=AAAA-MM  (um mês)   |   &todos=1  (todos os meses)
 */
export async function GET(req: Request) {
  if (!(await pedidoAutorizado(req))) return nega(401, "Token inválido ou ausente.");
  const q = new URL(req.url).searchParams;
  const pasta = q.get("cliente");

  if (!pasta) {
    const clientes = await Promise.all(
      DASHBOARDS.map(async (d) => {
        const dados = await dadosDoCliente(d.pasta);
        const fontes: Record<string, string[]> = {};
        for (const [f, meses] of Object.entries(dados)) {
          const ks = Object.keys(meses as object).sort();
          if (ks.length) fontes[f] = ks;
        }
        return { cliente: d.pasta, nome: d.nome, segmento: d.segmento, fontes };
      }),
    );
    return NextResponse.json({ clientes }, { headers: { "cache-control": "no-store" } });
  }

  const d = dashboardPorPasta(pasta);
  if (!d) return nega(404, "Cliente não encontrado. Use /api/toqan para ver a lista.");
  const dados = await dadosDoCliente(d.pasta);
  const fonte = q.get("fonte");
  const mes = q.get("mes");
  if (mes && !/^\d{4}-\d{2}$/.test(mes)) return nega(400, "mes deve ser AAAA-MM.");
  if (fonte && !(fonte in dados)) return nega(400, `fonte inválida: ${fonte}`);

  const saida: Record<string, unknown> = {};
  for (const [f, meses] of Object.entries(dados)) {
    if (fonte && f !== fonte) continue;
    if (f === "vendas_semana") { saida[f] = meses; continue; }
    const todos = meses as Record<string, unknown>;
    const ks = Object.keys(todos).sort();
    const usar = mes ? ks.filter((k) => k === mes) : q.get("todos") === "1" ? ks : ks.slice(-3);
    if (usar.length) saida[f] = Object.fromEntries(usar.map((k) => [k, todos[k]]));
  }
  return NextResponse.json(
    { cliente: d.pasta, nome: d.nome, segmento: d.segmento, perfil: await perfilDoCliente(d.pasta), dados: saida },
    { headers: { "cache-control": "no-store" } },
  );
}
