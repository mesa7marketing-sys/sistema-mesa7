"use client";

// Live no Instagram com um vídeo ou imagem enviado na hora (sem câmera e sem microfone).
// O arquivo sobe em pedaços para a VPS, que transmite sozinha (src/lib/live.ts) — o navegador
// só inicia, e encerra. O arquivo é apagado da VPS quando a live termina.
import { useEffect, useRef, useState } from "react";

type Cliente = { pasta: string; nome: string };
type Arquivo = {
  id: string; nome: string; tipo: "video" | "imagem"; tamanho: number; estado: "enviando" | "analisando" | "preparando" | "pronto" | "erro";
  progresso: number; largura: number | null; altura: number | null; duracao: number | null; preparado: boolean; erro: string | null;
};
type Live = {
  id: string; pasta: string; arquivoId: string; arquivoNome: string; tipo: "video" | "imagem"; destinos: string[]; usuario: string;
  noAr: boolean; orfa: boolean; segundos: number; transmitido: number | null; previsto: number | null;
  velocidade: string | null; bitrate: string | null; letreiro: string; avisos: string[]; motivo: string | null;
};
type Enq = "auto" | "cobrir" | "inteiro";

const IG_SERVIDOR = "rtmps://live-upload.instagram.com:443/rtmp/";
const FB_SERVIDOR = "rtmps://live-api-s.facebook.com:443/rtmp/";
const PEDACO = 4 * 1024 * 1024;

const caixa: React.CSSProperties = { background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, padding: 16 };
const rotulo: React.CSSProperties = { fontSize: 11, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--text-muted)", fontWeight: 700, display: "block", marginBottom: 5 };
const passo: React.CSSProperties = { fontSize: 13.5, fontWeight: 800, marginBottom: 10, color: "var(--text-primary)" };
const campo: React.CSSProperties = { width: "100%", background: "var(--page)", color: "var(--text-primary)", border: "1px solid var(--border-strong)", borderRadius: 9, padding: "9px 11px", fontSize: 13.5 };
const botao = (cor: string, ativo = true): React.CSSProperties => ({
  background: ativo ? cor : "var(--surface-raised)", color: ativo ? "#fff" : "var(--text-muted)", border: "none", borderRadius: 10,
  padding: "11px 18px", fontWeight: 800, fontSize: 14, cursor: ativo ? "pointer" : "not-allowed",
});
const link: React.CSSProperties = { background: "none", border: "none", color: "var(--accent)", cursor: "pointer", padding: 0, fontSize: 12.5, textDecoration: "underline" };
const tempo = (s: number) => `${String(Math.floor(s / 3600)).padStart(2, "0")}:${String(Math.floor((s % 3600) / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
const mb = (b: number) => (b / 1048576).toLocaleString("pt-BR", { maximumFractionDigits: b < 10485760 ? 1 : 0 }) + " MB";
const min = (s: number) => (s >= 3600 ? `${Math.floor(s / 3600)} h ${Math.round((s % 3600) / 60)} min` : s >= 60 ? `${Math.floor(s / 60)} min ${s % 60} s` : `${s} s`);
const novoId = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => (b % 36).toString(36)).join("");
const espera = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function LiveEstudio({ clientes, pastaFixa, base = "/api/live" }: { clientes: Cliente[]; pastaFixa?: string; base?: string }) {
  // pastaFixa: página do próprio cliente (/<cliente>/dashboard/live) — cliente já escolhido, rotas do cliente
  const [pasta, setPasta] = useState(pastaFixa ?? "");
  const [liberados, setLiberados] = useState<string[]>([]);
  const [enq, setEnq] = useState<Enq>("auto");
  const [local, setLocal] = useState<{ url: string; tipo: "video" | "imagem"; nome: string; tamanho: number } | null>(null);
  const [enviado, setEnviado] = useState(0);
  const [arquivo, setArquivo] = useState<Arquivo | null>(null);
  const [modo, setModo] = useState("uma");
    const [igChave, setIgChave] = useState("");
  const [igServidor, setIgServidor] = useState(IG_SERVIDOR);
  const [fbChave, setFbChave] = useState("");
  const [live, setLive] = useState<Live | null>(null);
  const [erro, setErro] = useState("");
  const [ocupado, setOcupado] = useState(false);
  const [servidor, setServidor] = useState<{ ffmpeg: string | null; livreGB: number | null } | null>(null);
  const [verificacao, setVerificacao] = useState(0);
  const cancelado = useRef(false);

  // ---------- VPS pronta? e live que já esteja no ar (aberta de outro computador) ----------
  useEffect(() => {
    let vivo = true;
    fetch(`${base}?verificar=1`).then((r) => r.json()).then((j) => { if (vivo) setServidor({ ffmpeg: j.ffmpeg ?? null, livreGB: j.livreGB ?? null }); }).catch(() => {});
    fetch(base).then((r) => r.json()).then((j) => { if (vivo && j.live) setLive(j.live); }).catch(() => {});
    if (!pastaFixa) fetch(`${base}?liberados=1`).then((r) => r.json()).then((j) => { if (vivo && j.liberados) setLiberados(j.liberados); }).catch(() => {});
    return () => { vivo = false; };
  }, [verificacao, base, pastaFixa]);

  // ---------- acompanhamento: arquivo sendo conferido/convertido na VPS ----------
  useEffect(() => {
    if (!arquivo || (arquivo.estado !== "analisando" && arquivo.estado !== "preparando")) return;
    const t = setInterval(async () => {
      const j = await fetch(`${base}/arquivo?id=${arquivo.id}`).then((r) => r.json()).catch(() => null);
      if (j?.arquivo) setArquivo(j.arquivo);
    }, 1500);
    return () => clearInterval(t);
  }, [arquivo, base]);

  // ---------- acompanhamento: live no ar ----------
  useEffect(() => {
    if (!live?.noAr) return;
    const id = live.id, arq = live.arquivoId;
    const t = setInterval(async () => {
      const j = await fetch(`${base}?id=${id}`).then((r) => r.json()).catch(() => null);
      if (!j?.live) return;
      setLive(j.live);
      if (!j.live.noAr) {   // terminou: a VPS apaga o arquivo (se caiu logo no início, fica para tentar de novo)
        const a = await fetch(`${base}/arquivo?id=${arq}`).then((r) => r.json()).catch(() => null);
        setArquivo(a?.arquivo ?? null);
        if (!a?.arquivo) setLocal(null);
      }
    }, 3000);
    return () => clearInterval(t);
  }, [live?.noAr, live?.id, live?.arquivoId, base]);

  // ---------- envio do arquivo ----------
  async function escolher(file: File | undefined) {
    if (!file) return;
    setErro("");
    await descartarAtual();
    const tipo = file.type.startsWith("image/") ? "imagem" : "video";
    setLocal({ url: URL.createObjectURL(file), tipo, nome: file.name, tamanho: file.size });
    setModo(tipo === "imagem" ? "60" : "uma");
    setEnviado(0);
    cancelado.current = false;
    const id = novoId();
    setArquivo({ id, nome: file.name, tipo, tamanho: file.size, estado: "enviando", progresso: 0, largura: null, altura: null, duracao: null, preparado: false, erro: null });
    let pos = 0, tam = PEDACO, falhas = 0;
    try {
      while (pos < file.size) {
        if (cancelado.current) return;
        const fim = Math.min(file.size, pos + tam);
        const q = new URLSearchParams({ id, nome: file.name, pos: String(pos), total: String(file.size), fim: fim === file.size ? "1" : "0", enquadramento: enq });
        let r: Response;
        try { r = await fetch(`${base}/arquivo?${q}`, { method: "POST", body: file.slice(pos, fim), headers: { "content-type": "application/octet-stream" } }); }
        catch { if (++falhas > 6) throw new Error("a internet caiu durante o envio"); await espera(1500 * falhas); continue; }
        if (r.status === 413 && tam > 256 * 1024) { tam = Math.floor(tam / 2); continue; }   // servidor recusou o tamanho: manda menor
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(j.erro || `erro ${r.status}`);
        falhas = 0; pos = fim; setEnviado(pos);
        if (j.arquivo) setArquivo(j.arquivo);
      }
    } catch (e) {
      if (cancelado.current) return;
      setArquivo(null);
      setErro("Não consegui enviar o arquivo: " + (e instanceof Error ? e.message : String(e)));
    }
  }

  async function descartarAtual() {
    cancelado.current = true;
    if (arquivo && !(live?.noAr && live.arquivoId === arquivo.id)) await fetch(`${base}/arquivo?id=${arquivo.id}`, { method: "DELETE" }).catch(() => {});
    if (local) URL.revokeObjectURL(local.url);
    setArquivo(null); setLocal(null); setEnviado(0);
  }

  // ---------- live ----------
  async function iniciar() {
    setErro("");
    if (!pasta) return setErro("Escolha o cliente.");
    if (!arquivo || arquivo.estado !== "pronto") return setErro("Envie o vídeo ou a imagem e espere ficar pronto.");
    if (!igChave.trim() && !fbChave.trim()) return setErro("Cole a chave de transmissão do Instagram.");
    setOcupado(true);
    try {
      const destinos = [
        igChave.trim() && { nome: "Instagram", servidor: igServidor, chave: igChave },
        fbChave.trim() && { nome: "Facebook", servidor: FB_SERVIDOR, chave: fbChave },
      ].filter(Boolean);
      const r = await fetch(base, { method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ acao: "iniciar", pasta, arquivo: arquivo.id, modo, logo: null, letreiro: "", destinos }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.erro || `erro ${r.status}`);
      setLive(j.live);
    } catch (e) {
      setErro("Não consegui iniciar: " + (e instanceof Error ? e.message : String(e)));
    } finally { setOcupado(false); }
  }

  async function liberar(ligado: boolean) {
    const j = await fetch(base, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ acao: "liberar", pasta, ligado }) }).then((r) => r.json()).catch(() => null);
    if (j?.liberados) setLiberados(j.liberados); else setErro(j?.erro || "Não consegui salvar a liberação.");
  }

  async function encerrar() {
    if (!live) return;
    setOcupado(true);
    const j = await fetch(base, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ acao: "encerrar", id: live.id }) }).then((r) => r.json()).catch(() => null);
    if (j?.live) setLive({ ...j.live, noAr: true });   // o acompanhamento confirma o fim e limpa o arquivo
    setOcupado(false);
  }

  const noAr = !!live?.noAr;
  const pronto = arquivo?.estado === "pronto";
  const tipo = arquivo?.tipo ?? local?.tipo;
  const enviando = arquivo?.estado === "enviando";
  const situacaoArquivo = !arquivo ? null
    : arquivo.estado === "enviando" ? `Enviando… ${mb(enviado)} de ${mb(arquivo.tamanho)} (${Math.floor((enviado / Math.max(1, arquivo.tamanho)) * 100)}%)`
    : arquivo.estado === "analisando" ? "Conferindo o arquivo na VPS…"
    : arquivo.estado === "preparando" ? `Convertendo para a live (arquivo pesado)… ${arquivo.progresso}%`
    : arquivo.estado === "erro" ? `Erro: ${arquivo.erro}`
    : `Pronto ✓ ${arquivo.tipo === "video" ? `vídeo ${arquivo.largura}x${arquivo.altura}${arquivo.duracao ? ` · ${min(arquivo.duracao)}` : ""}` : `imagem ${arquivo.largura}x${arquivo.altura}`}`;
  const barra = !arquivo ? 0 : arquivo.estado === "enviando" ? (enviado / Math.max(1, arquivo.tamanho)) * 100 : arquivo.estado === "preparando" ? arquivo.progresso : arquivo.estado === "pronto" ? 100 : 0;
  const r = arquivo?.largura && arquivo?.altura ? arquivo.largura / arquivo.altura : null;
  const inteiro = enq === "inteiro" || (enq === "auto" && r !== null && !(r >= 0.5 && r <= 0.65));
  const ajuste: React.CSSProperties = { width: "100%", height: "100%", objectFit: inteiro ? "contain" : "cover", position: "absolute", inset: 0 };
  const fundo: React.CSSProperties = { ...ajuste, objectFit: "cover", filter: "blur(18px) brightness(.85)", transform: "scale(1.1)" };

  return (
    <div style={{ display: "grid", gridTemplateColumns: pastaFixa ? "repeat(auto-fit, minmax(min(100%, 320px), 1fr))" : "minmax(300px, 440px) 1fr", gap: 18, alignItems: "start" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={caixa}>
          <div style={passo}>1. Cliente</div>
          {pastaFixa ? (
            <div style={{ fontSize: 14, fontWeight: 700 }}>{clientes.find((c) => c.pasta === pastaFixa)?.nome ?? pastaFixa}</div>
          ) : (
            <>
              <select style={campo} value={pasta} onChange={(e) => setPasta(e.target.value)} disabled={noAr}>
                <option value="">Escolha…</option>
                {clientes.map((c) => <option key={c.pasta} value={c.pasta}>{c.nome}{!liberados.includes(c.pasta) ? " (cliente bloqueado)" : ""}</option>)}
              </select>
              {pasta && (
                <label style={{ display: "flex", gap: 8, alignItems: "center", fontSize: 12.5, marginTop: 10, color: "var(--text-secondary)" }}>
                  <input type="checkbox" checked={liberados.includes(pasta)} onChange={(e) => liberar(e.target.checked)} />
                  Cliente pode transmitir pelo próprio link (/{pasta}/dashboard/live) — desmarque para bloquear
                </label>
              )}
            </>
          )}
        </div>

        <div style={caixa}>
          <div style={passo}>2. Vídeo ou imagem da live</div>
          <label style={rotulo}>Enquadramento no formato Stories (9:16)</label>
          <select style={campo} value={enq} onChange={(e) => setEnq(e.target.value as Enq)} disabled={!!arquivo}>
            <option value="auto">Automático</option>
            <option value="cobrir">Preencher a tela (corta as bordas)</option>
            <option value="inteiro">Inteiro, com fundo desfocado</option>
          </select>
          {!arquivo ? (
            <label style={{ display: "block", marginTop: 10, border: "1.5px dashed var(--border-strong)", borderRadius: 12, padding: "22px 14px", textAlign: "center", cursor: noAr ? "not-allowed" : "pointer", color: "var(--text-secondary)", fontSize: 13.5 }}
              onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); if (!noAr) void escolher(e.dataTransfer.files[0]); }}>
              <b style={{ color: "var(--accent)" }}>Escolher arquivo</b> ou arrastar aqui
              <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 4 }}>Vídeo MP4/MOV ou imagem JPG/PNG · até 3 GB</div>
              <input type="file" accept="video/*,image/*" style={{ display: "none" }} disabled={noAr} onChange={(e) => { void escolher(e.target.files?.[0]); e.target.value = ""; }} />
            </label>
          ) : (
            <div style={{ marginTop: 10, fontSize: 13 }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
                <b style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{arquivo.nome}</b>
                {!noAr && <button style={link} onClick={() => void descartarAtual()}>{enviando ? "Cancelar" : "Trocar arquivo"}</button>}
              </div>
              <div style={{ height: 7, borderRadius: 7, background: "var(--surface-raised)", margin: "8px 0 6px", overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${barra}%`, background: arquivo.estado === "erro" ? "var(--status-critical)" : "var(--accent)", transition: "width .3s" }} />
              </div>
              <div style={{ color: arquivo.estado === "erro" ? "var(--status-critical)" : arquivo.estado === "pronto" ? "var(--status-good)" : "var(--text-secondary)" }}>{situacaoArquivo}</div>
            </div>
          )}
          <p style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 8, lineHeight: 1.5 }}>O arquivo fica na VPS só para esta live e é apagado quando ela termina.</p>
        </div>

        <div style={caixa}>
          <div style={passo}>3. Duração</div>
          <select style={campo} value={modo} onChange={(e) => setModo(e.target.value)} disabled={noAr}>
            {tipo !== "imagem" && <option value="uma">Até o vídeo acabar{arquivo?.duracao ? ` (${min(arquivo.duracao)})` : ""}</option>}
            <option value="30">{tipo === "imagem" ? "30 minutos" : "Repetir por 30 minutos"}</option>
            <option value="60">{tipo === "imagem" ? "1 hora" : "Repetir por 1 hora"}</option>
            <option value="120">{tipo === "imagem" ? "2 horas" : "Repetir por 2 horas"}</option>
            <option value="max">Até eu encerrar (máx. 4 h)</option>
          </select>
        </div>

        <div style={caixa}>
          <div style={passo}>4. Destino</div>
          <label style={rotulo}>Instagram · chave de transmissão</label>
          <input style={campo} type="password" autoComplete="off" value={igChave} onChange={(e) => setIgChave(e.target.value)} disabled={noAr} placeholder="Cole a chave do instagram.com → Criar → Vídeo ao vivo" />
          <details style={{ marginTop: 6 }}>
            <summary style={{ fontSize: 11.5, color: "var(--text-muted)", cursor: "pointer" }}>Servidor (só se o Instagram mostrar outro)</summary>
            <input style={{ ...campo, marginTop: 6 }} value={igServidor} onChange={(e) => setIgServidor(e.target.value)} disabled={noAr} />
          </details>
          <label style={{ ...rotulo, marginTop: 12 }}>Facebook · chave (opcional, ao mesmo tempo)</label>
          <input style={campo} type="password" autoComplete="off" value={fbChave} onChange={(e) => setFbChave(e.target.value)} disabled={noAr} placeholder="Chave do Live Producer do Facebook" />
          <p style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 8, lineHeight: 1.5 }}>A chave não fica salva. O Instagram gera uma nova a cada live.</p>
        </div>

        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          {!noAr
            ? <button style={botao("#E5484D", !ocupado && pronto)} disabled={ocupado || !pronto} onClick={() => void iniciar()}>{ocupado ? "Conectando…" : "● Iniciar transmissão"}</button>
            : <button style={botao("#3a3a44", !ocupado)} disabled={ocupado} onClick={() => void encerrar()}>■ Encerrar live</button>}
          {servidor?.ffmpeg && <span style={{ fontSize: 11.5, color: "var(--text-muted)" }}>Servidor pronto{servidor.livreGB !== null ? ` · ${servidor.livreGB} GB livres` : ""}</span>}
        </div>
        {servidor && !servidor.ffmpeg && (
          <div style={{ ...caixa, borderColor: "var(--status-warning)", fontSize: 13, lineHeight: 1.55 }}>
            <b style={{ color: "var(--status-warning)" }}>A VPS ainda não tem o ffmpeg</b> (o programa que envia a live para o Instagram).
            A atualização automática instala sozinha em alguns minutos. Se não instalar, rode no terminal da VPS: <code>apt install -y ffmpeg</code>.{" "}
            <button style={link} onClick={() => setVerificacao((n) => n + 1)}>Verificar de novo</button>
          </div>
        )}
        {erro && <div style={{ ...caixa, borderColor: "var(--status-critical)", color: "var(--status-critical)", fontSize: 13 }}>{erro}</div>}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ ...caixa, padding: 10, display: "flex", justifyContent: "center", background: "#000" }}>
          <div style={{ position: "relative", height: "64vh", aspectRatio: "9 / 16", maxWidth: "100%", borderRadius: 10, overflow: "hidden", background: "#111" }}>
            {local && (local.tipo === "video"
              ? <>{inteiro && <video src={local.url} muted loop autoPlay playsInline style={fundo} />}<video src={local.url} muted loop autoPlay playsInline style={ajuste} /></>
              // eslint-disable-next-line @next/next/no-img-element
              : <>{inteiro && <img src={local.url} alt="" style={fundo} />}<img src={local.url} alt="" style={ajuste} /></>)}
            {!local && (
              <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", color: "var(--text-muted)", fontSize: 13, padding: 20 }}>
                {noAr ? `No ar: ${live?.arquivoNome}` : "A prévia aparece aqui depois de escolher o arquivo"}
              </div>
            )}
            <div style={{ position: "absolute", left: 8, bottom: 6, fontSize: 10, color: "rgba(255,255,255,.55)" }}>prévia aproximada</div>
          </div>
        </div>

        <div style={{ ...caixa, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, fontSize: 13 }}>
          <div><span style={rotulo}>Situação</span><b style={{ color: noAr ? "#E5484D" : "var(--text-secondary)" }}>{noAr ? "Transmitindo" : live ? "Encerrada" : "Pronto para começar"}</b></div>
          <div><span style={rotulo}>Tempo no ar</span><b>{live ? tempo(live.segundos) : "—"}</b></div>
          <div><span style={rotulo}>Programado</span><b>{live?.previsto ? tempo(Math.round(live.previsto)) : "—"}</b></div>
          <div><span style={rotulo}>Servidor</span><b>{live?.velocidade ? `${live.velocidade}${live.bitrate ? ` · ${live.bitrate}` : ""}` : noAr ? (live?.orfa ? "no ar" : "conectando…") : "—"}</b></div>
          {live && <div style={{ gridColumn: "1 / -1", color: "var(--text-muted)" }}>{live.arquivoNome} · {live.destinos.join(" + ")} · iniciada por {live.usuario}{!noAr && live.motivo ? ` · fim: ${live.motivo}` : ""}</div>}
          {!!live?.avisos?.length && <div style={{ gridColumn: "1 / -1", color: "var(--text-muted)", fontSize: 11.5, fontFamily: "monospace", whiteSpace: "pre-wrap" }}>{live.avisos.join("\n")}</div>}
        </div>

        <div style={{ ...caixa, fontSize: 13, lineHeight: 1.65, color: "var(--text-secondary)" }}>
          <b style={{ color: "var(--text-primary)" }}>Passo a passo</b>
          <ol style={{ margin: "6px 0 0 18px", padding: 0, listStyle: "decimal" }}>
            <li>{pastaFixa ? "Envie" : "Escolha o cliente e envie"} o vídeo ou a imagem. Espere ficar <b>Pronto ✓</b>.</li>
            <li>No instagram.com (conta do cliente): <b>Criar → Vídeo ao vivo</b>, título e público → copie a <b>chave de transmissão</b> e cole aqui.</li>
            <li>Clique <b>Iniciar transmissão</b>. Volte ao Instagram e, quando a prévia aparecer, clique <b>Entrar ao vivo</b>.</li>
            <li>A live roda na VPS: pode fechar esta página. Ela termina sozinha no tempo escolhido, ou em <b>Encerrar live</b> (aqui) e no Instagram.</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
