import { promises as fs } from "node:fs";
import path from "node:path";
import { auth } from "@/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { raizArquivos } from "@/lib/arquivos";
import { acessoLiberado } from "@/lib/acesso-cliente";
import { DASHBOARDS, dashboardPorPasta } from "@/lib/dashboards";

/** Só a equipe Mesa7 (login ativo, não cliente) transmite. */
export async function usuarioEquipe() {
  const session = await auth();
  if (!session?.user?.id) return null;
  const [u] = await db.select({ active: users.active, role: users.role, name: users.name }).from(users).where(eq(users.id, session.user.id)).limit(1);
  if (!u || !u.active || u.role === "client") return null;
  return u.name || "Equipe";
}

// Todos os clientes podem transmitir pelo próprio link; a equipe só marca quem fica de fora:
// <pasta de arquivos>/_acessos/live-bloqueados.json
const arqBloqueados = () => path.join(raizArquivos(), "_acessos", "live-bloqueados.json");

async function bloqueados(): Promise<string[]> {
  try {
    const l = JSON.parse(await fs.readFile(arqBloqueados(), "utf8"));
    return Array.isArray(l) ? l.filter((x) => typeof x === "string") : [];
  } catch {
    return [];
  }
}

export async function clientesLiberados(): Promise<string[]> {
  const b = new Set(await bloqueados());
  return DASHBOARDS.map((d) => d.pasta).filter((p) => !b.has(p));
}

export async function liberarCliente(pasta: string, ligado: boolean) {
  if (!dashboardPorPasta(pasta)) throw new Error("Cliente inválido.");
  const b = new Set(await bloqueados());
  if (ligado) b.delete(pasta); else b.add(pasta);
  await fs.mkdir(path.dirname(arqBloqueados()), { recursive: true });
  await fs.writeFile(arqBloqueados(), JSON.stringify([...b].sort(), null, 2), { mode: 0o600 });
}

export type Quem = { usuario: string; pastaFixa: string | null };

/** Quem está pedindo: a equipe (qualquer cliente) ou o cliente da pasta (senha dele + liberação da equipe). */
export async function quemTransmite(pastaCliente?: string): Promise<Quem | null> {
  if (!pastaCliente) {
    const u = await usuarioEquipe();
    return u ? { usuario: u, pastaFixa: null } : null;
  }
  const d = dashboardPorPasta(pastaCliente);
  if (!d || !(await acessoLiberado(d.pasta)) || !(await clientesLiberados()).includes(d.pasta)) return null;
  return { usuario: `Cliente ${d.nome}`, pastaFixa: d.pasta };
}
