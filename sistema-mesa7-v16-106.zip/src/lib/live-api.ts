// Regras da live compartilhadas pelas rotas da equipe (/api/live) e do cliente (/<cliente>/dashboard/live-api).
// Equipe transmite para qualquer cliente; o cliente só mexe na própria live e nos próprios arquivos.
import { NextResponse } from "next/server";
import { dashboardPorPasta } from "@/lib/dashboards";
import { encerrar, estado, ffmpegVersao, iniciar, liveAtiva, trocarLetreiro, arquivoEmUso, type Destino, type Modo } from "@/lib/live";
import { descartar, espacoLivreGB, lerArquivo, limparAntigos, receberPedaco, type Enquadramento } from "@/lib/live-arquivo";
import type { Quem } from "@/lib/live-acesso";

const MODOS: Modo[] = ["uma", "30", "60", "120", "max"];
const nega = () => NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
const dele = (q: Quem, usuarioDoItem: string | undefined) => !q.pastaFixa || usuarioDoItem === q.usuario;

export async function liveGet(req: Request, q: Quem | null) {
  if (!q) return nega();
  const p = new URL(req.url).searchParams;
  if (p.has("verificar")) {
    const [ff, gb] = [await ffmpegVersao(), await espacoLivreGB()];
    return NextResponse.json(q.pastaFixa ? { ffmpeg: ff ? "ok" : null, livreGB: null } : { ffmpeg: ff, livreGB: gb });
  }
  const id = p.get("id");
  const a = id ? null : liveAtiva();
  const s = id ? estado(id) : a ? estado(a.id) : null;
  if (s && q.pastaFixa && s.pasta !== q.pastaFixa) return NextResponse.json({ live: null, ocupada: true });
  return NextResponse.json({ live: s });
}

export async function livePost(req: Request, q: Quem | null) {
  if (!q) return nega();
  let b: { acao?: string; id?: string; pasta?: string; arquivo?: string; modo?: string; logo?: string | null; letreiro?: string; texto?: string; destinos?: Destino[] };
  try { b = await req.json(); } catch { return NextResponse.json({ erro: "Pedido inválido." }, { status: 400 }); }
  const minha = (id: string) => { const s = estado(id); return !!s && (!q.pastaFixa || s.pasta === q.pastaFixa); };
  try {
    if (b.acao === "encerrar" && b.id) return minha(b.id) ? NextResponse.json({ live: encerrar(b.id) }) : nega();
    if (b.acao === "letreiro" && b.id) return minha(b.id) ? NextResponse.json({ live: await trocarLetreiro(b.id, String(b.texto ?? "")) }) : nega();
    if (b.acao === "iniciar") {
      const pasta = q.pastaFixa ?? String(b.pasta || "");
      if (!dashboardPorPasta(pasta)) throw new Error("Escolha o cliente.");
      if (!(await ffmpegVersao())) {
        throw new Error(q.pastaFixa ? "A transmissão ainda não está disponível. Fale com a Mesa7." : "A VPS ainda não tem o ffmpeg (o programa que envia a live). A atualização automática instala sozinha em alguns minutos; se não instalar, rode no terminal da VPS: apt install -y ffmpeg");
      }
      const a = await lerArquivo(String(b.arquivo || ""));
      if (!a || !dele(q, a.usuario)) throw new Error("Envie o vídeo ou a imagem da live.");
      const modo = (MODOS.includes(b.modo as Modo) ? b.modo : "uma") as Modo;
      let logoPng: Buffer | null = null;
      if (b.logo) {
        const m = /^data:image\/png;base64,([A-Za-z0-9+/=]+)$/.exec(b.logo);
        const buf = m ? Buffer.from(m[1], "base64") : null;
        if (buf && buf.length < 600_000 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) logoPng = buf;
      }
      const destinos = (Array.isArray(b.destinos) ? b.destinos : [])
        .filter((d) => d && String(d.chave || "").trim())
        .slice(0, 3)
        .map((d) => ({ nome: String(d.nome || "Destino").slice(0, 30), servidor: String(d.servidor || ""), chave: String(d.chave || "") }));
      try {
        const id = await iniciar({ pasta, usuario: q.usuario, a, modo, logoPng, letreiro: String(b.letreiro ?? "").slice(0, 80), destinos });
        return NextResponse.json({ live: estado(id) });
      } catch (e) {
        // o cliente não precisa saber de quem é a outra live
        if (q.pastaFixa && e instanceof Error && e.message.startsWith("Já tem uma live no ar")) throw new Error("Já tem outra transmissão acontecendo agora. Tente de novo em alguns minutos.");
        throw e;
      }
    }
    return NextResponse.json({ erro: "Ação desconhecida." }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ erro: e instanceof Error ? e.message : String(e) }, { status: 400 });
  }
}

export async function arquivoPost(req: Request, q: Quem | null) {
  if (!q) return nega();
  const p = new URL(req.url).searchParams;
  const dados = Buffer.from(await req.arrayBuffer());
  if (dados.length > 8 * 1024 * 1024) return NextResponse.json({ erro: "Pedaço grande demais." }, { status: 413 });
  const enq = p.get("enquadramento");
  try {
    const pos = Number(p.get("pos"));
    const id = String(p.get("id") || "");
    if (q.pastaFixa && pos > 0) { const ex = await lerArquivo(id); if (ex && !dele(q, ex.usuario)) return nega(); }
    if (pos === 0) await limparAntigos(arquivoEmUso);
    const a = await receberPedaco({
      id, nome: String(p.get("nome") || ""), pos, total: Number(p.get("total")), fim: p.get("fim") === "1",
      enquadramento: (enq === "cobrir" || enq === "inteiro" ? enq : "auto") as Enquadramento, usuario: q.usuario, dados,
    });
    return NextResponse.json({ ok: true, arquivo: a });
  } catch (e) {
    return NextResponse.json({ erro: e instanceof Error ? e.message : String(e) }, { status: 409 });
  }
}

export async function arquivoGet(req: Request, q: Quem | null) {
  if (!q) return nega();
  const a = await lerArquivo(String(new URL(req.url).searchParams.get("id") || ""));
  return NextResponse.json({ arquivo: a && dele(q, a.usuario) ? a : null });
}

export async function arquivoDelete(req: Request, q: Quem | null) {
  if (!q) return nega();
  const id = String(new URL(req.url).searchParams.get("id") || "");
  const a = await lerArquivo(id);
  if (a && !dele(q, a.usuario)) return nega();
  if (arquivoEmUso(id)) return NextResponse.json({ erro: "Esse arquivo está no ar agora. Encerre a live antes." }, { status: 409 });
  await descartar(id);
  return NextResponse.json({ ok: true });
}
