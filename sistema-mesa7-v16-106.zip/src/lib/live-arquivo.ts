// Arquivo (vídeo ou imagem) que vai ao ar na live — enviado na hora pela página /live e
// apagado quando a live termina. Não existe biblioteca: nada fica guardado.
//
// O arquivo sobe em pedaços (se a internet cair, o pedaço é reenviado). Quando chega inteiro,
// a VPS confere o que é:
//  - imagem: vira um PNG 720x1280 (Stories 9:16), na hora;
//  - vídeo leve (até 1080p e 30 quadros): vai direto para a live, sem espera;
//  - vídeo pesado (4K, 60 quadros…): é convertido antes para 720x1280/30, com progresso,
//    porque a VPS (2 núcleos) não daria conta de converter isso em tempo real durante a live.
//
//   <ARQUIVOS_DIR>/_live/arquivos/<id>.json        dados do arquivo
//   <ARQUIVOS_DIR>/_live/arquivos/<id>.envio        o envio em andamento
//   <ARQUIVOS_DIR>/_live/arquivos/<id>.orig.<ext>   o arquivo enviado
//   <ARQUIVOS_DIR>/_live/arquivos/<id>.png|.mp4     a versão pronta (imagem / vídeo pesado)
import { execFile, spawn } from "node:child_process";
import { promises as fs } from "node:fs";
import path from "node:path";
import { raizArquivos } from "@/lib/arquivos";

export type Enquadramento = "auto" | "cobrir" | "inteiro";
export type ArquivoLive = {
  id: string;
  nome: string;
  tipo: "video" | "imagem";
  tamanho: number;
  enviadoEm: string;
  usuario: string;
  enquadramento: Enquadramento;
  estado: "enviando" | "analisando" | "preparando" | "pronto" | "erro";
  progresso: number;
  largura: number | null;
  altura: number | null;
  duracao: number | null;
  temAudio: boolean;
  /** Arquivo que a live toca e se ele já está em 720x1280 (preparado) ou precisa ser ajustado ao vivo. */
  arquivo: string | null;
  preparado: boolean;
  erro: string | null;
};

export const LIMITE_GB = 3;
const VIDEO = [".mp4", ".mov", ".m4v", ".webm", ".mkv"];
const IMAGEM = [".jpg", ".jpeg", ".png", ".webp"];
export const EXTENSOES_LIVE = [...VIDEO, ...IMAGEM];
const ID = /^[a-z0-9]{12,40}$/;
const W = 720, H = 1280;
const VALIDADE_MS = 12 * 3600_000;   // arquivo que não foi ao ar some depois de 12 h

const dir = () => path.join(raizArquivos(), "_live", "arquivos");
const f = (nome: string) => path.join(dir(), nome);

export async function lerArquivo(id: string): Promise<ArquivoLive | null> {
  if (!ID.test(id)) return null;
  try { return JSON.parse(await fs.readFile(f(`${id}.json`), "utf8")) as ArquivoLive; } catch { return null; }
}
async function gravar(a: ArquivoLive) {
  const alvo = f(`${a.id}.json`);
  await fs.writeFile(alvo + ".tmp", JSON.stringify(a));
  await fs.rename(alvo + ".tmp", alvo);
}
async function mudar(id: string, m: Partial<ArquivoLive>) {
  const a = await lerArquivo(id);
  if (!a) return null;
  Object.assign(a, m);
  await gravar(a);
  return a;
}

/** Apaga o arquivo da live (todas as versões). */
export async function descartar(id: string) {
  if (!ID.test(id)) return;
  for (const n of await fs.readdir(dir()).catch(() => [] as string[])) if (n.startsWith(`${id}.`)) await fs.rm(f(n), { force: true });
}

/** Apaga o que ficou para trás (envios abandonados, lives que não aconteceram). */
export async function limparAntigos(emUso: (id: string) => boolean) {
  const agora = Date.now();
  for (const n of await fs.readdir(dir()).catch(() => [] as string[])) {
    const id = n.split(".")[0];
    if (emUso(id)) continue;
    const st = await fs.stat(f(n)).catch(() => null);
    if (st && agora - st.mtimeMs > VALIDADE_MS) await fs.rm(f(n), { force: true });
  }
}

export async function espacoLivreGB() {
  try {
    await fs.mkdir(dir(), { recursive: true });
    const s = await fs.statfs(dir());
    return +((s.bavail * s.bsize) / 1073741824).toFixed(1);
  } catch { return null; }
}

/**
 * Recebe um pedaço do envio. `pos` = byte onde o pedaço começa (reenvio do mesmo pedaço é aceito).
 * No último pedaço (`fim`), começa a análise/preparação e devolve os dados do arquivo.
 */
export async function receberPedaco(o: {
  id: string; nome: string; pos: number; total: number; fim: boolean;
  enquadramento: Enquadramento; usuario: string; dados: Buffer;
}) {
  const ext = path.extname(o.nome).toLowerCase();
  if (!EXTENSOES_LIVE.includes(ext)) throw new Error(`Formato não aceito (${ext || "sem extensão"}). Use vídeo MP4/MOV ou imagem JPG/PNG.`);
  if (!ID.test(o.id)) throw new Error("Envio inválido.");
  if (!(o.total > 0) || o.total > LIMITE_GB * 1073741824) throw new Error(`Arquivo maior que ${LIMITE_GB} GB.`);
  await fs.mkdir(dir(), { recursive: true });
  const envio = f(`${o.id}.envio`);
  if (o.pos === 0) {
    const livre = await espacoLivreGB();
    if (livre !== null && livre < (o.total / 1073741824) * 2.2 + 2) throw new Error(`Pouco espaço livre na VPS (${livre} GB).`);
    await fs.writeFile(envio, "");
  }
  const atual = (await fs.stat(envio).catch(() => null))?.size;
  if (atual === undefined) throw new Error("Envio não encontrado. Escolha o arquivo de novo.");
  if (atual === o.pos + o.dados.length) { /* pedaço repetido (reenvio): já está gravado */ }
  else if (atual !== o.pos) throw new Error(`Pedaço fora de ordem (o servidor tem ${atual} bytes).`);
  else await fs.appendFile(envio, o.dados);
  if (!o.fim) return null;

  const tam = (await fs.stat(envio)).size;
  if (tam !== o.total) throw new Error(`O arquivo chegou incompleto (${tam} de ${o.total} bytes).`);
  const original = `${o.id}.orig${ext}`;
  await fs.rename(envio, f(original));
  const a: ArquivoLive = {
    id: o.id, nome: path.basename(o.nome).slice(0, 120), tipo: VIDEO.includes(ext) ? "video" : "imagem", tamanho: tam,
    enviadoEm: new Date().toISOString(), usuario: o.usuario, enquadramento: o.enquadramento,
    estado: "analisando", progresso: 0, largura: null, altura: null, duracao: null, temAudio: false,
    arquivo: null, preparado: false, erro: null,
  };
  await gravar(a);
  void analisar(a.id, f(original)).catch(async (e) => { await mudar(a.id, { estado: "erro", erro: (e instanceof Error ? e.message : String(e)).slice(0, 400) }); });
  return a;
}

type Sonda = { largura: number; altura: number; fps: number; duracao: number | null; temAudio: boolean };
function sondar(arquivo: string): Promise<Sonda> {
  return new Promise((ok, falha) => {
    execFile("ffprobe", ["-v", "error", "-print_format", "json", "-show_streams", "-show_format", arquivo], { timeout: 30_000, maxBuffer: 4 << 20 }, (err, saida) => {
      if (err) return falha(new Error("Não consegui abrir o arquivo (corrompido ou num formato que a VPS não lê)."));
      try {
        const j = JSON.parse(String(saida)) as { streams?: Record<string, unknown>[]; format?: { duration?: string } };
        const v = (j.streams || []).find((s) => s.codec_type === "video");
        if (!v) return falha(new Error("O arquivo não tem imagem de vídeo."));
        let w = Number(v.width) || 0, h = Number(v.height) || 0;
        const rot = Number((v.tags as Record<string, string> | undefined)?.rotate ?? ((v.side_data_list as { rotation?: number }[] | undefined) || []).find((s) => s.rotation !== undefined)?.rotation ?? 0);
        if (Math.abs(rot) % 180 === 90) [w, h] = [h, w];
        const [n, d] = String(v.avg_frame_rate || v.r_frame_rate || "30/1").split("/").map(Number);
        const dur = Number(j.format?.duration);
        ok({ largura: w, altura: h, fps: d ? n / d : n || 30, duracao: Number.isFinite(dur) && dur > 0 ? dur : null, temAudio: (j.streams || []).some((s) => s.codec_type === "audio") });
      } catch { falha(new Error("Não consegui ler o arquivo.")); }
    });
  });
}

/**
 * Filtro que leva qualquer imagem/vídeo a 720x1280 (Stories 9:16).
 * "cobrir" enche a tela cortando as sobras; "inteiro" mostra tudo sobre um fundo desfocado;
 * "auto" corta se o arquivo já é quase vertical e usa o fundo desfocado nos demais.
 */
export function filtroEnquadramento(modo: Enquadramento, largura: number, altura: number, entrada: string, saida: string) {
  const r = largura / Math.max(1, altura);
  const m = modo === "auto" ? (r >= 0.5 && r <= 0.65 ? "cobrir" : "inteiro") : modo;
  if (m === "cobrir") return `${entrada}scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},setsar=1${saida}`;
  return `${entrada}split=2[ea][eb];[ea]scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},boxblur=luma_radius=28:luma_power=2,eq=brightness=-0.08[ef];` +
    `[eb]scale=${W}:${H}:force_original_aspect_ratio=decrease[eg];[ef][eg]overlay=(W-w)/2:(H-h)/2,setsar=1${saida}`;
}

function ffmpeg(args: string[], aoProgresso?: (seg: number) => void): Promise<void> {
  return new Promise((ok, falha) => {
    const ff = spawn("nice", ["-n", "15", "ffmpeg", "-hide_banner", "-nostdin", "-y", ...args], { stdio: ["ignore", "pipe", "pipe"] });
    let erro = "";
    ff.stdout.setEncoding("utf8");
    ff.stdout.on("data", (t: string) => { const m = /out_time_(?:us|ms)=(\d+)/g; let x, ult = null; while ((x = m.exec(t))) ult = x[1]; if (ult && aoProgresso) aoProgresso(Number(ult) / 1e6); });
    ff.stderr.setEncoding("utf8");
    ff.stderr.on("data", (t: string) => { erro = (erro + t).slice(-1500); });
    ff.on("error", (e) => falha(new Error(`ffmpeg não disponível na VPS (${e.message}).`)));
    ff.on("close", (c) => (c === 0 ? ok() : falha(new Error(`Falhou ao converter: ${erro.trim().split("\n").slice(-2).join(" ").slice(0, 300)}`))));
  });
}

async function analisar(id: string, original: string) {
  const a = await lerArquivo(id);
  if (!a) return;
  const s = await sondar(original);
  await mudar(id, { largura: s.largura, altura: s.altura, duracao: s.duracao ? Math.round(s.duracao) : null, temAudio: s.temAudio });
  if (a.tipo === "imagem") {
    const pronto = `${id}.png`;
    await ffmpeg(["-i", original, "-filter_complex", filtroEnquadramento(a.enquadramento, s.largura, s.altura, "[0:v]", "[v]"), "-map", "[v]", "-frames:v", "1", f(pronto)]);
    await fs.rm(original, { force: true });
    await mudar(id, { estado: "pronto", progresso: 100, arquivo: pronto, preparado: true });
    return;
  }
  const pesado = Math.max(s.largura, s.altura) > 1920 || s.fps > 31;
  if (!pesado) { await mudar(id, { estado: "pronto", progresso: 100, arquivo: path.basename(original), preparado: false }); return; }

  // vídeo pesado: converte antes para 720x1280/30 (a live só toca o pronto)
  await mudar(id, { estado: "preparando", progresso: 0 });
  const pronto = `${id}.mp4`, tmp = f(`${id}.convertendo.mp4`);
  let ultimo = 0;
  try {
    await ffmpeg([
      "-i", original, ...(s.temAudio ? [] : ["-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo"]),
      "-filter_complex", filtroEnquadramento(a.enquadramento, s.largura, s.altura, "[0:v]", ",fps=30,format=yuv420p[v]"),
      "-map", "[v]", ...(s.temAudio ? ["-map", "0:a:0"] : ["-map", "1:a", "-shortest"]),
      "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-maxrate", "2500k", "-bufsize", "5000k", "-profile:v", "main", "-pix_fmt", "yuv420p",
      "-g", "60", "-keyint_min", "60", "-sc_threshold", "0", "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
      "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", tmp,
    ], (seg) => {
      const p = s.duracao ? Math.min(99, Math.round((seg / s.duracao) * 100)) : 0;
      if (p >= ultimo + 2) { ultimo = p; void mudar(id, { progresso: p }); }
    });
  } catch (e) { await fs.rm(tmp, { force: true }); throw e; }
  await fs.rename(tmp, f(pronto));
  await fs.rm(original, { force: true });
  await mudar(id, { estado: "pronto", progresso: 100, arquivo: pronto, preparado: true, temAudio: true });
}

/** Caminho completo do arquivo que a live vai tocar (só quando está pronto). */
export function caminho(a: ArquivoLive) {
  return a.arquivo ? f(a.arquivo) : null;
}
