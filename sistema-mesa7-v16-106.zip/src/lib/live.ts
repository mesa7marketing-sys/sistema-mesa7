// Live no Instagram (e Facebook) pelo painel da Mesa7, com um vídeo ou imagem enviado na hora
// (src/lib/live-arquivo.ts) — sem câmera e sem microfone.
//
// A VPS toca o arquivo em tempo real, ajusta para Stories 9:16 (720x1280), põe por cima o logo
// do cliente e o letreiro, converte para o que o Instagram pede (H.264, quadro-chave a cada 2 s,
// AAC 44,1 kHz) e envia por RTMPS para o servidor + chave de transmissão que o Instagram gerou
// (instagram.com → Criar → Vídeo ao vivo). O navegador só manda "iniciar"/"encerrar": a live
// continua mesmo com o computador desligado. O Instagram não deixa abrir a live por API: a chave
// muda a cada live e alguém clica "Entrar ao vivo" no instagram.com quando a prévia aparece.
//
// Uma live por vez. Enquanto houver live no ar, o arquivo .live-no-ar na raiz do app é tocado a
// cada 5 s e a atualização automática (deploy/atualizar.sh) espera ela acabar. Quando a live
// termina, o arquivo enviado é apagado (se ela caiu logo no começo, fica para tentar de novo).
import { execFile, spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { promises as fs, existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { raizArquivos } from "@/lib/arquivos";
import { caminho, descartar, filtroEnquadramento, type ArquivoLive } from "@/lib/live-arquivo";

export type Destino = { nome: string; servidor: string; chave: string };
/** "uma" = toca o vídeo uma vez; número = minutos (repete o vídeo / mostra a imagem); "max" = até encerrar (máx. 4 h). */
export type Modo = "uma" | "30" | "60" | "120" | "max";

type Sessao = {
  id: string;
  pasta: string;
  arquivoId: string;
  arquivoNome: string;
  tipo: "video" | "imagem";
  usuario: string;
  destinos: string[];        // só os nomes (a chave nunca sai daqui)
  segredos: string[];        // chaves, para apagar dos registros do ffmpeg
  ff: ChildProcessWithoutNullStreams | null;
  pid: number | null;
  inicio: number;
  fim: number | null;
  previsto: number | null;   // segundos previstos de transmissão
  progresso: string;         // última linha "frame= … time= … speed=" do ffmpeg
  avisos: string[];
  letreiro: string;
  encerrada: boolean;
  motivo?: string;
  orfa?: boolean;
};

const MAX_SEG = 4 * 3600;   // a live do Instagram vai até 4 h
const g = globalThis as unknown as { __m7lives?: Map<string, Sessao>; __m7liveTimer?: NodeJS.Timeout };
const LIVES = (g.__m7lives ??= new Map());
const MARCA = path.join(/*turbopackIgnore: true*/ process.cwd(), ".live-no-ar");
const FONTE = path.join(/*turbopackIgnore: true*/ process.cwd(), "src", "assets", "fontes", "Poppins-Bold.ttf");
const dirLive = () => path.join(raizArquivos(), "_live");

let cacheFfmpeg: { v: string | null; em: number } | null = null;

/** Versão do ffmpeg instalado na VPS (null = não instalado). Guarda o resultado por um tempo. */
export function ffmpegVersao(): Promise<string | null> {
  if (cacheFfmpeg && Date.now() - cacheFfmpeg.em < (cacheFfmpeg.v ? 10 * 60_000 : 15_000)) return Promise.resolve(cacheFfmpeg.v);
  return new Promise((ok) => {
    execFile("ffmpeg", ["-hide_banner", "-version"], { timeout: 5_000 }, (err, saida) => {
      const v = err ? null : (/ffmpeg version (\S+)/.exec(String(saida))?.[1] ?? "instalado");
      cacheFfmpeg = { v, em: Date.now() };
      ok(v);
    });
  });
}

/** Monta a URL completa de envio. Aceita só rtmp:// e rtmps://. */
export function urlDestino(d: Destino): string {
  const servidor = d.servidor.trim(), chave = d.chave.trim();
  if (!/^rtmps?:\/\/[^\s/]+(\/\S*)?$/i.test(servidor)) throw new Error(`Servidor de ${d.nome} inválido: precisa começar com rtmps://`);
  if (!chave || /\s/.test(chave)) throw new Error(`Chave de transmissão de ${d.nome} vazia ou com espaço.`);
  return servidor.replace(/\/+$/, "") + "/" + chave;
}

function limpar(s: string, segredos: string[]) {
  let t = s;
  for (const k of segredos) if (k) t = t.split(k).join("***");
  return t;
}

/** Letreiro em até 2 linhas de ~28 letras (o drawtext do ffmpeg não quebra linha sozinho). */
export function quebrarLetreiro(texto: string) {
  const palavras = texto.replace(/\s+/g, " ").trim().split(" ").filter(Boolean);
  const linhas: string[] = [];
  let atual = "";
  for (const p of palavras) {
    if (!atual) atual = p;
    else if ((atual + " " + p).length <= 28) atual += " " + p;
    else { linhas.push(atual); atual = p; }
  }
  if (atual) linhas.push(atual);
  if (linhas.length > 2) { linhas.length = 2; linhas[1] = linhas[1].slice(0, 27) + "…"; }
  return linhas.map((l) => (l.length > 30 ? l.slice(0, 29) + "…" : l)).join("\n");
}

async function gravarLetreiro(texto: string) {
  const f = path.join(dirLive(), "letreiro.txt"), tmp = f + ".tmp";
  await fs.writeFile(tmp, quebrarLetreiro(texto));
  await fs.rename(tmp, f);   // troca atômica: o ffmpeg relê o arquivo a cada quadro
}

function argsFfmpeg(o: { a: ArquivoLive; arquivo: string; repetir: boolean; segundos: number; logo: string | null; urls: string[] }) {
  const video = o.a.tipo === "video";
  const silencio = !video || !o.a.temAudio;
  const entrada = video
    ? ["-re", "-stream_loop", o.repetir ? "-1" : "0", "-i", o.arquivo]
    : ["-re", "-loop", "1", "-framerate", "30", "-i", o.arquivo];
  const iLogo = silencio ? 2 : 1;
  const q = (p: string) => `'${p.replace(/'/g, "")}'`;
  const fonte = existsSync(FONTE) ? `fontfile=${q(FONTE)}:` : "";
  const base = o.a.preparado
    ? `[0:v]fps=30,format=yuv420p[b0]`   // já está em 720x1280
    : filtroEnquadramento(o.a.enquadramento, o.a.largura ?? 720, o.a.altura ?? 1280, "[0:v]", ",fps=30,format=yuv420p[b0]");
  const filtros = [
    base,
    o.logo ? `[b0][${iLogo}:v]overlay=x=W-w-28:y=150[b1]` : `[b0]null[b1]`,
    `[b1]drawtext=${fonte}textfile=${q(path.join(dirLive(), "letreiro.txt"))}:reload=1:expansion=none:fontsize=34:fontcolor=0xF4F2EA:line_spacing=10:` +
      `box=1:boxcolor=0x0D0D10@0.88:boxborderw=22:x=40:y=h*0.62-th,format=yuv420p[v]`,
  ].join(";");
  const saida = o.urls.length === 1
    ? ["-f", "flv", o.urls[0]]
    : ["-f", "tee", o.urls.map((u) => `[f=flv:onfail=ignore]${u.replace(/([\\|[\]])/g, "\\$1")}`).join("|")];
  return [
    "-hide_banner", "-loglevel", "warning", "-stats",
    ...entrada, ...(silencio ? ["-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo"] : []), ...(o.logo ? ["-i", o.logo] : []),
    "-filter_complex", filtros, "-map", "[v]", "-map", silencio ? "1:a:0" : "0:a:0",
    "-c:v", "libx264", "-preset", "veryfast", "-tune", "zerolatency", "-profile:v", "main", "-pix_fmt", "yuv420p",
    "-r", "30", "-g", "60", "-keyint_min", "60", "-sc_threshold", "0",
    "-b:v", "2500k", "-maxrate", "2500k", "-bufsize", "5000k",
    "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
    "-t", String(o.segundos),
    ...saida,
  ];
}

async function tocarMarca() {
  try { await fs.writeFile(MARCA, new Date().toISOString()); } catch { /* sem permissão: segue sem a marca */ }
}

function vigiar() {
  if (g.__m7liveTimer) return;
  g.__m7liveTimer = setInterval(() => {
    if (liveAtiva()) void tocarMarca();
    else fs.rm(MARCA, { force: true }).catch(() => {});
    for (const s of LIVES.values()) if (s.encerrada && s.fim && Date.now() - s.fim > 15 * 60_000) LIVES.delete(s.id);
  }, 5_000);
  g.__m7liveTimer.unref?.();
}

function processoVivo(pid: number | null) {
  if (!pid) return false;
  try { process.kill(pid, 0); return true; } catch { return false; }
}

/** Live que ficou no ar de um processo anterior do sistema (reinício no meio da live). */
function orfa(): Sessao | null {
  try {
    const a = JSON.parse(readFileSync(path.join(dirLive(), "ativa.json"), "utf8")) as Partial<Sessao> & { pid: number };
    if (!a.pid || [...LIVES.values()].some((s) => s.pid === a.pid)) return null;
    if (!readFileSync(`/proc/${a.pid}/cmdline`, "utf8").includes("ffmpeg")) return null;
    const s: Sessao = {
      id: a.id || randomUUID(), pasta: a.pasta || "", arquivoId: a.arquivoId || "", arquivoNome: a.arquivoNome || "", tipo: a.tipo || "video",
      usuario: a.usuario || "", destinos: a.destinos || [], segredos: [], ff: null, pid: a.pid, inicio: a.inicio || Date.now(), fim: null,
      previsto: a.previsto ?? null, progresso: "", avisos: [], letreiro: a.letreiro || "", encerrada: false, orfa: true,
    };
    LIVES.set(s.id, s);
    return s;
  } catch { return null; }
}

export function liveAtiva(): Sessao | null {
  for (const s of LIVES.values()) {
    if (s.encerrada) continue;
    if (s.orfa && !processoVivo(s.pid)) { s.encerrada = true; s.fim = Date.now(); s.motivo = "a transmissão terminou"; continue; }
    return s;
  }
  return orfa();
}

/** O arquivo está sendo transmitido agora (não pode ser apagado). */
export function arquivoEmUso(id: string) {
  return liveAtiva()?.arquivoId === id;
}

export async function iniciar(o: {
  pasta: string; usuario: string; a: ArquivoLive; modo: Modo;
  logoPng: Buffer | null; letreiro: string; destinos: Destino[];
}) {
  const ativa = liveAtiva();
  if (ativa) throw new Error(`Já tem uma live no ar (${ativa.pasta}, por ${ativa.usuario}). Encerre antes de começar outra.`);
  if (!o.destinos.length) throw new Error("Cole a chave de transmissão do Instagram.");
  const arquivo = caminho(o.a);
  if (o.a.estado !== "pronto" || !arquivo || !existsSync(arquivo)) throw new Error("O arquivo ainda não está pronto (ou foi apagado). Envie de novo.");
  const urls = o.destinos.map(urlDestino);
  const segredos = o.destinos.map((d) => d.chave.trim());
  const modo: Modo = o.a.tipo === "imagem" && o.modo === "uma" ? "max" : o.modo;
  const repetir = o.a.tipo === "video" && modo !== "uma";
  const segundos = modo === "uma" ? Math.min(MAX_SEG, (o.a.duracao ?? MAX_SEG) + 5) : modo === "max" ? MAX_SEG : Number(modo) * 60;

  await fs.mkdir(dirLive(), { recursive: true });
  await gravarLetreiro(o.letreiro);
  const logo = o.logoPng ? path.join(dirLive(), "logo.png") : null;
  if (logo && o.logoPng) await fs.writeFile(logo, o.logoPng);

  const ff = spawn("ffmpeg", argsFfmpeg({ a: o.a, arquivo, repetir, segundos, logo, urls }), { stdio: ["pipe", "pipe", "pipe"] });
  const s: Sessao = {
    id: randomUUID(), pasta: o.pasta, arquivoId: o.a.id, arquivoNome: o.a.nome, tipo: o.a.tipo, usuario: o.usuario,
    destinos: o.destinos.map((d) => d.nome), segredos, ff, pid: ff.pid ?? null, inicio: Date.now(), fim: null,
    previsto: modo === "uma" ? o.a.duracao : segundos, progresso: "", avisos: [], letreiro: o.letreiro, encerrada: false,
  };
  let resto = "";
  ff.stderr.setEncoding("utf8");
  ff.stderr.on("data", (txt: string) => {
    const linhas = (resto + txt).split(/[\r\n]+/);
    resto = linhas.pop() ?? "";
    for (const l of linhas) {
      if (!l.trim()) continue;
      if (/^frame=/.test(l.trim())) s.progresso = l.trim();
      else { s.avisos.push(limpar(l.trim(), segredos).slice(0, 300)); if (s.avisos.length > 12) s.avisos.shift(); }
    }
  });
  ff.stdin.on("error", () => { /* ffmpeg já fechou */ });
  ff.on("error", (e) => { s.avisos.push(`Não consegui iniciar o ffmpeg: ${e.message}`); });
  ff.on("close", (codigo, sinal) => {
    const pelaPainel = s.encerrada;
    if (!s.encerrada) {
      s.encerrada = true;
      s.motivo = codigo === 0
        ? (modo === "uma" ? "o vídeo terminou" : "o tempo programado terminou")
        : Date.now() - s.inicio < 30_000
          ? "não consegui conectar no Instagram — confira a chave de transmissão (ela muda a cada live) e o servidor"
          : `a transmissão caiu (${sinal ? `sinal ${sinal}` : `código ${codigo}`}) — se a live foi encerrada no Instagram, é normal`;
    }
    s.fim = Date.now();
    fs.rm(path.join(dirLive(), "ativa.json"), { force: true }).catch(() => {});
    if (!liveAtiva()) fs.rm(MARCA, { force: true }).catch(() => {});
    // o arquivo não fica guardado: apaga ao fim da live (se caiu nos 2 primeiros minutos, fica para tentar de novo)
    if (pelaPainel || codigo === 0 || s.fim - s.inicio > 120_000) void descartar(s.arquivoId);
  });
  LIVES.set(s.id, s);
  vigiar();
  void tocarMarca();
  await fs.writeFile(path.join(dirLive(), "ativa.json"), JSON.stringify({
    id: s.id, pid: s.pid, pasta: s.pasta, arquivoId: s.arquivoId, arquivoNome: s.arquivoNome, tipo: s.tipo, usuario: s.usuario,
    destinos: s.destinos, inicio: s.inicio, previsto: s.previsto, letreiro: s.letreiro,
  })).catch(() => {});
  return s.id;
}

export async function trocarLetreiro(id: string, texto: string) {
  const s = LIVES.get(id);
  if (!s || s.encerrada) throw new Error("A live não está no ar.");
  s.letreiro = texto.slice(0, 80);
  await gravarLetreiro(s.letreiro);
  return estado(id);
}

export function encerrar(id: string, motivo = "encerrada pelo painel") {
  const s = LIVES.get(id);
  if (!s) return null;
  if (!s.encerrada) {
    s.encerrada = true;
    s.motivo = motivo;
    s.fim = Date.now();
    if (s.ff) {
      try { s.ff.stdin.write("q"); } catch { /* já fechado */ }   // "q": o ffmpeg fecha a transmissão direito
      const ff = s.ff;
      setTimeout(() => { if (ff.exitCode === null) ff.kill("SIGTERM"); }, 5_000).unref?.();
      setTimeout(() => { if (ff.exitCode === null) ff.kill("SIGKILL"); }, 12_000).unref?.();
    } else if (s.pid) {
      try { process.kill(s.pid, "SIGTERM"); } catch { /* já saiu */ }
      fs.rm(path.join(dirLive(), "ativa.json"), { force: true }).catch(() => {});
      void descartar(s.arquivoId);
    }
  }
  return estado(id);
}

export function estado(id: string) {
  const s = LIVES.get(id);
  if (!s) return null;
  const pega = (re: RegExp) => re.exec(s.progresso)?.[1] ?? null;
  const t = pega(/time=\s*(\d+:\d+:\d+(?:\.\d+)?)/);
  const transmitido = t ? t.split(":").reduce((a, x) => a * 60 + Number(x), 0) : null;
  return {
    id: s.id, pasta: s.pasta, arquivoId: s.arquivoId, arquivoNome: s.arquivoNome, tipo: s.tipo, destinos: s.destinos, usuario: s.usuario,
    noAr: !s.encerrada, orfa: !!s.orfa,
    segundos: Math.round(((s.fim ?? Date.now()) - s.inicio) / 1000),
    transmitido: transmitido !== null ? Math.round(transmitido) : null, previsto: s.previsto,
    velocidade: pega(/speed=\s*([\d.]+x)/), bitrate: pega(/bitrate=\s*([\d.]+\s*kbits\/s)/),
    letreiro: s.letreiro, avisos: s.avisos.slice(-5), motivo: s.motivo ?? null,
  };
}
