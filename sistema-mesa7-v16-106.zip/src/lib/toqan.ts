// Acesso do Toqan (assistente de IA) aos dados dos clientes, só leitura: GET /api/toqan com
// "Authorization: Bearer <token>". O token é um só da Mesa7, criado no servidor na primeira vez
// que a equipe abre a tela Toqan e guardado em <pasta de arquivos>/_acessos/toqan-token.txt —
// fora do código e do GitHub. Gerar um novo na tela derruba o anterior.
import { promises as fs } from "node:fs";
import path from "node:path";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { raizArquivos } from "@/lib/arquivos";

const arq = () => path.join(raizArquivos(), "_acessos", "toqan-token.txt");

async function ler() {
  try {
    return (await fs.readFile(arq(), "utf8")).trim() || null;
  } catch {
    return null;
  }
}

async function gravar(t: string) {
  await fs.mkdir(path.dirname(arq()), { recursive: true });
  await fs.writeFile(arq(), t + "\n", { mode: 0o600 });
}

/** Token atual (cria um, se ainda não existir) — só para a tela da equipe. */
export async function tokenToqan() {
  const atual = await ler();
  if (atual) return atual;
  const novo = "m7t_" + randomBytes(24).toString("hex");
  await gravar(novo);
  return novo;
}

export async function novoTokenToqan() {
  const novo = "m7t_" + randomBytes(24).toString("hex");
  await gravar(novo);
  return novo;
}

const h = (s: string) => createHash("sha256").update(s).digest();

/** O pedido traz o token certo? (nada de token criado ainda = ninguém entra) */
export async function pedidoAutorizado(req: Request) {
  const t = await ler();
  const dado = /^Bearer\s+(\S+)$/i.exec(req.headers.get("authorization") || "")?.[1];
  return !!t && !!dado && timingSafeEqual(h(t), h(dado));
}
