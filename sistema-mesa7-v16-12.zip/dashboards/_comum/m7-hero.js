/* =========================================================
   Destaque do Resumo Executivo (faturamento gigante + pílulas + gráfico),
   no padrão testado no La Pizza D'Caio, para os dashboards completos.
   Não mexe nos cálculos de cada dashboard: lê o que a página já mostra
   (#k1Fat, os cards de KPI, o filtro e o gráfico "Evolução de Faturamento")
   e monta o bloco por cima. Se o dashboard já tem .hero próprio, não faz nada.
   ========================================================= */
(function () {
  var brl = function (v) { return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var dec = function (v) { return (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var $ = function (id) { return document.getElementById(id); };
  var hero, cFat, stats = [], chart = null;

  function lista() { try { return (typeof MESES !== 'undefined' && MESES) || []; } catch (e) { return []; } }

  function investimento(periodo) {
    var ms = lista(), D = (window.M7_DADOS && window.M7_DADOS.meta) || {};
    var ids = periodo && /^\d{4}-\d{2}$/.test(periodo) ? [periodo] : ms.map(function (m) { return m.id; });
    var g = 0, f = 0, n = 0;
    ids.forEach(function (id) {
      var m = ms.filter(function (x) { return x.id === id; })[0];
      var mt = (m && m.meta) || D[id];
      if (mt && mt.gas) { g += mt.gas; f += mt.fat || 0; n++; }
    });
    return n ? { gas: g, fat: f } : null;
  }

  function montar() {
    var p1 = $('p1'), kf = $('k1Fat');
    if (!p1 || !kf || p1.querySelector('.hero')) return false;
    cFat = kf.closest('.kpi-card');
    var cards = Array.prototype.slice.call(p1.querySelectorAll('.kpi-grid .kpi-card')).filter(function (c) { return c !== cFat; });
    var pref = cards.filter(function (c) { return c.querySelector('#k1Ped,#k1Pess,#k1Tkt'); });
    stats = (pref.length >= 2 ? pref : cards).slice(0, 2);

    var sel = $('selCanal');
    var pills = sel ? Array.prototype.slice.call(sel.options).map(function (o, i) {
      var t = i === 0 ? 'Todos' : o.textContent;
      return '<button class="hero-pill" data-c="' + esc(o.value) + '">' + esc(t) + '</button>';
    }).join('') : '';

    hero = document.createElement('section');
    hero.className = 'hero';
    hero.setAttribute('aria-label', 'Faturamento do período');
    hero.innerHTML =
      (pills ? '<div class="hero-pills" role="group" aria-label="Tipo de pedido">' + pills + '</div>' : '') +
      '<div class="hero-label" data-h="lbl">Faturamento</div>' +
      '<div class="hero-value" data-h="fat">—</div>' +
      '<div class="hero-meta"><span data-h="per">—</span><span class="hero-delta flat" data-h="delta">—</span></div>' +
      '<div class="hero-spark" aria-hidden="true"><canvas></canvas></div>' +
      '<div class="hero-stats" data-h="stats"></div>';
    var chip = p1.querySelector(':scope > .filter-chip');
    p1.insertBefore(hero, chip ? chip.nextSibling : p1.firstChild);
    p1.classList.add('m7-hero-on');
    cFat.classList.add('hero-dup');
    stats.forEach(function (c) { c.classList.add('hero-dup'); });

    Array.prototype.slice.call(hero.querySelectorAll('.hero-pill')).forEach(function (b) {
      b.addEventListener('click', function () { sel.value = b.getAttribute('data-c'); sel.dispatchEvent(new Event('change')); });
    });
    return true;
  }

  function txt(el) { return el ? (el.textContent || '').trim() : ''; }

  function atualizar() {
    if (!hero) return;
    var q = function (k) { return hero.querySelector('[data-h="' + k + '"]'); };
    var sel = $('selCanal'), per = $('selPeriodo');
    var canalTxt = sel && sel.selectedIndex > 0 ? sel.options[sel.selectedIndex].textContent : '';
    Array.prototype.slice.call(hero.querySelectorAll('.hero-pill')).forEach(function (b) { b.classList.toggle('on', sel && b.getAttribute('data-c') === sel.value); });
    q('lbl').textContent = 'Faturamento' + (canalTxt ? ' · ' + canalTxt : '');

    var v = txt($('k1Fat'));
    q('fat').innerHTML = /^R\$\s*/.test(v) ? '<small>R$</small>' + esc(v.replace(/^R\$\s*/, '')) : esc(v);
    q('per').textContent = per && per.selectedIndex >= 0 ? per.options[per.selectedIndex].textContent : '';

    var sub = $('k1FatSub'), d = q('delta'), st = sub ? sub.className : '';
    var t = txt(sub);
    d.className = 'hero-delta ' + (/\bdown\b/.test(st) ? 'down' : /\bup\b/.test(st) ? '' : 'flat');
    d.innerHTML = (/\bup\b/.test(st) ? '<i class="fa-solid fa-arrow-trend-up"></i> ' : /\bdown\b/.test(st) ? '<i class="fa-solid fa-arrow-trend-down"></i> ' : '') + esc(t || '—');

    var html = stats.map(function (c) {
      var s = c.querySelector('.kpi-sub');
      var cls = s && /\bup\b/.test(s.className) ? ' up' : s && /\bdown\b/.test(s.className) ? ' down' : '';
      return '<div class="hero-stat"><div class="l">' + esc(txt(c.querySelector('.kpi-label'))) + '</div><div class="v">' + esc(txt(c.querySelector('.kpi-value'))) + '</div><div class="d' + cls + '">' + esc(txt(s)) + '</div></div>';
    });
    var inv = investimento(per ? per.value : null);
    if (inv) html.push('<div class="hero-stat"><div class="l">Investimento em mídia</div><div class="v">' + brl(inv.gas) + '</div><div class="d">' + (inv.fat ? 'ROAS ' + dec(inv.fat / inv.gas) + 'x · Meta Ads' : 'Meta Ads') + '</div></div>');
    var box = q('stats');
    box.style.gridTemplateColumns = 'repeat(' + html.length + ',minmax(0,1fr))';
    box.innerHTML = html.join('');

    desenhar(per ? per.value : null);
  }

  function desenhar(periodo) {
    var cv = hero.querySelector('canvas');
    var orig = typeof Chart !== 'undefined' && Chart.getChart ? Chart.getChart('chartEvolucao') : null;
    if (!cv || !orig) { hero.querySelector('.hero-spark').style.display = 'none'; return; }
    var labels = orig.data.labels.slice(), dados = orig.data.datasets[0].data.slice();
    var m = lista().filter(function (x) { return x.id === periodo; })[0];
    var sel = m ? labels.indexOf(m.cur) : -1;
    var vals = dados.filter(function (x) { return typeof x === 'number' && x > 0; });
    if (!vals.length) { hero.querySelector('.hero-spark').style.display = 'none'; return; }
    hero.querySelector('.hero-spark').style.display = '';
    var mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals), r = (mx - mn) || mx * .2;
    if (!chart) {
      var g = cv.getContext('2d').createLinearGradient(0, 0, 0, cv.parentElement.offsetHeight || 120);
      g.addColorStop(0, 'rgba(249,134,18,.38)'); g.addColorStop(.6, 'rgba(155,174,217,.10)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      chart = new Chart(cv, {
        type: 'line',
        data: { labels: [], datasets: [{ data: [], fill: true, backgroundColor: g, borderColor: 'rgba(249,134,18,.9)', borderWidth: 2, tension: .4, spanGaps: true, pointBackgroundColor: '#F98612', pointBorderColor: '#fff', pointBorderWidth: 2 }] },
        options: { responsive: true, maintainAspectRatio: false, animation: { duration: 400 }, layout: { padding: { left: 0, right: 12, top: 10, bottom: 0 } },
          plugins: { legend: { display: false }, tooltip: { enabled: false } },
          scales: { x: { display: true, grid: { display: false }, border: { display: false }, ticks: { color: 'rgba(155,174,217,.65)', font: { size: 10 } } }, y: { display: false } } }
      });
    }
    chart.data.labels = labels;
    chart.data.datasets[0].data = dados;
    chart.data.datasets[0].pointRadius = dados.map(function (_, i) { return i === sel ? 6 : 0; });
    chart.options.scales.y.min = Math.max(0, mn - r * 1.2);
    chart.options.scales.y.max = mx + r * .25;
    chart.update();
  }

  function iniciar() {
    if (!montar()) return;
    if (typeof window.render === 'function') {
      var orig = window.render;
      window.render = function () { var r = orig.apply(this, arguments); try { atualizar(); } catch (e) { /* não derruba a página */ } return r; };
    }
    document.addEventListener('change', function () { setTimeout(atualizar, 0); }, true);
    atualizar();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
