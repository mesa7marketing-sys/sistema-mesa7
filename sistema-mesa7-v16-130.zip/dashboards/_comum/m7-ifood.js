/* =========================================================
   Área iFood em todos os dashboards (injetado pelo sistema), na página Marketplace.
   Layout em cartões: 4 indicadores do mês comparados com o mês anterior, operação
   (window.M7_DADOS.ifood_op[AAAA-MM] = {o?, canc?, canc_pct?, canc_var?, cl?, cc?, atr?, cham_pct?, cham_var?,
   motivos?:[{m,n}], aberto?:{txt,pct,var}, desp?:{dia,n}, dist?:{km:clientes}, dist_var?:{km:%}}), funil de venda, pedidos por horário, mais vendidos,
   dias da semana e formas de pagamento.
   Fonte (só número real, nada estimado):
   - window.M7_DADOS.ifood[AAAA-MM]       relatório de desempenho do Portal do Parceiro (Arquivos);
   - window.M7_DADOS.ifood_funil[AAAA-MM] relatório de cardápio do Portal do Parceiro (Arquivos);
   - dashboards completos sem o relatório no mês: faturamento, pedidos e ticket do próprio
     dashboard (window.m7PlatDados → plat.ifd).
   O mês segue o filtro Período do dashboard.
   Cartão sem o relatório correspondente diz qual relatório falta, sem número.
   - dashboards em implantação: o m7-esqueleto.js deixa <div id="m7ifood"> na página Marketplace;
   - dashboards completos: o bloco entra no topo da página Marketplace/Plataformas.
   Com dado de iFood, a área substitui os blocos antigos da página (cartões, gráfico de
   12 meses e comparativo), que ficam escondidos.
   ========================================================= */
(function () {
  var MN = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  var nome = function (id) { return MN[+id.split('-')[1] - 1]; };
  var lbl = function (id) { return nome(id) + '/' + id.slice(0, 4); };
  var cur = function (id) { return nome(id).slice(0, 3).toLowerCase(); };
  var ant = function (id) { var p = id.split('-'), y = +p[0], m = +p[1] - 1; if (!m) { m = 12; y--; } return y + '-' + (m < 10 ? '0' : '') + m; };
  var R = function (v) { return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var R0 = function (v) { return 'R$ ' + Math.round(v || 0).toLocaleString('pt-BR'); };
  var N = function (v) { return Math.round(v || 0).toLocaleString('pt-BR'); };
  var P = function (v) { return (v || 0).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%'; };
  var P2 = function (v) { return (v || 0).toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + '%'; };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  var CSS = '.m7f{margin-bottom:22px;color:var(--m7-cream,#F4F2EA)}' +
    '.m7f-hd{display:flex;align-items:flex-end;justify-content:space-between;gap:12px;flex-wrap:wrap}' +
    '.m7f-hd h2{margin:0;font-size:21px;font-weight:800}.m7f-s{font-size:12.5px;opacity:.6;margin-top:3px}' +
    '.m7f-line{height:3px;border-radius:3px;background:linear-gradient(90deg,#F98612,rgba(249,134,18,.15));margin:12px 0 16px}' +
    '.m7f-g{display:grid;gap:14px;margin-bottom:14px}.m7f-g4{grid-template-columns:repeat(4,minmax(0,1fr))}.m7f-g3{grid-template-columns:repeat(3,minmax(0,1fr))}' +
    '@media(max-width:1100px){.m7f-g4{grid-template-columns:repeat(2,minmax(0,1fr))}.m7f-g3{grid-template-columns:1fr}}' +
    '.m7f-c{background:var(--bg-card,#0D0D10);border:1px solid var(--border,rgba(244,242,234,.08));border-radius:16px;padding:16px 18px;min-width:0}' +
    '.m7f-kl{font-size:11.5px;opacity:.75}.m7f-kv{font-size:27px;font-weight:800;margin:4px 0;letter-spacing:-.01em;white-space:nowrap}.m7f-kv.o{color:#F98612}' +
    '.m7f-d{font-size:11.5px}.m7f-d .u{color:#4ade80}.m7f-d .n{color:#f87171}.m7f-d .m{opacity:.55}' +
    '.m7f-t{display:flex;justify-content:space-between;align-items:baseline;gap:8px;margin-bottom:12px}.m7f-t b{font-size:14.5px}.m7f-t i{font-style:normal;font-size:11px;opacity:.55;text-align:right}' +
    '.m7f-row{margin-bottom:11px}.m7f-a{display:flex;justify-content:space-between;gap:10px;font-size:12.5px;margin-bottom:5px}.m7f-a span:last-child{font-weight:700;white-space:nowrap}' +
    '.m7f-x{font-size:11px;opacity:.55;margin:-3px 0 5px}' +
    '.m7f-bar{height:5px;border-radius:5px;background:rgba(255,255,255,.07)}.m7f-bar i{display:block;height:100%;border-radius:5px;background:#F98612}.m7f-bar.b2 i{background:#F4F2EA}.m7f-bar.b3 i{background:#9BAED9}' +
    '.m7f-mini{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-bottom:12px}' +
    '.m7f-mini>div{background:var(--bg-hover,#17171C);border-radius:12px;padding:10px 12px;border-top:3px solid #F98612}.m7f-mini>div:nth-child(2){border-color:#F4F2EA}.m7f-mini>div:nth-child(3){border-color:#9BAED9}' +
    '.m7f-ml{font-size:11px;opacity:.75}.m7f-mv{font-size:17px;font-weight:800;margin-top:3px;white-space:nowrap}.m7f-mx{font-size:10.5px;opacity:.55}' +
    '.m7f-hrs{display:flex;align-items:flex-end;gap:6px;height:158px}.m7f-hrs>div{flex:1;text-align:center;font-size:10px;opacity:.9;min-width:0}' +
    '.m7f-pair{display:flex;align-items:flex-end;gap:2px;justify-content:center;height:130px;margin-bottom:5px}.m7f-pair i{width:44%;max-width:22px;display:block;border-radius:5px 5px 2px 2px;background:#F98612}.m7f-pair i.p{background:rgba(155,174,217,.4)}' +
    '.m7f-leg{display:flex;gap:14px;font-size:11px;opacity:.7;margin:8px 0 12px}.m7f-leg span:before{content:"";display:inline-block;width:9px;height:9px;border-radius:2px;background:#F98612;margin-right:5px;vertical-align:-1px}.m7f-leg span.p:before{background:rgba(155,174,217,.6)}' +
    '.m7f-f{display:flex;flex-direction:column;gap:8px}.m7f-fs{display:flex;align-items:center;gap:10px}.m7f-fl{font-size:12px;opacity:.8;width:118px;flex:none}' +
    '.m7f-fw{flex:1;min-width:0;display:flex;align-items:center;gap:8px}.m7f-fb{height:30px;border-radius:7px;background:linear-gradient(90deg,#F98612,#d96f05);display:flex;align-items:center;padding:0 10px;font-weight:800;font-size:13px;color:#0D0D10;white-space:nowrap;flex:none;box-sizing:border-box}' +
    '.m7f-fp{font-size:11px;opacity:.6;white-space:nowrap}' +
    '.m7f-w{font-size:12.5px;line-height:1.55;opacity:.75;background:rgba(255,255,255,.04);border-left:3px solid #9BAED9;border-radius:9px;padding:10px 12px}' +
    '.m7f-note{font-size:11px;opacity:.55;margin:2px 0 0}';

  var D = window.M7_DADOS || {}, V = D.ifood || {}, F = D.ifood_funil || {}, OP = D.ifood_op || {};
  // faturamento, pedidos e ticket do iFood que o dashboard completo já tem lançado
  var B = {};
  try { if (typeof window.m7PlatDados === 'function') (window.m7PlatDados() || []).forEach(function (m) { var i = m && m.plat && m.plat.ifd; if (i && i.o > 0 && i.r > 0 && !m.parcial && !m.ate) B[m.id] = { r: i.r, o: i.o, t: i.t || i.r / i.o }; }); } catch (e) { /* sem plataformas */ }
  var venda = function (id) { return V[id] || B[id] || null; };
  var meses = Object.keys(V).concat(Object.keys(B), Object.keys(F), Object.keys(OP)).filter(function (k, i, a) { return /^\d{4}-\d{2}$/.test(k) && a.indexOf(k) === i; }).sort();
  var sel = meses[meses.length - 1];
  // o mês vem do filtro Período do próprio dashboard (#selPeriodo nos completos, #selMes nos em implantação);
  // "Período completo" (ou nenhum filtro) mostra o último mês com dado do iFood
  function mesDoFiltro() {
    var f = document.getElementById('selPeriodo') || document.getElementById('selMes'), v = f && f.value;
    return /^\d{4}-\d{2}$/.test(v || '') ? v : meses[meses.length - 1];
  }

  function delta(at, an, fmt, extra) {
    if (at == null) return '';
    if (an == null || !an) return '<div class="m7f-d"><span class="m">' + (extra || 'sem o mês anterior para comparar') + '</span></div>';
    var d = (at - an) / an * 100;
    return '<div class="m7f-d"><span class="' + (d >= 0 ? 'u' : 'n') + '">' + (d >= 0 ? '▲ ' : '▼ ') + P(Math.abs(d)) + '</span> <span class="m">vs ' + cur(ant(sel)) + ': ' + fmt(an) + (extra ? ' · ' + extra : '') + '</span></div>';
  }
  var kpi = function (l, val, fmt, an, o, extra) { return '<div class="m7f-c"><div class="m7f-kl">' + l + '</div><div class="m7f-kv' + (o ? ' o' : '') + '">' + (val == null ? '—' : fmt(val)) + '</div>' + (val == null ? '<div class="m7f-d"><span class="m">' + extra + '</span></div>' : delta(val, an, fmt, extra)) + '</div>'; };
  var card = function (t, s, corpo) { return '<div class="m7f-c"><div class="m7f-t"><b>' + t + '</b><i>' + s + '</i></div>' + corpo + '</div>'; };
  var falta = function (txt) { return '<div class="m7f-w">' + txt + '</div>'; };
  var row = function (a, b, x, pc, cls) { return '<div class="m7f-row"><div class="m7f-a"><span>' + esc(a) + '</span><span>' + b + '</span></div>' + (x ? '<div class="m7f-x">' + x + '</div>' : '') + '<div class="m7f-bar' + (cls ? ' ' + cls : '') + '"><i style="width:' + Math.max(0, Math.min(100, pc)).toFixed(1) + '%"></i></div></div>'; };
  var CL = ['', 'b2', 'b3'];
  var horas = function (i) { var o = {}; if (!i || !i.horas) return o; ['semana', 'fds'].forEach(function (k) { var h = i.horas[k] || {}; Object.keys(h).forEach(function (s) { o[s] = (o[s] || 0) + (h[s] || 0); }); }); return o; };
  var DESEMP = 'relatório de desempenho do Portal do Parceiro iFood', CARD = 'relatório de cardápio do Portal do Parceiro iFood';

  function desenhar(el) {
    var cliente = (window.CLIENTE && window.CLIENTE.nome) || '';
    if (!meses.length) {
      el.innerHTML = '<div class="m7f"><div class="m7f-hd"><div><h2>iFood' + (cliente ? ' · ' + esc(cliente) : '') + '</h2></div></div><div class="m7f-line"></div>' +
        falta('<b>Aguardando os relatórios do iFood.</b> Esta área mostra faturamento, pedidos, ticket, clientes novos, funil de venda, horários, mais vendidos e formas de pagamento assim que o ' + DESEMP + ' e o relatório de cardápio do mês forem enviados em Arquivos.') + '</div>';
      return;
    }
    function dist() {
      var o = OP[sel], d = o && o.dist;
      if (!d || !Object.keys(d).length) return '';
      var ks = Object.keys(d).sort(function (x, y) { return parseFloat(x) - parseFloat(y); }), tot = ks.reduce(function (t, k) { return t + d[k]; }, 0), mx = Math.max.apply(null, ks.map(function (k) { return d[k]; }));
      var ate3 = ks.filter(function (k) { return parseFloat(k) <= 3; }).reduce(function (t, k) { return t + d[k]; }, 0);
      var colunas = ks.map(function (k) {
        var dv = o.dist_var && o.dist_var[k];
        return '<div style="flex:1;min-width:34px;text-align:center;font-size:10.5px"><div style="font-weight:700;font-size:12px;margin-bottom:4px">' + N(d[k]) + '</div>' +
          '<div style="height:110px;display:flex;align-items:flex-end;justify-content:center"><i style="display:block;width:60%;max-width:26px;border-radius:5px 5px 2px 2px;background:#F98612;height:' + Math.max(3, d[k] / mx * 110).toFixed(0) + 'px"></i></div>' +
          '<div style="margin-top:5px;opacity:.85">' + String(k).replace('.', ',') + ' km</div>' + (dv != null ? '<div style="font-size:10px;color:' + (dv >= 0 ? '#4ade80' : '#f87171') + '">' + (dv >= 0 ? '+' : '−') + P(Math.abs(dv)) + '</div>' : '') + '</div>';
      }).join('');
      return '<div class="m7f-g" style="grid-template-columns:1fr">' + card('Clientes por distância', 'quantos clientes pediram em cada raio · variação vs ' + cur(a), '<div style="display:flex;gap:6px;align-items:flex-end;overflow-x:auto">' + colunas + '</div>' +
        '<p class="m7f-note" style="margin-top:10px">' + N(tot) + ' clientes no mês · ' + P(tot ? ate3 / tot * 100 : 0) + ' a até 3 km da loja.</p>') + '</div>';
    }
    var v = venda(sel), i = V[sel] || null, f = F[sel] || null, a = ant(sel), pv = venda(a), pi = V[a] || null, pf = F[a] || null;
    var h = '<div class="m7f"><div class="m7f-hd"><div><h2>iFood' + (cliente ? ' · ' + esc(cliente) : '') + '</h2><div class="m7f-s">' + lbl(sel) + (pv || pf ? ' comparado com ' + lbl(a).toLowerCase() : '') +
      ' · relatórios do Portal do Parceiro' + (i && i.periodo ? ' (' + esc(i.periodo) + ')' : '') + '</div></div></div><div class="m7f-line"></div>';

    /* indicadores */
    var sem = 'aguardando o relatório de desempenho';
    h += '<div class="m7f-g m7f-g4">' +
      kpi('Faturamento iFood', v ? v.r : null, R, pv && pv.r, true, v ? '' : sem) +
      kpi('Pedidos', v ? v.o : null, N, pv && pv.o, false, v ? '' : sem) +
      kpi('Ticket médio', v ? (v.t || (v.o ? v.r / v.o : null)) : null, R, pv && (pv.t || (pv.o ? pv.r / pv.o : null)), false, v ? '' : sem) +
      kpi('Clientes novos', i ? i.novos : null, N, pi && pi.novos, false, i ? (i.o ? P(i.novos / i.o * 100) + ' dos pedidos' : '') : sem) + '</div>';

    /* operação: cancelamentos, atrasos, chamados e loja aberta (relatório de operação do Portal do Parceiro) */
    var op, o = OP[sel] || null, po = OP[a] || null, ped = (o && o.o) || (v && v.o) || 0;
    if (o) {
      var tile = function (l, x, sub) { return '<div><div class="m7f-ml">' + l + '</div><div class="m7f-mv">' + x + '</div><div class="m7f-mx">' + sub + '</div></div>'; };
      var vr = function (d) { return d == null ? '' : (d <= 0 ? '▼ ' : '▲ ') + P2(Math.abs(d)) + ' vs ' + cur(a); };
      var cmp = function (x, y) { return y == null || x == null ? '' : (x <= y ? '▼ ' : '▲ ') + 'vs ' + cur(a) + ': ' + N(y); };
      var canc = o.canc != null ? o.canc : (o.cl != null || o.cc != null ? (o.cl || 0) + (o.cc || 0) : null);
      var pcanc = po ? (po.canc != null ? po.canc : (po.cl != null || po.cc != null ? (po.cl || 0) + (po.cc || 0) : null)) : null;
      var cpct = o.canc_pct != null ? o.canc_pct : canc != null && ped ? canc / ped * 100 : null;
      var tiles = [tile('Cancelamentos', cpct != null ? P2(cpct) : canc != null ? N(canc) : '—', (canc != null && cpct != null ? N(canc) + ' pedidos' : 'dos pedidos') + (o.canc_var != null ? ' · ' + vr(o.canc_var) : ''))];
      if (o.atr != null) tiles.push(tile('Atrasos', N(o.atr), ped ? P(o.atr / ped * 100) + ' dos pedidos' : 'no mês'));
      if (o.cham_pct != null) tiles.push(tile('Chamados abertos', P2(o.cham_pct), 'dos pedidos' + (o.cham_var != null ? ' · ' + vr(o.cham_var) : '')));
      if (o.aberto) tiles.push(tile('Loja aberta', P2(o.aberto.pct), esc(o.aberto.txt) + (o.aberto.var != null ? ' · ' + vr(o.aberto.var) : '')));
      if (tiles.length < 3) tiles.push(tile('Pedidos', ped ? N(ped) : '—', 'no mês'));
      var mot = (o.motivos || []).slice().sort(function (x, y) { return y.n - x.n; }), mmax = mot.length ? mot[0].n : 0;
      op = '<div class="m7f-mini">' + tiles.slice(0, 3).join('') + '</div>' +
        (o.cl != null ? row('Cancelados pela loja', N(o.cl) + (ped ? ' · ' + P(o.cl / ped * 100) : ''), cmp(o.cl, po && po.cl), ped ? o.cl / ped * 1000 : 0, '') : '') +
        (o.cc != null ? row('Cancelados pelo cliente', N(o.cc) + (ped ? ' · ' + P(o.cc / ped * 100) : ''), cmp(o.cc, po && po.cc), ped ? o.cc / ped * 1000 : 0, 'b2') : '') +
        (!mot.length && o.cl == null && o.cc == null && canc != null ? row('Cancelamentos', N(canc) + (ped ? ' · ' + P(canc / ped * 100) : ''), cmp(canc, pcanc), ped ? canc / ped * 1000 : 0, '') : '') +
        (o.atr != null ? row('Pedidos atrasados', N(o.atr) + (ped ? ' · ' + P(o.atr / ped * 100) : ''), cmp(o.atr, po && po.atr), ped ? o.atr / ped * 1000 : 0, 'b3') : '') +
        (mot.length ? '<div class="m7f-ml" style="margin:4px 0 8px">Motivos de cancelamento</div>' + mot.map(function (m, k) { return row(m.m, N(m.n) + (m.n === 1 ? ' pedido' : ' pedidos'), '', mmax ? m.n / mmax * 100 : 0, CL[k % 3]); }).join('') : '') +
        (o.desp ? '<div class="m7f-row"><div class="m7f-a"><span>Dia com mais pedidos despachados</span><span>' + esc(o.desp.dia) + ' · ' + N(o.desp.n) + ' pedidos</span></div></div>' : '');
    } else op = falta('Cancelamentos, atrasos e motivos aparecem com o relatório de operação do Portal do Parceiro iFood de ' + lbl(sel).toLowerCase() + '.');
    /* funil */
    var fu;
    if (f && f.vis) {
      var et = [['Visitas à loja', 'vis'], ['Viram o cardápio', 'vw'], ['Adicionaram à sacola', 'sac'], ['Revisaram o pedido', 'rev'], ['Concluíram o pedido', 'conc']].filter(function (e) { return e[1] === 'vis' || f[e[1]] > 0; });
      fu = '<div class="m7f-f">' + et.map(function (e, n) {
        var x = f[e[1]], pr = n ? f[et[n - 1][1]] : 0;
        return '<div class="m7f-fs"><span class="m7f-fl">' + e[0] + '</span><div class="m7f-fw"><div class="m7f-fb" style="width:' + Math.max(22, x / f.vis * 100).toFixed(1) + '%">' + N(x) + '</div>' + (n && pr ? '<span class="m7f-fp">' + P(x / pr * 100) + '</span>' : '') + '</div></div>';
      }).join('') + '</div>';
      var cv = f.conv || (f.conc / f.vis * 100), pa = pf && pf.vis ? { conv: pf.conv || pf.conc / pf.vis * 100, conc: pf.conc, vis: pf.vis, n: nome(a).toLowerCase() } : f.ant && f.ant.vis ? { conv: f.ant.conv || f.ant.conc / f.ant.vis * 100, conc: f.ant.conc, vis: f.ant.vis, n: 'período anterior' } : null;
      fu += '<div style="margin-top:14px">' + row('Conversão total (visita → pedido)', P(cv), pa ? pa.n + ': ' + P(pa.conv) + ' · ' + N(pa.conc) + ' de ' + N(pa.vis) + ' visitas' : '', Math.min(100, cv * 4)) + '</div>';
    } else fu = falta('O funil (visitas, cardápio, sacola e pedidos concluídos) aparece com o ' + CARD + ' de ' + lbl(sel).toLowerCase() + '.');
    /* horários */
    var hr, ha = horas(i), hp = horas(pi), slots = Object.keys(ha).filter(function (s) { return ha[s] > 0 || hp[s] > 0; }).sort();
    if (slots.length) {
      var mx = Math.max.apply(null, slots.map(function (s) { return Math.max(ha[s] || 0, hp[s] || 0); })), temP = slots.some(function (s) { return hp[s] > 0; });
      var pico = slots.slice().sort(function (x, y) { return ha[y] - ha[x]; })[0], dias = i.dias || {}, md = Object.keys(dias).sort(function (x, y) { return dias[y] - dias[x]; })[0];
      hr = '<div class="m7f-hrs">' + slots.map(function (s) {
        var t = '<i style="height:' + Math.max(2, (ha[s] || 0) / mx * 130).toFixed(0) + 'px" title="' + esc(lbl(sel) + ' · ' + s + ': ' + N(ha[s]) + ' pedidos') + '"></i>';
        if (temP) t = '<i class="p" style="height:' + Math.max(2, (hp[s] || 0) / mx * 130).toFixed(0) + 'px" title="' + esc(lbl(a) + ' · ' + s + ': ' + N(hp[s]) + ' pedidos') + '"></i>' + t;
        return '<div><div class="m7f-pair">' + t + '</div>' + esc(s.replace(/h/g, '').replace(/\s*-\s*/, '–') + 'h') + '</div>';
      }).join('') + '</div><div class="m7f-leg"><span>' + nome(sel) + '</span>' + (temP ? '<span class="p">' + nome(a) + '</span>' : '') + '</div>' +
        '<div class="m7f-row"><div class="m7f-a"><span>Pico</span><span>' + esc(pico) + ' · ' + P(i.o ? ha[pico] / i.o * 100 : 0) + ' dos pedidos</span></div></div>' +
        (md ? '<div class="m7f-row"><div class="m7f-a"><span>Melhor dia</span><span>' + esc(md) + ' · ' + N(dias[md]) + ' pedidos</span></div></div>' : '');
    } else hr = falta('Os pedidos por horário aparecem com o ' + DESEMP + ' de ' + lbl(sel).toLowerCase() + '.');
    h += '<div class="m7f-g m7f-g3">' + card('Operação', 'cancelamentos e atendimento', op) + card('Funil de venda', 'visita → pedido', fu) + card('Pedidos por horário', temP ? nome(sel).toLowerCase() + ' x ' + nome(a).toLowerCase() : 'semana + fim de semana', hr) + '</div>';

    /* mais vendidos */
    var mv, it = f && f.itens ? f.itens.filter(function (x) { return x.r > 0; }).sort(function (x, y) { return y.r - x.r; }).slice(0, 5) : [];
    if (it.length) {
      var base = v && v.r ? v.r : 0;
      mv = it.map(function (x, n) { return row(x.nome, R0(x.r), N(x.qtd) + ' un' + (base ? ' · ' + P(x.r / base * 100) + ' do faturamento' : ''), x.r / it[0].r * 100, ''); }).join('');
    } else mv = falta('Os itens que mais faturaram aparecem com o ' + CARD + ' de ' + lbl(sel).toLowerCase() + '.');
    /* dias da semana */
    var ds, ORD = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
    if (i && i.dias && Object.keys(i.dias).length) {
      var dk = Object.keys(i.dias).sort(function (x, y) { return ORD.indexOf(x) - ORD.indexOf(y); }), dm = Math.max.apply(null, dk.map(function (k) { return i.dias[k]; })), dt = dk.reduce(function (t, k) { return t + i.dias[k]; }, 0);
      ds = dk.map(function (k) { return row(k, N(i.dias[k]) + ' · ' + P(dt ? i.dias[k] / dt * 100 : 0), '', dm ? i.dias[k] / dm * 100 : 0, i.dias[k] === dm ? '' : 'b3'); }).join('');
    } else ds = falta('Os pedidos por dia da semana aparecem com o ' + DESEMP + ' de ' + lbl(sel).toLowerCase() + '.');
    /* pagamento e clientes */
    var pg;
    if (i && i.pg && Object.keys(i.pg).length) {
      var pk = Object.keys(i.pg).sort(function (x, y) { return i.pg[y] - i.pg[x]; }), pt = pk.reduce(function (t, k) { return t + i.pg[k]; }, 0), top = pk.slice(0, 4), resto = pk.slice(4).reduce(function (t, k) { return t + i.pg[k]; }, 0);
      pg = top.map(function (k, n) { return row(k, P(i.pg[k] / pt * 100), N(i.pg[k]) + ' pedidos', i.pg[k] / pt * 100, CL[Math.min(n, 2)]); }).join('') +
        (resto ? row('Outros', P(resto / pt * 100), N(resto) + ' pedidos', resto / pt * 100, 'b3') : '') +
        (i.o ? '<div style="margin-top:14px">' + row('Pedidos de clientes novos', N(i.novos) + ' · ' + P(i.novos / i.o * 100), 'demais pedidos: ' + N(i.o - i.novos) + ' · ' + P((i.o - i.novos) / i.o * 100), i.novos / i.o * 100, '') + '</div>' : '');
    } else pg = falta('As formas de pagamento e os clientes novos aparecem com o ' + DESEMP + ' de ' + lbl(sel).toLowerCase() + '.');
    h += '<div class="m7f-g m7f-g3">' + card('Mais vendidos', 'top 5 em faturamento', mv) + card('Dias da semana', 'pedidos por dia', ds) + card('Pagamento e clientes', 'como pagam · quem é novo', pg) + '</div>' +
      dist() +
      '<p class="m7f-note">Fonte: ' + [v ? (i ? DESEMP : 'faturamento, pedidos e ticket lançados no dashboard') : '', f ? CARD : ''].filter(Boolean).join(' e ') + '. Cartões sem número aguardam o relatório indicado.</p></div>';
    el.innerHTML = h;
  }

  function alvo() {
    var el = document.getElementById('m7ifood');
    if (el) return el;
    if (window.__ESQUELETO__ || typeof window.m7Historico === 'function') return null;   // em implantação: o lugar vem do m7-esqueleto.js
    var li = Array.prototype.slice.call(document.querySelectorAll('.nav-item')).filter(function (x) { return /Marketplace|Plataformas/i.test(x.textContent || ''); })[0];
    if (!li) return null;
    var id = li.getAttribute('data-page'); if (!id) { var m = /switchPage\('([^']+)'\)/.exec(li.getAttribute('onclick') || ''); id = m && m[1]; }
    var pg = id && document.getElementById(id); if (!pg) return null;
    if (Array.isArray(window.m7SemCanais) && window.m7SemCanais.indexOf('ifd') > -1 && !meses.length) return null;
    el = document.createElement('div'); el.id = 'm7ifood'; pg.insertBefore(el, pg.firstChild);
    return el;
  }
  // com a área nova, os blocos antigos da página (cartões, gráfico de 12 meses e comparativo) saem
  function limpar(el) { if (!meses.length || !el.parentNode) return; Array.prototype.slice.call(el.parentNode.children).forEach(function (x) { if (x !== el && x.style.display !== 'none') x.style.display = 'none'; }); }
  function montar() { var el = alvo(); if (!el) return; if (!el.firstChild) { sel = mesDoFiltro(); desenhar(el); } limpar(el); }
  function iniciar() {
    var st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    montar();
    // trocar o Período redesenha a área no mês escolhido
    document.addEventListener('change', function (e) { var t = e.target; if (!t || (t.id !== 'selPeriodo' && t.id !== 'selMes')) return; setTimeout(function () { var el = document.getElementById('m7ifood'); if (el && el.firstChild) { sel = mesDoFiltro(); desenhar(el); } }, 0); });
    // a página dos dashboards em implantação é redesenhada ao trocar o mês: devolve o bloco
    if (window.MutationObserver) new MutationObserver(montar).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'complete') iniciar(); else window.addEventListener('load', iniciar);
})();
