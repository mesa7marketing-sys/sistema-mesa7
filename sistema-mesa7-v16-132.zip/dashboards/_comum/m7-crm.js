/* =========================================================
   "CRM em números" para os clientes que usam o RePediu (injetado pelo sistema quando o
   cliente tem repediu: true em src/lib/dashboards.ts).
   - Lê window.M7_DADOS.crm: { "AAAA-MM": {rec, msg, conv, r, rr?, rc?, rcr?, ate?} }.
   - Desenha no topo da página de CRM do dashboard (ou na página CRM & Retenção criada
     pelo m7-paginas.js): 8 cartões do mês comparados com o mês anterior, uma leitura
     automática e um seletor de mês (com o acumulado).
   - Sem dados ainda: mostra o aviso de que o RePediu está ativo e o que falta enviar.
   - O Paçocas 1 tem o bloco próprio no HTML (#crmNumeros); lá este arquivo não faz nada.
   ========================================================= */
(function () {
  var MN = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  var cur = function (id) { var p = id.split('-'); return MN[+p[1] - 1].slice(0, 3) + '/' + p[0].slice(2); };
  var nome = function (id) { return MN[+id.split('-')[1] - 1]; };
  var ant = function (id) { var p = id.split('-'), y = +p[0], m = +p[1] - 1; if (!m) { m = 12; y--; } return y + '-' + (m < 10 ? '0' : '') + m; };
  var R = function (v) { return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var N = function (v) { return Math.round(v || 0).toLocaleString('pt-BR'); };
  var P = function (v) { return v.toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + '%'; };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  var CSS = '.m7n{background:var(--bg-card,#0D0D10);border:1px solid var(--border,rgba(244,242,234,.08));border-radius:16px;padding:20px 20px 16px;margin-bottom:18px}' +
    '.m7n-top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}' +
    '.m7n-tag{display:inline-flex;align-items:center;gap:10px;background:var(--m7-orange,#F98612);color:#0D0D10;font-weight:800;font-size:17px;padding:7px 28px 7px 14px;clip-path:polygon(0 0,100% 0,94% 100%,0 100%);border-radius:6px 0 0 6px}' +
    '.m7n-tag b{opacity:.7}.m7n-sel{background:var(--bg-hover,#17171C);color:inherit;border:1px solid var(--border-strong,rgba(244,242,234,.16));border-radius:9px;padding:7px 10px;font:inherit;font-size:13px}' +
    '.m7n-g{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:16px}@media(max-width:900px){.m7n-g{grid-template-columns:repeat(2,minmax(0,1fr))}}' +
    '.m7n-c{background:var(--bg-hover,#17171C);border:1px solid var(--border,rgba(244,242,234,.07));border-radius:13px;padding:12px 14px;min-height:88px}' +
    '.m7n-c.hl{background:linear-gradient(135deg,#F98612,#d96f05);border:none;color:#0D0D10}' +
    '.m7n-l{font-size:10.5px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;opacity:.7}.m7n-v{font-size:22px;font-weight:800;margin:5px 0 7px}' +
    '.m7n-p{display:inline-block;font-size:11px;font-weight:700;border-radius:99px;padding:3px 9px}' +
    '.m7n-p.up{background:rgba(74,222,128,.14);color:#4ade80}.m7n-p.down{background:rgba(248,113,113,.14);color:#f87171}.m7n-p.neu{background:rgba(155,174,217,.14);color:#9BAED9}' +
    '.m7n-c.hl .m7n-p{background:rgba(13,13,16,.22);color:#0D0D10}' +
    '.m7n-i{margin-top:14px;background:rgba(255,255,255,.04);border-left:4px solid var(--m7-orange,#F98612);border-radius:10px;padding:11px 14px;font-size:13px;line-height:1.5}.m7n-i b{color:var(--m7-orange,#F98612)}';

  function alvo() {
    var el = document.getElementById('m7crm');
    if (el) return el;
    // página de CRM que o próprio dashboard já tem: bloco no topo
    var li = Array.prototype.slice.call(document.querySelectorAll('.nav-item')).filter(function (x) { return /CRM/.test(x.textContent || ''); })[0];
    if (!li) return null;
    var id = li.getAttribute('data-page'); if (!id) { var m = /switchPage\('([^']+)'\)/.exec(li.getAttribute('onclick') || ''); id = m && m[1]; }
    var pg = id && document.getElementById(id); if (!pg) return null;
    el = document.createElement('div'); el.id = 'm7crm'; pg.insertBefore(el, pg.firstChild);
    return el;
  }

  function desenhar(el, D, per) {
    var meses = Object.keys(D).sort();
    var cliente = (window.CLIENTE && window.CLIENTE.nome) || '';
    if (!meses.length) {
      el.innerHTML = '<div class="m7n"><div class="m7n-top"><div class="m7n-tag"><b>CRM</b> RePediu</div></div>' +
        '<div class="m7n-i"><b>RePediu ativo' + (cliente ? ' em ' + esc(cliente) : '') + '.</b> Os números do CRM entram aqui quando o relatório do painel do RePediu for enviado: ' +
        'mensagens enviadas, conversões, receita gerada, clientes recuperados e recorrentes de cada mês. A partir do segundo mês, cada número vem comparado com o mês anterior.</div></div>';
      return;
    }
    var full = per === 'full', soma = { rec: 0, msg: 0, conv: 0, r: 0, rr: null, rc: null, rcr: null };
    if (full) meses.forEach(function (k) { var x = D[k]; soma.rec += x.rec || 0; soma.msg += x.msg || 0; soma.conv += x.conv || 0; soma.r += x.r || 0;
      ['rr', 'rc', 'rcr'].forEach(function (f) { if (x[f] != null) soma[f] = (soma[f] || 0) + x[f]; }); });
    var v = full ? soma : D[per], a = full ? null : ant(per), p = full ? null : D[a] || null;
    var tx = function (o) { return o && o.msg ? o.conv / o.msg * 100 : null; }, tk = function (o) { return o && o.conv ? o.r / o.conv : null; };
    var pill = function (at, an, fmt) {
      if (full) return '<span class="m7n-p neu">desde ' + cur(meses[0]) + '</span>';
      if (at == null) return '<span class="m7n-p neu">sem o dado no mês</span>';
      if (an == null || !an) return '<span class="m7n-p neu">sem ' + cur(a) + ' para comparar</span>';
      var d = (at - an) / an * 100;
      return '<span class="m7n-p ' + (d >= 0 ? 'up' : 'down') + '">' + (d >= 0 ? '▲ +' : '▼ ') + d.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '% · ' + cur(a).split('/')[0].toLowerCase() + ': ' + fmt(an) + '</span>';
    };
    var c = function (cls, l, val, fmt, an) { return '<div class="m7n-c ' + cls + '"><div class="m7n-l">' + l + '</div><div class="m7n-v">' + (val == null ? '—' : fmt(val)) + '</div>' + pill(val, an, fmt) + '</div>'; };
    var g = function (o, f) { return o && o[f] != null ? o[f] : null; };
    var cards = [
      c('hl', 'Receita gerada', v.r, R, g(p, 'r')),
      c('', 'Mensagens enviadas', v.msg, N, g(p, 'msg')),
      c('', 'Conversões', v.conv, N, g(p, 'conv')),
      c('', 'Taxa de conversão', tx(v), P, tx(p)),
      c('', 'Ticket do CRM', tk(v), R, tk(p)),
      c('', 'Clientes recuperados', g(v, 'rec'), N, g(p, 'rec')),
      c('', 'Receita recuperada', g(v, 'rr'), R, g(p, 'rr')),
      c('', 'Receita de recorrentes', g(v, 'rcr'), R, g(p, 'rcr'))
    ];
    var ins;
    if (full) ins = '<b>Acumulado do RePediu:</b> ' + R(v.r) + ' em ' + N(v.conv) + ' compras a partir de ' + N(v.msg) + ' mensagens, de ' + cur(meses[0]) + ' a ' + cur(meses[meses.length - 1]) + ' (' + meses.length + (meses.length > 1 ? ' meses' : ' mês') + ').';
    else if (p && p.r) {
      var it = [['receita', v.r, p.r], ['conversões', v.conv, p.conv], ['mensagens', v.msg, p.msg], ['clientes recuperados', v.rec, p.rec]]
        .filter(function (x) { return x[1] != null && x[2]; }).map(function (x) { return { n: x[0], d: (x[1] - x[2]) / x[2] * 100 }; });
      var fd = function (x) { return (x.d >= 0 ? '+' : '') + x.d.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%'; };
      var up = it.slice().sort(function (x, y) { return y.d - x.d; })[0], dn = it.slice().sort(function (x, y) { return x.d - y.d; })[0], dif = v.r - p.r;
      ins = '<b>O CRM vendeu ' + (dif >= 0 ? 'mais' : 'menos') + ' que em ' + nome(a).toLowerCase() + ':</b> receita ' + fd(it[0]) + ' (' + (dif >= 0 ? '+' : '−') + R(Math.abs(dif)) + '), ' + N(v.conv) + ' compras' + (tx(v) != null ? ' com taxa de ' + P(tx(v)) : '') + '.' +
        (up && up.d > 0 && up.n !== 'receita' ? ' Maior alta: ' + up.n + ' ' + fd(up) + '.' : '') + (dn && dn.d < 0 && dn.n !== 'receita' ? ' Maior queda: ' + dn.n + ' ' + fd(dn) + '.' : '');
    } else ins = '<b>' + nome(per) + ' é o primeiro mês com RePediu no dashboard.</b> Os próximos meses entram com a comparação.';
    var opts = '<option value="full"' + (full ? ' selected' : '') + '>Acumulado</option>' + meses.slice().reverse().map(function (k) { return '<option value="' + k + '"' + (k === per ? ' selected' : '') + '>' + nome(k) + '/' + k.slice(0, 4) + (D[k].ate ? ' (até ' + D[k].ate.split('-').reverse().slice(0, 2).join('/') + ')' : '') + '</option>'; }).join('');
    el.innerHTML = '<div class="m7n"><div class="m7n-top"><div class="m7n-tag"><b>CRM</b> ' + (full ? 'Acumulado do RePediu' : nome(per) + ' em números') + '</div>' +
      '<select class="m7n-sel" aria-label="Mês do RePediu">' + opts + '</select></div><div class="m7n-g">' + cards.join('') + '</div><div class="m7n-i">' + ins + '</div></div>';
    el.querySelector('select').addEventListener('change', function (e) { desenhar(el, D, e.target.value); });
  }

  function iniciar() {
    if (document.getElementById('crmNumeros')) return;   // Paçocas 1: bloco próprio no HTML
    var el = alvo(); if (!el) return;
    var st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    var D = (window.M7_DADOS && window.M7_DADOS.crm) || {}, ms = Object.keys(D).sort();
    desenhar(el, D, ms.length ? ms[ms.length - 1] : 'full');
  }
  if (document.readyState === 'complete') iniciar(); else window.addEventListener('load', iniciar);
})();
