/* =========================================================
   Mesa7 — Esqueleto de dashboard (padrão Taverna dos Pandas)
   Usado pelos clientes que ainda não têm base de dados completa.
   Cada HTML define window.CLIENTE = {nome, seg, icone, logo}
   e carrega este arquivo. O Sistema Mesa7 injeta window.M7_DADOS
   ({ifood:{AAAA-MM:...}, meta:{AAAA-MM:...}}) com o que já chegou
   (uploads da equipe e integrações); o resto aparece como
   "Aguardando dados".
   ========================================================= */
(function () {
  var C = window.CLIENTE || { nome: 'Cliente', seg: '', icone: 'fa-utensils', logo: '' };
  // CLIENTE.ocultar: pedaços de rótulo que não aparecem para esse cliente (ex.: ['compras', '99food']).
  var OCULTAR = (C.ocultar || []).map(function (x) { return String(x).toLowerCase(); });
  function visivel(rot) { var r = String(rot || '').toLowerCase(); return !OCULTAR.some(function (o) { return r.indexOf(o) > -1; }); }
  document.title = 'Mesa7 — Dashboard ' + C.nome;

  function addHead(tag, attrs) {
    var el = document.createElement(tag);
    for (var k in attrs) el.setAttribute(k, attrs[k]);
    document.head.appendChild(el);
  }
  addHead('link', { rel: 'preconnect', href: 'https://fonts.googleapis.com' });
  addHead('link', { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap' });
  addHead('link', { rel: 'stylesheet', href: 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css' });

  var css = [
    ':root{--m7-orange:#F98612;--m7-cream:#F4F2EA;--m7-blue:#9BAED9;--m7-navy-deep:#101243;--m7-navy:#1A2361;--bg-main:#0C0E36;--bg-panel:#101243;--bg-card:#1A2361;--bg-hover:#26307E;--border:rgba(155,174,217,.18);--border-strong:rgba(155,174,217,.32);--primary-glow:rgba(249,134,18,.14);--text-muted:#9BAED9;--text-sub:#D6DEF0}',
    '*{box-sizing:border-box;margin:0;padding:0}',
    'body{background:var(--bg-main);color:var(--m7-cream);font-family:Poppins,sans-serif;display:flex;min-height:100vh;overflow-x:hidden;-webkit-font-smoothing:antialiased}',
    'h1,.kpi-value,.brand-title,.chart-title{letter-spacing:-.03em}',
    'aside{width:262px;background:var(--bg-panel);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;height:100vh;z-index:100}',
    '.brand-header{padding:24px 20px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px}',
    '.brand-logo{width:40px;height:40px;background:var(--m7-orange);border-radius:11px;display:flex;align-items:center;justify-content:center;color:var(--m7-navy-deep);font-weight:700;font-size:16px;letter-spacing:-.05em}',
    '.brand-title{font-size:19px;font-weight:600;line-height:1.15}',
    '.brand-title span{color:var(--m7-orange);font-size:10px;display:block;text-transform:uppercase;letter-spacing:1.8px;font-weight:500;margin-top:2px}',
    '.client-block{padding:16px 16px 18px;border-bottom:1px solid var(--border);background:rgba(155,174,217,.04)}',
    '.client-label{font-size:10px;text-transform:uppercase;letter-spacing:1.4px;color:var(--text-muted);font-weight:600;opacity:.75;margin-bottom:10px;display:block}',
    '.client-card{display:flex;align-items:center;gap:11px;background:var(--bg-card);border:1px solid var(--border-strong);border-radius:11px;padding:11px 13px}',
    '.client-mark{width:38px;height:38px;border-radius:9px;background:#232323;display:flex;align-items:center;justify-content:center;flex:0 0 auto;overflow:hidden}',
    '.client-mark i{color:#fff;font-size:15px}.client-mark img{width:100%;height:100%;object-fit:contain}',
    '.data-table td.up{color:var(--m7-blue,#9BAED9);font-weight:600}.data-table td.down{color:var(--m7-orange,#F98612);font-weight:600}',
    '.client-name{font-size:14px;font-weight:600;line-height:1.2}',
    '.client-seg{font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.9px;margin-top:2px;font-weight:500}',
    '.nav-menu{list-style:none;padding:14px 12px;flex-grow:1;overflow-y:auto}',
    '.nav-label{font-size:10px;text-transform:uppercase;letter-spacing:1.4px;color:var(--text-muted);padding:10px 12px 8px;font-weight:600;opacity:.75}',
    '.nav-item{display:flex;align-items:center;gap:12px;padding:11px 14px;color:var(--text-sub);border-radius:10px;cursor:pointer;font-size:13.5px;font-weight:500;transition:all .2s ease;margin-bottom:3px;border:1px solid transparent}',
    '.nav-item:hover{background:var(--bg-hover);color:var(--m7-cream)}',
    '.nav-item.active{background:var(--primary-glow);color:var(--m7-orange);border-color:rgba(249,134,18,.35);font-weight:600}',
    '.nav-item i{width:18px;font-size:15px;text-align:center}',
    '.sidebar-footer{padding:16px;border-top:1px solid var(--border);font-size:11.5px;color:var(--text-muted);text-align:center}',
    'main{margin-left:262px;flex-grow:1;padding:26px 34px 60px;max-width:calc(100vw - 262px)}',
    'header.top-bar{display:flex;align-items:center;gap:14px;margin-bottom:24px;padding-bottom:18px;border-bottom:1px solid var(--border)}',
    '.page-title h1{font-size:27px;font-weight:600;display:flex;align-items:center;gap:11px}',
    '.page-title p{color:var(--text-muted);font-size:13px;margin-top:3px}',
    '.aviso{display:flex;gap:12px;align-items:flex-start;background:linear-gradient(135deg,rgba(249,134,18,.10),rgba(155,174,217,.06));border:1px solid rgba(249,134,18,.28);border-radius:14px;padding:18px 20px;margin-bottom:22px;font-size:12.5px;color:var(--text-sub);line-height:1.6}',
    '.aviso i{color:var(--m7-orange);font-size:17px;margin-top:2px}.aviso b{color:var(--m7-orange)}',
    '.view-page{display:none}.view-page.active{display:block;animation:fadeIn .28s ease}',
    '@keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}',
    '.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin-bottom:22px}',
    '.kpi-card{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:20px;position:relative;overflow:hidden}',
    '.kpi-card::before{content:"";position:absolute;top:0;left:0;width:100%;height:3px;background:var(--m7-orange)}',
    '.kpi-card:nth-child(2)::before{background:var(--m7-blue)}.kpi-card:nth-child(3)::before{background:var(--m7-cream)}.kpi-card:nth-child(4)::before{background:linear-gradient(90deg,var(--m7-orange),var(--m7-blue))}',
    '.kpi-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:9px;gap:8px}',
    '.kpi-label{font-size:12px;color:var(--text-muted);font-weight:500}.kpi-icon{font-size:15px;color:var(--text-muted);opacity:.7}',
    '.kpi-value{font-size:16px;font-weight:400;font-style:italic;color:var(--text-muted);line-height:1.6}',
    '.grid-2{display:grid;grid-template-columns:repeat(auto-fit,minmax(440px,1fr));gap:18px;margin-bottom:22px}',
    '.chart-card{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:22px}',
    '.chart-title{font-size:16px;font-weight:600;display:flex;align-items:center;gap:9px;margin-bottom:14px}.chart-title i{color:var(--m7-orange);font-size:15px}',
    '.data-table{width:100%;border-collapse:collapse;font-size:13px}',
    '.data-table td{padding:11px 14px;border-bottom:1px solid var(--border);color:var(--text-sub)}',
    '.data-table tr:last-child td{border-bottom:none}',
    '.wait{color:var(--text-muted);font-style:italic}',
    '.menu-toggle{display:none;flex:0 0 auto;width:42px;height:42px;border-radius:11px;background:var(--bg-card);border:1px solid var(--border-strong);color:var(--m7-orange);font-size:17px;cursor:pointer;align-items:center;justify-content:center}',
    '.sidebar-close{display:none;background:transparent;border:none;color:var(--text-muted);font-size:20px;cursor:pointer;margin-left:auto}',
    '.overlay{display:none;position:fixed;inset:0;z-index:99;background:rgba(12,14,54,.72);backdrop-filter:blur(3px)}.overlay.show{display:block}',
    '.kpi-value.ok{font-size:25px;font-weight:600;font-style:normal;color:var(--m7-cream);line-height:1.25}',
    '.kpi-sub{font-size:11.5px;color:var(--text-muted);margin-top:5px}',
    '.data-table td.v{text-align:right;color:var(--m7-cream);font-weight:600;white-space:nowrap}',
    '.data-table th{padding:9px 14px;text-align:left;font-size:10.5px;text-transform:uppercase;letter-spacing:.8px;color:var(--text-muted);font-weight:600;border-bottom:1px solid var(--border-strong)}',
    '.data-table th.v{text-align:right}',
    '.filtro{display:flex;align-items:flex-end;gap:12px;margin-bottom:20px;flex-wrap:wrap}',
    '.filtro label{display:flex;flex-direction:column;gap:6px;font-size:10.5px;text-transform:uppercase;letter-spacing:1.2px;color:var(--text-muted);font-weight:600}',
    '.filtro select{background:var(--bg-card);color:var(--m7-cream);border:1px solid var(--border-strong);border-radius:10px;padding:10px 14px;font-family:inherit;font-size:13.5px;min-width:200px}',
    '.tabela-scroll{overflow-x:auto;-webkit-overflow-scrolling:touch}.chart-card{min-width:0}',
    '@media (max-width:560px){.grid-2{grid-template-columns:minmax(0,1fr)}.chart-card{padding:16px}.data-table td,.data-table th{padding:9px 8px}.filtro select{min-width:0;width:100%}.filtro label{flex:1}}',
    '.fonte{font-size:11px;color:var(--text-muted);margin-top:10px;opacity:.85}',
    '.tag{display:inline-block;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.6px;border-radius:99px;padding:2px 8px;margin-left:6px;background:rgba(155,174,217,.14);color:var(--text-muted);vertical-align:middle}',
    '@media (max-width:1100px){.grid-2{grid-template-columns:1fr}}',
    '@media (max-width:900px){aside{transform:translateX(-100%);transition:transform .28s cubic-bezier(.4,0,.2,1);width:280px}body.nav-open aside{transform:none;box-shadow:0 0 44px rgba(0,0,0,.55)}main{margin-left:0;max-width:100vw;padding:18px 16px 48px}.menu-toggle{display:flex}.sidebar-close{display:block}.page-title h1{font-size:21px}.kpi-grid{grid-template-columns:repeat(auto-fit,minmax(158px,1fr));gap:12px}}',
    '@media (max-width:560px){.kpi-grid{grid-template-columns:1fr 1fr}}'
  ].join('\n');
  var st = document.createElement('style');
  st.textContent = css;
  document.head.appendChild(st);
  // o tema preto da Mesa7 (m7-tema.css, colocado pelo sistema) precisa vir depois deste estilo
  var tema = document.querySelector('link[href="m7-tema.css"]');
  if (tema) document.head.appendChild(tema);

  // ---------- dados recebidos ----------
  var D = window.M7_DADOS || {};
  var IF = D.ifood || {}, MT = D.meta || {}, FU = D.ifood_funil || {}, CD = D.cardapio || {}, SP = D.saipos || {};
  var GM = D.gmb || {}, GA = D.google || {};   // Google Meu Negócio e Google Ads
  var SL = D.salao || {};   // faturamento do salão (relatório do caixa)
  var MESES_N = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  function mesLbl(id) { var p = id.split('-'); return MESES_N[+p[1] - 1] + '/' + p[0]; }
  function mesCurto(id) { var p = id.split('-'); return MESES_N[+p[1] - 1].slice(0, 3) + '/' + p[0].slice(2); }
  var comDados = Object.keys(IF).concat(Object.keys(MT), Object.keys(FU), Object.keys(CD), Object.keys(SP), Object.keys(GM), Object.keys(GA), Object.keys(SL)).filter(function (m, i, a) { return a.indexOf(m) === i; }).sort();
  // O seletor lista todos os meses, do primeiro com dado até o último mês fechado
  // (ou o último com dado, se for mais recente) — assim o mês corrente do calendário
  // já aparece mesmo quando o cliente ainda não tem número lançado.
  function proxMes(id) { var p = id.split('-'); var y = +p[0], m = +p[1] + 1; if (m > 12) { m = 1; y++; } return y + '-' + (m < 10 ? '0' : '') + m; }
  var hoje = new Date(), pm = hoje.getMonth() === 0 ? (hoje.getFullYear() - 1) + '-12' : hoje.getFullYear() + '-' + (hoje.getMonth() < 10 ? '0' : '') + hoje.getMonth();
  var ini = comDados[0] || pm, fim = comDados.length && comDados[comDados.length - 1] > pm ? comDados[comDados.length - 1] : pm;
  var meses = [];
  for (var mm0 = ini; mm0 <= fim && meses.length < 60; mm0 = proxMes(mm0)) meses.push(mm0);
  meses.reverse();
  var comIfood = meses.filter(function (m) { return IF[m]; });
  // Abre no mês mais recente, pulando o mês que só tem anúncios parciais do Meta
  // (mês em andamento sem faturamento lançado não deve ser o primeiro que o cliente vê).
  var mesSel = meses.filter(function (m) { return SL[m] || SP[m] || IF[m] || CD[m] || (MT[m] && !MT[m].ate); })[0] || meses[0] || null;

  function brl(n) { return 'R$ ' + Number(n || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function num(n) { return Number(n || 0).toLocaleString('pt-BR'); }
  function pct(a, b) { return b ? (a / b * 100).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%' : '—'; }
  function maior(obj) { var k = null; for (var x in obj) if (k === null || obj[x] > obj[k]) k = x; return k; }
  function somaHoras(h) { var o = {}; ['semana', 'fds'].forEach(function (g) { var s = (h || {})[g] || {}; for (var k in s) o[k] = (o[k] || 0) + s[k]; }); return o; }
  // Cardápio próprio: só avisa "até dd/mm" quando o último pedido é antes do fim do mês.
  function ateC(c) { if (!c || !c.ate) return ''; var p = c.mes.split('-'), fim = new Date(+p[0], +p[1], 0).getDate(); return +c.ate.slice(8, 10) < fim ? ate(c) : ''; }
  function ate(m) { return m && m.ate ? ' (até ' + m.ate.split('-').reverse().slice(0, 2).join('/') + ')' : ''; }

  // Delivery próprio: canais do SAIPOS que não são marketplace (ex.: Delivery Vip, Telefone, app próprio);
  // sem SAIPOS, usa o relatório do cardápio próprio.
  function proprio(c, s) {
    var cs = s && s.canais ? s.canais.filter(function (x) { return !/ifood|99/i.test(x.nome); }) : [];
    if (cs.length) {
      var o = 0, r = 0; cs.forEach(function (x) { o += x.o; r += x.r; });
      return { o: o, r: r, det: cs.map(function (x) { return x.nome + ' ' + brl(x.r); }).join(' · ') + (s.canais_estimados ? ' (divisão estimada)' : '') };
    }
    return c ? { o: c.o, r: c.r, det: num(c.o) + ' pedidos · cardápio próprio' } : null;
  }

  // Dias e horários: soma iFood (pedidos) e cardápio próprio (pedidos), quando houver.
  function juntar(a, b, fa, fb) {
    var o = {}, f = [];
    if (a) { for (var k in a) o[k] = (o[k] || 0) + (typeof a[k] === 'number' ? a[k] : a[k].o); f.push(fa); }
    if (b) { for (var j in b) o[j] = (o[j] || 0) + (typeof b[j] === 'number' ? b[j] : b[j].o); f.push(fb); }
    return f.length ? { o: o, fonte: f.join(' + ') } : null;
  }
  function vazio(x) { return !x || !Object.keys(x).length; }
  function diasJuntos(i, c) { return juntar(i && !vazio(i.dias) ? i.dias : null, c && !vazio(c.dias) ? c.dias : null, 'iFood', 'cardápio próprio'); }
  function horasJuntas(i, c) { var h = i && somaHoras(i.horas); return juntar(!vazio(h) ? h : null, c && !vazio(c.horas) ? c.horas : null, 'iFood', 'cardápio próprio'); }

  // Faturamento total do mês (mesma regra de VAL.fat): salão + delivery; sem salão, o SAIPOS.
  function totalMes(id) {
    var l = SL[id], sp = SP[id], i = IF[id], c = CD[id];
    if (!l) return sp ? sp.r : null;
    return l.r + (sp ? sp.r : (i ? i.r : 0) + (c ? c.r : 0));
  }
  // Itens do mês para a Curva ABC: os do cardápio próprio ou, sem eles, o relatório de produtos (D.itens, ex.: PDV/SAIPOS).
  var ITS = D.itens || {};
  function abcMes(id) {
    var c = CD[id]; if (c && c.itens && c.itens.length) return c;
    var x = ITS[id]; if (!x || !x.itens || !x.itens.length) return c || null;
    return { itens: x.itens.map(function (k) { return { nome: k.n, qtd: k.q, r: k.v }; }).sort(function (a, b) { return b.r - a.r; }), prod: x.total, origem: x.origem || 'relatório de produtos', ate: x.ate };
  }
  function fontesMes(id) { var f = []; if (SL[id]) f.push('salão'); if (SP[id]) f.push('SAIPOS'); else { if (IF[id]) f.push('iFood'); if (CD[id]) f.push('delivery próprio'); } return f; }
  function mesAnt(id) { var p = id.split('-'); var y = +p[0], m = +p[1] - 1; if (m < 1) { m = 12; y--; } return y + '-' + (m < 10 ? '0' : '') + m; }
  // Série completa para o card "Histórico de faturamento" (m7-historico.js): todo mês com faturamento, com a mesma regra do resumo.
  window.m7Historico = function () {
    return comDados.map(function (id) {
      var t = totalMes(id); if (t == null || !(t > 0)) return null;
      return { id: id, r: t, parcial: !!((SP[id] && SP[id].ate) || (SL[id] && SL[id].ate)), fonte: null };
    }).filter(Boolean);
  };

  // Cada chave devolve {v, sub} quando há dado no mês, ou null (Aguardando dados).
  var VAL = {
    ifood_r: function (i) { return i && { v: brl(i.r), sub: num(i.o) + ' pedidos · ticket ' + brl(i.t) }; },
    ifood_o: function (i) { return i && { v: num(i.o), sub: num(i.novos) + ' clientes novos' }; },
    ifood_t: function (i) { return i && { v: brl(i.t), sub: 'ticket médio no iFood' }; },
    abc_vol: function (i, m, c) { var x = c && c.itens && c.itens.slice().sort(function (a, b) { return b.qtd - a.qtd; })[0]; return x && { v: x.nome, sub: num(x.qtd) + ' vendidos ' + (c.origem ? 'no ' + c.origem : 'no cardápio próprio') }; },
    abc_fat: function (i, m, c) { var l = c && c.itens && c.itens.filter(function (x) { return x.r; }); if (!l || !l.length) return null; var x = l.slice().sort(function (a, b) { return b.r - a.r; })[0]; return { v: x.nome, sub: brl(x.r) + (c.prod ? ' · ' + pct(x.r, c.prod) + ' das vendas de produtos' : '') }; },
    abc_sab: function (i, m, c) { var x = c && c.sabores && c.sabores[0]; return x && { v: x.nome, sub: num(Math.round(x.qtd)) + ' pizzas (somando meias e terços)' }; },
    abc_top5: function (i, m, c) { if (c && c.prod && c.itens && c.itens.length && c.itens[0].r) { var s5 = c.itens.slice().sort(function (a, b) { return b.r - a.r; }).slice(0, 5).reduce(function (t, x) { return t + x.r; }, 0); return { v: pct(s5, c.prod), sub: 'das vendas de produtos ' + (c.origem ? '' : 'do delivery próprio ') + 'em 5 itens' }; } if (!c || !c.itens || !c.itens.length) return null; var t = 0, s5 = 0; c.itens.forEach(function (x, k) { t += x.qtd; if (k < 5) s5 += x.qtd; }); return { v: pct(s5, t), sub: 'das unidades entre os 15 itens mais pedidos' }; },
    dp_r: function (i, m, c, s) { var d = proprio(c, s); return d && { v: brl(d.r), sub: d.det }; },
    dp_o: function (i, m, c, s) { var d = proprio(c, s); return d && { v: num(d.o), sub: 'pedidos no delivery próprio' }; },
    dp_t: function (i, m, c, s) { var d = proprio(c, s); return d && d.o ? { v: brl(d.r / d.o), sub: 'ticket médio do delivery próprio' } : null; },
    pdv_r: function (i, m, c, s) { return s && { v: brl(s.r), sub: 'delivery no SAIPOS (sem salão)' + ate(s) }; },
    pdv_o: function (i, m, c, s) { return s && { v: num(s.o), sub: 'pedidos no SAIPOS, sem cancelados' + ate(s) }; },
    pdv_t: function (i, m, c, s) { return s && { v: brl(s.t), sub: 'faturamento ÷ pedidos no SAIPOS' }; },
    pdv_mix: function (i, m, c, s) { if (!s || !s.r) return null; var p = []; if (i && i.r) p.push('iFood ' + pct(i.r, s.r)); if (c && c.r) p.push('próprio ' + pct(c.r, s.r)); return p.length ? { v: p.join(' · '), sub: 'participação nas vendas do SAIPOS' } : null; },
    car_r: function (i, m, c) { return c && { v: brl(c.r), sub: num(c.o) + ' pedidos · ticket ' + brl(c.t) + ateC(c) }; },
    car_o: function (i, m, c) { if (c && c.formato === 'resumo' && !c.del.o && !c.ret.o) return { v: num(c.o), sub: 'pedidos no app/site próprio' }; return c && { v: num(c.o), sub: 'delivery ' + num(c.del.o) + ' · retirada ' + num(c.ret.o) + (c.mesa.o + c.local.o ? ' · salão ' + num(c.mesa.o + c.local.o) : '') }; },
    car_t: function (i, m, c) { return c && { v: brl(c.t), sub: c.canc && c.canc.o ? num(c.canc.o) + ' cancelados fora da conta' : 'ticket médio no cardápio próprio' }; },
    mkt: function (i, m, c, s) { if (i) return { v: brl(i.r), sub: 'iFood · ' + num(i.o) + ' pedidos' }; var x = s && s.canais && s.canais.filter(function (k) { return /ifood|99/i.test(k.nome); }); if (!x || !x.length) return null; var o = 0, r = 0; x.forEach(function (k) { o += k.o; r += k.r; }); return { v: brl(r), sub: 'iFood no SAIPOS · ' + num(o) + ' pedidos' }; },
    // Faturamento total = salão + delivery. Delivery = SAIPOS (que já inclui o iFood) ou, sem SAIPOS,
    // iFood + cardápio próprio. Sem salão lançado, segue só o delivery do SAIPOS, como antes.
    fat: function (i, m, c, s) {
      var l = SL[mesSel];
      if (!l) return s ? VAL.pdv_r(i, m, c, s) : null;
      var p = ['salão ' + brl(l.r)], t = l.r;
      if (s) { p.push('delivery ' + brl(s.r)); t += s.r; }
      else { if (i) { p.push('iFood ' + brl(i.r)); t += i.r; } if (c) { p.push('delivery próprio ' + brl(c.r)); t += c.r; } }
      return { v: brl(t), sub: p.join(' + ') + (p.length === 1 && visivel('delivery') ? ' · delivery do mês ainda não lançado' : '') + ate(l) };
    },
    fat_mes: function (i, m, c, s) { return VAL.fat(i, m, c, s); },
    fat_mom: function () {
      var a = totalMes(mesSel), ant = mesAnt(mesSel), b = totalMes(ant);
      if (a == null || !b) return null;
      var d = (a - b) / b * 100;
      // Avisa quando um mês tem fonte que o outro não tem (ex.: iFood ainda não lançado).
      var fa = fontesMes(mesSel), fb = fontesMes(ant), dif = fa.filter(function (x) { return fb.indexOf(x) < 0; }).map(function (x) { return x + ' só em ' + mesCurto(mesSel); })
        .concat(fb.filter(function (x) { return fa.indexOf(x) < 0; }).map(function (x) { return x + ' só em ' + mesCurto(ant); }));
      return { v: (d > 0 ? '+' : '') + d.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '% vs ' + mesCurto(ant) + (dif.length ? ' (parcial: ' + dif.join(', ') + ')' : ''), sub: 'vs ' + mesCurto(ant) + ' (' + brl(b) + ')' };
    },
    deliv: function (i, m, c, s) { if (s) return { v: brl(s.r), sub: (s.fonte || 'SAIPOS') + ate(s) }; if (!i && !c) return null; var p = []; if (i) p.push('iFood ' + brl(i.r)); if (c) p.push('próprio ' + brl(c.r)); return { v: brl((i ? i.r : 0) + (c ? c.r : 0)), sub: p.join(' + ') }; },
    ped: function (i, m, c, s) { var l = SL[mesSel]; if (!l && s) return VAL.pdv_o(i, m, c, s); return l && l.vis ? { v: num(l.vis), sub: (l.un || 'visitas no salão') + (l.p ? ' · ' + num(l.p) + ' pessoas' : '') + ate(l) } : null; },
    tkt: function (i, m, c, s) { var l = SL[mesSel]; if (!l && s) return VAL.pdv_t(i, m, c, s); return l && l.t ? { v: brl(l.t), sub: l.un ? 'por ' + l.un.replace(/s$/, '') + ' (faturamento ÷ ' + l.un + ')' : 'por pessoa no salão' } : null; },
    mix: function (i, m, c, s) { var l = SL[mesSel]; if (!l) return s ? VAL.pdv_mix(i, m, c, s) : null; var d = s ? s.r : (i ? i.r : 0) + (c ? c.r : 0), t = l.r + d; return d ? { v: 'salão ' + pct(l.r, t) + ' · delivery ' + pct(d, t), sub: 'participação no faturamento' } : { v: 'salão 100%', sub: 'delivery do mês ainda não lançado' }; },
    sal_r: function () { var l = SL[mesSel]; return l && { v: brl(l.r), sub: (l.vis ? num(l.vis) + ' ' + (l.un || 'visitas') + ' · ' : '') + (l.p ? num(l.p) + ' pessoas · ' : '') + (l.obs ? l.obs : l.g ? 'inclui ' + brl(l.g) + ' de gorjeta' : 'com gorjeta') + ate(l) }; },
    meta_gas: function (i, m) { return m && { v: brl(m.gas), sub: 'Meta Ads' + ate(m) }; },
    // Mídia paga do mês: Meta Ads + Google Ads (o que houver).
    midia: function (i, m) { var g = GA[mesSel]; if (!m && !g) return null; var p = []; if (m) p.push('Meta ' + brl(m.gas)); if (g) p.push('Google ' + brl(g.i)); return { v: brl((m ? m.gas : 0) + (g ? g.i : 0)), sub: p.join(' + ') + ate(m) }; },
    goo_i: function () { var g = GA[mesSel]; return g && { v: brl(g.i), sub: (g.clk ? num(g.clk) + ' cliques' : '') + (g.clk && g.i ? ' · CPC ' + brl(g.i / g.clk) : '') + ate(g) }; },
    goo_c: function () { var g = GA[mesSel]; return g && g.c != null ? { v: num(g.c), sub: 'custo por conversão ' + brl(g.cpa || (g.c ? g.i / g.c : 0)) + (g.clk ? ' · taxa ' + pct(g.c, g.clk) : '') } : null; },
    gmb_v: function () { var g = GM[mesSel]; return g && { v: num(g.v), sub: 'interações no perfil do Google' + (g.cd ? ' · ' + num(g.cd) + ' no cardápio' : '') }; },
    gmb_rt: function () { var g = GM[mesSel]; return g && { v: num(g.rt), sub: num(g.st) + ' cliques no site' }; },
    gmb_ch: function () { var g = GM[mesSel]; return g && { v: num(g.ch), sub: g.ct != null ? num(g.ct) + ' cliques no chat' : 'ligações pelo perfil' }; },
    dep_ifood: function () { var x = ifoodMes(mesSel), t = totalMes(mesSel); return x && t ? { v: pct(x.r, t), sub: 'iFood ' + brl(x.r) + (x.o ? ' · ' + num(x.o) + ' pedidos' : '') } : null; },
    nota: function () { return C.nota ? { v: Number(C.nota).toLocaleString('pt-BR', { minimumFractionDigits: 1 }) + ' ★', sub: 'Google Meu Negócio' } : null; },
    meta_alc: function (i, m) { return m && { v: num(m.alc), sub: num(m.imp) + ' impressões' }; },
    meta_clk: function (i, m) { return m && { v: num(m.clk), sub: m.clk ? 'custo por clique ' + brl(m.gas / m.clk) : '' }; },
    meta_cmp: function (i, m) { return m && (m.cmp ? { v: num(m.cmp), sub: 'valor atribuído ' + brl(m.fat) } : { v: '0', sub: 'sem compras rastreadas pelo pixel' }); },
    dia: function (i, m, c) { var d = diasJuntos(i, c), k = d && maior(d.o); return k && { v: k, sub: num(d.o[k]) + ' pedidos · ' + d.fonte }; },
    tkt_dia: function (i, m, c) { if (!c || !c.dias) return null; var k = null, t = 0; for (var x in c.dias) { var v = c.dias[x].o ? c.dias[x].r / c.dias[x].o : 0; if (v > t) { t = v; k = x; } } return k && { v: k, sub: brl(t) + ' por pedido no cardápio próprio' }; },
    pico: function (i, m, c) { var h = horasJuntas(i, c), k = h && maior(h.o); return k && { v: k, sub: num(h.o[k]) + ' pedidos · ' + h.fonte }; },
    fds: function (i, m, c) { var d = diasJuntos(i, c); if (!d) return null; var t = 0, f = 0; for (var k in d.o) { t += d.o[k]; if (/sexta|s.bado|domingo/i.test(k)) f += d.o[k]; } return t ? { v: pct(f, t), sub: 'dos pedidos · ' + d.fonte } : null; }
  };

  var PAGES = [
    { id: 'p1', icon: 'fa-gauge-high', t: 'Resumo Executivo', s: 'Visão rápida de performance e saúde financeira em 30 segundos.',
      kpis: [['Faturamento', 'fa-sack-dollar', 'fat'], ['Pedidos', 'fa-bag-shopping', 'ped'], ['Ticket Médio', 'fa-receipt', 'tkt'], ['Mix de Canais', 'fa-layer-group', 'mix']],
      recebidos: true,
      cards: [['Evolução de Faturamento', 'fa-chart-line', [['Faturamento mensal', 'fat_mes'], ['Comparativo vs mês anterior', 'fat_mom']]], ['Comparativo de Período', 'fa-scale-balanced', [['Faturamento Total', 'fat'], ['Salão / Loja', 'sal_r'], ['Delivery', 'deliv'], ['Invest. Mídia', 'midia']]]] },
    { id: 'p2', icon: 'fa-filter', t: 'Método CVR', s: 'Conversão, Valor e Relacionamento do restaurante.',
      cards: [['1. Conversão', 'fa-filter', [['Investimento em Mídia', 'midia'], ['Alcance (Meta Ads)', 'meta_alc'], ['Cliques no Link', 'meta_clk'], ['Compras Atribuídas', 'meta_cmp']]], ['2. Valor · Google Meu Negócio', 'fa-star', [['Interações no Perfil', 'gmb_v'], ['Solicitações de Rota', 'gmb_rt'], ['Chamadas Telefônicas', 'gmb_ch'], ['Nota Média Atual', 'nota']]]] },
    { id: 'p3', icon: 'fa-chart-pie', t: 'Financeiro & Canais', s: 'Composição do faturamento por canal.',
      kpis: [['Salão / Loja', 'fa-utensils', 'sal_r'], ['Delivery Próprio', 'fa-motorcycle', 'dp_r'], ['Marketplace', 'fa-shop', 'mkt'], ['Faturamento Total', 'fa-chart-simple', 'fat']],
      canaisDet: true },
    { id: 'p4', icon: 'fa-bag-shopping', t: 'Marketplace', s: 'iFood e 99Food: faturamento, pedidos e ticket médio.',
      kpis: [['iFood', 'fa-bowl-food', 'ifood_r'], ['99Food', 'fa-motorcycle'], ['Pedidos iFood', 'fa-bag-shopping', 'ifood_o'], ['Ticket Médio iFood', 'fa-receipt', 'ifood_t']],
      ifoodDet: true, mkt12: true },
    { id: 'p4d', icon: 'fa-motorcycle', t: 'Delivery', s: 'Delivery próprio: Cardápio Web, Anota Aí, site e WhatsApp — sem comissão de marketplace.',
      kpis: [['Delivery Próprio', 'fa-motorcycle', 'dp_r'], ['Cardápio próprio', 'fa-mobile-screen', 'car_r'], ['Pedidos Delivery Próprio', 'fa-bowl-food', 'dp_o'], ['Ticket Delivery Próprio', 'fa-receipt', 'dp_t']],
      canaisDet: true,
      carDet: true },
    { id: 'p5', icon: 'fa-bullhorn', t: 'Marketing 360°', s: 'Meta Ads, Google Ads e Google Meu Negócio.',
      cards: [['Meta Ads', 'fa-hashtag', [['Investimento', 'meta_gas'], ['Alcance', 'meta_alc'], ['Cliques no Link', 'meta_clk'], ['Compras Atribuídas', 'meta_cmp'], ['Seguidores']]], ['Google Ads & Meu Negócio', 'fa-magnifying-glass', [['Investimento Google Ads', 'goo_i'], ['Conversões', 'goo_c'], ['Interações no Perfil', 'gmb_v'], ['Solicitações de Rota', 'gmb_rt'], ['Chamadas Telefônicas', 'gmb_ch']].concat(C.nota ? [['Nota Google', 'nota']] : [])]],
      metaHist: true },
    { id: 'p6', icon: 'fa-utensils', t: 'Cardápio & ABC', s: 'Engenharia de menu e ranking dos itens mais vendidos.',
      kpis: [['Maior Faturamento', 'fa-crown', 'abc_fat'], ['Maior Volume', 'fa-ranking-star', 'abc_vol'], ['Sabor Mais Pedido', 'fa-pizza-slice', 'abc_sab'], ['Concentração Top 5', 'fa-layer-group', 'abc_top5']],
      abcDet: true },
    { id: 'p7', icon: 'fa-clock', t: 'Comportamento', s: 'Quando o cliente compra ao longo da semana e do dia.',
      kpis: [['Melhor Dia', 'fa-star', 'dia'], ['Melhor Ticket', 'fa-receipt', 'tkt_dia'], ['Horário de Pico', 'fa-clock', 'pico'], ['Concentração Sex–Dom', 'fa-fire', 'fds']] },
    { id: 'p8', icon: 'fa-bullseye', t: 'Metas 30/60/90', s: 'Planejamento estratégico organizado pelo Método CVR.',
      cards: [['30 dias · Organização', 'fa-layer-group', [['Conversão'], ['Valor'], ['Relacionamento']]], ['60 dias · Otimização', 'fa-sliders', [['Conversão'], ['Valor'], ['Relacionamento']]], ['90 dias · Escala', 'fa-rocket', [['Conversão'], ['Valor'], ['Relacionamento']]]] }
  ];
  // CLIENTE.ocultar com 'delivery' / 'marketplace' tira também as páginas inteiras.
  PAGES = PAGES.filter(function (p) { return !((p.id === 'p4d' && !visivel('delivery')) || (p.id === 'p4' && !visivel('marketplace'))); });
  if (!visivel('99food')) PAGES.forEach(function (p) { p.s = p.s.replace('iFood e 99Food', 'iFood'); });

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var WAIT = '<span class="wait">Aguardando dados</span>';

  function valor(chave) {
    if (!chave || !mesSel || !VAL[chave]) return null;
    return VAL[chave](IF[mesSel], MT[mesSel], /^abc_/.test(chave) ? abcMes(mesSel) : CD[mesSel], SP[mesSel]) || null;
  }
  function kpi(k) {
    var r = valor(k[2]);
    return '<div class="kpi-card"><div class="kpi-header"><span class="kpi-label">' + esc(k[0]) + '</span><i class="fa-solid ' + k[1] + ' kpi-icon"></i></div>' +
      (r ? '<div class="kpi-value ok">' + esc(r.v) + '</div>' + (r.sub ? '<div class="kpi-sub">' + esc(r.sub) + '</div>' : '') : '<div class="kpi-value">Aguardando dados</div>') + '</div>';
  }
  function linha(r) {
    var x = valor(r[1]);
    return '<tr><td>' + esc(r[0]) + '</td>' + (x ? '<td class="v">' + esc(x.v) + '</td>' : '<td>' + WAIT + '</td>') + '</tr>';
  }
  function card(titulo, icone, corpo, rodape) {
    return '<div class="chart-card"><div class="chart-title"><i class="fa-solid ' + icone + '"></i> ' + titulo + '</div><div class="tabela-scroll">' + corpo + '</div>' + (rodape ? '<div class="fonte">' + esc(rodape) + '</div>' : '') + '</div>';
  }

  function recebidos() {
    var i = IF[mesSel], m = MT[mesSel];
    if (!i && !m) return '';
    return '<div class="kpi-grid">' + [
      ['iFood · Faturamento', 'fa-bowl-food', 'ifood_r'], ['iFood · Pedidos', 'fa-bag-shopping', 'ifood_o'],
      ['Investimento Meta Ads', 'fa-hashtag', 'meta_gas'], ['Alcance Meta Ads', 'fa-users', 'meta_alc']
    ].map(kpi).join('') + '</div>';
  }


  // Cardápio próprio (Relatório de Pedidos do Cardápio Web): tipos de pedido e origens.
  function cardapioDetalhe() {
    var c = CD[mesSel];
    if (!c) return '';
    var tipos = [['Delivery', c.del], ['Retirada', c.ret], ['Mesa / comanda', c.mesa], ['Consumo no local', c.local]].filter(function (t) { return t[1] && t[1].o; });
    var tab1 = '<table class="data-table"><thead><tr><th>Tipo de pedido</th><th class="v">Pedidos</th><th class="v">Faturamento</th><th class="v">Ticket</th></tr></thead><tbody>' +
      tipos.map(function (t) { return '<tr><td>' + t[0] + '</td><td class="v">' + num(t[1].o) + '</td><td class="v">' + brl(t[1].r) + '</td><td class="v">' + brl(t[1].r / t[1].o) + '</td></tr>'; }).join('') +
      (c.frete ? '<tr><td>Taxa de entrega cobrada</td><td></td><td class="v">' + brl(c.frete) + '</td><td></td></tr>' : '') +
      (c.canc && c.canc.o ? '<tr><td>Cancelados (fora do total)</td><td class="v">' + num(c.canc.o) + '</td><td class="v">' + brl(c.canc.r) + '</td><td></td></tr>' : '') + '</tbody></table>';
    var ks = Object.keys(c.orig || {}).sort(function (a, b) { return c.orig[b].r - c.orig[a].r; });
    var fonte = (c.formato === 'detalhado' ? 'Fonte: relatório de pedidos do app/site próprio · ' : c.formato === 'resumo' ? 'Fonte: painel do cardápio próprio · ' : 'Fonte: Relatório de Pedidos do Cardápio Web · ') + mesLbl(mesSel) + ateC(c);
    if (!tipos.length) tab1 = '<table class="data-table"><tbody><tr><td>Pedidos</td><td class="v">' + num(c.o) + '</td></tr><tr><td>Faturamento</td><td class="v">' + brl(c.r) + '</td></tr><tr><td>Ticket médio</td><td class="v">' + brl(c.t) + '</td></tr></tbody></table>';
    var h = card('Cardápio próprio · ' + esc(mesLbl(mesSel)), 'fa-mobile-screen', tab1, fonte);
    if (ks.length) {
      var tab2 = '<table class="data-table"><thead><tr><th>Origem do pedido</th><th class="v">Pedidos</th><th class="v">Faturamento</th><th class="v">%</th></tr></thead><tbody>' +
        ks.map(function (k) { return '<tr><td>' + esc(k) + '</td><td class="v">' + num(c.orig[k].o) + '</td><td class="v">' + brl(c.orig[k].r) + '</td><td class="v">' + pct(c.orig[k].r, c.r) + '</td></tr>'; }).join('') + '</tbody></table>';
      h += card('Cardápio próprio · De onde vêm os pedidos', 'fa-share-nodes', tab2, fonte);
    }
    return '<div class="grid-2">' + h + '</div>';
  }

  // Vendas por canal no mês (SAIPOS).
  function canaisDetalhe() {
    var s = SP[mesSel];
    if (!s || !s.canais || !s.canais.length) return '';
    // r_saipos: o faturamento do mês veio de outro relatório (s.fonte); a tabela fecha com o total do SAIPOS.
    var base = s.r_saipos || s.r;
    var lin = s.canais.slice().sort(function (a, b) { return b.r - a.r; }).map(function (x) {
      return '<tr><td>' + esc(x.nome) + '</td><td class="v">' + num(x.o) + '</td><td class="v">' + brl(x.r) + '</td><td class="v">' + brl(x.o ? x.r / x.o : 0) + '</td><td class="v">' + pct(x.r, base) + '</td></tr>';
    }).join('');
    var t = '<table class="data-table"><thead><tr><th>Canal</th><th class="v">Pedidos</th><th class="v">Faturamento</th><th class="v">Ticket</th><th class="v">%</th></tr></thead><tbody>' + lin +
      '<tr><td><strong>Total' + (s.r_saipos ? ' no SAIPOS' : '') + '</strong></td><td class="v"><strong>' + num(s.o) + '</strong></td><td class="v"><strong>' + brl(base) + '</strong></td><td class="v"><strong>' + brl(s.t) + '</strong></td><td class="v"><strong>100%</strong></td></tr>' +
      (s.r_saipos ? '<tr><td>Faturamento do delivery · ' + esc(s.fonte || 'relatório do mês') + '</td><td class="v">—</td><td class="v">' + brl(s.r) + '</td><td class="v">—</td><td class="v">—</td></tr>' : '') + '</tbody></table>';
    var fonte = 'Fonte: Acompanhamento de vendas do SAIPOS (delivery) · ' + mesLbl(mesSel) + ate(s) + (s.canais_estimados ? ' · total do mês exato; divisão por canal estimada pelo gráfico do relatório' : '');
    return '<div class="grid-2">' + card('Vendas por canal · ' + esc(mesLbl(mesSel)), 'fa-layer-group', t, fonte) + '</div>';
  }

  // Ranking por quantidade (relatório detalhado do cardápio próprio).
  function rankingItens() {
    var c = abcMes(mesSel);
    if (!c || !(c.itens && c.itens.length)) return '';
    var comR = c.itens.some(function (x) { return x.r; });
    var tab = function (lista, rot, valor) {
      return '<table class="data-table"><thead><tr><th>#</th><th>' + rot + '</th><th class="v">Qtd.</th>' + (valor ? '<th class="v">Faturamento</th><th class="v">%</th>' : '') + '</tr></thead><tbody>' +
        lista.slice(0, 15).map(function (x, k) { return '<tr><td>' + (k + 1) + '</td><td>' + esc(x.nome) + '</td><td class="v">' + num(Math.round(x.qtd * 10) / 10) + '</td>' + (valor ? '<td class="v">' + brl(x.r) + '</td><td class="v">' + (c.prod ? pct(x.r, c.prod) : '—') + '</td>' : '') + '</tr>'; }).join('') + '</tbody></table>';
    };
    var fonte = c.origem
      ? 'Fonte: ' + c.origem + ' · ' + mesLbl(mesSel) + ' · por faturamento · % sobre ' + brl(c.prod) + ' em produtos'
      : comR
      ? 'Fonte: painel do delivery próprio · ' + mesLbl(mesSel) + ' · por faturamento' + (c.prod ? ' · % sobre ' + brl(c.prod) + ' em produtos' : '') + (c.itensParcial ? ' · mostra só os primeiros itens do ranking' : '')
      : 'Fonte: relatório de pedidos do cardápio próprio · ' + mesLbl(mesSel) + ' · por quantidade (o relatório não traz o valor por item)';
    var h = card(comR ? 'Itens que mais venderam' : 'Itens mais pedidos', 'fa-ranking-star', tab(c.itens, 'Item', comR), fonte);
    if (c.sabores && c.sabores.length) h += card('Sabores mais pedidos', 'fa-pizza-slice', tab(c.sabores, 'Sabor'), 'Meia pizza conta 0,5 e um terço conta 0,33 · ' + mesLbl(mesSel));
    return '<div class="grid-2">' + h + '</div>';
  }


  // Marketplaces · últimos 12 meses: linha com área (SVG, sem biblioteca), mesmo estilo da Evolução de Faturamento.
  function mkt12() {
    if (!comIfood.length || !mesSel) return '';
    var asc = meses.slice().reverse().filter(function (m) { return m <= mesSel; });
    var jan = asc.slice(-12);
    if (!jan.length) return '';
    var W = 640, H = 260, L = 52, R = 14, T = 14, B = 34;
    var vals = jan.map(function (m) { return IF[m] ? IF[m].r : null; });
    var max = Math.max.apply(null, vals.map(function (v) { return v || 0; })) || 1;
    var passo = Math.pow(10, Math.floor(Math.log10(max))), topo = Math.ceil(max / passo) * passo;
    if (topo / passo < 2) topo = passo * 2;
    var X = function (i) { return jan.length === 1 ? (L + (W - L - R) / 2) : L + (W - L - R) * i / (jan.length - 1); };
    var Y = function (v) { return T + (H - T - B) * (1 - v / topo); };
    var g = '';
    for (var k = 0; k <= 4; k++) {
      var v = topo * k / 4, y = Y(v);
      g += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '" stroke="rgba(155,174,217,.12)"/><text x="' + (L - 8) + '" y="' + (y + 4) + '" text-anchor="end" fill="#9BAED9" font-size="11">R$ ' + (v >= 1000 ? (v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + 'k' : v) + '</text>';
    }
    var seg = [], atual = [];
    vals.forEach(function (v, i) { if (v === null) { if (atual.length) seg.push(atual); atual = []; } else atual.push([X(i), Y(v)]); });
    if (atual.length) seg.push(atual);
    var linhas = '', area = '';
    seg.forEach(function (pts) {
      // curva suave (Catmull-Rom → Bézier), igual ao tension do gráfico principal
      var d = 'M' + pts[0][0] + ',' + pts[0][1];
      for (var i = 0; i < pts.length - 1; i++) {
        var p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2, t = .35;
        d += ' C' + (p1[0] + (p2[0] - p0[0]) * t / 1.5) + ',' + (p1[1] + (p2[1] - p0[1]) * t / 1.5) + ' ' + (p2[0] - (p3[0] - p1[0]) * t / 1.5) + ',' + (p2[1] - (p3[1] - p1[1]) * t / 1.5) + ' ' + p2[0] + ',' + p2[1];
      }
      linhas += '<path d="' + d + '" fill="none" stroke="#F98612" stroke-width="2.5"/>';
      if (pts.length > 1) area += '<path d="' + d + ' L' + pts[pts.length - 1][0] + ',' + Y(0) + ' L' + pts[0][0] + ',' + Y(0) + ' Z" fill="rgba(249,134,18,.14)"/>';
    });
    var pontos = '', rotulos = '';
    jan.forEach(function (m, i) {
      var x = X(i);
      rotulos += '<text x="' + x + '" y="' + (H - 12) + '" text-anchor="middle" fill="#9BAED9" font-size="11">' + esc(mesCurto(m)) + '</text>';
      if (vals[i] !== null) {
        var o = IF[m];
        pontos += '<circle cx="' + x + '" cy="' + Y(vals[i]) + '" r="4" fill="#F98612"><title>' + esc(mesLbl(m)) + ' · ' + esc(brl(o.r)) + ' · ' + num(o.o) + ' pedidos · ticket ' + esc(brl(o.t)) + '</title></circle>';
      }
    });
    var svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Faturamento do iFood nos últimos 12 meses" style="display:block;max-height:300px">' + g + area + linhas + pontos + rotulos + '</svg>';
    var leg = '<div style="display:flex;justify-content:center;gap:8px;align-items:center;margin-top:8px;font-size:12px;color:var(--m7-cream)"><span style="width:10px;height:10px;border-radius:50%;background:#F98612;display:inline-block"></span>iFood</div>';
    return '<div class="grid-2"><div class="chart-card" style="grid-column:1/-1"><div class="chart-title"><i class="fa-solid fa-bag-shopping"></i> Marketplaces · últimos 12 meses</div>' + svg + leg +
      '<div class="fonte">Faturamento do iFood mês a mês (relatório do Portal do Parceiro). Meses sem relatório ficam em branco. Passe o mouse nos pontos para ver pedidos e ticket médio.</div></div></div>';
  }

  function metaHistorico() {
    var ms = Object.keys(MT).sort().reverse();
    if (!ms.length) return '';
    var linhas = ms.map(function (id) {
      var m = MT[id];
      return '<tr><td>' + esc(mesCurto(id)) + (m.ate ? '<span class="tag">parcial</span>' : '') + '</td><td class="v">' + brl(m.gas) + '</td><td class="v">' + num(m.alc) + '</td><td class="v">' + num(m.clk) + '</td><td class="v">' + (m.clk ? brl(m.gas / m.clk) : '—') + '</td>' + (visivel('compras') ? '<td class="v">' + num(m.cmp) + '</td>' : '') + '</tr>';
    }).join('');
    var t = '<table class="data-table"><thead><tr><th>Mês</th><th class="v">Investimento</th><th class="v">Alcance</th><th class="v">Cliques</th><th class="v">CPC</th>' + (visivel('compras') ? '<th class="v">Compras</th>' : '') + '</tr></thead><tbody>' + linhas + '</tbody></table>';
    return '<div class="grid-2">' + card('Meta Ads · mês a mês', 'fa-calendar', t, 'Fonte: integração Meta Ads da Mesa7') + '</div>';
  }

  function aviso() {
    var tem = [];
    if (comIfood.length) tem.push('iFood (' + comIfood.slice().reverse().map(mesCurto).join(', ') + ')');
    var mm = Object.keys(MT).sort();
    if (mm.length) tem.push('Meta Ads (' + (mm.length > 1 ? mesCurto(mm[0]) + ' a ' + mesCurto(mm[mm.length - 1]) : mesCurto(mm[0])) + ')');
    if (!tem.length) return '<div class="aviso"><i class="fa-solid fa-circle-info"></i><div><b>Dados a caminho.</b> Os indicadores de ' + esc(C.nome) + ' aparecem aqui assim que os dados do cliente forem enviados à Mesa7 (faturamento, iFood, Meta Ads, Google e CRM).</div></div>';
    return '<div class="aviso"><i class="fa-solid fa-circle-info"></i><div><b>Dados recebidos:</b> ' + esc(tem.join(' e ')) + '. Faturamento de salão e delivery próprio, Google e CRM aparecem aqui assim que chegarem.</div></div>';
  }

  // ---------- Resumo Executivo no padrão dos dashboards completos ----------
  // Liga quando o cliente tem faturamento lançado (salão e/ou SAIPOS): destaque grande,
  // gráfico de evolução e comparativo com o mês anterior.
  var temFat = meses.some(function (m) { return totalMes(m) != null; });
  function delivMes(id) { var sp = SP[id], i = IF[id], c = CD[id]; if (sp) return sp.r; if (!i && !c) return null; return (i ? i.r : 0) + (c ? c.r : 0); }
  function midiaMes(id) { var m = MT[id], g = GA[id]; if (!m && !g) return null; return (m ? m.gas : 0) + (g ? g.i : 0); }
  function variacao(a, b) { if (a == null || !b) return null; var d = (a - b) / b * 100; return { t: (d > 0 ? '+' : '') + d.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%', c: Math.abs(d) < 0.05 ? 'flat' : d > 0 ? 'up' : 'down' }; }
  // Últimos 12 meses até o selecionado, começando no primeiro mês com faturamento.
  function janela12() { var j = meses.slice().reverse().filter(function (m) { return m <= mesSel; }).slice(-12); while (j.length > 1 && totalMes(j[0]) == null) j.shift(); return j; }

  // Linha suave com área (SVG puro), no estilo dos gráficos de Chart.js dos dashboards completos.
  function grafLinha(jan, vals, dica, aria, opt) {
    opt = opt || {};
    var W = opt.W || 640, H = opt.H || 260, L = opt.semEixo ? 0 : 52, R = opt.semEixo ? 0 : 14, T = opt.semEixo ? 14 : 44, B = opt.semEixo ? 0 : 34;
    var max = Math.max.apply(null, vals.map(function (v) { return v || 0; })) || 1;
    var passo = Math.pow(10, Math.floor(Math.log10(max))), topo = Math.ceil(max / passo) * passo;
    if (topo / passo < 2) topo = passo * 2;
    var X = function (i) { return jan.length === 1 ? (L + (W - L - R) / 2) : L + (W - L - R) * i / (jan.length - 1); };
    var Y = function (v) { return T + (H - T - B) * (1 - v / topo); };
    var g = '';
    if (!opt.semEixo) for (var k = 0; k <= 4; k++) {
      var v = topo * k / 4, y = Y(v);
      g += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '" stroke="rgba(155,174,217,.12)"/><text x="' + (L - 8) + '" y="' + (y + 4) + '" text-anchor="end" fill="#9BAED9" font-size="11">R$ ' + (v >= 1000 ? (v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + 'k' : v) + '</text>';
    }
    var seg = [], atualSeg = [];
    vals.forEach(function (v, i) { if (v === null) { if (atualSeg.length) seg.push(atualSeg); atualSeg = []; } else atualSeg.push([X(i), Y(v)]); });
    if (atualSeg.length) seg.push(atualSeg);
    var linhas = '', area = '';
    seg.forEach(function (pts) {
      var d = 'M' + pts[0][0] + ',' + pts[0][1];
      for (var i = 0; i < pts.length - 1; i++) {
        var p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2, t = .35;
        d += ' C' + (p1[0] + (p2[0] - p0[0]) * t / 1.5) + ',' + (p1[1] + (p2[1] - p0[1]) * t / 1.5) + ' ' + (p2[0] - (p3[0] - p1[0]) * t / 1.5) + ',' + (p2[1] - (p3[1] - p1[1]) * t / 1.5) + ' ' + p2[0] + ',' + p2[1];
      }
      linhas += '<path d="' + d + '" fill="none" stroke="#F98612" stroke-width="' + (opt.semEixo ? 2 : 2.5) + '"/>';
      if (pts.length > 1) area += '<path d="' + d + ' L' + pts[pts.length - 1][0] + ',' + Y(0) + ' L' + pts[0][0] + ',' + Y(0) + ' Z" fill="rgba(249,134,18,' + (opt.semEixo ? '.18' : '.14') + ')"/>';
    });
    var pontos = '', rotulos = '';
    jan.forEach(function (m, i) {
      var x = X(i);
      if (!opt.semEixo) rotulos += '<text x="' + x + '" y="' + (H - 12) + '" text-anchor="middle" fill="#9BAED9" font-size="11">' + esc(mesCurto(m)) + '</text>';
      if (vals[i] !== null) {
        var r = opt.semEixo ? (m === mesSel ? 5 : 0) : (m === mesSel ? 6 : 4);
        if (r) pontos += '<circle cx="' + x + '" cy="' + Y(vals[i]) + '" r="' + r + '" fill="#F98612"' + (m === mesSel ? ' stroke="#fff" stroke-width="2"' : '') + '><title>' + esc(dica(m, vals[i])) + '</title></circle>';
        // Valor escrito em cima de cada ponto (só no gráfico com eixo).
        if (!opt.semEixo) { var vv = vals[i], tx = vv >= 1e6 ? 'R$ ' + (vv / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + ' mi' : vv >= 1e3 ? 'R$ ' + (vv / 1e3).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + 'k' : 'R$ ' + Math.round(vv);
          var parc = opt.parcial && opt.parcial(m), pv = i > 0 ? vals[i - 1] : null, dd = pv && !parc && (!opt.comparavel || opt.comparavel(m, jan[i - 1])) ? (vv - pv) / pv * 100 : null, tx2 = parc ? 'parcial' : dd == null ? '' : (dd > 0 ? '▲ +' : dd < 0 ? '▼ ' : '') + dd.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%';
          var lx = Math.min(Math.max(x, L + 24), W - R - 24), ly = Y(vv) - (tx2 ? 23 : 11);
          pontos += '<text x="' + lx + '" y="' + ly + '" text-anchor="middle" fill="#F4F2EA" font-size="11" font-weight="600" paint-order="stroke" stroke="#0d0d10" stroke-width="3">' + esc(tx) + '</text>';
          if (tx2) pontos += '<text x="' + lx + '" y="' + (ly + 12) + '" text-anchor="middle" fill="' + (parc ? '#9BAED9' : dd >= 0 ? '#9BAED9' : '#F98612') + '" font-size="10" font-weight="600" paint-order="stroke" stroke="#0d0d10" stroke-width="3">' + esc(tx2) + '</text>'; }
      }
    });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" ' + (opt.semEixo ? 'height="100%" preserveAspectRatio="none"' : '') + ' role="img" aria-label="' + esc(aria) + '" style="display:block;' + (opt.semEixo ? '' : 'max-height:300px') + '">' + g + area + linhas + pontos + rotulos + '</svg>';
  }

  // Botões de canal no destaque do Resumo (como nos dashboards completos): Todos / Salão / Delivery / iFood.
  var canalRes = 'todos';
  var CANAIS = [['todos', 'Todos'], ['salao', 'Salão / Loja'], ['deliv', 'Delivery'], ['ifood', 'iFood']];
  function ifoodMes(m) {
    var s = SP[m];
    if (s && s.canais && s.canais.length) {
      var x = s.canais.filter(function (k) { return /ifood/i.test(k.nome); });
      if (x.length) { var o = 0, r = 0; x.forEach(function (k) { o += k.o || 0; r += k.r || 0; }); return { r: r, o: o }; }
    }
    return IF[m] ? { r: IF[m].r, o: IF[m].o } : null;
  }
  function valCanal(m, c) {
    if (c === 'salao') return SL[m] ? SL[m].r : null;
    if (c === 'deliv') return delivMes(m);
    if (c === 'ifood') { var x = ifoodMes(m); return x ? x.r : null; }
    return totalMes(m);
  }
  function pedCanal(m, c) {   // {o, sub, r?} para Pedidos/Ticket do canal (r: SAIPOS, quando o faturamento veio de outro relatório)
    if (c === 'salao') { var l = SL[m]; return l && l.vis ? { o: l.vis, u: l.un || 'visitas' } : null; }
    if (c === 'deliv') { var s = SP[m]; if (s && s.o) return { o: s.o, u: 'pedidos', r: s.r_saipos }; var o = (IF[m] ? IF[m].o : 0) + (CD[m] ? CD[m].o : 0); return o ? { o: o, u: 'pedidos' } : null; }
    if (c === 'ifood') { var x = ifoodMes(m); return x && x.o ? { o: x.o, u: 'pedidos' } : null; }
    return null;
  }
  function canaisComDado() {
    var lista = CANAIS.filter(function (k) { return k[0] !== 'todos' && visivel(k[1]) && meses.some(function (m) { return valCanal(m, k[0]) != null; }); });
    return lista.length > 1 ? [CANAIS[0]].concat(lista) : [];
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('.hero-pill[data-canal]');
    if (!b) return;
    canalRes = b.getAttribute('data-canal'); render();
  });

  function resumoCompleto() {
    var pills = canaisComDado();
    if (!pills.some(function (k) { return k[0] === canalRes; })) canalRes = 'todos';
    var cn = canalRes, nomeC = (CANAIS.filter(function (k) { return k[0] === cn; })[0] || CANAIS[0])[1];
    var tot = valCanal(mesSel, cn), ant = mesAnt(mesSel), totAnt = valCanal(ant, cn);
    // Mês em andamento (relatório "até" um dia): não compara com o mês anterior fechado.
    var emAnd = [SL, SP, IF, CD].some(function (x) { return x[mesSel] && x[mesSel].ate; });
    var f = valor('fat'), d = emAnd ? null : variacao(tot, totAnt);
    var fa = fontesMes(mesSel), fb = fontesMes(ant), parcial = cn === 'todos' && totAnt && fa.join() !== fb.join();
    var jan = janela12(), vals = jan.map(function (m) { var v = valCanal(m, cn); return v == null ? null : v; });
    var dica = function (m, v) { return mesLbl(m) + ' · ' + brl(v); };
    var pc = cn === 'todos' ? null : pedCanal(mesSel, cn);
    var sPed = cn === 'todos' ? valor('ped') : pc ? { v: num(pc.o), sub: pc.u + ' · ' + nomeC } : null;
    var sTkt = cn === 'todos' ? valor('tkt') : pc && tot ? { v: brl((pc.r || tot) / pc.o), sub: 'por ' + pc.u.replace(/s$/, '') } : null;
    var subC = cn === 'todos' ? (f && f.sub) : cn === 'salao' ? (SL[mesSel] && (SL[mesSel].obs || 'salão')) + (SL[mesSel] && SL[mesSel].ate ? ate(SL[mesSel]) : '')
      : cn === 'deliv' ? (valor('deliv') || {}).sub : 'iFood' + (totalMes(mesSel) && tot ? ' · ' + pct(tot, totalMes(mesSel)) + ' do faturamento total' : '');
    var unL = (cn === 'todos' || cn === 'salao') && SL[mesSel] && SL[mesSel].un, rotPed = unL ? (unL === 'pessoas' ? 'Pessoas atendidas' : unL.charAt(0).toUpperCase() + unL.slice(1)) : 'Pedidos';
    var st = [[rotPed, sPed], ['Ticket médio', sTkt], ['Investimento em mídia', valor('midia')]].map(function (s) {
      return '<div class="hero-stat"><div class="l">' + s[0] + '</div><div class="v">' + (s[1] ? esc(s[1].v) : '—') + '</div><div class="d">' + (s[1] && s[1].sub ? esc(s[1].sub) : 'aguardando dados') + '</div></div>';
    }).join('');
    var valorTxt = tot == null ? 'Aguardando' : brl(tot).replace(/^R\$\s*/, '');
    var hero = '<section class="hero" aria-label="Faturamento do período">' +
      (pills.length ? '<div class="hero-pills" role="group" aria-label="Canal">' + pills.map(function (k) { return '<button type="button" class="hero-pill' + (k[0] === cn ? ' on' : '') + '" data-canal="' + k[0] + '">' + esc(k[1]) + '</button>'; }).join('') + '</div>' : '') +
      '<div class="hero-label">' + (cn !== 'todos' ? 'Faturamento · ' + esc(nomeC) : SL[mesSel] ? 'Faturamento total' : 'Faturamento') + '</div>' +
      '<div class="hero-value">' + (tot == null ? '' : '<small>R$</small>') + esc(valorTxt) + '</div>' +
      '<div class="hero-meta"><span>' + esc(mesLbl(mesSel)) + (subC ? ' · ' + esc(subC) : '') + '</span>' +
      (d ? '<span class="hero-delta ' + (d.c === 'up' ? '' : d.c) + '">' + (d.c === 'up' ? '<i class="fa-solid fa-arrow-trend-up"></i> ' : d.c === 'down' ? '<i class="fa-solid fa-arrow-trend-down"></i> ' : '') + esc(d.t + ' vs ' + mesCurto(ant)) + (parcial ? ' · comparação parcial' : '') + '</span>' : '') + '</div>' +
      (vals.filter(function (v) { return v != null; }).length > 1 ? '<div class="hero-spark" aria-hidden="true">' + grafLinha(jan, vals, dica, 'Evolução do faturamento', { semEixo: true, W: 640, H: 120 }) + '</div>' : '') +
      '<div class="hero-stats">' + st + '</div></section>';
    var kp = [['Mix de Canais', 'fa-layer-group', 'mix'], ['Salão / Loja', 'fa-utensils', 'sal_r'], ['Delivery', 'fa-motorcycle', 'deliv'], ['Investimento em Mídia', 'fa-bullhorn', 'midia']];
    if (visivel('ifood') && meses.some(function (m) { return ifoodMes(m); })) kp.splice(3, 0, ['Dependência do iFood', 'fa-bowl-food', 'dep_ifood']);
    // Mês ainda em andamento (relatório "até" um dia): mostra o valor, sem comparar com o mês fechado.
    var mesParcial = function (m) { return [SL[m], SP[m], IF[m], CD[m]].some(function (x) { return x && x.ate; }); };
    // Só compara meses com as mesmas fontes (ex.: julho só com delivery × agosto com salão + delivery não compara).
    var comparavel = function (m, a) { return fontesMes(m).join() === fontesMes(a).join(); };
    var evol = grafLinha(jan, vals, dica, 'Faturamento total mês a mês', { parcial: mesParcial, comparavel: comparavel });
    var linhaC = function (rot, a, b) { var v = emAnd ? null : variacao(a, b); return '<tr><td><strong>' + rot + '</strong></td><td class="v">' + (a == null ? '—' : brl(a)) + '</td><td class="v">' + (b == null ? '—' : brl(b)) + '</td><td class="v"' + (v && v.c !== 'flat' ? ' style="color:' + (v.c === 'up' ? '#9BAED9' : '#F98612') + ';font-weight:600"' : '') + '>' + (v ? v.t : '—') + '</td></tr>'; };
    var comp = '<table class="data-table"><thead><tr><th>Métrica</th><th class="v">' + esc(mesCurto(mesSel)) + '</th><th class="v">' + esc(mesCurto(ant)) + '</th><th class="v">MoM</th></tr></thead><tbody>' +
      linhaC('Faturamento total', tot, totAnt) +
      linhaC('Salão / Loja', SL[mesSel] ? SL[mesSel].r : null, SL[ant] ? SL[ant].r : null) +
      (visivel('delivery') ? linhaC('Delivery', delivMes(mesSel), delivMes(ant)) : '') +
      linhaC('Invest. mídia', midiaMes(mesSel), midiaMes(ant)) + '</tbody></table>';
    var notaComp = emAnd ? 'Mês em andamento: a variação aparece quando o mês fechar.' : parcial ? 'Comparação parcial: ' + fa.filter(function (x) { return fb.indexOf(x) < 0; }).map(function (x) { return x + ' só em ' + mesCurto(mesSel); })
      .concat(fb.filter(function (x) { return fa.indexOf(x) < 0; }).map(function (x) { return x + ' só em ' + mesCurto(ant); })).join(', ') + '.' : 'Mês selecionado contra o mês anterior.';
    return hero + '<div class="kpi-grid">' + kp.filter(function (k) { return visivel(k[0]); }).map(kpi).join('') + '</div>' +
      '<div class="grid-2">' + card('Evolução de Faturamento', 'fa-chart-line', evol, 'Faturamento total' + (visivel('delivery') ? ' (salão + delivery)' : '') + ' dos últimos 12 meses com dado · meses sem relatório ficam em branco') +
      card('Comparativo de Período', 'fa-scale-balanced', comp, notaComp) + '</div>';
  }

  function filtro() {
    if (!meses.length) return '';
    return '<div class="filtro"><label>Período<select id="selMes">' + meses.map(function (m) {
      var tags = [SL[m] ? 'Salão' : '', IF[m] ? 'iFood' : FU[m] ? 'iFood (cardápio)' : '', CD[m] ? 'Delivery próprio' : '', SP[m] ? 'PDV' : '', MT[m] ? 'Meta' : '', GA[m] ? 'Google' : ''].filter(Boolean).join(' + ') || 'aguardando dados';
      return '<option value="' + m + '"' + (m === mesSel ? ' selected' : '') + '>' + esc(mesLbl(m)) + ' · ' + tags + '</option>';
    }).join('') + '</select></label></div>';
  }

  function pageHtml(p, i) {
    var h = '<div id="' + p.id + '" class="view-page' + (i === 0 ? ' active' : '') + '">';
    if (i === 0 && p.recebidos && temFat) return h + resumoCompleto() + '</div>';
    if (i === 0) h += aviso();
    if (p.recebidos) h += recebidos();
    if (p.kpis) h += '<div class="kpi-grid">' + p.kpis.filter(function (k) { return visivel(k[0]); }).map(kpi).join('') + '</div>';
    if (p.ifoodDet) h += '<div id="m7ifood"></div>';   // área iFood: m7-ifood.js
    if (p.canaisDet) h += canaisDetalhe();
    if (p.carDet) h += cardapioDetalhe();
    if (p.abcDet) h += rankingItens();
    if (p.mkt12) h += mkt12();
    if (p.cards) {
      h += '<div class="grid-2">' + p.cards.map(function (c) {
        return card(esc(c[0]), c[1], '<table class="data-table"><tbody>' + c[2].filter(function (r) { return visivel(r[0]); }).map(linha).join('') + '</tbody></table>');
      }).join('') + '</div>';
    }
    if (p.metaHist) h += metaHistorico();
    return h + '</div>';
  }

  var mark = C.logo
    ? '<img src="' + esc(C.logo) + '" alt="' + esc(C.nome) + '" onerror="this.parentNode.innerHTML=\'<i class=&quot;fa-solid ' + esc(C.icone) + '&quot;></i>\'">'
    : '<i class="fa-solid ' + esc(C.icone || 'fa-utensils') + '"></i>';

  var nav = '<div class="nav-label">Relatório Executivo</div>' + PAGES.map(function (p, i) {
    return '<li class="nav-item' + (i === 0 ? ' active' : '') + '" data-page="' + p.id + '"><i class="fa-solid ' + p.icon + '"></i> ' + (i + 1) + '. ' + esc(p.t) + '</li>';
  }).join('');

  document.body.innerHTML =
    '<div class="overlay" id="overlay"></div>' +
    '<aside id="sidebar"><div class="brand-header"><div class="brand-logo">M7</div><div class="brand-title">Mesa7<span>Intelligence</span></div><button class="sidebar-close" id="btnClose" aria-label="Fechar menu"><i class="fa-solid fa-xmark"></i></button></div>' +
    '<div class="client-block"><span class="client-label">Cliente</span><div class="client-card"><div class="client-mark">' + mark + '</div><div><div class="client-name">' + esc(C.nome) + '</div><div class="client-seg">' + esc(C.seg || '') + '</div></div></div></div>' +
    '<ul class="nav-menu">' + nav + '</ul><div class="sidebar-footer">Desenvolvido por Mesa7 Marketing</div></aside>' +
    '<main><header class="top-bar"><button class="menu-toggle" id="btnMenu" aria-label="Abrir menu"><i class="fa-solid fa-bars"></i></button><div class="page-title"><h1 id="page-heading"></h1><p id="page-subheading"></p></div></header>' +
    filtro() + '<div id="paginas"></div></main>';

  var atual = 'p1';
  function render() {
    document.getElementById('paginas').innerHTML = PAGES.map(pageHtml).join('');
    document.querySelectorAll('.view-page').forEach(function (el) { el.classList.toggle('active', el.id === atual); });
  }
  function closeNav() { document.body.classList.remove('nav-open'); document.getElementById('overlay').classList.remove('show'); }
  function openNav() { document.body.classList.add('nav-open'); document.getElementById('overlay').classList.add('show'); }
  function show(id) {
    closeNav();
    atual = id;
    var p = PAGES.filter(function (x) { return x.id === id; })[0];
    document.querySelectorAll('.view-page').forEach(function (el) { el.classList.toggle('active', el.id === id); });
    document.querySelectorAll('.nav-item').forEach(function (el) { el.classList.toggle('active', el.getAttribute('data-page') === id); });
    document.getElementById('page-heading').innerHTML = '<i class="fa-solid ' + p.icon + '" style="color:var(--m7-orange)"></i> ' + esc(p.t);
    document.getElementById('page-subheading').textContent = p.s;
  }
  render();
  window.switchPage = show;
  var sel = document.getElementById('selMes');
  if (sel) sel.addEventListener('change', function () { mesSel = sel.value; render(); });
  document.querySelectorAll('.nav-item').forEach(function (el) { el.addEventListener('click', function () { window.switchPage(el.getAttribute('data-page')); }); });
  document.getElementById('btnMenu').addEventListener('click', openNav);
  document.getElementById('btnClose').addEventListener('click', closeNav);
  document.getElementById('overlay').addEventListener('click', closeNav);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeNav(); });
  show('p1');
})();
