/* =========================================================
   Histórico mensal de faturamento em todos os dashboards (injetado pelo sistema).
   Card no Resumo Executivo, logo antes da "Evolução de Faturamento":
   - barras: faturamento de cada mês, desde o primeiro mês com dado;
   - linha tracejada: o mesmo mês do ano anterior, quando existe na base;
   - cartões: total, média mensal, melhor mês e último mês vs ano anterior (ou vs mês anterior).
   Fonte dos números:
   - dashboards completos: o array MESES do próprio dashboard (tot, ou salão + delivery);
     mês com relatório SAIPOS completo usa o total do SAIPOS, como o resumo do dashboard;
   - dashboards em implantação: window.m7Historico() do m7-esqueleto.js (mesma regra do faturamento do mês).
   Meses parciais (em andamento) aparecem mais claros e ficam fora das médias.
   Desenhado em SVG, sem biblioteca.
   ========================================================= */
(function () {
  var NOMES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  var LONGOS = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  function cur(id) { var p = id.split('-'); return NOMES[+p[1] - 1] + '/' + p[0].slice(2); }
  function longo(id) { var p = id.split('-'); return LONGOS[+p[1] - 1] + '/' + p[0]; }
  function anoAntes(id) { var p = id.split('-'); return (+p[0] - 1) + '-' + p[1]; }
  function mesAntes(id) { var p = id.split('-'); var y = +p[0], m = +p[1] - 1; if (!m) { m = 12; y--; } return y + '-' + (m < 10 ? '0' : '') + m; }
  function brl(n) { return 'R$ ' + Math.round(n).toLocaleString('pt-BR'); }
  function curto(n) { return n >= 1e6 ? (n / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + ' mi' : n >= 1e3 ? Math.round(n / 1e3).toLocaleString('pt-BR') + ' mil' : Math.round(n).toLocaleString('pt-BR'); }
  function pct(a, b) { var d = (a - b) / b * 100; return (d >= 0 ? '+' : '') + d.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%'; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function serie() {
    if (typeof window.m7Historico === 'function') return window.m7Historico();
    var M; try { M = MESES; } catch (e) { return []; }   // eslint-disable-line no-undef
    if (!Array.isArray(M)) return [];
    var SP = (window.M7_DADOS && window.M7_DADOS.saipos) || {};
    return M.map(function (m) {
      if (!m || !/^\d{4}-\d{2}$/.test(m.id || '') || m.semFaturamento || m.semVenda) return null;
      var s = SP[m.id], r, fonte = null;
      if (s && !s.ate && s.r > 0) { r = s.r; if (!(Math.abs(s.r - (m.tot || 0)) < 1)) fonte = 'SAIPOS'; }   // só marca quando o SAIPOS muda o número
      else if (m.tot > 0) r = m.tot;
      else r = (m.sal || 0) + (m.del && typeof m.del === 'object' ? m.del.r || 0 : m.del || 0);
      return r > 0 ? { id: m.id, r: r, parcial: !!(m.parcial || m.ate), fonte: fonte } : null;
    }).filter(Boolean);
  }

  function svg(S) {
    var W = 1000, H = 320, L = 64, R = 14, T = 30, B = 46, n = S.length;
    var mapa = {}; S.forEach(function (x) { mapa[x.id] = x; });
    var ant = S.map(function (x) { var a = mapa[anoAntes(x.id)]; return a && !a.parcial ? a.r : null; });
    var max = Math.max.apply(null, S.map(function (x) { return x.r; }).concat(ant.filter(function (v) { return v != null; })));
    var passo = Math.pow(10, Math.floor(Math.log10(max))), topo = Math.ceil(max / passo) * passo;
    if (topo / passo <= 2) { passo /= 2; topo = Math.ceil(max / passo) * passo; }
    var y = function (v) { return T + (H - T - B) * (1 - v / topo); };
    var bw = (W - L - R) / n, larg = Math.min(46, bw * 0.62), o = '';
    for (var g = 0; g <= topo + 1e-6; g += passo) {
      o += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + y(g) + '" y2="' + y(g) + '" stroke="currentColor" stroke-opacity=".08"/>' +
        '<text x="' + (L - 8) + '" y="' + (y(g) + 4) + '" text-anchor="end" font-size="11" fill="currentColor" fill-opacity=".6">R$ ' + curto(g) + '</text>';
    }
    var rotulos = n > 14;
    S.forEach(function (x, i) {
      var cx = L + bw * i + bw / 2, yy = y(x.r);
      o += '<rect x="' + (cx - larg / 2) + '" y="' + yy + '" width="' + larg + '" height="' + (H - B - yy) + '" rx="4" fill="#F98612" fill-opacity="' + (x.parcial ? '.35' : '1') + '"><title>' +
        esc(longo(x.id) + ': ' + brl(x.r) + (x.parcial ? ' (mês em andamento)' : '') + (ant[i] != null ? ' · ano anterior ' + brl(ant[i]) : '')) + '</title></rect>';
      o += '<text x="' + cx + '" y="' + (yy - 6) + '" text-anchor="middle" font-size="' + (rotulos ? 9.5 : 11) + '" fill="currentColor" fill-opacity=".85">' + curto(x.r) + '</text>';
      o += '<text x="' + cx + '" y="' + (H - B + 18) + '" text-anchor="middle" font-size="' + (rotulos ? 10 : 11.5) + '" fill="currentColor" fill-opacity=".7">' + cur(x.id) + '</text>';
      if (x.parcial) o += '<text x="' + cx + '" y="' + (H - B + 32) + '" text-anchor="middle" font-size="9.5" fill="currentColor" fill-opacity=".5">parcial</text>';
    });
    var pts = [], linhas = [];
    ant.forEach(function (v, i) { if (v == null) { if (pts.length) linhas.push(pts); pts = []; return; } pts.push([L + bw * i + bw / 2, y(v)]); });
    if (pts.length) linhas.push(pts);
    linhas.forEach(function (p) {
      if (p.length > 1) o += '<polyline points="' + p.map(function (q) { return q.join(','); }).join(' ') + '" fill="none" stroke="#9BAED9" stroke-width="2.5" stroke-dasharray="7 6"/>';
      p.forEach(function (q) { o += '<circle cx="' + q[0] + '" cy="' + q[1] + '" r="3.5" fill="#9BAED9"/>'; });
    });
    return { svg: '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" style="display:block;color:inherit" role="img" aria-label="Faturamento mês a mês">' + o + '</svg>', temAnt: ant.some(function (v) { return v != null; }) };
  }

  function montar() {
    var p1 = document.getElementById('p1'); if (!p1 || document.getElementById('m7hist')) return;
    var S = serie(); if (S.length < 2) return;
    var g = svg(S), fech = S.filter(function (x) { return !x.parcial; }), mapa = {};
    S.forEach(function (x) { mapa[x.id] = x; });
    var tot = fech.reduce(function (t, x) { return t + x.r; }, 0), melhor = fech.slice().sort(function (a, b) { return b.r - a.r; })[0];
    var ult = fech[fech.length - 1], k4 = '';
    if (ult) {
      var aa = mapa[anoAntes(ult.id)], am = mapa[mesAntes(ult.id)];
      var igual = function (x) { return (x.fonte || '') === (ult.fonte || ''); };   // não compara mês do SAIPOS com mês sem SAIPOS
      if (aa && !aa.parcial && igual(aa)) k4 = kpi(cur(ult.id) + ' vs ' + cur(aa.id), pct(ult.r, aa.r), brl(ult.r) + ' vs ' + brl(aa.r));
      else if (am && !am.parcial && igual(am)) k4 = kpi(cur(ult.id) + ' vs ' + cur(am.id), pct(ult.r, am.r), 'sem o ano anterior na base');
      else k4 = kpi('Último mês fechado', longo(ult.id), brl(ult.r) + (am && !igual(am) ? ' · fonte diferente de ' + cur(am.id) : ''));
    }
    var fontes = S.filter(function (x) { return x.fonte; }).map(function (x) { return cur(x.id); });
    var nota = 'Meses claros estão em andamento e ficam fora do total e da média.' +
      (g.temAnt ? '' : ' A linha do ano anterior aparece quando o faturamento do mesmo mês do ano passado entrar na base.') +
      (fontes.length && fontes.length < S.length ? ' Total do relatório SAIPOS em ' + fontes.join(', ') + '; nos demais meses, o faturamento lançado no dashboard.' : '');
    var card = document.createElement('div');
    card.id = 'm7hist'; card.className = 'chart-card'; card.style.marginBottom = '18px';
    card.innerHTML =
      '<div class="chart-title"><i class="fa-solid fa-chart-column" style="color:var(--m7-orange,#F98612)"></i> Histórico de faturamento · ' + cur(S[0].id) + ' a ' + cur(S[S.length - 1].id) + '</div>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin:12px 0 6px">' +
      kpi('Total (' + fech.length + ' meses fechados)', brl(tot), '') +
      kpi('Média mensal', brl(fech.length ? tot / fech.length : 0), '') +
      (melhor ? kpi('Melhor mês', longo(melhor.id), brl(melhor.r)) : '') + k4 + '</div>' +
      '<div style="display:flex;gap:16px;justify-content:flex-end;font-size:12px;opacity:.8;margin-bottom:2px">' +
      '<span><span style="display:inline-block;width:11px;height:11px;border-radius:3px;background:#F98612;vertical-align:-1px"></span> Faturamento do mês</span>' +
      (g.temAnt ? '<span><span style="display:inline-block;width:18px;border-top:2.5px dashed #9BAED9;vertical-align:3px"></span> Mesmo mês do ano anterior</span>' : '') + '</div>' +
      g.svg + '<p class="chart-note" style="margin-top:6px">' + esc(nota) + '</p>';
    var alvo = null;
    Array.prototype.slice.call(p1.children).some(function (el) { var t = el.querySelector && el.querySelector('.chart-title'); if (t && /Evolu/i.test(t.textContent)) { alvo = el; return true; } return false; });
    if (alvo) p1.insertBefore(card, alvo); else p1.appendChild(card);
  }
  function kpi(l, v, s) {
    return '<div style="background:var(--bg-hover,rgba(255,255,255,.04));border-radius:12px;padding:10px 14px"><div style="font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;opacity:.65">' + esc(l) +
      '</div><div style="font-size:18px;font-weight:700;margin-top:3px">' + esc(v) + '</div>' + (s ? '<div style="font-size:11.5px;opacity:.65;margin-top:2px">' + esc(s) + '</div>' : '') + '</div>';
  }
  function iniciar() {
    montar();
    // o resumo dos dashboards em implantação é redesenhado ao trocar o mês: devolve o card se ele sumir
    if (window.MutationObserver) new MutationObserver(function () { if (document.getElementById('p1') && !document.getElementById('m7hist')) montar(); }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'complete') iniciar(); else window.addEventListener('load', iniciar);
})();
