"use server";

import { revalidatePath } from "next/cache";
import { requireSession } from "@/lib/access";
import { conversarComAssistente, gravarProposta, validarProposta, type Historico, type RespostaAssistente } from "@/lib/assistente";

async function exigirEquipe() {
  const s = await requireSession();
  if (s.user.role === "client") throw new Error("Apenas a equipe Mesa7 usa o Assistente.");
  return s.user.name || s.user.email || "Equipe";
}

export async function conversar(historico: Historico): Promise<RespostaAssistente> {
  await exigirEquipe();
  if (!Array.isArray(historico) || !historico.length) return { ok: false, erro: "Mensagem vazia." };
  return conversarComAssistente(historico);
}

export async function lancarProposta(p: unknown): Promise<{ ok: boolean; mensagem: string }> {
  const quem = await exigirEquipe();
  const v = validarProposta(p);
  if (typeof v === "string") return { ok: false, mensagem: v };
  try {
    const mensagem = await gravarProposta(v, quem);
    revalidatePath("/dashboards");
    return { ok: true, mensagem: `${mensagem} Já aparece no dashboard.` };
  } catch (e) {
    return { ok: false, mensagem: e instanceof Error ? e.message : "Não consegui gravar." };
  }
}
