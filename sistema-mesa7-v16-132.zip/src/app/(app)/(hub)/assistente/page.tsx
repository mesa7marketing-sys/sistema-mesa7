import { requireSession } from "@/lib/access";
import { PageHead } from "@/components/ui";
import { ChatAssistente } from "@/components/ChatAssistente";
import { chaveConfigurada } from "@/lib/assistente";

export const dynamic = "force-dynamic";

// Assistente (IA) da equipe: dúvidas sobre resultados e lançamento de números que chegam em print.
export default async function AssistentePage() {
  const s = await requireSession();
  if (s.user.role === "client") return null;
  return (
    <div style={{ padding: "28px 32px 40px", maxWidth: 980 }}>
      <PageHead
        kicker="Clientes"
        title="Assistente"
        description="Pergunte sobre os resultados dos clientes ou envie um print para lançar no dashboard (cancelamentos e atrasos do iFood, faturamento do mês, seguidores). Nada é gravado sem você clicar em Lançar."
      />
      <div style={{ marginTop: 18 }}>
        <ChatAssistente ligado={chaveConfigurada()} />
      </div>
    </div>
  );
}
