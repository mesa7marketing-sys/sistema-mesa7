"use client";

import { useRef, useState } from "react";
import { conversar, lancarProposta } from "@/app/(app)/(hub)/assistente/actions";
import type { Historico, Proposta } from "@/lib/assistente";

type Anexo = { nome: string; tipo: string; dados: string };
type Item =
  | { k: "eu"; texto: string; anexos: string[] }
  | { k: "ia"; texto: string }
  | { k: "cartao"; p: Proposta; estado: "aberto" | "gravando" | "lancado" | "erro" | "descartado"; msg?: string }
  | { k: "erro"; texto: string };

const TIPOS_OK = ["image/png", "image/jpeg", "image/webp", "image/gif", "application/pdf"];
const LIMITE = { imagem: 5 * 1024 * 1024, pdf: 20 * 1024 * 1024 };
const SUGESTOES = [
  "Como foi o iFood da La Pizza em outubro comparado com setembro?",
  "Quais clientes ainda não têm o faturamento de outubro?",
  "Lançar print de cancelamentos e atrasos do iFood",
];

const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const mesLbl = (m: string) => new Date(+m.slice(0, 4), +m.slice(5) - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

function linhasProposta(p: Proposta): [string, string][] {
  const l: [string, string][] = [];
  if (p.tipo === "ifood_operacao") {
    if (p.cancelados_loja != null) l.push(["Cancelados pela loja", String(p.cancelados_loja)]);
    if (p.cancelados_cliente != null) l.push(["Cancelados pelo cliente", String(p.cancelados_cliente)]);
    if (p.atrasados != null) l.push(["Pedidos atrasados", String(p.atrasados)]);
    if (p.pedidos != null) l.push(["Pedidos no mês", String(p.pedidos)]);
  } else if (p.tipo === "faturamento_mes") l.push(["Faturamento total", brl(p.faturamento ?? 0)]);
  else l.push(["Seguidores", (p.seguidores ?? 0).toLocaleString("pt-BR")], ["Data da leitura", (p.data_leitura ?? "").split("-").reverse().join("/")]);
  return l;
}
const TITULO: Record<Proposta["tipo"], string> = {
  ifood_operacao: "Operação do iFood",
  faturamento_mes: "Faturamento do mês",
  seguidores_instagram: "Seguidores do Instagram",
};

function lerArquivo(f: File): Promise<Anexo> {
  return new Promise((ok, falha) => {
    const r = new FileReader();
    r.onload = () => ok({ nome: f.name || "print.png", tipo: f.type, dados: String(r.result).split(",")[1] ?? "" });
    r.onerror = () => falha(new Error("Não consegui ler o arquivo."));
    r.readAsDataURL(f);
  });
}

export function ChatAssistente({ ligado }: { ligado: boolean }) {
  const [historico, setHistorico] = useState<Historico>([]);
  const [itens, setItens] = useState<Item[]>([]);
  const [texto, setTexto] = useState("");
  const [anexos, setAnexos] = useState<Anexo[]>([]);
  const [aviso, setAviso] = useState("");
  const [pensando, setPensando] = useState(false);
  const fimRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const rolar = () => setTimeout(() => fimRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }), 50);

  async function anexar(files: FileList | File[] | null) {
    setAviso("");
    const lista = Array.from(files ?? []);
    const novos: Anexo[] = [];
    for (const f of lista) {
      if (!TIPOS_OK.includes(f.type)) { setAviso(`${f.name}: envie imagem (PNG, JPG, WEBP) ou PDF.`); continue; }
      if (f.size > (f.type === "application/pdf" ? LIMITE.pdf : LIMITE.imagem)) { setAviso(`${f.name}: arquivo grande demais (imagem até 5 MB, PDF até 20 MB).`); continue; }
      novos.push(await lerArquivo(f));
    }
    setAnexos((a) => [...a, ...novos].slice(0, 5));
  }

  async function enviar(msg?: string) {
    const t = (msg ?? texto).trim();
    if ((!t && !anexos.length) || pensando) return;
    const blocos: Historico[number]["content"] = [
      ...anexos.map((a) =>
        a.tipo === "application/pdf"
          ? ({ type: "document", source: { type: "base64", media_type: "application/pdf", data: a.dados } } as const)
          : ({ type: "image", source: { type: "base64", media_type: a.tipo as "image/png", data: a.dados } } as const),
      ),
      { type: "text", text: t || "Segue o anexo." },
    ];
    const novo: Historico = [...historico, { role: "user", content: blocos }];
    setItens((i) => [...i, { k: "eu", texto: t, anexos: anexos.map((a) => a.nome) }]);
    setTexto("");
    setAnexos([]);
    setPensando(true);
    rolar();
    try {
      const r = await conversar(novo);
      if (!r.ok) {
        setItens((i) => [...i, { k: "erro", texto: r.erro }]);
        return;
      }
      const respostas = r.historico
        .slice(novo.length)
        .filter((m) => m.role === "assistant")
        .flatMap((m) => (typeof m.content === "string" ? [m.content] : m.content.flatMap((b) => (b.type === "text" ? [b.text] : []))))
        .join("\n\n")
        .trim();
      setHistorico(r.historico);
      setItens((i) => [
        ...i,
        ...(respostas ? [{ k: "ia", texto: respostas } as Item] : []),
        ...r.propostas.map((p) => ({ k: "cartao", p, estado: "aberto" }) as Item),
      ]);
    } catch {
      setItens((i) => [...i, { k: "erro", texto: "Não consegui enviar. Se tiver anexo grande, tente um menor." }]);
    } finally {
      setPensando(false);
      rolar();
    }
  }

  async function lancar(idx: number) {
    const it = itens[idx];
    if (it.k !== "cartao") return;
    setItens((l) => l.map((x, i) => (i === idx ? { ...it, estado: "gravando" } : x)));
    const r = await lancarProposta(it.p).catch(() => ({ ok: false, mensagem: "Não consegui gravar." }));
    setItens((l) => l.map((x, i) => (i === idx ? { ...it, estado: r.ok ? "lancado" : "erro", msg: r.mensagem } : x)));
  }
  const descartar = (idx: number) => setItens((l) => l.map((x, i) => (i === idx && x.k === "cartao" ? { ...x, estado: "descartado" } : x)));

  const caixa: React.CSSProperties = { background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14 };
  const botao: React.CSSProperties = { background: "var(--accent)", color: "var(--accent-ink)", border: "none", borderRadius: 9, padding: "9px 16px", fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit" };
  const botao2: React.CSSProperties = { ...botao, background: "transparent", color: "var(--text-secondary)", border: "1px solid var(--border-strong)" };

  if (!ligado) {
    return (
      <div style={{ ...caixa, padding: 18, fontSize: 14, color: "var(--text-secondary)", lineHeight: 1.6 }}>
        <b style={{ color: "var(--text-primary)" }}>O Assistente ainda não está ligado.</b> Falta colocar a chave da API da Anthropic no servidor: a linha <code>ANTHROPIC_API_KEY=...</code> no arquivo <code>.env</code> do Sistema na VPS, e depois reiniciar o app (<code>pm2 restart sistema-mesa7</code>).
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ ...caixa, padding: 16, minHeight: 360, maxHeight: "62vh", overflowY: "auto", display: "flex", flexDirection: "column", gap: 12 }}>
        {!itens.length && (
          <div style={{ color: "var(--text-muted)", fontSize: 14, lineHeight: 1.6 }}>
            <p style={{ margin: "0 0 10px" }}>Exemplos do que dá para pedir:</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {SUGESTOES.map((s) => (
                <button key={s} type="button" onClick={() => setTexto(s)} style={{ ...botao2, fontWeight: 500, fontSize: 13, padding: "7px 12px" }}>
                  {s}
                </button>
              ))}
            </div>
            <p style={{ margin: "12px 0 0", fontSize: 12.5 }}>Para lançar um print, anexe a imagem (ou cole com Ctrl+V) e diga o cliente e o mês. Ex.: &quot;La Pizza, operação do iFood de outubro&quot;.</p>
          </div>
        )}
        {itens.map((it, i) => {
          if (it.k === "eu")
            return (
              <div key={i} style={{ alignSelf: "flex-end", maxWidth: "80%", background: "var(--accent)", color: "var(--accent-ink)", borderRadius: "14px 14px 4px 14px", padding: "9px 13px", fontSize: 14, whiteSpace: "pre-wrap" }}>
                {it.texto}
                {it.anexos.length > 0 && <div style={{ fontSize: 12, opacity: 0.8, marginTop: it.texto ? 4 : 0 }}>Anexo: {it.anexos.join(", ")}</div>}
              </div>
            );
          if (it.k === "ia")
            return (
              <div key={i} style={{ alignSelf: "flex-start", maxWidth: "85%", background: "var(--surface-2)", borderRadius: "14px 14px 14px 4px", padding: "10px 14px", fontSize: 14, lineHeight: 1.55, whiteSpace: "pre-wrap" }}>
                {it.texto}
              </div>
            );
          if (it.k === "erro")
            return (
              <div key={i} style={{ alignSelf: "flex-start", color: "var(--status-critical)", fontSize: 13.5, fontWeight: 600 }}>
                {it.texto}
              </div>
            );
          const { p } = it;
          return (
            <div key={i} style={{ alignSelf: "flex-start", width: "min(420px, 100%)", border: "1px solid var(--border-strong)", borderTop: "3px solid var(--accent)", borderRadius: 12, padding: "12px 14px", background: "var(--surface-2)" }}>
              <div style={{ fontSize: 11.5, fontWeight: 800, letterSpacing: ".06em", textTransform: "uppercase", color: "var(--text-muted)" }}>Conferir e lançar</div>
              <div style={{ fontWeight: 800, fontSize: 15, margin: "3px 0 8px" }}>
                {TITULO[p.tipo]} · {p.nome} · {mesLbl(p.mes)}
              </div>
              <table style={{ width: "100%", fontSize: 13.5, borderCollapse: "collapse" }}>
                <tbody>
                  {linhasProposta(p).map(([a, b]) => (
                    <tr key={a}>
                      <td style={{ padding: "4px 0", color: "var(--text-secondary)" }}>{a}</td>
                      <td style={{ padding: "4px 0", textAlign: "right", fontWeight: 700 }}>{b}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {p.resumo && <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 6 }}>{p.resumo}</div>}
              <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center", flexWrap: "wrap" }}>
                {(it.estado === "aberto" || it.estado === "erro") && (
                  <>
                    <button type="button" style={botao} onClick={() => lancar(i)}>Lançar no dashboard</button>
                    <button type="button" style={botao2} onClick={() => descartar(i)}>Descartar</button>
                  </>
                )}
                {it.estado === "gravando" && <span style={{ fontSize: 13 }}>Gravando…</span>}
                {it.estado === "descartado" && <span style={{ fontSize: 13, color: "var(--text-muted)" }}>Descartado: nada foi gravado.</span>}
                {it.msg && <span style={{ fontSize: 13, fontWeight: 600, color: it.estado === "lancado" ? "var(--status-good, #4ade80)" : "var(--status-critical)" }}>{it.msg}</span>}
              </div>
            </div>
          );
        })}
        {pensando && <div style={{ alignSelf: "flex-start", fontSize: 13, color: "var(--text-muted)" }}>O Assistente está pensando…</div>}
        <div ref={fimRef} />
      </div>

      <div style={{ ...caixa, padding: 12, display: "flex", flexDirection: "column", gap: 8 }}>
        {anexos.length > 0 && (
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {anexos.map((a, i) => (
              <span key={i} style={{ fontSize: 12, background: "var(--surface-2)", border: "1px solid var(--border-strong)", borderRadius: 99, padding: "4px 10px" }}>
                {a.nome}{" "}
                <button type="button" aria-label={`Tirar ${a.nome}`} onClick={() => setAnexos((l) => l.filter((_, j) => j !== i))} style={{ background: "none", border: "none", color: "inherit", cursor: "pointer", padding: 0 }}>
                  ×
                </button>
              </span>
            ))}
          </div>
        )}
        <textarea
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          onPaste={(e) => {
            const fs = Array.from(e.clipboardData.files);
            if (fs.length) { e.preventDefault(); anexar(fs); }
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); enviar(); }
          }}
          rows={3}
          placeholder="Escreva sua pergunta ou diga o que é o print (cliente e mês). Enter envia; Shift+Enter quebra linha."
          style={{ background: "var(--surface-2)", border: "1px solid var(--border-strong)", borderRadius: 9, padding: "9px 11px", color: "var(--text-primary)", fontSize: 14, fontFamily: "inherit", resize: "vertical" }}
        />
        {aviso && <div style={{ fontSize: 12.5, color: "var(--status-critical)", fontWeight: 600 }}>{aviso}</div>}
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <input ref={inputRef} type="file" accept={TIPOS_OK.join(",")} multiple hidden onChange={(e) => { anexar(e.target.files); e.target.value = ""; }} />
          <button type="button" style={botao2} onClick={() => inputRef.current?.click()}>Anexar print ou PDF</button>
          <button type="button" style={{ ...botao, opacity: pensando ? 0.6 : 1 }} disabled={pensando} onClick={() => enviar()}>Enviar</button>
          {itens.length > 0 && (
            <button type="button" style={{ ...botao2, marginLeft: "auto" }} onClick={() => { setHistorico([]); setItens([]); setAviso(""); }}>
              Nova conversa
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
