/* =========================================================
   "CRM em números" para os clientes que usam o RePediu (injetado pelo sistema quando o
   cliente tem repediu: true em src/lib/dashboards.ts).
   - Lê window.M7_DADOS.crm: { "AAAA-MM": {rec, msg, conv, r, rr?, rc?, rcr?, ate?, custo?, roas?, part?, rfv?, camp?, freq?} }.
   - Com os detalhes do painel do RePediu no mês: custo (descontos), ROAS, participação na receita,
     tabela RFV, campanhas e frequência de compra, embaixo dos cartões.
   - Desenha no topo da página de CRM do dashboard (ou na página CRM & Retenção criada
     pelo m7-paginas.js): 8 cartões do mês comparados com o mês anterior, uma leitura
     automática e um seletor de mês (com o acumulado).
   - Sem dados ainda: mostra o aviso de que o RePediu está ativo e o que falta enviar.
   - O Paçocas 1 tem o bloco próprio no HTML (#crmNumeros); lá este arquivo não faz nada.
   ========================================================= */
(function () {
  var MN = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  var cur = function (id) { var p = id.split('-'); return MN[+p[1] - 1].slice(0, 3) + '/' + p[0].slice(2); };
  var nome = function (id) { return MN[+id.split('-')[1] - 1]; };
  var ant = function (id) { var p = id.split('-'), y = +p[0], m = +p[1] - 1; if (!m) { m = 12; y--; } return y + '-' + (m < 10 ? '0' : '') + m; };
  var R = function (v) { return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var N = function (v) { return Math.round(v || 0).toLocaleString('pt-BR'); };
  var P = function (v) { return v.toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + '%'; };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  var CSS = '.m7n{background:var(--bg-card,#0D0D10);border:1px solid var(--border,rgba(244,242,234,.08));border-radius:16px;padding:24px 24px 16px;margin-bottom:16px}' +
    '.m7n-top{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}' +
    '.m7n-tag{display:inline-flex;align-items:center;gap:8px;background:var(--m7-orange,#F98612);color:#0D0D10;font-weight:800;font-size:16px;padding:8px 32px 8px 16px;clip-path:polygon(0 0,100% 0,94% 100%,0 100%);border-radius:8px 0 0 8px}' +
    '.m7n-tag b{opacity:.7}.m7n-sel{background:var(--bg-hover,#17171C);color:inherit;border:1px solid var(--border-strong,rgba(244,242,234,.16));border-radius:8px;padding:8px 8px;font:inherit;font-size:14px}' +
    '.m7n-g{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin-top:16px}@media(max-width:900px){.m7n-g{grid-template-columns:repeat(2,minmax(0,1fr))}}' +
    '.m7n-c{background:var(--bg-hover,#17171C);border:1px solid var(--border,rgba(244,242,234,.07));border-radius:16px;padding:16px 16px;min-height:88px}' +
    '.m7n-c.hl{background:linear-gradient(135deg,#F98612,#d96f05);border:none;color:#0D0D10}' +
    '.m7n-l{font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;opacity:.7}.m7n-v{font-size:24px;font-weight:800;margin:4px 0 8px}' +
    '.m7n-p{display:inline-block;font-size:12px;font-weight:700;border-radius:99px;padding:4px 8px}' +
    '.m7n-p.up{background:rgba(74,222,128,.14);color:#4ade80}.m7n-p.down{background:rgba(248,113,113,.14);color:#f87171}.m7n-p.neu{background:rgba(155,174,217,.14);color:#9BAED9}' +
    '.m7n-c.hl .m7n-p{background:rgba(13,13,16,.22);color:#0D0D10}' +
    '.m7n-x{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:16px}@media(max-width:900px){.m7n-x{grid-template-columns:1fr}}' +
    '.m7n-b{background:var(--bg-hover,#17171C);border:1px solid var(--border,rgba(244,242,234,.07));border-radius:16px;padding:16px 16px;min-width:0;overflow-x:auto}.m7n-b h4{margin:0 0 8px;font-size:14px}' +
    '.m7n-t{width:100%;border-collapse:collapse;font-size:12px}.m7n-t th{text-align:right;font-size:12px;opacity:.6;font-weight:700;text-transform:uppercase;letter-spacing:.04em;padding:4px 8px}.m7n-t th:first-child,.m7n-t td:first-child{text-align:left}.m7n-t td{text-align:right;padding:8px;border-top:1px solid rgba(244,242,234,.07)}' +
    '.m7n-i{margin-top:16px;background:rgba(255,255,255,.04);border-left:4px solid var(--m7-orange,#F98612);border-radius:8px;padding:8px 16px;font-size:14px;line-height:1.5}.m7n-i b{color:var(--m7-orange,#F98612)}';

  function alvo() {
    var el = document.getElementById('m7crm');
    if (el) return el;
    // página de CRM que o próprio dashboard já tem: bloco no topo
    var li = Array.prototype.slice.call(document.querySelectorAll('.nav-item')).filter(function (x) { return /CRM/.test(x.textContent || ''); })[0];
    if (!li) return null;
    var id = li.getAttribute('data-page'); if (!id) { var m = /switchPage\('([^']+)'\)/.exec(li.getAttribute('onclick') || ''); id = m && m[1]; }
    var pg = id && document.getElementById(id); if (!pg) return null;
    el = document.createElement('div'); el.id = 'm7crm'; pg.insertBefore(el, pg.firstChild);
    return el;
  }

  // detalhes do painel do RePediu no mês (quando enviados)
  function detalhes(v, p) {
    if (!v || !(v.custo != null || v.roas != null || v.part || v.rfv || v.camp || v.freq)) return '';
    var antes = function (b, fmt) { return b == null ? '' : ' <span style="font-size:12px;opacity:.7">(antes ' + fmt(b) + ')</span>'; };
    var X = function (x) { return x.toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + 'x'; };
    var mini = [];
    if (v.custo != null) mini.push(['Custo em descontos', R(v.custo) + antes(p && p.custo, R), 'desconto concedido nas compras do CRM']);
    if (v.roas != null) mini.push(['ROAS', X(v.roas) + antes(p && p.roas, X), 'receita do CRM ÷ custo']);
    if (v.part) mini.push(['Participação na receita', P(v.part.pct), 'de ' + R(v.part.total) + ' de receita total no período']);
    var h = mini.length ? '<div class="m7n-g" style="grid-template-columns:repeat(' + mini.length + ',minmax(0,1fr))">' + mini.map(function (m) { return '<div class="m7n-c"><div class="m7n-l">' + m[0] + '</div><div class="m7n-v" style="font-size:20px">' + m[1] + '</div><div style="font-size:12px;opacity:.6">' + m[2] + '</div></div>'; }).join('') + '</div>' : '';
    var bl = [];
    if (v.rfv && v.rfv.length) bl.push('<div class="m7n-b"><h4>Análise RFV por conversões</h4><table class="m7n-t"><tr><th>Grupo</th><th>Conv.</th><th>Ticket</th><th>Receita</th><th>Msg → compra</th></tr>' +
      v.rfv.map(function (x) { return '<tr><td>' + esc(x.c) + '</td><td>' + N(x.conv) + '</td><td>' + R(x.tk) + '</td><td>' + R(x.r) + '</td><td>' + (x.dias != null ? x.dias + (x.dias === 1 ? ' dia' : ' dias') : '—') + '</td></tr>'; }).join('') + '</table></div>');
    if (v.camp && v.camp.length) bl.push('<div class="m7n-b"><h4>Campanhas que venderam</h4><table class="m7n-t"><tr><th>Campanha</th><th>Env.</th><th>Conv.</th><th>Ticket</th><th>Receita</th></tr>' +
      v.camp.slice().sort(function (a, b) { return b.r - a.r; }).map(function (x) { return '<tr><td>' + esc(x.n) + '</td><td>' + (x.env != null ? N(x.env) : '—') + '</td><td>' + N(x.conv) + (x.env ? ' <span style="opacity:.6">(' + P(x.conv / x.env * 100) + ')</span>' : '') + '</td><td>' + R(x.tk) + '</td><td>' + R(x.r) + '</td></tr>'; }).join('') + '</table></div>');
    if (v.freq) {
      var f = v.freq, rot = ['1', '2', '3', '4', '5', '6', '7+'], mx = Math.max.apply(null, f.dist.concat((f.dist_ant || []).filter(function (n) { return n != null; })));
      bl.push('<div class="m7n-b" style="grid-column:1/-1"><h4>Frequência de compra</h4><div style="display:flex;gap:24px;flex-wrap:wrap;font-size:12px;margin-bottom:8px">' +
        '<span>Frequência média mensal: <b>' + f.media.toLocaleString('pt-BR') + '</b>' + antes(f.media_ant, function (x) { return x.toLocaleString('pt-BR'); }) + '</span>' +
        '<span>Compram 4x ou mais no mês: <b>' + N(f.c4) + '</b>' + antes(f.c4_ant, N) + '</span>' +
        '<span>Clientes que compraram: <b>' + N(f.tot) + '</b>' + antes(f.tot_ant, N) + '</span></div>' +
        '<div style="display:flex;gap:8px;align-items:flex-end">' + f.dist.map(function (n, k) {
          var a = f.dist_ant && f.dist_ant[k];
          return '<div style="flex:1;text-align:center;font-size:12px;min-width:44px"><div style="display:flex;gap:4px;align-items:flex-end;justify-content:center;height:92px">' +
            (a != null ? '<i title="antes: ' + a + '" style="display:block;width:38%;max-width:18px;background:rgba(155,174,217,.45);border-radius:4px 4px 1px 1px;height:' + Math.max(2, a / mx * 92).toFixed(0) + 'px"></i>' : '') +
            '<i title="' + n + '" style="display:block;width:38%;max-width:18px;background:#F98612;border-radius:4px 4px 1px 1px;height:' + Math.max(2, n / mx * 92).toFixed(0) + 'px"></i></div><b>' + N(n) + '</b><br>' + rot[k] + (k ? ' compras' : ' compra') + '</div>';
        }).join('') + '</div><div style="font-size:12px;opacity:.6;margin-top:8px">Clientes por número de compras no mês (laranja) e no período anterior (azul, quando o print mostra).</div></div>');
    }
    return h + (bl.length ? '<div class="m7n-x">' + bl.join('') + '</div>' : '');
  }

  function desenhar(el, D, per) {
    var meses = Object.keys(D).sort();
    var cliente = (window.CLIENTE && window.CLIENTE.nome) || '';
    if (!meses.length) {
      el.innerHTML = '<div class="m7n"><div class="m7n-top"><div class="m7n-tag"><b>CRM</b> RePediu</div></div>' +
        '<div class="m7n-i"><b>RePediu ativo' + (cliente ? ' em ' + esc(cliente) : '') + '.</b> Os números do CRM entram aqui quando o relatório do painel do RePediu for enviado: ' +
        'mensagens enviadas, conversões, receita gerada, clientes recuperados e recorrentes de cada mês. A partir do segundo mês, cada número vem comparado com o mês anterior.</div></div>';
      return;
    }
    var full = per === 'full', soma = { rec: 0, msg: 0, conv: 0, r: 0, rr: null, rc: null, rcr: null };
    if (full) meses.forEach(function (k) { var x = D[k]; soma.rec += x.rec || 0; soma.msg += x.msg || 0; soma.conv += x.conv || 0; soma.r += x.r || 0;
      ['rr', 'rc', 'rcr'].forEach(function (f) { if (x[f] != null) soma[f] = (soma[f] || 0) + x[f]; }); });
    var v = full ? soma : D[per], a = full ? null : ant(per), p = full ? null : D[a] || null;
    var tx = function (o) { return o && o.msg ? o.conv / o.msg * 100 : null; }, tk = function (o) { return o && o.conv ? o.r / o.conv : null; };
    var pill = function (at, an, fmt) {
      if (full) return '<span class="m7n-p neu">desde ' + cur(meses[0]) + '</span>';
      if (at == null) return '<span class="m7n-p neu">sem o dado no mês</span>';
      if (an == null || !an) return '<span class="m7n-p neu">sem ' + cur(a) + ' para comparar</span>';
      var d = (at - an) / an * 100;
      return '<span class="m7n-p ' + (d >= 0 ? 'up' : 'down') + '">' + (d >= 0 ? '▲ +' : '▼ ') + d.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '% · ' + cur(a).split('/')[0].toLowerCase() + ': ' + fmt(an) + '</span>';
    };
    var c = function (cls, l, val, fmt, an) { return '<div class="m7n-c ' + cls + '"><div class="m7n-l">' + l + '</div><div class="m7n-v">' + (val == null ? '—' : fmt(val)) + '</div>' + pill(val, an, fmt) + '</div>'; };
    var g = function (o, f) { return o && o[f] != null ? o[f] : null; };
    var cards = [
      c('hl', 'Receita gerada', v.r, R, g(p, 'r')),
      c('', 'Mensagens enviadas', v.msg, N, g(p, 'msg')),
      c('', 'Conversões', v.conv, N, g(p, 'conv')),
      c('', 'Taxa de conversão', tx(v), P, tx(p)),
      c('', 'Ticket do CRM', tk(v), R, tk(p)),
      c('', 'Clientes recuperados', g(v, 'rec'), N, g(p, 'rec')),
      c('', 'Receita recuperada', g(v, 'rr'), R, g(p, 'rr')),
      c('', 'Receita de recorrentes', g(v, 'rcr'), R, g(p, 'rcr'))
    ];
    var ins;
    if (full) ins = '<b>Acumulado do RePediu:</b> ' + R(v.r) + ' em ' + N(v.conv) + ' compras a partir de ' + N(v.msg) + ' mensagens, de ' + cur(meses[0]) + ' a ' + cur(meses[meses.length - 1]) + ' (' + meses.length + (meses.length > 1 ? ' meses' : ' mês') + ').';
    else if (p && p.r) {
      var it = [['receita', v.r, p.r], ['conversões', v.conv, p.conv], ['mensagens', v.msg, p.msg], ['clientes recuperados', v.rec, p.rec]]
        .filter(function (x) { return x[1] != null && x[2]; }).map(function (x) { return { n: x[0], d: (x[1] - x[2]) / x[2] * 100 }; });
      var fd = function (x) { return (x.d >= 0 ? '+' : '') + x.d.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%'; };
      var up = it.slice().sort(function (x, y) { return y.d - x.d; })[0], dn = it.slice().sort(function (x, y) { return x.d - y.d; })[0], dif = v.r - p.r;
      ins = '<b>O CRM vendeu ' + (dif >= 0 ? 'mais' : 'menos') + ' que em ' + nome(a).toLowerCase() + ':</b> receita ' + fd(it[0]) + ' (' + (dif >= 0 ? '+' : '−') + R(Math.abs(dif)) + '), ' + N(v.conv) + ' compras' + (tx(v) != null ? ' com taxa de ' + P(tx(v)) : '') + '.' +
        (up && up.d > 0 && up.n !== 'receita' ? ' Maior alta: ' + up.n + ' ' + fd(up) + '.' : '') + (dn && dn.d < 0 && dn.n !== 'receita' ? ' Maior queda: ' + dn.n + ' ' + fd(dn) + '.' : '');
    } else ins = '<b>' + nome(per) + ' é o primeiro mês com RePediu no dashboard.</b> Os próximos meses entram com a comparação.';
    var opts = '<option value="full"' + (full ? ' selected' : '') + '>Acumulado</option>' + meses.slice().reverse().map(function (k) { return '<option value="' + k + '"' + (k === per ? ' selected' : '') + '>' + nome(k) + '/' + k.slice(0, 4) + (D[k].ate ? ' (até ' + D[k].ate.split('-').reverse().slice(0, 2).join('/') + ')' : '') + '</option>'; }).join('');
    var ex = full ? '' : detalhes(v, p);
    el.innerHTML = '<div class="m7n"><div class="m7n-top"><div class="m7n-tag"><b>CRM</b> ' + (full ? 'Acumulado do RePediu' : nome(per) + ' em números') + '</div>' +
      '<select class="m7n-sel" aria-label="Mês do RePediu">' + opts + '</select></div><div class="m7n-g">' + cards.join('') + '</div><div class="m7n-i">' + ins + '</div>' + ex + '</div>';
    el.querySelector('select').addEventListener('change', function (e) { desenhar(el, D, e.target.value); });
  }

  function iniciar() {
    if (document.getElementById('crmNumeros')) return;   // Paçocas 1: bloco próprio no HTML
    var el = alvo(); if (!el) return;
    var st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    var D = (window.M7_DADOS && window.M7_DADOS.crm) || {}, ms = Object.keys(D).sort();
    desenhar(el, D, ms.length ? ms[ms.length - 1] : 'full');
  }
  if (document.readyState === 'complete') iniciar(); else window.addEventListener('load', iniciar);
})();
