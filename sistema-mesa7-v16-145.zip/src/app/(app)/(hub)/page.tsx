import { requireSession } from "@/lib/access";
import { IconGlyph } from "@/components/ui";
import { BuscarCliente } from "@/components/BuscarCliente";
import { clientesAtivos, painelDe, type CartaoArea } from "@/lib/painel";

export const dynamic = "force-dynamic";

const ROLE_LABEL: Record<string, string> = {
  admin: "Administração",
  cs: "Customer Success",
  trafego: "Tráfego",
  social: "Social Media",
  cardapio: "Cardápio, iFood e RePediu",
  crm: "CRM",
  design: "Design",
  google: "Google",
};

type Icone = "store" | "money" | "percent" | "users" | "chart" | "megaphone" | "grid";
const ICONE_AREA: Record<string, Icone> = { trafego: "megaphone", social: "users", crm: "money", cardapio: "money", google: "chart", design: "grid", admin: "money", cs: "money" };

function Cartao({ icone, rotulo, valor, legenda }: { icone: Icone; rotulo: string; valor: string; legenda: string }) {
  return (
    <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 16, padding: 24, boxShadow: "var(--shadow)", minWidth: 0 }}>
      <div style={{ width: 40, height: 40, borderRadius: 8, background: "var(--accent-soft)", display: "grid", placeItems: "center" }}>
        <IconGlyph name={icone} color="var(--accent)" />
      </div>
      <div className="num" style={{ fontSize: 32, lineHeight: "40px", fontWeight: 700, margin: "24px 0 8px", letterSpacing: "-0.02em", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
        {valor}
      </div>
      <div style={{ fontSize: 14, fontWeight: 800, lineHeight: "24px" }}>{rotulo}</div>
      <div style={{ fontSize: 12, lineHeight: "16px", color: "var(--text-muted)", marginTop: 4 }}>{legenda}</div>
    </div>
  );
}

// Painel inicial da equipe: "Olá, nome!" e os números da carteira e da área de quem entrou.
export default async function PainelPage() {
  const session = await requireSession();
  const role = session.user.role;
  const nome = (session.user.name || "").trim().split(/\s+/)[0] || "equipe";
  const painel = await painelDe(role, session.user.email);
  const area: CartaoArea = painel.area;
  const taxa: CartaoArea = painel.taxa;

  return (
    <div style={{ padding: 48, maxWidth: 1240 }}>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 24, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--accent)" }}>
            Mesa7 · {ROLE_LABEL[role] ?? role}
          </div>
          <h1 style={{ fontSize: 40, lineHeight: "48px", margin: "8px 0" }}>Olá, {nome}!</h1>
          <p style={{ margin: 0, fontSize: 16, lineHeight: "24px", color: "var(--text-secondary)" }}>
            Resultados de {painel.mesRefNome} da sua área. Bora cuidar dos clientes.
          </p>
        </div>
        <BuscarCliente clientes={clientesAtivos().map((d) => ({ pasta: d.pasta, nome: d.nome, segmento: d.segmento }))} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 16, marginTop: 32 }}>
        <Cartao
          icone="store"
          rotulo="Clientes que você cuida"
          valor={String(painel.carteira.n)}
          legenda={painel.carteira.todos ? "todos os clientes ativos" : `de ${painel.carteira.ativos} clientes ativos`}
        />
        <Cartao icone={ICONE_AREA[role] ?? "chart"} rotulo={area.rotulo} valor={area.valor} legenda={area.legenda} />
        <Cartao icone="percent" rotulo={taxa.rotulo} valor={taxa.valor} legenda={taxa.legenda} />
        <Cartao
          icone="users"
          rotulo="Empresas já cuidadas"
          valor={String(painel.total.n)}
          legenda={`${painel.total.ativos} ativas · ${painel.total.encerrados} encerradas`}
        />
      </div>
    </div>
  );
}
