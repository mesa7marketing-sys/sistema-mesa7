import type { Metadata } from "next";
import { cookies } from "next/headers";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sistema Mesa7",
  description: "Painel de relatórios Mesa7 — Método CVR",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  // tema escolhido em Opções (cookie): escuro é o padrão
  const tema = (await cookies()).get("m7tema")?.value === "claro" ? "light" : "dark";
  return (
    <html lang="pt-BR" data-theme={tema}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500;600;700&family=Nunito+Sans:opsz,wght@6..12,400;6..12,500;6..12,600;6..12,700;6..12,800&family=Poppins:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
