"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";

type Item = { pasta: string; nome: string; segmento: string };

// Botão "Buscar cliente" do painel: abre uma busca (Esc fecha, Enter abre o primeiro resultado).
export function BuscarCliente({ clientes }: { clientes: Item[] }) {
  const [aberto, setAberto] = useState(false);
  const [q, setQ] = useState("");
  const [sel, setSel] = useState(0);
  const router = useRouter();

  const norm = (s: string) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const lista = useMemo(() => {
    const t = norm(q.trim());
    return clientes.filter((c) => !t || norm(c.nome).includes(t) || norm(c.segmento).includes(t));
  }, [q, clientes]);

  const fechar = () => { setAberto(false); setQ(""); setSel(0); };

  function abrir(c: Item | undefined) {
    if (!c) return;
    fechar();
    router.push(`/dashboards/${c.pasta}`);
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setAberto(true)}
        style={{
          display: "inline-flex", alignItems: "center", gap: 8, height: 40, padding: "0 24px",
          borderRadius: 99, border: "none", background: "var(--accent)", color: "var(--accent-ink)",
          fontFamily: "inherit", fontSize: 14, fontWeight: 800, cursor: "pointer",
          boxShadow: "0 8px 24px var(--accent-soft)",
        }}
      >
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" aria-hidden>
          <circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" />
        </svg>
        Buscar cliente
      </button>

      {aberto && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Buscar cliente"
          onClick={(e) => { if (e.target === e.currentTarget) fechar(); }}
          onKeyDown={(e) => {
            if (e.key === "Escape") fechar();
            if (e.key === "ArrowDown") { e.preventDefault(); setSel((s) => Math.min(s + 1, lista.length - 1)); }
            if (e.key === "ArrowUp") { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
            if (e.key === "Enter") abrir(lista[sel]);
          }}
          style={{ position: "fixed", inset: 0, zIndex: 50, background: "rgba(0,0,0,.55)", display: "flex", justifyContent: "center", alignItems: "flex-start", padding: "96px 16px 16px" }}
        >
          <div style={{ width: "100%", maxWidth: 560, background: "var(--surface)", border: "1px solid var(--border-strong)", borderRadius: 16, boxShadow: "var(--shadow)", overflow: "hidden" }}>
            <input
              autoFocus
              value={q}
              onChange={(e) => { setQ(e.target.value); setSel(0); }}
              placeholder="Digite o nome do cliente…"
              aria-label="Nome do cliente"
              style={{ width: "100%", height: 56, padding: "0 24px", border: "none", borderBottom: "1px solid var(--border)", background: "transparent", color: "var(--text-primary)", fontFamily: "inherit", fontSize: 16, outline: "none" }}
            />
            <div style={{ maxHeight: 360, overflowY: "auto", padding: 8 }}>
              {lista.map((c, i) => (
                <button
                  key={c.pasta}
                  type="button"
                  onClick={() => abrir(c)}
                  onMouseEnter={() => setSel(i)}
                  style={{
                    width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16,
                    padding: "8px 16px", minHeight: 40, borderRadius: 8, border: "none", textAlign: "left", cursor: "pointer",
                    fontFamily: "inherit", background: i === sel ? "var(--accent-soft)" : "transparent", color: "var(--text-primary)",
                  }}
                >
                  <span style={{ fontWeight: 700, fontSize: 14 }}>{c.nome}</span>
                  <span style={{ fontSize: 12, color: "var(--text-muted)" }}>{c.segmento}</span>
                </button>
              ))}
              {!lista.length && <div style={{ padding: 24, textAlign: "center", fontSize: 14, color: "var(--text-muted)" }}>Nenhum cliente com esse nome.</div>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
