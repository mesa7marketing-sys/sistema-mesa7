import { LogoMesa7 } from "@/components/LogoMesa7";
import { SignOutButton } from "@/components/SignOutButton";
import Link from "next/link";
import { HubNavLinks } from "@/components/HubNavLinks";
import { TemaSwitch } from "@/components/TemaSwitch";

export function HubSidebar({ userName, userRole, isAdmin = false }: { userName: string; userRole: string; isAdmin?: boolean }) {
  return (
    <aside
      style={{
        background: "var(--surface)",
        borderRight: "1px solid var(--border)",
        padding: "22px 14px 18px",
        display: "flex",
        flexDirection: "column",
        gap: 20,
        position: "sticky",
        top: 0,
        height: "100vh",
        overflowY: "auto",
      }}
    >
      <LogoMesa7 legenda="Sistema Mesa7" />

      <HubNavLinks isAdmin={isAdmin} />

      <div style={{ marginTop: "auto", display: "flex", flexDirection: "column", gap: 8 }}>
        <div style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: "0.1em", color: "var(--text-muted)", padding: "0 8px", fontWeight: 700 }}>Opções</div>
        <TemaSwitch />
      </div>

      <div
        style={{
          padding: 12,
          borderTop: "1px solid var(--border)",
          fontSize: 11,
          color: "var(--text-muted)",
          lineHeight: 1.5,
        }}
      >
        <div style={{ color: "var(--text-secondary)", fontWeight: 700 }}>{userName}</div>
        <div>{userRole}</div>
        <Link href="/minha-senha" style={{ display: "inline-block", marginTop: 8, color: "var(--text-muted)", fontSize: 11, textDecoration: "underline" }}>
          Minha senha
        </Link>
        <SignOutButton />
      </div>
    </aside>
  );
}
