"use client";

import { useSyncExternalStore } from "react";

// Escolha de tema (escuro/claro) em "Opções" na lateral. Grava o cookie m7tema (lido no servidor,
// sem piscar ao carregar) e troca o atributo data-theme da página na hora.
type Tema = "dark" | "light";

function gravarTema(t: Tema) {
  document.documentElement.dataset.theme = t;
  document.cookie = `m7tema=${t === "light" ? "claro" : "escuro"}; path=/; max-age=31536000; samesite=lax`;
}
const lerTema = (): Tema => (document.documentElement.dataset.theme === "light" ? "light" : "dark");
function assinar(aviso: () => void) {
  const o = new MutationObserver(aviso);
  o.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
  return () => o.disconnect();
}

export function TemaSwitch() {
  const tema = useSyncExternalStore(assinar, lerTema, () => "dark" as Tema);
  const escolher = (t: Tema) => gravarTema(t);

  const base: React.CSSProperties = {
    flex: 1,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    height: 32,
    borderRadius: 8,
    border: "none",
    fontFamily: "inherit",
    fontSize: 12,
    fontWeight: 700,
    cursor: "pointer",
  };
  const item = (t: "dark" | "light", rotulo: string, icone: React.ReactNode) => (
    <button
      type="button"
      onClick={() => escolher(t)}
      aria-pressed={tema === t}
      style={{
        ...base,
        background: tema === t ? "var(--accent)" : "transparent",
        color: tema === t ? "var(--accent-ink)" : "var(--text-secondary)",
      }}
    >
      <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        {icone}
      </svg>
      {rotulo}
    </button>
  );

  return (
    <div role="group" aria-label="Tema da tela" style={{ display: "flex", gap: 4, padding: 4, borderRadius: 12, background: "var(--surface-2)", border: "1px solid var(--border)" }}>
      {item("dark", "Escuro", <path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5Z" />)}
      {item("light", "Claro", <path d="M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0-13v2m0 14v2M3 12h2m14 0h2M5.6 5.6 7 7m10 10 1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4" />)}
    </div>
  );
}
