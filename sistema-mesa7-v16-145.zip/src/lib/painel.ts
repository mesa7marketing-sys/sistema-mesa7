// Painel inicial da equipe: números da carteira de cada pessoa e dos resultados da área dela.
//
// Carteira (quais clientes cada pessoa cuida): arquivo opcional <pasta de arquivos>/_acessos/carteira.json,
//   { "email@da.pessoa": ["pasta-do-cliente", ...] }. Quem não está no arquivo vê todos os clientes ativos.
// Faturamento dos clientes: dashboards em implantação (dados enviados) e completos (a lista MESES do próprio
// HTML do dashboard, lida aqui no servidor, sem executar nada além do literal da lista).
import { promises as fs } from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { ARQUIVADOS, DASHBOARDS, estaArquivado, type Dashboard } from "@/lib/dashboards";
import { dadosDoCliente, type DadosCliente } from "@/lib/dados-clientes";
import { raizArquivos } from "@/lib/arquivos";

const MESES_NOME = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
export const mesNome = (id: string) => `${MESES_NOME[+id.slice(5) - 1]}/${id.slice(0, 4)}`;

/** Mês de referência dos totais: o último mês fechado (o mês atual ainda está em andamento). */
export function mesReferencia(hoje = new Date()) {
  const d = new Date(hoje.getFullYear(), hoje.getMonth() - 1, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
const antes = (id: string) => {
  const d = new Date(+id.slice(0, 4), +id.slice(5) - 2, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
};

export const clientesAtivos = (): Dashboard[] => DASHBOARDS.filter((d) => !estaArquivado(d.pasta));

export async function carteiraDe(email: string | null | undefined): Promise<{ clientes: Dashboard[]; todos: boolean }> {
  const ativos = clientesAtivos();
  try {
    const j = JSON.parse(await fs.readFile(path.join(raizArquivos(), "_acessos", "carteira.json"), "utf8")) as Record<string, string[]>;
    const meus = email ? j[email.toLowerCase()] ?? j[email] : undefined;
    if (Array.isArray(meus)) return { clientes: ativos.filter((d) => meus.includes(d.pasta)), todos: false };
  } catch {
    /* sem arquivo de carteira: todos os clientes ativos */
  }
  return { clientes: ativos, todos: true };
}

type LinhaMes = { id: string; tot?: number; sal?: number; del?: number | { r?: number }; parcial?: unknown; ate?: unknown; semFaturamento?: boolean; semVenda?: boolean };

/** Lê a lista MESES de um dashboard completo (só o literal da lista, em sandbox, sem acesso a nada). */
async function mesesDoHtml(pasta: string): Promise<LinhaMes[]> {
  try {
    const s = await fs.readFile(path.join(process.cwd(), "dashboards", pasta, "index.html"), "utf8");
    const ini = s.indexOf("const MESES = [");
    if (ini < 0) return [];
    const a = ini + "const MESES = ".length;
    let prof = 0, aspa: string | null = null, esc = false, j = a;
    for (; j < s.length; j++) {
      const c = s[j];
      if (aspa) { if (esc) esc = false; else if (c === "\\") esc = true; else if (c === aspa) aspa = null; continue; }
      if (c === "'" || c === '"' || c === "`") { aspa = c; continue; }
      if (c === "[") prof++;
      if (c === "]" && --prof === 0) { j++; break; }
    }
    const lista = vm.runInNewContext("(" + s.slice(a, j) + ")", Object.create(null), { timeout: 500 });
    return Array.isArray(lista) ? (lista as LinhaMes[]) : [];
  } catch {
    return [];
  }
}

/** Faturamento total do cliente no mês (mesma regra dos dashboards); null quando o mês não tem número fechado. */
async function faturamentoDo(d: Dashboard, dados: DadosCliente, mes: string): Promise<number | null> {
  const sp = dados.saipos[mes];
  const spCompleto = sp && !sp.ate && sp.r > 0 ? sp.r : null;
  if (d.status === "completo") {
    const m = (await mesesDoHtml(d.pasta)).find((x) => x.id === mes);
    if (!m || m.semFaturamento || m.semVenda || m.parcial || m.ate) return spCompleto;
    if (spCompleto) return spCompleto;
    const dlv = typeof m.del === "object" && m.del ? m.del.r ?? 0 : m.del ?? 0;
    let r = (m.tot ?? 0) > 0 ? (m.tot as number) : (m.sal ?? 0) + dlv;
    // Burguin e Duana Centro: o iFood fica fora do MESES e entra na soma
    if ((m.tot ?? 0) > 0 && ["burguin", "duana-centro"].includes(d.pasta)) r += dados.ifood[mes]?.r ?? 0;
    return r > 0 ? r : null;
  }
  const sal = dados.salao[mes];
  if (!sal) return spCompleto;
  if (sal.ate) return null;
  return sal.r + (spCompleto ?? (dados.ifood[mes]?.r ?? 0) + (dados.cardapio[mes]?.r ?? 0));
}

export type CartaoArea = { rotulo: string; valor: string; legenda: string; tom?: "bom" | "ruim" };
export type PainelDados = {
  mesRef: string;
  mesRefNome: string;
  carteira: { n: number; ativos: number; todos: boolean };
  area: CartaoArea;
  taxa: CartaoArea;
  total: { n: number; ativos: number; encerrados: number };
};

const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
const int = (n: number) => Math.round(n).toLocaleString("pt-BR");
const pct = (n: number) => `${n.toLocaleString("pt-BR", { maximumFractionDigits: 1 })}%`;
const variacao = (a: number, b: number) => (b ? ((a - b) / b) * 100 : null);
const sufixo = (v: number | null, ref: string) => (v == null ? "" : ` · ${v >= 0 ? "▲" : "▼"} ${pct(Math.abs(v))} vs ${mesNome(antes(ref)).split("/")[0]}`);

export async function painelDe(role: string, email: string | null | undefined): Promise<PainelDados> {
  const mes = mesReferencia();
  const ant = antes(mes);
  const { clientes, todos } = await carteiraDe(email);
  const dados = await Promise.all(clientes.map(async (c) => ({ c, d: await dadosDoCliente(c.pasta) })));
  const soma = <T,>(f: (x: { c: Dashboard; d: DadosCliente }) => T | undefined | null, get: (v: T) => number) =>
    dados.reduce((t, x) => { const v = f(x); return v == null ? t : t + get(v); }, 0);
  const comDado = <T,>(f: (x: { c: Dashboard; d: DadosCliente }) => T | undefined | null) => dados.filter((x) => f(x) != null).length;

  let area: CartaoArea, taxa: CartaoArea;
  const semDado = (rotulo: string): CartaoArea => ({ rotulo, valor: "—", legenda: `aguardando dados de ${mesNome(mes)}` });

  if (role === "trafego") {
    const gas = soma((x) => x.d.meta[mes], (m) => m.gas), gasA = soma((x) => x.d.meta[ant], (m) => m.gas);
    const cmp = soma((x) => x.d.meta[mes], (m) => m.cmp ?? 0), clk = soma((x) => x.d.meta[mes], (m) => m.clk);
    const n = comDado((x) => x.d.meta[mes]);
    area = n ? { rotulo: "Investimento em Meta Ads", valor: brl(gas), legenda: `${int(cmp)} compras · ${mesNome(mes)}${sufixo(variacao(gas, gasA), mes)}` } : semDado("Investimento em Meta Ads");
    taxa = n && clk ? { rotulo: "Taxa de conversão do tráfego", valor: pct((cmp / clk) * 100), legenda: "compras ÷ cliques no link" } : semDado("Taxa de conversão do tráfego");
  } else if (role === "social") {
    // ganho = última leitura do mês − última do mês anterior; sem o mês anterior, desde a primeira leitura do próprio mês
    const ganho = (x: { d: DadosCliente }) => {
      const a = x.d.instagram[mes], b = x.d.instagram[ant];
      if (a && b) return { g: a.seg - b.seg, base: b.seg, parcial: false };
      if (a && a.ini != null) return { g: a.seg - a.ini, base: a.ini, parcial: true };
      return null;
    };
    const n = comDado(ganho);
    const g = soma(ganho, (v) => v!.g), base = soma(ganho, (v) => v!.base);
    const parc = dados.some((x) => ganho(x)?.parcial);
    area = n ? { rotulo: "Seguidores ganhos", valor: `${g >= 0 ? "+" : ""}${int(g)}`, legenda: `em ${n} perfis · ${mesNome(mes)}${parc ? " (desde a 1ª leitura do mês)" : ""}`, tom: g >= 0 ? "bom" : "ruim" } : semDado("Seguidores ganhos");
    taxa = n && base ? { rotulo: "Crescimento da audiência", valor: pct((g / base) * 100), legenda: "seguidores no mês ÷ base do mês anterior" } : semDado("Crescimento da audiência");
  } else if (role === "crm") {
    const n = comDado((x) => x.d.crm[mes]);
    const r = soma((x) => x.d.crm[mes], (m) => m.r), msg = soma((x) => x.d.crm[mes], (m) => m.msg ?? 0), conv = soma((x) => x.d.crm[mes], (m) => m.conv);
    area = n ? { rotulo: "Receita gerada pelo CRM", valor: brl(r), legenda: `${int(conv)} compras · RePediu · ${mesNome(mes)}` } : semDado("Receita gerada pelo CRM");
    taxa = n && msg ? { rotulo: "Taxa de conversão do CRM", valor: pct((conv / msg) * 100), legenda: "compras ÷ mensagens enviadas" } : semDado("Taxa de conversão do CRM");
  } else if (role === "google") {
    const n = comDado((x) => x.d.gmb[mes]);
    const acoes = soma((x) => x.d.gmb[mes], (m) => m.ch + m.rt + m.st);
    const vis = soma((x) => x.d.gmb[mes], (m) => m.v);
    area = n ? { rotulo: "Ações no Google Meu Negócio", valor: int(acoes), legenda: `ligações, rotas e cliques · ${mesNome(mes)}` } : semDado("Ações no Google Meu Negócio");
    taxa = n && vis ? { rotulo: "Taxa de ação do perfil", valor: pct((acoes / vis) * 100), legenda: "ações ÷ visualizações do perfil" } : semDado("Taxa de ação do perfil");
  } else if (role === "design") {
    area = { rotulo: "Resultados da área", valor: "—", legenda: "em breve" };
    taxa = { rotulo: "Taxa de conversão", valor: "—", legenda: "em breve" };
  } else {
    // administração, CS e cardápio/iFood: faturamento dos clientes (cardápio: iFood) e conversão do cardápio no iFood
    const funil = (x: { d: DadosCliente }) => x.d.ifood_funil[mes];
    const nf = comDado(funil);
    const vis = soma(funil, (f) => f.vis), conc = soma(funil, (f) => f.conc);
    taxa = nf && vis ? { rotulo: "Conversão do cardápio no iFood", valor: pct((conc / vis) * 100), legenda: `visita → pedido em ${nf} clientes · ${mesNome(mes)}` } : semDado("Conversão do cardápio no iFood");
    if (role === "cardapio") {
      const n = comDado((x) => x.d.ifood[mes]);
      const r = soma((x) => x.d.ifood[mes], (m) => m.r), rA = soma((x) => x.d.ifood[ant], (m) => m.r);
      area = n ? { rotulo: "Faturamento no iFood", valor: brl(r), legenda: `${n} clientes · ${mesNome(mes)}${sufixo(variacao(r, rA), mes)}` } : semDado("Faturamento no iFood");
    } else {
      const fat = await Promise.all(dados.map((x) => faturamentoDo(x.c, x.d, mes)));
      const fatA = await Promise.all(dados.map((x) => faturamentoDo(x.c, x.d, ant)));
      const n = fat.filter((v) => v != null).length;
      const total = fat.reduce<number>((t, v) => t + (v ?? 0), 0);
      // compara só os clientes que têm número nos dois meses
      let a = 0, b = 0;
      fat.forEach((v, i) => { if (v != null && fatA[i] != null) { a += v; b += fatA[i] as number; } });
      area = n ? { rotulo: "Faturamento dos clientes", valor: brl(total), legenda: `${n} de ${dados.length} clientes · ${mesNome(mes)}${sufixo(variacao(a, b), mes)}` } : semDado("Faturamento dos clientes");
    }
  }

  const ativos = clientesAtivos().length;
  return {
    mesRef: mes,
    mesRefNome: mesNome(mes),
    carteira: { n: clientes.length, ativos, todos },
    area,
    taxa,
    total: { n: ativos + ARQUIVADOS.length, ativos, encerrados: ARQUIVADOS.length },
  };
}
