/* =========================================================
   Mesa7 — Marketplace e Delivery (padrão de todos os dashboards "completos")
   Injetado pelo Sistema Mesa7 (src/app/d/[token]/arquivo/...) depois do HTML.

   Cada dashboard define, depois de montar MESES, a função
     window.m7PlatDados = () => [{ id:'2026-07', cur:'Jul/26', lbl:'Julho/2026',
        entrega:{r,o,t} | null,                      // delivery total (PDV / cardápio)
        plat:{ ifd:{r,o,t}, f99:{...}, car:{...}, loj:{...}, wpp:{...} } }]
   (r = faturamento, o = pedidos, t = ticket; mês sem relatório = ausente ou zerado,
   e conta como "sem dados", nunca como zero).

   O que este script faz:
   - Marketplace = só iFood e 99Food. Delivery = só delivery próprio (Cardápio Web,
     Anota Aí, site, WhatsApp, pedido pela loja). Cada um tem a sua página no menu.
   - Se o dashboard já tem uma página "Plataformas"/"Marketplace" feita à mão, ela é
     renomeada para "Marketplace", perde os blocos de canais próprios (que vão para
     Delivery) e ganha no fim o gráfico dos últimos 12 meses.
   - Senão, a página Marketplace é criada aqui.
   - A página Delivery é sempre criada.
   ========================================================= */
(function () {
  'use strict';
  var main = document.querySelector('main');
  var nav = document.querySelector('.nav-menu');
  if (!main || !nav || typeof window.m7PlatDados !== 'function' || typeof window.Chart === 'undefined') return;

  var PLATS = [
    { k: 'ifd', nome: 'iFood', ic: 'fa-bag-shopping', mkt: true, cor: '#F98612', fundo: 'rgba(249,134,18,.14)', cls: 'highlight' },
    { k: 'f99', nome: '99Food', ic: 'fa-motorcycle', mkt: true, cor: '#F4F2EA', fundo: 'rgba(244,242,234,.10)', cls: 'cream' },
    { k: 'car', nome: 'Cardápio Próprio', ic: 'fa-link', mkt: false, cor: '#9BAED9', fundo: 'rgba(155,174,217,.16)', cls: 'blue' },
    { k: 'loj', nome: 'Portal (pedido pela loja)', ic: 'fa-shop', mkt: false, cor: '#6FD3C4', fundo: 'rgba(111,211,196,.12)', cls: 'deep' },
    { k: 'ana', nome: 'Anota Aí', ic: 'fa-bag-shopping', mkt: false, cor: '#F2C94C', fundo: 'rgba(242,201,76,.12)', cls: 'blue' },
    { k: 'wpp', nome: 'WhatsApp', ic: 'fa-comments', mkt: false, cor: '#C792EA', fundo: 'rgba(199,146,234,.12)', cls: 'deep' }
  ];
  var MESES = [];
  try { MESES = window.m7PlatDados() || []; } catch (e) { console.error('m7PlatDados', e); }
  if (!MESES.length) return;
  MESES.sort(function (a, b) { return a.id < b.id ? -1 : 1; });

  var brl = function (v) { return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var int = function (v) { return (v || 0).toLocaleString('pt-BR'); };
  var pct = function (v) { return (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%'; };
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function delta(cur, prev) {
    if (prev === null || prev === undefined || !prev) return null;
    var p = (cur - prev) / prev * 100;
    return { t: (p > 0 ? '+' : '') + p.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%', c: Math.abs(p) < 0.05 ? 'neutral' : (p > 0 ? 'up' : 'down') };
  }

  var tem = function (m, k) { var p = m && m.plat && m.plat[k]; return !!(p && (p.r > 0 || p.o > 0)); };
  var ativas = PLATS.filter(function (p) { return MESES.some(function (m) { return tem(m, p.k); }); });
  function ticket(p) { return p.t || (p.o ? p.r / p.o : null); }
  function janela12(idx) { return MESES.slice(Math.max(0, idx - 11), idx + 1); }
  function soma(lista, k) {
    var l = lista.filter(function (m) { return tem(m, k); });
    if (!l.length) return null;
    var r = 0, o = 0; l.forEach(function (m) { r += m.plat[k].r; o += m.plat[k].o || 0; });
    return { r: r, o: o, t: o ? r / o : null };
  }

  /* ---------- gráficos (mesmo estilo da Evolução de Faturamento) ---------- */
  var AX = { grid: { color: 'rgba(155,174,217,.12)' }, ticks: { color: '#9BAED9' }, border: { color: 'rgba(155,174,217,.12)' } };
  var eixoR = Object.assign({}, AX, { beginAtZero: true, ticks: { color: '#9BAED9', callback: function (v) { return 'R$ ' + (v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v); } } });
  var legenda = { position: 'bottom', labels: { color: '#F4F2EA', padding: 12, usePointStyle: true, pointStyle: 'circle' } };
  function tip(fmt) {
    return { callbacks: {
      label: function (c) { return c.dataset.label + ': ' + (fmt ? fmt(c.parsed.y) : brl(c.parsed.y)); },
      afterLabel: function (c) { var d = c.dataset.det && c.dataset.det[c.dataIndex]; if (!d || !d.o) return ''; var t = ticket(d); return int(d.o) + ' pedidos' + (t ? ' · ticket ' + brl(t) : ''); }
    } };
  }
  function linha(canvasId, fmtEixo, fmtTip) {
    var el = document.getElementById(canvasId); if (!el) return null;
    return new Chart(el, { type: 'line', data: { labels: [], datasets: [] },
      options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
        plugins: { legend: legenda, tooltip: tip(fmtTip) },
        scales: { x: AX, y: fmtEixo ? Object.assign({}, AX, { beginAtZero: true, ticks: { color: '#9BAED9', callback: fmtEixo } }) : eixoR } } });
  }
  function serie(label, cor, fundo, dados, det, preencher) {
    return { label: label, borderColor: cor, backgroundColor: fundo, fill: !!preencher, tension: .35, pointBackgroundColor: cor, pointRadius: 3, pointHoverRadius: 6, borderWidth: 2.5, data: dados, det: det, spanGaps: false };
  }

  /* ---------- menu ---------- */
  function renumerar() {
    Array.prototype.slice.call(nav.querySelectorAll('.nav-item')).forEach(function (el, i) {
      Array.prototype.slice.call(el.childNodes).forEach(function (n) {
        if (n.nodeType === 3) { var t = n.nodeValue.replace(/^\s*(\d+\.\s*)?/, ''); if (t) n.nodeValue = ' ' + (i + 1) + '. ' + t; }
      });
    });
  }
  function novoItem(id, icone, titulo, depoisDe) {
    var li = document.createElement('li');
    li.className = 'nav-item';
    li.setAttribute('onclick', "switchPage('" + id + "')");
    li.innerHTML = '<i class="fa-solid ' + icone + '"></i> ' + titulo;
    if (depoisDe && depoisDe.nextSibling) nav.insertBefore(li, depoisDe.nextSibling); else nav.appendChild(li);
    var pagina = document.createElement('div');
    pagina.id = id;
    pagina.className = 'view-page';
    main.appendChild(pagina);
    return { li: li, pagina: pagina };
  }
  function titulo(id, icone, t, sub) {
    try { headings[id] = { t: '<i class="fa-solid ' + icone + '" style="color:var(--m7-orange)"></i> ' + t, s: sub }; } catch (e) { /* dashboard sem headings */ }
  }

  /* ---------- páginas ---------- */
  var paginas = [];   // cada uma com seu atualizar(per, idx, mes, isRange)
  var todosCharts = [];

  /* cfg: { pref, nome, icone, sub, grupo:[plataformas], tituloR, notaR, extras }  */
  function montar(cfg, pg, criar) {
    var grupo = cfg.grupo, P = cfg.pref;
    var gAt = grupo.filter(function (p) { return ativas.indexOf(p) > -1; });   // só o que tem dado entra nos gráficos
    var multi = gAt.length > 1;
    var h = '';
    if (criar) {
      h += '<div class="filter-chip"><i class="fa-solid fa-calendar-day"></i> <span id="' + P + 'Chip"></span></div>';
      h += '<div class="kpi-grid" id="' + P + 'Cards"></div>';
    }
    h += '<div class="grid-2"><div class="chart-card" ' + (multi || !criar ? 'style="grid-column:1/-1"' : 'style="grid-column:1/-1"') + '><div class="chart-header"><div class="chart-title"><i class="fa-solid ' + cfg.icone + '"></i> ' + cfg.tituloR + ' · últimos 12 meses</div></div>' +
      '<div class="chart-container"><canvas id="' + P + 'R"></canvas></div><p class="chart-note" id="' + P + 'RNota"></p></div></div>';
    if (criar) {
      h += '<div class="chart-card" style="margin-bottom:22px"><div class="chart-header"><div class="chart-title"><i class="fa-solid fa-scale-balanced"></i> Comparativo · ' + cfg.nome + '</div></div>' +
        '<div style="overflow-x:auto"><table class="data-table"><thead><tr><th>Canal</th><th>Faturamento</th><th>Pedidos</th><th>Ticket médio</th><th>Participação</th><th>vs mês anterior</th></tr></thead><tbody id="' + P + 'Tab"></tbody></table></div>' +
        '<p class="chart-note">Canais sem relatório no mês aparecem como "—" e ficam fora do total.</p></div>';
      var cPiz = '<div class="chart-card"><div class="chart-header"><div class="chart-title"><i class="fa-solid fa-chart-pie"></i> Participação por Canal</div></div><div class="chart-container"><canvas id="' + P + 'Piz"></canvas></div></div>';
      var cPed = '<div class="chart-card"><div class="chart-header"><div class="chart-title"><i class="fa-solid fa-bag-shopping"></i> Pedidos · 12 meses</div></div><div class="chart-container"><canvas id="' + P + 'Ped"></canvas></div></div>';
      var cTkt = '<div class="chart-card"><div class="chart-header"><div class="chart-title"><i class="fa-solid fa-receipt"></i> Ticket Médio · 12 meses</div></div><div class="chart-container"><canvas id="' + P + 'Tkt"></canvas></div></div>';
      h += multi
        ? '<div class="grid-2">' + cPiz + cPed + '</div><div class="grid-2">' + cTkt.replace('class="chart-card"', 'class="chart-card" style="grid-column:1/-1"') + '</div>'
        : '<div class="grid-2">' + cPed + cTkt + '</div>';
    }
    var secao = document.createElement('div');
    secao.innerHTML = h;
    pg.appendChild(secao);

    var chR = linha(P + 'R'), chPed = linha(P + 'Ped', function (v) { return int(v); }, function (v) { return int(v) + ' pedidos'; }),
        chTkt = linha(P + 'Tkt', function (v) { return 'R$ ' + v; }), chPiz = null;
    [chR, chPed, chTkt].forEach(function (c) { if (c) todosCharts.push(c); });
    if (document.getElementById(P + 'Piz')) {
      chPiz = new Chart(document.getElementById(P + 'Piz'), { type: 'doughnut',
        data: { labels: [], datasets: [{ data: [], backgroundColor: [], borderColor: '#0D0D10', borderWidth: 3 }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '62%',
          plugins: { legend: { position: 'bottom', labels: { color: '#F4F2EA', padding: 14, usePointStyle: true, pointStyle: 'circle' } },
            tooltip: { callbacks: { label: function (c) { return c.label + ': ' + brl(c.parsed); } } } } } });
      todosCharts.push(chPiz);
    }

    return function atualizar(isRange, idx, mes) {
      var cur = {}, prev = {};
      grupo.forEach(function (p) {
        cur[p.k] = isRange ? soma(MESES, p.k) : (tem(mes, p.k) ? mes.plat[p.k] : null);
        prev[p.k] = (!isRange && idx > 0 && tem(MESES[idx - 1], p.k)) ? MESES[idx - 1].plat[p.k] : null;
      });
      var jan = janela12(idx), lab = jan.map(function (m) { return m.cur; });

      if (criar) {
        var chip = document.getElementById(P + 'Chip');
        if (chip) chip.textContent = isRange ? 'Período completo (' + MESES[0].cur + ' – ' + MESES[MESES.length - 1].cur + ')' : mes.lbl;
        var totR = 0, totO = 0, totPrevR = 0, temPrev = false;
        grupo.forEach(function (p) {
          var c = cur[p.k]; if (c) { totR += c.r; totO += c.o || 0; }
          if (prev[p.k]) { totPrevR += prev[p.k].r; temPrev = true; }
        });
        var cards = grupo.map(function (p) {
          var c = cur[p.k], d = (c && prev[p.k]) ? delta(c.r, prev[p.k].r) : null, t = c ? ticket(c) : null;
          return '<div class="kpi-card ' + p.cls + '"><div class="kpi-header"><span class="kpi-label">' + esc(p.nome) + '</span><i class="fa-solid ' + p.ic + ' kpi-icon"></i></div>' +
            '<div class="kpi-value">' + (c ? brl(c.r) : 'Sem dados') + '</div>' +
            '<div class="kpi-sub neutral">' + (c ? (c.o ? int(c.o) + ' pedidos' : '') + (t ? (c.o ? ' · ' : '') + 'ticket ' + brl(t) : '') : 'Relatório do mês ainda não enviado') + '</div>' +
            '<div class="kpi-sub ' + (d ? d.c : 'neutral') + '">' + (isRange ? 'Acumulado do período' : (d ? d.t + ' vs mês anterior' : 'Sem base de comparação')) + '</div></div>';
        });
        var dT = (totR && temPrev && !isRange) ? delta(totR, totPrevR) : null;
        cards.push('<div class="kpi-card deep"><div class="kpi-header"><span class="kpi-label">Total ' + cfg.nome + '</span><i class="fa-solid fa-chart-simple kpi-icon"></i></div>' +
          '<div class="kpi-value">' + (totR ? brl(totR) : 'Sem dados') + '</div>' +
          '<div class="kpi-sub neutral">' + (totO ? int(totO) + ' pedidos · ticket ' + brl(totR / totO) : '') + '</div>' +
          '<div class="kpi-sub ' + (dT ? dT.c : 'neutral') + '">' + (isRange ? 'Acumulado do período' : (dT ? dT.t + ' vs mês anterior' : 'Sem base de comparação')) + '</div></div>');
        if (cfg.comparar) { var cc = cfg.comparar(isRange, idx, mes); if (cc) cards.push(cc); }
        document.getElementById(P + 'Cards').innerHTML = cards.join('');

        document.getElementById(P + 'Tab').innerHTML = grupo.map(function (p) {
          var c = cur[p.k], d = (c && prev[p.k]) ? delta(c.r, prev[p.k].r) : null, t = c ? ticket(c) : null;
          return '<tr><td><strong>' + esc(p.nome) + '</strong></td><td>' + (c ? brl(c.r) : '—') + '</td><td>' + (c && c.o ? int(c.o) : '—') + '</td><td>' + (t ? brl(t) : '—') + '</td><td>' +
            (c && totR ? pct(c.r / totR * 100) : '—') + '</td><td>' + (d ? d.t : '—') + '</td></tr>';
        }).join('') + '<tr><td><strong>Total</strong></td><td><strong>' + (totR ? brl(totR) : '—') + '</strong></td><td><strong>' + (totO ? int(totO) : '—') + '</strong></td><td><strong>' + (totO ? brl(totR / totO) : '—') + '</strong></td><td></td><td></td></tr>';

        if (chPiz) {
          var lis = gAt.filter(function (p) { return cur[p.k]; });
          chPiz.data.labels = lis.map(function (p) { return p.nome; });
          chPiz.data.datasets[0].data = lis.map(function (p) { return cur[p.k].r; });
          chPiz.data.datasets[0].backgroundColor = lis.map(function (p) { return p.cor; });
          chPiz.update();
        }
      }

      if (chR) {
        var cardR = document.getElementById(P + 'R').closest('.chart-card');
        if (cardR) cardR.style.display = gAt.length ? '' : 'none';   // sem nenhum dado, não mostra gráfico vazio
        chR.data.labels = lab;
        chR.data.datasets = gAt.map(function (p) {
          return serie(p.nome, p.cor, p.fundo, jan.map(function (m) { return tem(m, p.k) ? m.plat[p.k].r : null; }), jan.map(function (m) { return tem(m, p.k) ? m.plat[p.k] : null; }), gAt.length === 1);
        });
        chR.options.plugins.legend.display = gAt.length > 1;
        chR.update();
        var n = document.getElementById(P + 'RNota');
        if (n) n.textContent = (gAt.length ? cfg.notaR : 'Ainda sem dados neste canal.') + ' Meses sem relatório ficam em branco. Passe o mouse para ver pedidos e ticket médio.';
      }
      if (chPed) {
        chPed.data.labels = lab;
        chPed.data.datasets = gAt.map(function (p) { return serie(p.nome, p.cor, p.fundo, jan.map(function (m) { return tem(m, p.k) && m.plat[p.k].o ? m.plat[p.k].o : null; }), null, false); });
        chPed.options.plugins.legend.display = gAt.length > 1;
        chPed.update();
      }
      if (chTkt) {
        chTkt.data.labels = lab;
        chTkt.data.datasets = gAt.map(function (p) { return serie(p.nome, p.cor, p.fundo, jan.map(function (m) { var t = tem(m, p.k) ? ticket(m.plat[p.k]) : null; return t ? Math.round(t * 100) / 100 : null; }), null, false); });
        chTkt.options.plugins.legend.display = gAt.length > 1;
        chTkt.update();
      }
    };
  }

  /* ---------- Marketplace (iFood + 99Food) ---------- */
  var MKT = PLATS.filter(function (p) { return p.mkt; });          // sempre os dois, mesmo sem dado
  var PROP = PLATS.filter(function (p) { return !p.mkt && ativas.indexOf(p) > -1; });
  if (!PROP.length) PROP = PLATS.filter(function (p) { return p.k === 'car'; });

  var itens = Array.prototype.slice.call(nav.querySelectorAll('.nav-item'));
  var existente = itens.filter(function (li) { return /Plataformas|Marketplace/i.test(li.textContent); })[0];
  var p3 = itens.filter(function (li) { return /switchPage\('p3'\)/.test(li.getAttribute('onclick') || ''); })[0];
  var ancora = p3, idMkt, pgMkt, criarMkt = !existente;

  if (existente) {
    var mm = /switchPage\('([^']+)'\)/.exec(existente.getAttribute('onclick') || '');
    idMkt = mm ? mm[1] : null;
    pgMkt = idMkt && document.getElementById(idMkt);
    if (!pgMkt) return;
    ancora = existente;
    // renomeia e tira o que é delivery próprio (vai para a página Delivery)
    Array.prototype.slice.call(existente.childNodes).forEach(function (n) { if (n.nodeType === 3) n.nodeValue = n.nodeValue.replace(/Plataformas/i, 'Marketplace'); });
    titulo(idMkt, 'fa-bag-shopping', 'Marketplace', 'iFood e 99Food: faturamento, pedidos e ticket médio.');
    Array.prototype.slice.call(pgMkt.querySelectorAll('.kpi-card')).forEach(function (c) {
      var l = c.querySelector('.kpi-label');
      if (l && /Pr[óo]prio|Portal|Site|Canais/i.test(l.textContent)) c.style.display = 'none';
    });
    Array.prototype.slice.call(pgMkt.querySelectorAll('.chart-card')).forEach(function (c) {
      var t = c.querySelector('.chart-title');
      if (t && /Divis[ãa]o por Canal|Evolu[çc][ãa]o por Canal|Detalhamento por Canal/i.test(t.textContent)) c.style.display = 'none';
    });
  } else {
    idMkt = 'pmkt';
    var n1 = novoItem(idMkt, 'fa-bag-shopping', 'Marketplace', p3);
    pgMkt = n1.pagina; ancora = n1.li;
    titulo(idMkt, 'fa-bag-shopping', 'Marketplace', 'iFood e 99Food: faturamento, pedidos e ticket médio.');
  }
  var atMkt = montar({ pref: 'm7mk', nome: 'Marketplace', icone: 'fa-bag-shopping', grupo: MKT, tituloR: 'Marketplaces',
    notaR: 'Faturamento do iFood e do 99Food mês a mês.' }, pgMkt, criarMkt);

  /* ---------- Delivery próprio ---------- */
  var idDel = 'pdel';
  var n2 = novoItem(idDel, 'fa-motorcycle', 'Delivery', ancora);
  titulo(idDel, 'fa-motorcycle', 'Delivery', 'Delivery próprio: Cardápio Web, Anota Aí, site e WhatsApp — sem comissão de marketplace.');
  var atDel = montar({ pref: 'm7dl', nome: 'Delivery Próprio', icone: 'fa-motorcycle', grupo: PROP, tituloR: 'Delivery próprio',
    notaR: 'Faturamento do delivery próprio (' + PROP.map(function (p) { return p.nome; }).join(', ') + ').',
    comparar: function (isRange, idx, mes) {
      // ticket próprio × marketplace
      var base = isRange ? MESES : [mes];
      var rp = 0, op = 0, rm = 0, om = 0;
      base.forEach(function (m) {
        PROP.forEach(function (p) { if (tem(m, p.k)) { rp += m.plat[p.k].r; op += m.plat[p.k].o || 0; } });
        MKT.forEach(function (p) { if (tem(m, p.k)) { rm += m.plat[p.k].r; om += m.plat[p.k].o || 0; } });
      });
      if (!op || !om) return '';
      var tp = rp / op, tm = rm / om, dif = tp - tm;
      return '<div class="kpi-card cream"><div class="kpi-header"><span class="kpi-label">Ticket Próprio vs Marketplace</span><i class="fa-solid fa-arrow-right-arrow-left kpi-icon"></i></div>' +
        '<div class="kpi-value" style="font-size:15px;white-space:nowrap">' + brl(tp) + ' vs ' + brl(tm) + '</div>' +
        '<div class="kpi-sub neutral">' + (Math.abs(dif) < 0.005 ? 'Tickets iguais' : 'Próprio ' + (dif > 0 ? 'maior' : 'menor') + ' em ' + brl(Math.abs(dif)) + ' por pedido') + '</div></div>';
    } }, n2.pagina, true);

  renumerar();
  [n2.li].concat(criarMkt ? [] : []).forEach(function (li) { li.addEventListener('click', function () { setTimeout(function () { todosCharts.forEach(function (c) { c.resize(); }); }, 80); }); });
  if (criarMkt) ancora.addEventListener('click', function () { setTimeout(function () { todosCharts.forEach(function (c) { c.resize(); }); }, 80); });

  /* ---------- atualização (acompanha filtro de período e "Limpar") ---------- */
  function atualizar() {
    var sel = document.getElementById('selPeriodo');
    var per = sel ? sel.value : 'full';
    var isRange = per === 'full';
    var idx = MESES.length - 1;
    if (!isRange) { for (var i = 0; i < MESES.length; i++) if (MESES[i].id === per) idx = i; }
    var mes = MESES[idx];
    atMkt(isRange, idx, mes);
    atDel(isRange, idx, mes);
  }
  var origRender = window.render;
  if (typeof origRender === 'function') {
    window.render = function () {
      var r = origRender.apply(this, arguments);
      try { atualizar(); } catch (e) { console.error('m7-plataformas', e); }
      return r;
    };
  }
  var selP = document.getElementById('selPeriodo');
  if (selP) selP.addEventListener('change', function () { try { atualizar(); } catch (e) { console.error(e); } });
  window.addEventListener('load', function () { try { atualizar(); } catch (e) { console.error(e); } });
  if (document.readyState === 'complete') { try { atualizar(); } catch (e) { console.error(e); } }
})();
