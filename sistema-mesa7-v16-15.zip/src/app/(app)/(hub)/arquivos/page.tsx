import Link from "next/link";
import { requireSession } from "@/lib/access";
import { PageHead, Card } from "@/components/ui";
import { DASHBOARDS, dashboardPorPasta } from "@/lib/dashboards";
import {
  EXTENSOES_ACEITAS,
  FONTES,
  LIMITE_MB,
  fonteLabel,
  formatarTamanho,
  listarArquivos,
  mesLabel,
  mesesRecentes,
} from "@/lib/arquivos";
import { FormEnvioArquivos } from "@/components/FormEnvioArquivos";
import { alternarStatus, relerIfood, remover } from "./actions";

export const dynamic = "force-dynamic";

const filtro: React.CSSProperties = {
  background: "var(--surface-2)",
  border: "1px solid var(--border-strong)",
  borderRadius: 9,
  padding: "7px 10px",
  color: "var(--text-primary)",
  fontSize: 13,
  fontFamily: "inherit",
};

const botaoPequeno: React.CSSProperties = {
  background: "transparent",
  border: "1px solid var(--border-strong)",
  borderRadius: 8,
  padding: "5px 9px",
  fontSize: 12,
  fontWeight: 700,
  color: "var(--text-secondary)",
  cursor: "pointer",
  fontFamily: "inherit",
  whiteSpace: "nowrap",
};

function dataHora(iso: string) {
  return new Date(iso).toLocaleString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// Tela única da equipe para subir os resultados dos clientes (PDF, CSV,
// Excel, prints) que alimentam os dashboards, com o histórico de envios.
export default async function ArquivosPage({ searchParams }: PageProps<"/arquivos">) {
  await requireSession();
  const sp = await searchParams;
  const cliente = typeof sp.cliente === "string" && dashboardPorPasta(sp.cliente) ? sp.cliente : "";
  const fonte = typeof sp.fonte === "string" && FONTES.some((f) => f.id === sp.fonte) ? sp.fonte : "";
  const status = sp.status === "pendente" || sp.status === "lancado" ? sp.status : "";

  const todos = await listarArquivos();
  const lista = todos.filter(
    (a) => (!cliente || a.pasta === cliente) && (!fonte || a.fonte === fonte) && (!status || a.status === status),
  );
  const pendentes = todos.filter((a) => a.status === "pendente").length;

  const clientes = [...DASHBOARDS]
    .sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"))
    .map((d) => ({ value: d.pasta, label: d.nome }));
  const nomeCliente = cliente ? dashboardPorPasta(cliente)?.nome : null;

  return (
    <div style={{ padding: "40px", maxWidth: 1120 }}>
      {cliente && (
        <Link
          href={`/dashboards/${cliente}`}
          style={{ display: "inline-block", color: "var(--accent)", fontSize: 13, fontWeight: 800, textDecoration: "none", marginBottom: 14 }}
        >
          ← Voltar para o dashboard {nomeCliente}
        </Link>
      )}
      <PageHead
        kicker="Clientes"
        title="Subir resultados"
        description="Suba aqui os relatórios e exportações dos clientes (iFood, Meta Ads, Google Ads, cardápio próprio, PDV, Google Meu Negócio e faturamento). Relatório do iFood (de vendas ou de cardápio) em Excel ou CSV e o PDF do SAIPOS (Taverna) são lidos na hora e já vão para o dashboard. No Google Meu Negócio, digite os números do mês e anexe o print. Os outros ficam como Pendente até os números serem lançados."
      />

      <Card title="Novo envio">
        <FormEnvioArquivos
          clientes={clientes}
          fontes={FONTES.map((f) => ({ value: f.id, label: f.label }))}
          meses={mesesRecentes(13)}
          clienteInicial={cliente || undefined}
          aceitos={EXTENSOES_ACEITAS}
          limiteMb={LIMITE_MB}
        />
      </Card>

      <Card
        title="Arquivos enviados"
        subtitle={`${todos.length} no total · ${pendentes} pendente${pendentes === 1 ? "" : "s"} de lançar no dashboard`}
      >
        <form method="get" style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
          <select name="cliente" defaultValue={cliente} style={filtro} aria-label="Filtrar por cliente">
            <option value="">Todos os clientes</option>
            {clientes.map((c) => (
              <option key={c.value} value={c.value}>
                {c.label}
              </option>
            ))}
          </select>
          <select name="fonte" defaultValue={fonte} style={filtro} aria-label="Filtrar por fonte">
            <option value="">Todas as fontes</option>
            {FONTES.map((f) => (
              <option key={f.id} value={f.id}>
                {f.label}
              </option>
            ))}
          </select>
          <select name="status" defaultValue={status} style={filtro} aria-label="Filtrar por status">
            <option value="">Todos os status</option>
            <option value="pendente">Pendente</option>
            <option value="lancado">Lançado no dashboard</option>
          </select>
          <button type="submit" style={{ ...botaoPequeno, padding: "7px 14px", color: "var(--text-primary)" }}>
            Filtrar
          </button>
          {(cliente || fonte || status) && (
            <Link href="/arquivos" style={{ ...botaoPequeno, padding: "7px 14px", textDecoration: "none" }}>
              Limpar
            </Link>
          )}
        </form>
        <form action={relerIfood} style={{ marginBottom: 14 }}>
          <button
            type="submit"
            title="Lê de novo todas as planilhas do iFood da lista e refaz os números dos dashboards"
            style={{ ...botaoPequeno, padding: "7px 14px", color: "var(--accent)" }}
          >
            Reler planilhas do iFood
          </button>
        </form>

        {lista.length === 0 ? (
          <div style={{ padding: "26px 0", textAlign: "center", color: "var(--text-muted)", fontSize: 13.5 }}>
            Nenhum arquivo {cliente || fonte || status ? "com esses filtros" : "enviado ainda"}.
          </div>
        ) : (
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ textAlign: "left", color: "var(--text-muted)", fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em" }}>
                  <th style={{ padding: "8px 8px 8px 0" }}>Cliente</th>
                  <th style={{ padding: 8 }}>Fonte</th>
                  <th style={{ padding: 8 }}>Mês</th>
                  <th style={{ padding: 8 }}>Arquivo</th>
                  <th style={{ padding: 8 }}>Enviado por</th>
                  <th style={{ padding: 8 }}>Status</th>
                  <th style={{ padding: "8px 0 8px 8px" }} />
                </tr>
              </thead>
              <tbody>
                {lista.map((a) => (
                  <tr key={a.id} style={{ borderTop: "1px solid var(--border)", verticalAlign: "top" }}>
                    <td style={{ padding: "10px 8px 10px 0", fontWeight: 700 }}>{dashboardPorPasta(a.pasta)?.nome ?? a.pasta}</td>
                    <td style={{ padding: "10px 8px" }}>{fonteLabel(a.fonte)}</td>
                    <td style={{ padding: "10px 8px", whiteSpace: "nowrap" }}>{mesLabel(a.mes)}</td>
                    <td style={{ padding: "10px 8px", maxWidth: 260 }}>
                      <a
                        href={`/arquivos/baixar/${a.pasta}/${a.id}`}
                        target="_blank"
                        rel="noopener"
                        style={{ color: "var(--accent)", fontWeight: 700, textDecoration: "none", wordBreak: "break-word" }}
                      >
                        {a.nomeOriginal}
                      </a>
                      <div style={{ color: "var(--text-muted)", fontSize: 11.5, marginTop: 2 }}>
                        {formatarTamanho(a.tamanho)}
                        {a.observacao ? ` · ${a.observacao}` : ""}
                      </div>
                      {a.leitura && (
                        <div
                          style={{
                            fontSize: 11.5,
                            marginTop: 4,
                            fontWeight: 600,
                            color: a.leitura.ok ? "var(--status-good)" : "var(--status-warning)",
                          }}
                        >
                          {a.leitura.ok ? "Lido: " : "Não lido: "}
                          {a.leitura.resumo}
                        </div>
                      )}
                    </td>
                    <td style={{ padding: "10px 8px", color: "var(--text-secondary)" }}>
                      {a.enviadoPor}
                      <div style={{ color: "var(--text-muted)", fontSize: 11.5, marginTop: 2 }}>{dataHora(a.enviadoEm)}</div>
                    </td>
                    <td style={{ padding: "10px 8px" }}>
                      <span
                        style={{
                          display: "inline-block",
                          fontSize: 11,
                          fontWeight: 800,
                          borderRadius: 99,
                          padding: "3px 9px",
                          whiteSpace: "nowrap",
                          color: a.status === "lancado" ? "var(--status-good)" : "var(--status-warning)",
                          background: a.status === "lancado" ? "var(--status-good-bg)" : "var(--status-warning-bg)",
                        }}
                      >
                        {a.status === "lancado" ? (a.lancadoPor === "Leitura automática" ? "✓ Lido automático" : "✓ Lançado") : "● Pendente"}
                      </span>
                      {a.status === "lancado" && a.lancadoPor && (
                        <div style={{ color: "var(--text-muted)", fontSize: 11.5, marginTop: 4 }}>
                          {a.lancadoPor}
                          {a.lancadoEm ? ` · ${dataHora(a.lancadoEm)}` : ""}
                        </div>
                      )}
                    </td>
                    <td style={{ padding: "10px 0 10px 8px" }}>
                      <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                        <form action={alternarStatus}>
                          <input type="hidden" name="pasta" value={a.pasta} />
                          <input type="hidden" name="id" value={a.id} />
                          <input type="hidden" name="status" value={a.status === "lancado" ? "pendente" : "lancado"} />
                          <button type="submit" style={botaoPequeno}>
                            {a.status === "lancado" ? "Voltar p/ pendente" : "Marcar lançado"}
                          </button>
                        </form>
                        <form action={remover}>
                          <input type="hidden" name="pasta" value={a.pasta} />
                          <input type="hidden" name="id" value={a.id} />
                          <button type="submit" title="Tirar da lista" style={{ ...botaoPequeno, color: "var(--text-muted)" }}>
                            Remover
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
