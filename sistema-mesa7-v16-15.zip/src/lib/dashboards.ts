// Dashboards de cliente no padrão Mesa7 (modelo Taverna dos Pandas).
//
// Cada dashboard é um HTML autocontido em `dashboards/<pasta>/index.html`
// (na raiz do projeto, fora de `public/`, então nunca é servido sem passar
// pelas rotas abaixo). Arquivos comuns a todos (ex.: m7-esqueleto.js) ficam
// em `dashboards/_comum/`. Logos: basta soltar o PNG na pasta do cliente com
// o nome que o HTML usa (ex.: garage84-logo.png).
//
// Acesso:
//  - Equipe: /dashboards (lista) e /dashboards/<pasta> (visualizar, com Voltar).
//  - Cliente, sem senha: /d/<token>. O token é o "segredo" do link — quem tem
//    o link vê o dashboard. Para cortar o acesso de um cliente, troque o token
//    aqui (gere um novo com `openssl rand -hex 12`) e publique de novo.
import { promises as fs } from "node:fs";
import path from "node:path";

export type DashboardStatus = "completo" | "implantacao";

export type Dashboard = {
  /** Nome da pasta em dashboards/ (igual ao slug do cliente no sistema, quando existe). */
  pasta: string;
  nome: string;
  segmento: string;
  status: DashboardStatus;
  token: string;
  /** Mostra a página "Datas Comemorativas" para o cliente escolher as datas do ano. */
  datas?: boolean;
};

export const DASHBOARDS: Dashboard[] = [
  { pasta: "arco-iris-cafe", nome: "Arco Íris Café", segmento: "Café", status: "implantacao", token: "4fb31810be3e082d294c9209", datas: true },
  { pasta: "bar-abilio", nome: "Bar Abílio", segmento: "Bar", status: "implantacao", token: "743a6b1ce24ec0901e492e72", datas: true },
  { pasta: "bionatural", nome: "Bionatural", segmento: "Produtos Naturais", status: "completo", token: "7bd327679e310e86ecd2120d", datas: true },
  { pasta: "burguin", nome: "Burguin", segmento: "Hamburgueria", status: "completo", token: "fd6d7cf19659093b189657b2", datas: true },
  { pasta: "deck-cantareira", nome: "Deck Cantareira", segmento: "Restaurante", status: "implantacao", token: "2a608851958aa55714edf01f", datas: true },
  { pasta: "garagem-espetinhos", nome: "Garagem Espetinho", segmento: "Espetinho", status: "implantacao", token: "81f97b7ebdcc1da3429ca24e", datas: true },
  { pasta: "gold-hamburgueria", nome: "Gold Hamburgueria", segmento: "Hamburgueria", status: "implantacao", token: "ad8fd1b7e455bf2b731c2371", datas: true },
  { pasta: "grand-vinea", nome: "Grand Vinea", segmento: "Restaurante", status: "implantacao", token: "7192def6a844391574416398", datas: true },
  { pasta: "hattori", nome: "Hattori", segmento: "Restaurante", status: "implantacao", token: "ae08db4b6a4599fc147b935e", datas: true },
  { pasta: "jardim-de-minas", nome: "Jardim de Minas", segmento: "Restaurante", status: "implantacao", token: "44827c480e8d644afe870d3c", datas: true },
  { pasta: "la-pizza-dcaio", nome: "La Pizza D'Caio", segmento: "Pizzaria", status: "completo", token: "5e76e0cdb2755a131a89de8a", datas: true },
  { pasta: "pacocas-unidade-1", nome: "Paçocas — Unidade 1", segmento: "Restaurante", status: "completo", token: "2a977154f0a651e456eb530a", datas: true },
  { pasta: "duana-centro", nome: "Pizzaria Duana Centro", segmento: "Pizzaria", status: "completo", token: "35d336b249436054c5d8bb80", datas: true },
  { pasta: "duana-serra", nome: "Pizzaria Duana Serra", segmento: "Pizzaria", status: "implantacao", token: "f4648a338dc309f433c92f9e", datas: true },
  { pasta: "rei-pizza-pinda", nome: "Rei Pizza Pinda", segmento: "Pizzaria", status: "implantacao", token: "59716231b2e77358c35986eb", datas: true },
  { pasta: "rei-pizza-taubate", nome: "Rei Pizza Taubaté", segmento: "Pizzaria", status: "implantacao", token: "3f891d513771e5c245ed5650", datas: true },
  { pasta: "taverna-dos-pandas", nome: "Taverna dos Pandas", segmento: "Luderia", status: "completo", token: "02554ab2b8c6efb43a5f8055", datas: true },
];

export function dashboardPorPasta(pasta: string) {
  return DASHBOARDS.find((d) => d.pasta === pasta) ?? null;
}

export function dashboardPorToken(token: string) {
  if (!/^[a-f0-9]{24}$/.test(token)) return null;
  return DASHBOARDS.find((d) => d.token === token) ?? null;
}

const RAIZ = path.join(process.cwd(), "dashboards");

const TIPOS: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
};

/** Script que coloca o botão "Voltar" dentro de todo dashboard servido. */
const SCRIPT_VOLTAR = '<script defer src="m7-voltar.js"></script>';

/**
 * Lê um arquivo do dashboard (primeiro na pasta do cliente, depois em
 * `_comum/`). Só aceita nomes simples com extensão conhecida — nada de
 * subpastas nem `..`.
 */
export async function lerArquivoDashboard(d: Dashboard, partes: string[]) {
  const nome = partes.length === 0 ? "index.html" : partes.join("/");
  if (!/^[a-zA-Z0-9._-]+$/.test(nome) || nome.startsWith(".")) return null;
  const tipo = TIPOS[path.extname(nome).toLowerCase()];
  if (!tipo) return null;

  for (const pasta of [d.pasta, "_comum"]) {
    try {
      const buf = await fs.readFile(path.join(RAIZ, pasta, nome));
      if (nome === "index.html") {
        const html = buf.toString("utf8");
        const comVoltar = html.includes("</head>")
          ? html.replace("</head>", `${SCRIPT_VOLTAR}\n</head>`)
          : SCRIPT_VOLTAR + html;
        return { corpo: comVoltar, tipo };
      }
      return { corpo: buf, tipo };
    } catch {
      // tenta a próxima pasta
    }
  }
  // Miniaturas dos anúncios (scripts/meta-anuncios.mjs) ficam junto dos dados do cliente.
  if (/^anuncio-\d{4}-\d{2}-\d{1,2}\.(jpg|png|webp)$/.test(nome)) {
    const raiz =
      process.env.ARQUIVOS_DIR || path.resolve(/*turbopackIgnore: true*/ process.cwd(), "..", "sistema-mesa7-arquivos");
    try {
      return { corpo: await fs.readFile(path.join(raiz, d.pasta, "_dados", nome)), tipo };
    } catch {
      // sem miniatura
    }
  }
  return null;
}
