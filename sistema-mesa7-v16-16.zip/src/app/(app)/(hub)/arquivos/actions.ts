"use server";

import { revalidatePath } from "next/cache";
import { requireSession } from "@/lib/access";
import {
  FONTES,
  LIMITE_MB,
  extensaoAceita,
  listarArquivos,
  lerConteudoArquivo,
  marcarStatus,
  mesLabel,
  registrarLeitura,
  removerArquivo,
  salvarArquivo,
  type FonteId,
} from "@/lib/arquivos";
import { dashboardPorPasta } from "@/lib/dashboards";
import { lerRelatorioCardapio, type CardapioMes } from "@/lib/leitor-cardapio";
import { lerArquivoIfood, type IfoodFunilMes, type IfoodMes, type LeituraIfood } from "@/lib/leitor-ifood";
import { lerRelatorioSaipos } from "@/lib/leitor-saipos";
import { salvarMeses, substituirFonte, type GmbMes } from "@/lib/dados-clientes";

const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

type Leitura = { ok: boolean; resumo: string; /** Alimenta o dashboard direto, mesmo nos "completos". */ direto?: boolean };

const int = (n: number) => Math.round(n).toLocaleString("pt-BR");

/**
 * Lê uma planilha do iFood e confere se é do mês escolhido no envio.
 * Não grava nada: quem chama decide (envio novo ou "reler tudo").
 */
async function interpretarIfood(nome: string, buf: Buffer, mes: string): Promise<LeituraIfood> {
  const l = await lerArquivoIfood(nome, buf);
  const meses = l.meses.map((m) => m.mes);
  if (!meses.includes(mes) || meses.length > 1) {
    throw new Error(
      `O relatório é de ${meses.map(mesLabel).join(", ")}, mas o mês escolhido no envio foi ${mesLabel(mes)}. Nada foi lançado — envie de novo com o mês certo.`,
    );
  }
  return l;
}

function resumoIfood(l: LeituraIfood) {
  if (l.tipo === "vendas") {
    return l.meses.map((m) => `${mesLabel(m.mes)}: ${m.o} pedidos · ${brl(m.r)} · ticket ${brl(m.t)}`).join(" | ");
  }
  return l.meses
    .map((m) => {
      const top = m.itens[0] ? ` · mais vendido: ${m.itens[0].nome}` : "";
      return `${mesLabel(m.mes)} (relatório de cardápio): ${int(m.vis)} visitas · ${int(m.vw)} viram o cardápio · ${int(m.sac)} sacolas · ${int(m.conc)} pedidos concluídos · conversão ${m.conv.toLocaleString("pt-BR")}%${top}`;
    })
    .join(" | ");
}

/** Relatório de pedidos do Cardápio Web: pode ter vários meses (separa pelo dia do pedido). */
async function interpretarCardapio(nome: string, buf: Buffer, mes: string): Promise<CardapioMes[]> {
  const meses = await lerRelatorioCardapio(nome, buf);
  if (!meses.some((m) => m.mes === mes)) {
    throw new Error(
      `O relatório tem pedidos de ${meses.map((m) => mesLabel(m.mes)).join(", ")}, mas o mês escolhido no envio foi ${mesLabel(mes)}. Nada foi lançado — envie de novo com o mês certo.`,
    );
  }
  return meses;
}

function resumoCardapio(meses: CardapioMes[]) {
  const dm = (d?: string) => (d ? d.slice(8, 10) + "/" + d.slice(5, 7) : "");
  return meses
    .map((m) => {
      const tipos = ([["del", "delivery"], ["ret", "retirada"], ["mesa", "mesa"], ["local", "consumo no local"]] as const)
        .filter(([k]) => m[k].o)
        .map(([k, n]) => `${n} ${m[k].o}`)
        .join(", ");
      const per = m.de && m.ate ? ` (${dm(m.de)} a ${dm(m.ate)})` : "";
      return `${mesLabel(m.mes)}${per}: ${m.o} pedidos · ${brl(m.r)} · ticket ${brl(m.t)}${tipos ? ` · ${tipos}` : ""}${m.canc.o ? ` · ${m.canc.o} cancelado${m.canc.o > 1 ? "s" : ""} fora do total` : ""}`;
    })
    .join(" | ");
}

/** Lê o relatório quando a fonte tem leitura automática. Nunca impede o envio. */
async function lerAutomatico(pasta: string, fonte: FonteId, mes: string, arquivo: File): Promise<Leitura | null> {
  if (fonte === "ifood" && /\.(xlsx|csv)$/i.test(arquivo.name)) {
    try {
      const l = await interpretarIfood(arquivo.name, Buffer.from(await arquivo.arrayBuffer()), mes);
      if (l.tipo === "vendas") await salvarMeses(pasta, "ifood", Object.fromEntries(l.meses.map((m) => [m.mes, m])));
      else await salvarMeses(pasta, "ifood_funil", Object.fromEntries(l.meses.map((m) => [m.mes, m])));
      // Todos os dashboards leem o iFood enviado (os completos preenchem os meses que estão vazios).
      return { ok: true, direto: true, resumo: resumoIfood(l) };
    } catch (e) {
      return { ok: false, resumo: e instanceof Error ? e.message : "Não consegui ler o arquivo." };
    }
  }
  if (fonte === "cardapio-proprio" && /\.(xlsx|csv)$/i.test(arquivo.name)) {
    try {
      const meses = await interpretarCardapio(arquivo.name, Buffer.from(await arquivo.arrayBuffer()), mes);
      await salvarMeses(pasta, "cardapio", Object.fromEntries(meses.map((m) => [m.mes, m])));
      return { ok: true, direto: true, resumo: resumoCardapio(meses) };
    } catch (e) {
      return { ok: false, resumo: e instanceof Error ? e.message : "Não consegui ler o arquivo." };
    }
  }
  // PDV SAIPOS (Taverna dos Pandas): "Acompanhamento de vendas" em PDF ou print.
  if (fonte === "pdv" && pasta === "taverna-dos-pandas" && /\.(pdf|png|jpe?g|webp)$/i.test(arquivo.name)) {
    try {
      const m = await lerRelatorioSaipos(arquivo.name, Buffer.from(await arquivo.arrayBuffer()));
      await salvarMeses(pasta, "saipos", { [m.mes]: m });
      const canais = m.canais.map((c) => `${c.nome} ${c.o} (${brl(c.r)})`).join(", ");
      return {
        ok: true,
        direto: true,
        resumo: `${mesLabel(m.mes)}${m.ate ? ` (até ${m.ate.split("-").reverse().join("/")})` : ""}: ${m.o} pedidos · ${brl(m.r)} · ticket ${brl(m.t)} · canais: ${canais} · cancelados ${m.cancelados.o} (${brl(m.cancelados.r)}, fora do total)`,
      };
    } catch (e) {
      return { ok: false, resumo: e instanceof Error ? e.message : "Não consegui ler o arquivo." };
    }
  }
  return null;
}

// Dashboards que já têm a seção de Google Meu Negócio. Nos outros os números ficam
// guardados, mas o arquivo segue Pendente até a seção existir.
const PASTAS_COM_GMB = ["bionatural", "la-pizza-dcaio", "pacocas-unidade-1", "taverna-dos-pandas"];

const CAMPOS_GMB = [
  { k: "v", nome: "Visualizações", obrigatorio: true },
  { k: "ch", nome: "Ligações", obrigatorio: true },
  { k: "rt", nome: "Solicitações de rota", obrigatorio: true },
  { k: "st", nome: "Cliques no site", obrigatorio: true },
  { k: "ct", nome: "Conversas", obrigatorio: false },
  { k: "cd", nome: "Cliques no cardápio", obrigatorio: false },
] as const;

/** Números do Google Meu Negócio digitados no formulário. null = nada preenchido. */
function lerCamposGmb(fd: FormData, quem: string): { dados: GmbMes } | { erro: string } | null {
  const bruto = Object.fromEntries(CAMPOS_GMB.map((c) => [c.k, String(fd.get(`gmb_${c.k}`) ?? "").trim()]));
  if (CAMPOS_GMB.every((c) => !bruto[c.k])) return null;
  const out: Record<string, number | null> = {};
  for (const c of CAMPOS_GMB) {
    const t = bruto[c.k].replace(/\./g, "").replace(/\s/g, "");
    if (!t) {
      if (c.obrigatorio) return { erro: `Preencha "${c.nome}" (se foi zero, digite 0).` };
      out[c.k] = null;
      continue;
    }
    if (!/^\d{1,7}$/.test(t)) return { erro: `"${c.nome}" precisa ser um número inteiro (ex.: 1.137).` };
    out[c.k] = Number(t);
  }
  return { dados: { v: out.v!, ch: out.ch!, rt: out.rt!, st: out.st!, ct: out.ct, cd: out.cd, por: quem, em: new Date().toISOString() } };
}

export type EstadoEnvio = { ok: boolean; mensagem: string } | null;

async function exigirEquipe() {
  const session = await requireSession();
  if (session.user.role === "client") throw new Error("Apenas a equipe Mesa7 pode enviar arquivos.");
  return { session, quem: session.user.name || session.user.email || "Equipe" };
}

export async function enviarArquivos(_prev: EstadoEnvio, formData: FormData): Promise<EstadoEnvio> {
  const { quem } = await exigirEquipe();

  const pasta = String(formData.get("pasta") || "");
  const fonte = String(formData.get("fonte") || "") as FonteId;
  const mes = String(formData.get("mes") || "");
  const observacao = String(formData.get("observacao") || "").trim().slice(0, 500);
  const arquivos = formData.getAll("arquivos").filter((f): f is File => f instanceof File && f.size > 0);

  const cliente = dashboardPorPasta(pasta);
  if (!cliente) return { ok: false, mensagem: "Escolha o cliente." };
  if (!FONTES.some((f) => f.id === fonte)) return { ok: false, mensagem: "Escolha a fonte dos dados." };
  if (!/^\d{4}-\d{2}$/.test(mes)) return { ok: false, mensagem: "Escolha o mês de referência." };
  if (arquivos.length === 0) return { ok: false, mensagem: "Selecione pelo menos um arquivo." };

  const recusados = arquivos.filter((a) => !extensaoAceita(a.name)).map((a) => a.name);
  if (recusados.length) {
    return { ok: false, mensagem: `Tipo de arquivo não aceito: ${recusados.join(", ")}. Use PDF, CSV, Excel ou imagem.` };
  }
  const total = arquivos.reduce((s, a) => s + a.size, 0);
  if (total > LIMITE_MB * 1024 * 1024) {
    return { ok: false, mensagem: `Os arquivos passam de ${LIMITE_MB} MB juntos. Envie em partes.` };
  }

  let gmb: GmbMes | null = null;
  if (fonte === "google-meu-negocio") {
    const r = lerCamposGmb(formData, quem);
    if (r && "erro" in r) return { ok: false, mensagem: r.erro };
    gmb = r?.dados ?? null;
  }

  // Dashboards "em implantação" leem os dados direto; os completos têm histórico
  // montado pela equipe, então o arquivo lido fica Pendente para conferência.
  const automatico = cliente.status !== "completo";
  let lidos = 0;
  let diretos = 0; // lidos que já foram para o dashboard
  for (const arquivo of arquivos) {
    const info = await salvarArquivo({ pasta, fonte, mes, observacao, enviadoPor: quem, arquivo });
    const leitura: Leitura | null = gmb
      ? {
          ok: true,
          direto: PASTAS_COM_GMB.includes(pasta),
          resumo: `${mesLabel(mes)}: ${gmb.v} visualizações · ${gmb.ch} ligações · ${gmb.rt} rotas · ${gmb.st} cliques no site${gmb.ct != null ? ` · ${gmb.ct} conversas` : ""}${gmb.cd != null ? ` · ${gmb.cd} cliques no cardápio` : ""} (digitado por ${quem})`,
        }
      : await lerAutomatico(pasta, fonte, mes, arquivo);
    if (leitura) {
      await registrarLeitura(pasta, info.id, { ok: leitura.ok, resumo: leitura.resumo }, automatico || !!leitura.direto);
      if (leitura.ok) {
        lidos++;
        if (automatico || leitura.direto) diretos++;
      }
    }
  }

  if (gmb) await salvarMeses(pasta, "gmb", { [mes]: gmb });

  revalidatePath("/arquivos");
  revalidatePath("/dashboards");
  const n = arquivos.length;
  const enviados = `${n} arquivo${n > 1 ? "s" : ""} de ${cliente.nome} enviado${n > 1 ? "s" : ""}.`;
  if (gmb) {
    return {
      ok: true,
      mensagem: PASTAS_COM_GMB.includes(pasta)
        ? `${enviados} Números do Google Meu Negócio de ${mesLabel(mes)} já estão no dashboard.`
        : `${enviados} Números de ${mesLabel(mes)} guardados; o dashboard desse cliente ainda não tem a seção do Google Meu Negócio, então fica "Pendente".`,
    };
  }
  if (lidos > 0 && diretos === 0) {
    return { ok: true, mensagem: `${enviados} Números lidos (veja abaixo). Como esse dashboard já tem histórico completo, fica "Pendente" para a equipe lançar.` };
  }
  if (lidos === n) return { ok: true, mensagem: `${enviados} Lido${n > 1 ? "s" : ""} automaticamente e já no dashboard.` };
  if (lidos > 0) return { ok: true, mensagem: `${enviados} ${lidos} lido(s) automaticamente; o resto fica como "Pendente".` };
  return { ok: true, mensagem: `${enviados} Fica como "Pendente" até ser lançado no dashboard.` };
}

export async function alternarStatus(formData: FormData) {
  const { quem } = await exigirEquipe();
  const pasta = String(formData.get("pasta") || "");
  const id = String(formData.get("id") || "");
  const status = formData.get("status") === "lancado" ? "lancado" : "pendente";
  await marcarStatus(pasta, id, status, quem);
  revalidatePath("/arquivos");
  revalidatePath("/dashboards");
}

export async function remover(formData: FormData) {
  await exigirEquipe();
  const pasta = String(formData.get("pasta") || "");
  const id = String(formData.get("id") || "");
  const era = (await listarArquivos()).find((a) => a.pasta === pasta && a.id === id);
  await removerArquivo(pasta, id);
  // Tirou uma planilha do iFood ou do cardápio próprio: refaz os números do cliente sem ela.
  if (era?.fonte === "ifood" || era?.fonte === "cardapio-proprio") await relerDoCliente(pasta, era.fonte);
  revalidatePath("/arquivos");
  revalidatePath("/dashboards");
}

/**
 * Refaz do zero os números de uma fonte (iFood ou cardápio próprio) de um cliente
 * a partir das planilhas que estão na lista, da mais antiga para a mais nova:
 * a mais nova de cada mês ganha. Planilha que não passa na leitura volta para
 * "Pendente" com o motivo.
 */
async function relerDoCliente(pasta: string, fonte: "ifood" | "cardapio-proprio") {
  const lista = (await listarArquivos())
    .filter((a) => a.pasta === pasta && a.fonte === fonte && /\.(xlsx|csv)$/i.test(a.arquivo))
    .sort((a, b) => a.enviadoEm.localeCompare(b.enviadoEm));
  const vendas: Record<string, IfoodMes> = {};
  const funil: Record<string, IfoodFunilMes> = {};
  const cardapio: Record<string, CardapioMes> = {};
  for (const a of lista) {
    const c = await lerConteudoArquivo(pasta, a.id);
    if (!c) continue;
    const nome = a.nomeOriginal || a.arquivo;
    try {
      let resumo: string;
      if (fonte === "ifood") {
        const l = await interpretarIfood(nome, c.corpo, a.mes);
        for (const m of l.meses) {
          if (l.tipo === "vendas") vendas[m.mes] = m as IfoodMes;
          else funil[m.mes] = m as IfoodFunilMes;
        }
        resumo = resumoIfood(l);
      } else {
        const meses = await interpretarCardapio(nome, c.corpo, a.mes);
        for (const m of meses) cardapio[m.mes] = m;
        resumo = resumoCardapio(meses);
      }
      await registrarLeitura(pasta, a.id, { ok: true, resumo }, a.status !== "lancado");
    } catch (e) {
      await registrarLeitura(pasta, a.id, { ok: false, resumo: e instanceof Error ? e.message : "Não consegui ler o arquivo." }, false);
      if (a.status === "lancado") await marcarStatus(pasta, a.id, "pendente", "Leitura automática");
    }
  }
  if (fonte === "ifood") {
    await substituirFonte(pasta, "ifood", vendas);
    await substituirFonte(pasta, "ifood_funil", funil);
  } else {
    await substituirFonte(pasta, "cardapio", cardapio);
  }
}

/** Botão "Reler planilhas" da página Arquivos: refaz iFood e cardápio próprio de todos os clientes. */
export async function relerPlanilhas() {
  await exigirEquipe();
  const todos = await listarArquivos();
  for (const fonte of ["ifood", "cardapio-proprio"] as const) {
    const pastas = [...new Set(todos.filter((a) => a.fonte === fonte).map((a) => a.pasta))];
    for (const p of pastas) await relerDoCliente(p, fonte);
  }
  revalidatePath("/arquivos");
  revalidatePath("/dashboards");
}
