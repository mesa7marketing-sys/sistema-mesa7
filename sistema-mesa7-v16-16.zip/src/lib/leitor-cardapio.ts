// Leitura automática do cardápio próprio (delivery próprio).
// Aceita dois formatos, em .csv ou .xlsx:
//  1. "Relatório de Pedidos" do Cardápio Web — um pedido por linha (Número do
//     Pedido, Origem, Retirada, Valor do frete, Valor total, Data, Status...).
//  2. Resumo mensal (cliente, mes, faturamento_brl, pedidos, delivery_brl...),
//     o formato dos arquivos cardapio_web_<cliente>_AAAA-MM.csv.
// Pedido cancelado não entra no faturamento (fica contado à parte).
import { abasDoXlsx, linhasDoCsv, norm, numero } from "@/lib/leitor-ifood";

type Parte = { o: number; r: number };

export type CardapioMes = {
  mes: string;
  /** Pedidos, faturamento (R$, com frete) e ticket médio — sem cancelados. */
  o: number;
  r: number;
  t: number;
  frete: number;
  /** Por tipo de pedido. */
  del: Parte;
  ret: Parte;
  mesa: Parte;
  local: Parte;
  /** Por origem (Site, WhatsApp, Compartilhamento do menu...) e forma de pagamento. */
  orig: Record<string, Parte>;
  pg: Record<string, number>;
  canc: Parte;
  /** Primeiro e último dia com pedido (AAAA-MM-DD), quando o relatório tem data. */
  de?: string;
  ate?: string;
  formato: "pedidos" | "resumo";
};

const vazio = (mes: string, formato: CardapioMes["formato"]): CardapioMes => ({
  mes, o: 0, r: 0, t: 0, frete: 0,
  del: { o: 0, r: 0 }, ret: { o: 0, r: 0 }, mesa: { o: 0, r: 0 }, local: { o: 0, r: 0 },
  orig: {}, pg: {}, canc: { o: 0, r: 0 }, formato,
});

function tipoDe(v: unknown): "del" | "ret" | "mesa" | "local" {
  const s = norm(v);
  if (/mesa|comanda/.test(s)) return "mesa";
  if (/consumo|local|salao/.test(s)) return "local";
  if (/retir|balcao|busca/.test(s)) return "ret";
  return "del";
}

function dataIso(v: unknown): string | null {
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  const m = String(v ?? "").match(/(\d{2})\/(\d{2})\/(\d{4})/);
  if (m) return `${m[3]}-${m[2]}-${m[1]}`;
  const iso = String(v ?? "").match(/(\d{4})-(\d{2})-(\d{2})/);
  return iso ? `${iso[1]}-${iso[2]}-${iso[3]}` : null;
}

const r2 = (n: number) => Math.round(n * 100) / 100;

function fechar(m: CardapioMes): CardapioMes {
  const arred = (p: Parte) => ({ o: p.o, r: r2(p.r) });
  return {
    ...m, r: r2(m.r), frete: r2(m.frete), t: m.o ? r2(m.r / m.o) : 0,
    del: arred(m.del), ret: arred(m.ret), mesa: arred(m.mesa), local: arred(m.local), canc: arred(m.canc),
    orig: Object.fromEntries(Object.entries(m.orig).map(([k, p]) => [k, arred(p)])),
  };
}

function acharCabecalho(linhas: unknown[][], teste: (cab: string[]) => boolean) {
  const i = linhas.findIndex((l) => teste(l.map(norm)));
  return i < 0 ? null : { cab: linhas[i].map(norm), dados: linhas.slice(i + 1).filter((l) => l.some((c) => String(c ?? "").trim() !== "")) };
}

function lerPedidos(cab: string[], dados: unknown[][]): CardapioMes[] {
  const c = (...p: string[]) => cab.findIndex((h) => p.every((x) => h.includes(x)));
  const iTot = cab.findIndex((h) => h === "valor total");
  const iData = c("data"), iStatus = c("status"), iRet = c("retirada"), iOrig = c("origem");
  const iFrete = c("valor do frete"), iPg = c("condicao de pagamento");
  const meses = new Map<string, CardapioMes>();
  for (const l of dados) {
    const dia = dataIso(l[iData]);
    if (!dia) continue;
    const mes = dia.slice(0, 7);
    const m = meses.get(mes) ?? vazio(mes, "pedidos");
    meses.set(mes, m);
    const r = numero(l[iTot]);
    if (iStatus >= 0 && /cancel|recus|estorn/.test(norm(l[iStatus]))) {
      m.canc.o++; m.canc.r += r;
      continue;
    }
    m.o++; m.r += r;
    if (iFrete >= 0) m.frete += numero(l[iFrete]);
    const t = m[tipoDe(iRet >= 0 ? l[iRet] : "")];
    t.o++; t.r += r;
    const origem = iOrig >= 0 ? String(l[iOrig] ?? "").trim() || "Outros" : "Cardápio próprio";
    const o = (m.orig[origem] ||= { o: 0, r: 0 });
    o.o++; o.r += r;
    if (iPg >= 0) {
      const pg = String(l[iPg] ?? "").trim() || "Outros";
      m.pg[pg] = (m.pg[pg] ?? 0) + 1;
    }
    if (!m.de || dia < m.de) m.de = dia;
    if (!m.ate || dia > m.ate) m.ate = dia;
  }
  return [...meses.values()].map(fechar);
}

function lerResumo(cab: string[], dados: unknown[][]): CardapioMes[] {
  const i = (n: string) => cab.indexOf(n);
  const v = (l: unknown[], n: string) => (i(n) >= 0 ? numero(l[i(n)]) : 0);
  const saida: CardapioMes[] = [];
  for (const l of dados) {
    const mes = String(l[i("mes")] ?? "").trim().slice(0, 7);
    if (!/^\d{4}-\d{2}$/.test(mes)) continue;
    const m = vazio(mes, "resumo");
    m.o = v(l, "pedidos"); m.r = v(l, "faturamento_brl");
    m.del = { o: v(l, "delivery_pedidos"), r: v(l, "delivery_brl") };
    m.ret = { o: v(l, "retirada_pedidos"), r: v(l, "retirada_brl") };
    m.mesa = { o: v(l, "mesa_comanda_pedidos"), r: v(l, "mesa_comanda_brl") };
    m.local = { o: v(l, "consumo_local_pedidos"), r: v(l, "consumo_local_brl") };
    saida.push(fechar(m));
  }
  return saida;
}

/** Lê o relatório e devolve um resumo por mês. Erro com mensagem amigável quando não reconhece. */
export async function lerRelatorioCardapio(nomeArquivo: string, buf: Buffer): Promise<CardapioMes[]> {
  const ext = nomeArquivo.toLowerCase().split(".").pop();
  let tabelas: unknown[][][];
  if (ext === "xlsx") tabelas = Object.values(await abasDoXlsx(buf));
  else if (ext === "csv") {
    let texto = buf.toString("utf8");
    if (texto.includes("�")) texto = buf.toString("latin1");
    tabelas = [linhasDoCsv(texto)];
  } else throw new Error("A leitura automática do cardápio próprio aceita .csv ou .xlsx.");

  for (const linhas of tabelas) {
    const ped = acharCabecalho(linhas, (c) => c.includes("valor total") && c.some((h) => h.startsWith("data")));
    if (ped) {
      const meses = lerPedidos(ped.cab, ped.dados);
      if (!meses.length) throw new Error("O relatório de pedidos não tem nenhuma linha com data.");
      return meses.sort((a, b) => a.mes.localeCompare(b.mes));
    }
    const res = acharCabecalho(linhas, (c) => c.includes("mes") && c.includes("faturamento_brl") && c.includes("pedidos"));
    if (res) {
      const meses = lerResumo(res.cab, res.dados);
      if (meses.length) return meses.sort((a, b) => a.mes.localeCompare(b.mes));
    }
  }
  throw new Error('Não reconheci o formato. Use o "Relatório de Pedidos" do Cardápio Web (CSV ou Excel), com as colunas Valor total, Data e Status.');
}
