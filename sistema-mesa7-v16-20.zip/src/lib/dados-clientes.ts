// Dados estruturados dos clientes que alimentam os dashboards "em implantação".
//
// Duas origens, mescladas por mês (a de baixo ganha):
//  1. dashboards/<pasta>/dados.json  — carga inicial versionada no código
//     (ex.: Meta Ads puxado pela integração, iFood dos relatórios do Emerson).
//  2. <pasta de arquivos>/<pasta>/_dados/<fonte>.json — gerado pelo sistema
//     quando a equipe sobe um relatório que ele sabe ler (hoje: iFood).
import { promises as fs } from "node:fs";
import path from "node:path";
import { raizArquivos } from "@/lib/arquivos";
import { dashboardPorPasta } from "@/lib/dashboards";
import type { IfoodFunilMes, IfoodMes } from "@/lib/leitor-ifood";
import type { SaiposMes } from "@/lib/leitor-saipos";
import type { CardapioMes } from "@/lib/leitor-cardapio";
import type { ItensMes } from "@/lib/leitor-itens";

export type MetaMes = {
  gas: number;
  alc: number;
  imp?: number;
  clk: number;
  vpd?: number;
  adc?: number;
  chk?: number;
  cmp?: number;
  fat?: number;
  /** Último dia considerado, quando o mês ainda não fechou. */
  ate?: string;
};

/** Google Meu Negócio (aba Desempenho do perfil), digitado pela equipe a cada mês. */
export type GmbMes = {
  /** Visualizações do perfil (Pesquisa + Maps). */
  v: number;
  /** Ligações. */
  ch: number;
  /** Solicitações de rota. */
  rt: number;
  /** Cliques no site. */
  st: number;
  /** Conversas / cliques em mensagem (nem todo perfil tem). */
  ct?: number | null;
  /** Cliques no cardápio (nem todo perfil tem). */
  cd?: number | null;
  por?: string;
  em?: string;
};

/** Seguidores do Instagram (scripts/instagram-seguidores.mjs, coleta diária). */
export type InstagramMes = {
  /** Seguidores na última leitura do mês. */
  seg: number;
  /** Data da última leitura (AAAA-MM-DD). */
  em: string;
  /** Seguidores na primeira leitura do mês e a data dela. */
  ini?: number;
  ini_em?: string;
};

/** Top 5 anúncios do mês (scripts/meta-anuncios.mjs ou carga inicial no dados.json). */
export type AnunciosMes = {
  minimo: number;
  ate?: string;
  top: {
    nome: string;
    gas: number;
    alc: number;
    clk: number;
    res: number;
    tipo: string;
    custo: number;
    media: number;
    img?: string;
  }[];
};

export type DadosCliente = {
  ifood: Record<string, IfoodMes>;
  /** Relatório de cardápio do iFood (funil da loja e itens), por mês. */
  ifood_funil: Record<string, IfoodFunilMes>;
  /** Cardápio próprio (Cardápio Web): relatório de pedidos lido em Arquivos, por mês. */
  cardapio: Record<string, CardapioMes>;
  /** Itens vendidos no mês (Curva ABC), de relatório de produtos do cardápio próprio ou PDV. */
  itens: Record<string, ItensMes>;
  meta: Record<string, MetaMes>;
  /** Relatório "Acompanhamento de vendas" do SAIPOS (PDV), por mês. */
  saipos: Record<string, SaiposMes>;
  gmb: Record<string, GmbMes>;
  instagram: Record<string, InstagramMes>;
  anuncios: Record<string, AnunciosMes>;
  /** Promoções do mês (página Promoções), preenchidas pela equipe. */
  promocoes: Record<string, PromocaoItem[]>;
};

export type PromocaoItem = { titulo: string; canal?: string; periodo?: string; descricao?: string; resultado?: string };

type Fonte = keyof DadosCliente;

const RAIZ_DASH = path.join(process.cwd(), "dashboards");

async function lerJson<T>(arquivo: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(arquivo, "utf8")) as T;
  } catch {
    return null;
  }
}

function arquivoFonte(pasta: string, fonte: Fonte) {
  return path.join(raizArquivos(), pasta, "_dados", `${fonte}.json`);
}

export async function dadosDoCliente(pasta: string): Promise<DadosCliente> {
  const d: DadosCliente = { ifood: {}, ifood_funil: {}, cardapio: {}, itens: {}, meta: {}, saipos: {}, gmb: {}, instagram: {}, anuncios: {}, promocoes: {} };
  if (!dashboardPorPasta(pasta)) return d;
  const base = await lerJson<Partial<DadosCliente>>(path.join(RAIZ_DASH, pasta, "dados.json"));
  for (const fonte of ["ifood", "ifood_funil", "cardapio", "itens", "meta", "saipos", "gmb", "instagram", "anuncios", "promocoes"] as const) {
    Object.assign(d[fonte], base?.[fonte] ?? {});
    Object.assign(d[fonte], (await lerJson<DadosCliente[Fonte]>(arquivoFonte(pasta, fonte))) ?? {});
  }
  return d;
}

/** Grava (ou substitui) os meses de uma fonte vindos de um upload. */
export async function salvarMeses<F extends Fonte>(pasta: string, fonte: F, meses: DadosCliente[F]) {
  if (!dashboardPorPasta(pasta)) throw new Error("Cliente inválido.");
  const arq = arquivoFonte(pasta, fonte);
  const atual = (await lerJson<DadosCliente[F]>(arq)) ?? {};
  await fs.mkdir(path.dirname(arq), { recursive: true });
  await fs.writeFile(arq, JSON.stringify({ ...atual, ...meses }, null, 2));
}

// Dashboards "completos" têm os meses escritos no próprio HTML; esta função põe por cima
// o Google Meu Negócio lançado em Arquivos. Cada HTML a chama depois de montar MESES.
const MESCLAR_GMB =
  "window.m7MesclarGmb=function(meses){var g=(window.M7_DADOS&&window.M7_DADOS.gmb)||{};" +
  "(meses||[]).forEach(function(m){var d=g[m.id];if(!d)return;var a=m.gmb||{};" +
  "var n=function(x,y){return typeof x==='number'?x:(typeof y==='number'?y:null)};" +
  "m.gmb=Object.assign({},a,{v:d.v,ch:d.ch,rt:d.rt,or:d.rt,st:d.st,ct:n(d.ct,a.ct),cd:n(d.cd,a.cd)});});};";

/** Troca todos os meses de uma fonte (usado ao reler as planilhas do zero). */
export async function substituirFonte<F extends Fonte>(pasta: string, fonte: F, meses: DadosCliente[F]) {
  if (!dashboardPorPasta(pasta)) throw new Error("Cliente inválido.");
  const arq = arquivoFonte(pasta, fonte);
  await fs.mkdir(path.dirname(arq), { recursive: true });
  await fs.writeFile(arq, JSON.stringify(meses, null, 2));
}

// Mesma ideia para o iFood: cada HTML completo chama m7MesclarIfood(MESES, fn) e
// a fn coloca os números do upload nos campos daquele dashboard (só onde está vazio).
const MESCLAR_IFOOD =
  "window.m7MesclarIfood=function(meses,fn){var D=window.M7_DADOS||{},V=D.ifood||{},F=D.ifood_funil||{};" +
  "(meses||[]).forEach(function(m){var v=V[m.id]||null,f=F[m.id]||null;if(v||f){try{fn(m,v,f);}catch(e){}}});};" +
  "window.m7Vazio=function(x){return x==null||x===0||x==='';};";

// Cardápio próprio: m7MesclarCardapio(MESES, fn, novo). fn preenche os campos do mês
// (só onde está vazio); novo(id, c), opcional, monta a linha de um mês que ainda não
// existe no HTML — usado nos dashboards em que o Cardápio Web é a base (Burguin, Duana).
const MESCLAR_CARDAPIO =
  "window.m7MesclarCardapio=function(meses,fn,novo){var C=(window.M7_DADOS||{}).cardapio||{};if(!meses)return;" +
  "var ult=meses.length?meses[meses.length-1].id:'';" +
  "Object.keys(C).sort().forEach(function(id){var m=null;for(var i=0;i<meses.length;i++)if(meses[i].id===id)m=meses[i];" +
  "if(!m&&novo&&id>ult){try{m=novo(id,C[id]);if(m)meses.push(m);}catch(e){m=null;}}" +
  "if(m){try{fn(m,C[id]);}catch(e){}}});" +
  "meses.sort(function(a,b){return a.id<b.id?-1:1;});};" +
  "window.m7NomeMes=function(id){var N=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];" +
  "var p=id.split('-');var n=N[+p[1]-1];return {lbl:n+'/'+p[0],cur:n.slice(0,3)+'/'+p[0].slice(2)};};";

/** Script que entrega os dados ao HTML do dashboard (antes dos outros scripts). */
export async function scriptDados(pasta: string) {
  const json = JSON.stringify(await dadosDoCliente(pasta)).replace(/</g, "\\u003c");
  return `<script>window.M7_DADOS=${json};${MESCLAR_GMB}${MESCLAR_IFOOD}${MESCLAR_CARDAPIO}</script>`;
}
