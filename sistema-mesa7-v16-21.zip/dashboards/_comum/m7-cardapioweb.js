/* =========================================================
   Dashboards com base no Cardápio Web (Burguin, Duana Centro).
   Depois de cada render do dashboard, completa com o que chega pelo sistema:
   - Meta Ads (M7_DADOS.meta): "Invest. Mídia" do Resumo e o bloco Conversão do CVR;
   - iFood (M7_DADOS.ifood, planilhas de Arquivos): Dependência de Marketplace,
     card Marketplace, total e tabela do Financeiro, divisão por tipo e por canal.
   O iFood fica fora do faturamento do Resumo Executivo (que segue só Cardápio Web,
   porque o iFood só existe a partir de Jul/26 e distorceria a comparação mês a mês).
   ========================================================= */
(function () {
  var D = window.M7_DADOS || {};
  var MT = D.meta || {}, IF = D.ifood || {};
  var brl = function (v) { return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var int = function (v) { return Math.round(v || 0).toLocaleString('pt-BR'); };
  var pct = function (v) { return (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%'; };
  var $ = function (id) { return document.getElementById(id); };
  var WAIT = function (t) { return '<span class="wait">' + t + '</span>'; };

  function lista() { try { return MESES; } catch (e) { return []; } }
  function per() { try { return periodo; } catch (e) { var s = $('selPeriodo'); return s ? s.value : 'full'; } }
  function ids() { var p = per(); return p === 'full' ? lista().map(function (m) { return m.id; }) : [p]; }
  function anterior() { var p = per(), l = lista(); if (p === 'full') return null; for (var i = 1; i < l.length; i++) if (l[i].id === p) return l[i - 1].id; return null; }
  function somaMeta(lst) { var o = { gas: 0, alc: 0, clk: 0, vpd: 0, cmp: 0, n: 0 }; lst.forEach(function (id) { var m = MT[id]; if (!m) return; o.n++; for (var k in o) if (k !== 'n') o[k] += m[k] || 0; }); return o; }
  function somaIfood(lst) { var o = { r: 0, o: 0, n: 0, nov: 0 }; lst.forEach(function (id) { var x = IF[id]; if (x && x.o) { o.r += x.r; o.o += x.o; o.nov += x.novos || 0; o.n++; } }); return o; }
  function dif(a, b) { if (!b) return '—'; var d = (a - b) / b * 100; return (d > 0 ? '+' : '') + d.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%'; }
  function a() { try { return per() === 'full' ? aggRange(lista()) : agg(lista().filter(function (m) { return m.id === per(); })[0]); } catch (e) { return null; } }

  function meta() {
    var l = ids(), s = somaMeta(l), full = per() === 'full';
    var pa = anterior(), sp = pa ? somaMeta([pa]) : null;
    if ($('tInv')) {
      $('tInv').innerHTML = s.n ? brl(s.gas) : WAIT('Sem anúncios no período');
      $('tInvM').textContent = s.n && sp && sp.n ? dif(s.gas, sp.gas) : '—';
    }
    var put = function (id, v) { if ($(id)) $(id).innerHTML = v; };
    if (!s.n) {
      ['cInv', 'cAlc', 'cClk', 'cVpd', 'cCmp'].forEach(function (id) { put(id, WAIT('Sem anúncios no período')); });
      return;
    }
    put('cInv', '<strong>' + brl(s.gas) + '</strong>');
    put('cAlc', int(s.alc) + (full && s.n > 1 ? ' (soma dos meses)' : ''));
    put('cClk', int(s.clk) + (s.clk ? ' · CPC ' + brl(s.gas / s.clk) : ''));
    put('cVpd', int(s.vpd));
    put('cCmp', s.cmp ? int(s.cmp) + ' · custo por compra ' + brl(s.gas / s.cmp) : '0');
    if ($('cNota')) $('cNota').textContent = 'Fonte: integração Meta Ads da Mesa7' + (full ? ' (soma dos meses do período).' : '.');
  }

  function ifood() {
    var x = a(); if (!x) return;
    var l = ids(), f = somaIfood(l), full = per() === 'full';
    var prop = x.total || 0, tot = prop + f.r;
    // PDV (SAIPOS) do mês: o total do caixa inclui telefone e outros canais fora do Cardápio Web/iFood
    var S = full ? null : (D.saipos || {})[per()], outR = 0, outO = 0;
    if (S && S.r && f.n) { outR = Math.max(0, S.r - tot); outO = Math.max(0, S.o - ((x.ped || 0) + f.o)); tot = S.r; }
    // Resumo: dependência de marketplace
    if ($('k1Dep')) {
      $('k1Dep').textContent = f.n ? pct(tot ? f.r / tot * 100 : 0) : '—';
      $('k1DepSub').textContent = f.n ? 'iFood ' + brl(f.r) + ' de ' + brl(tot) + (outR ? ' (total do PDV)' : ' (Cardápio Web + iFood)') + (full && f.n < l.length ? ' · iFood em ' + f.n + ' de ' + l.length + ' meses' : '') : 'Sem relatório do iFood no período';
    }
    // Financeiro
    if ($('f3Mkt')) {
      $('f3Mkt').textContent = f.n ? brl(f.r) : 'R$ 0,00';
      $('f3MktSub').textContent = f.n ? 'iFood · ' + int(f.o) + ' pedidos · ticket ' + brl(f.o ? f.r / f.o : 0) + ' · ' + pct(tot ? f.r / tot * 100 : 0) + ' do total' : 'Sem relatório do iFood no período';
    }
    if (f.n && f.nov && $('cNovos')) $('cNovos').innerHTML = '<strong>' + int(f.nov) + '</strong> no iFood';
    if (!f.n) return;
    if ($('f3Tot')) {
      $('f3Tot').textContent = brl(tot);
      var lab = $('f3Tot').parentNode.querySelector('.kpi-label'); if (lab) lab.textContent = outR ? 'Faturamento Total (PDV)' : 'Faturamento Total (com iFood)';
      $('f3TotSub').className = 'kpi-sub neutral';
      $('f3TotSub').textContent = 'Cardápio Web ' + brl(prop) + ' + iFood ' + brl(f.r) + (outR ? ' + telefone e outros ' + brl(outR) : '');
    }
    var pp = function (v) { return pct(tot ? v / tot * 100 : 0); };
    if ($('f3DelSub')) $('f3DelSub').textContent = int(x.delO) + ' pedidos • Ticket ' + brl(x.delO ? x.delR / x.delO : 0) + ' • ' + pp(x.delR) + ' do total';
    if ($('f3RetSub')) $('f3RetSub').textContent = int(x.retO) + ' pedidos • Ticket ' + brl(x.retO ? x.retR / x.retO : 0) + ' • ' + pp(x.retR) + ' do total';
    var ped = (x.ped || 0) + f.o + outO;
    var row = function (n, r, o, b) { return '<tr><td><strong>' + n + '</strong></td><td>' + (b ? '<strong>' : '') + brl(r) + (b ? '</strong>' : '') + '</td><td>' + int(o) + '</td><td>' + brl(o ? r / o : 0) + '</td><td>' + (b ? '<strong>100,0%</strong>' : pp(r)) + '</td></tr>'; };
    if ($('f3Tabela')) $('f3Tabela').innerHTML = row('Delivery (Cardápio Web)', x.delR, x.delO) + row('Retirada (Cardápio Web)', x.retR, x.retO) +
      row('iFood', f.r, f.o) + (outR ? row('Telefone e outros (PDV)', outR, outO) : '') + row('Total', tot, ped, true);
    if ($('f3Nota')) $('f3Nota').textContent = 'Fonte: Cardápio Web (pedidos não cancelados) e relatório do iFood enviado à Mesa7' + (outR ? '; total do mês e "telefone e outros" (diferença) pelo PDV SAIPOS' : '') + (full && f.n < l.length ? ' — iFood só nos meses com relatório.' : '.');
    try {
      if (typeof chTipos !== 'undefined' && chTipos) {
        chTipos.data.labels = ['Delivery', 'Retirada', 'iFood'].concat(outR ? ['Telefone e outros'] : []);
        chTipos.data.datasets[0].data = [x.delR, x.retR, f.r].concat(outR ? [outR] : []);
        chTipos.data.datasets[0].backgroundColor = ['#9BAED9', '#F4F2EA', '#F98612', '#C792EA'];
        chTipos.update();
      }
      if (typeof chCanais !== 'undefined' && chCanais) {
        var base = chCanais.$m7 || (chCanais.$m7 = { labels: chCanais.data.labels.slice(), cores: chCanais.data.datasets[0].backgroundColor.slice() });
        var dados = chCanais.data.datasets[0].data.slice(0, base.labels.length);
        chCanais.data.labels = base.labels.concat(['iFood']);
        chCanais.data.datasets[0].data = dados.concat([f.r]);
        chCanais.data.datasets[0].backgroundColor = base.cores.concat(['#E5484D']);
        chCanais.update();
      }
    } catch (e) { /* gráfico ainda não criado */ }
  }

  // Resumo Executivo: no mês com relatório do SAIPOS, o número principal passa a ser o
  // faturamento total do delivery (Cardápio Web + iFood + telefone). Só em "Todos os tipos".
  function resumoPdv() {
    var cn; try { cn = canal; } catch (e) { cn = 'todos'; }
    var p = per(), S = (D.saipos || {})[p];
    if (p === 'full' || cn !== 'todos' || !S || !S.r || !$('k1Fat')) return;
    var pa = anterior(), SA = pa ? (D.saipos || {})[pa] : null;
    var put = function (id, v) { if ($(id)) $(id).textContent = v; };
    var sub = function (id, cur, ant, fmt) {
      var e = $(id); if (!e) return;
      if (ant) { var d = (cur - ant) / ant * 100; e.className = 'kpi-sub ' + (d > 0.05 ? 'up' : d < -0.05 ? 'down' : 'neutral'); e.textContent = (d > 0 ? '+' : '') + d.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '% vs mês anterior · total do SAIPOS'; }
      else { e.className = 'kpi-sub neutral'; e.textContent = 'Total do SAIPOS · ' + fmt; }
    };
    put('k1Fat', brl(S.r)); put('k1Ped', int(S.o)); put('k1Tkt', brl(S.t));
    sub('k1FatSub', S.r, SA && SA.r, 'Cardápio Web + iFood + telefone');
    sub('k1PedSub', S.o, SA && SA.o, 'pedidos de todos os canais');
    sub('k1TktSub', S.t, SA && SA.t, 'ticket de todos os canais');
    var lab = $('k1Fat').parentNode.querySelector('.kpi-label'); if (lab) lab.textContent = 'Faturamento Total';
    if ($('tFat')) { put('tFat', brl(S.r) + ' (SAIPOS)'); if ($('tFatM')) { $('tFatM').textContent = SA && SA.r ? dif(S.r, SA.r) : '—'; } }
    if ($('tPed')) { put('tPed', int(S.o)); if ($('tPedM')) $('tPedM').textContent = SA && SA.o ? dif(S.o, SA.o) : '—'; }
    if ($('tTkt')) { put('tTkt', brl(S.t)); if ($('tTktM')) $('tTktM').textContent = SA && SA.t ? dif(S.t, SA.t) : '—'; }
  }

  function tudo() { try { meta(); ifood(); resumoPdv(); } catch (e) { console.error('m7-cardapioweb', e); } }
  if (typeof window.render === 'function') {
    var orig = window.render;
    window.render = function () { var r = orig.apply(this, arguments); tudo(); return r; };
  }
  window.addEventListener('load', function () { setTimeout(tudo, 0); });
})();
