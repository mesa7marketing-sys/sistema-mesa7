/* =========================================================
   Top 5 anúncios do mês, na página "Marketing 360°" de todos os dashboards.
   Lê window.M7_DADOS.anuncios (scripts/meta-anuncios.mjs ou carga no dados.json).
   Ranking: menor custo por resultado comparado à média da conta para o mesmo tipo
   de resultado; só entram anúncios que investiram pelo menos a média por anúncio
   da conta no mês. Sem ROAS (decisão da Mesa7: não mostrar ROAS ao cliente).
   ========================================================= */
(function () {
  var AN = (window.M7_DADOS && window.M7_DADOS.anuncios) || {};
  var ids = Object.keys(AN).filter(function (k) { return AN[k] && AN[k].top && AN[k].top.length; }).sort();
  if (!ids.length) return;

  var TIPOS = {
    LPV: ['visita ao cardápio', 'visitas ao cardápio', 'fa-utensils'],
    LNK: ['clique no link', 'cliques no link', 'fa-arrow-pointer'],
    PUR: ['compra no site', 'compras no site', 'fa-bag-shopping'],
    PRF: ['visita ao perfil', 'visitas ao perfil', 'fa-user'],
    RCH: ['mil pessoas alcançadas', 'pessoas alcançadas', 'fa-users'],
    INT: ['interação', 'interações', 'fa-heart'],
    ENG: ['engajamento', 'engajamentos', 'fa-heart'],
    MSG: ['conversa iniciada', 'conversas iniciadas', 'fa-comments'],
    CHK: ['checkout iniciado', 'checkouts iniciados', 'fa-cart-shopping']
  };
  var MES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  var brl = function (v) { return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var int = function (v) { return Math.round(v || 0).toLocaleString('pt-BR'); };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var rotMes = function (id) { var p = id.split('-'); return MES[+p[1] - 1] + '/' + p[0].slice(2); };

  var css = document.createElement('style');
  css.textContent = [
    '#m7-top-anuncios .ta-lista{display:flex;flex-direction:column;gap:10px}',
    '#m7-top-anuncios .ta-item{display:grid;grid-template-columns:34px 64px minmax(0,1fr) auto;gap:14px;align-items:center;padding:12px 14px;border:1px solid var(--border,rgba(255,255,255,.08));border-radius:14px;background:rgba(255,255,255,.02)}',
    '#m7-top-anuncios .ta-pos{font-family:var(--m7-display,inherit);font-size:22px;font-weight:700;color:var(--m7-orange,#F98612);text-align:center}',
    '#m7-top-anuncios .ta-img{width:64px;height:64px;border-radius:10px;object-fit:cover;background:rgba(255,255,255,.05);display:flex;align-items:center;justify-content:center;color:var(--text-muted,#9BAED9);font-size:20px;overflow:hidden}',
    '#m7-top-anuncios .ta-img img{width:100%;height:100%;object-fit:cover}',
    '#m7-top-anuncios .ta-nome{font-weight:600;color:var(--m7-cream,#F4F2EA);font-size:13.5px;line-height:1.35;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}',
    '#m7-top-anuncios .ta-meta{font-size:11.5px;color:var(--text-muted,#9BAED9);margin-top:4px}',
    '#m7-top-anuncios .ta-res{text-align:right;white-space:nowrap}',
    '#m7-top-anuncios .ta-res b{display:block;font-family:var(--m7-display,inherit);font-size:17px;color:var(--m7-cream,#F4F2EA)}',
    '#m7-top-anuncios .ta-res span{font-size:11.5px;color:var(--text-muted,#9BAED9)}',
    '#m7-top-anuncios .ta-tag{display:inline-block;margin-top:5px;font-size:11px;font-weight:600;padding:3px 10px;border-radius:100px;background:rgba(155,174,217,.14);color:var(--m7-blue,#9BAED9)}',
    '#m7-top-anuncios .ta-tag.bom{background:rgba(249,134,18,.14);color:var(--m7-orange,#F98612)}',
    '@media(max-width:700px){#m7-top-anuncios .ta-item{grid-template-columns:26px 52px minmax(0,1fr)}#m7-top-anuncios .ta-img{width:52px;height:52px}#m7-top-anuncios .ta-res{grid-column:2/-1;text-align:left}}'
  ].join('\n');
  document.head.appendChild(css);

  function paginaMarketing() {
    var navs = Array.prototype.slice.call(document.querySelectorAll('.nav-item'));
    for (var i = 0; i < navs.length; i++) {
      if (!/Marketing 360/i.test(navs[i].textContent || '')) continue;
      var id = navs[i].getAttribute('data-page');
      if (!id) { var m = /switchPage\('([^']+)'\)/.exec(navs[i].getAttribute('onclick') || ''); id = m && m[1]; }
      var pg = id && document.getElementById(id);
      if (pg) return pg;
    }
    return null;
  }

  function mesEscolhido() {
    var s = document.getElementById('selPeriodo') || document.getElementById('selMes');
    var v = s ? s.value : '';
    return /^\d{4}-\d{2}$/.test(v) ? v : ids[ids.length - 1];
  }

  function linha(a, i) {
    var t = TIPOS[a.tipo] || [a.tipo, a.tipo, 'fa-bullhorn'];
    var porMil = a.tipo === 'RCH';
    var dif = a.media ? Math.round((1 - a.custo / a.media) * 100) : 0;
    var tag = dif >= 5 ? '<span class="ta-tag bom">' + dif + '% mais barato que a média da conta</span>'
      : dif > -5 ? '<span class="ta-tag">na média da conta</span>'
      : '<span class="ta-tag">' + Math.abs(dif) + '% acima da média da conta</span>';
    var video = /v[ií]deo|video|reels?/i.test(a.nome);
    var img = a.img ? '<img src="' + esc(a.img) + '" alt="" loading="lazy">' : '<i class="fa-solid ' + (video ? 'fa-film' : 'fa-image') + '"></i>';
    var qtd = porMil ? int(a.res) + ' ' + t[1] : int(a.res) + ' ' + (a.res === 1 ? t[0] : t[1]);
    return '<div class="ta-item"><div class="ta-pos">' + (i + 1) + '</div><div class="ta-img">' + img + '</div>' +
      '<div><div class="ta-nome" title="' + esc(a.nome) + '">' + esc(a.nome) + '</div>' +
      '<div class="ta-meta">Investido ' + brl(a.gas) + ' · alcance ' + int(a.alc) + ' · ' + int(a.clk) + ' cliques</div>' + tag + '</div>' +
      '<div class="ta-res"><b>' + brl(a.custo) + '</b><span>' + (porMil ? 'por mil pessoas alcançadas' : 'por ' + t[0]) + '</span><br><span>' + qtd + '</span></div></div>';
  }

  function html() {
    var id = mesEscolhido(), m = AN[id];
    var titulo = '<div class="chart-header"><div class="chart-title"><i class="fa-solid fa-trophy"></i> Top 5 anúncios do mês</div></div>';
    if (!m) return titulo + '<p class="chart-note" style="margin-top:0">Sem ranking de anúncios em ' + rotMes(id) + '. Meses com ranking: ' + ids.map(rotMes).join(', ') + '.</p>';
    return titulo + '<div class="ta-lista">' + m.top.map(linha).join('') + '</div>' +
      '<p class="chart-note">Ranking de ' + rotMes(id) + (m.ate ? ' (até ' + m.ate.split('-').reverse().slice(0, 2).join('/') + ')' : '') +
      ': menor custo por resultado comparado à média da conta para o mesmo tipo de resultado. Entram só anúncios que investiram pelo menos a média por anúncio do mês (' + brl(m.minimo) + '). Fonte: Meta Ads.</p>';
  }

  var feito = new WeakMap(), ocupado = false;
  function aplicar() {
    if (ocupado) return; ocupado = true;
    try {
      var pg = paginaMarketing(); if (!pg) return;
      var card = document.getElementById('m7-top-anuncios');
      if (!card || !pg.contains(card)) {
        card = document.createElement('div');
        card.id = 'm7-top-anuncios';
        card.className = 'chart-card';
        pg.appendChild(card);
      }
      var h = html();
      if (feito.get(card) !== h) { card.innerHTML = h; feito.set(card, h); }
    } finally { ocupado = false; }
  }

  var t = null;
  var agendar = function () { clearTimeout(t); t = setTimeout(aplicar, 40); };
  function iniciar() {
    aplicar();
    new MutationObserver(function () { if (!ocupado) agendar(); }).observe(document.body, { childList: true, subtree: true });
    document.addEventListener('change', agendar, true);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
