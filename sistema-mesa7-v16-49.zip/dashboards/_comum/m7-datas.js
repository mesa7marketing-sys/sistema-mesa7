/* =========================================================
   Mesa7 — página "Datas Comemorativas" dentro do dashboard
   Injetada pelo Sistema Mesa7 nos clientes com a página ligada
   (src/lib/dashboards.ts → datas: true), junto com window.M7_DATAS:
     { cliente, catalogo:[{id,nome,cat,data,obs}], selecao:{selecionadas,proprias,obs,...} }
   O cliente marca as datas que quer trabalhar; a equipe usa a
   seleção para montar o calendário individual.
   ========================================================= */
(function () {
  var D = window.M7_DATAS;
  var nav = document.querySelector('.nav-menu');
  var main = document.querySelector('main');
  if (!D || !nav || !main || typeof window.switchPage !== 'function') return;

  var ID = 'pdatas';
  var TITULO = 'Datas Comemorativas';
  var SUB = 'Escolha as datas que o ' + D.cliente + ' quer trabalhar. A Mesa7 monta o calendário de conteúdo e campanhas a partir delas.';
  var MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  var SEMANA = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
  var CATS = ['Todas', 'Feriado', 'Comercial', 'Gastronomia', 'Temática', 'Escolhidas'];

  var sel = D.selecao || {};
  var escolhidas = {};
  (sel.selecionadas || []).forEach(function (id) { escolhidas[id] = true; });
  var proprias = (sel.proprias || []).slice();
  var obs = sel.obs || '';
  var filtro = 'Todas';
  var sujo = false;
  var salvoInfo = sel.atualizadoEm ? { em: sel.atualizadoEm, por: sel.atualizadoPor } : null;

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function dt(iso) { var p = iso.split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])); }
  function diaMes(iso) { var p = iso.split('-'); return p[2] + '/' + p[1]; }
  function semana(iso) { return SEMANA[dt(iso).getUTCDay()]; }
  function hoje() { return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo' }).format(new Date()); }
  function proximaPropria(mmdd) { var h = hoje(), a = +h.slice(0, 4), d = a + '-' + mmdd; return d >= h ? d : (a + 1) + '-' + mmdd; }

  var css = document.createElement('style');
  css.textContent = [
    '.m7d-top{display:flex;flex-wrap:wrap;align-items:center;gap:12px;margin-bottom:18px}',
    '.m7d-cont{font-size:13px;color:var(--text-muted)}.m7d-cont b{color:var(--m7-orange);font-size:15px}',
    '.m7d-chips{display:flex;flex-wrap:wrap;gap:8px;flex:1 1 auto}',
    '.m7d-chip{border:1px solid var(--border-strong);background:transparent;color:var(--text-sub);border-radius:99px;padding:7px 13px;font:600 12px Poppins,sans-serif;cursor:pointer}',
    '.m7d-chip.on{background:var(--primary-glow,rgba(249,134,18,.14));border-color:rgba(249,134,18,.5);color:var(--m7-orange)}',
    '.m7d-grid{display:grid;grid-template-columns:minmax(0,2fr) minmax(0,1fr);gap:18px;align-items:start}',
    '@media (max-width:1100px){.m7d-grid{grid-template-columns:minmax(0,1fr)}}',
    '.m7d-card{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:20px 20px 12px;margin-bottom:18px}',
    '.m7d-card h3{font-size:15px;font-weight:600;color:var(--m7-cream);margin-bottom:12px;display:flex;align-items:center;gap:9px}.m7d-card h3 i{color:var(--m7-orange)}',
    '.m7d-mes{font-size:11px;text-transform:uppercase;letter-spacing:1.3px;color:var(--text-muted);font-weight:600;margin:14px 0 8px}',
    '.m7d-mes:first-child{margin-top:0}',
    '.m7d-item{display:flex;align-items:center;gap:12px;width:100%;text-align:left;background:transparent;border:1px solid var(--border);border-radius:11px;padding:11px 13px;margin-bottom:8px;cursor:pointer;color:var(--m7-cream);font-family:Poppins,sans-serif;transition:all .15s ease}',
    '.m7d-item:hover{border-color:var(--border-strong);background:var(--bg-hover)}',
    '.m7d-item.on{border-color:rgba(249,134,18,.55);background:var(--primary-glow,rgba(249,134,18,.14))}',
    '.m7d-check{flex:0 0 auto;width:22px;height:22px;border-radius:7px;border:1.5px solid var(--border-strong);display:flex;align-items:center;justify-content:center;font-size:13px;color:transparent}',
    '.m7d-item.on .m7d-check{background:var(--m7-orange);border-color:var(--m7-orange);color:var(--m7-navy-deep,#101243);font-weight:800}',
    '.m7d-data{flex:0 0 64px;font-weight:700;font-size:14px;line-height:1.1}.m7d-data small{display:block;font-weight:500;font-size:11px;color:var(--text-muted);margin-top:2px}',
    '.m7d-nome{flex:1 1 auto;min-width:0;font-size:13.5px;font-weight:500}.m7d-nome small{display:block;font-size:11px;color:var(--text-muted);margin-top:2px}',
    '.m7d-tag{flex:0 0 auto;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.6px;border-radius:99px;padding:3px 9px;background:rgba(155,174,217,.14);color:var(--text-muted)}',
    '.m7d-vazio{color:var(--text-muted);font-size:13px;padding:10px 0 14px}',
    '.m7d-form{display:flex;flex-wrap:wrap;gap:8px;margin:6px 0 12px}',
    '.m7d-in{background:var(--bg-panel,#101243);border:1px solid var(--border-strong);border-radius:10px;padding:10px 12px;color:var(--m7-cream);font:500 13px Poppins,sans-serif;min-width:0}',
    '.m7d-in[type=text]{flex:1 1 150px}.m7d-in[type=date]{flex:0 0 150px;color-scheme:dark}',
    'textarea.m7d-in{width:100%;min-height:110px;resize:vertical;line-height:1.5}',
    '.m7d-btn{border:1px solid var(--border-strong);background:transparent;color:var(--text-sub);border-radius:10px;padding:9px 14px;font:600 12.5px Poppins,sans-serif;cursor:pointer}',
    '.m7d-btn:hover{border-color:var(--m7-orange);color:var(--m7-orange)}',
    '.m7d-prop{display:flex;align-items:center;gap:10px;border:1px solid var(--border);border-radius:10px;padding:9px 12px;margin-bottom:8px;font-size:13px}',
    '.m7d-prop span{flex:1 1 auto;min-width:0}.m7d-prop b{color:var(--m7-orange);font-weight:700;margin-right:6px}',
    '.m7d-x{background:transparent;border:none;color:var(--text-muted);cursor:pointer;font-size:16px;padding:2px 6px}.m7d-x:hover{color:#ef4444}',
    '.m7d-salvar{position:sticky;bottom:12px;z-index:5;display:flex;flex-wrap:wrap;align-items:center;gap:12px;background:var(--bg-panel,#101243);border:1px solid var(--border-strong);border-radius:14px;padding:12px 14px;box-shadow:0 10px 30px rgba(0,0,0,.35)}',
    '.m7d-principal{background:var(--m7-orange);color:var(--m7-navy-deep,#101243);border:none;border-radius:10px;padding:11px 20px;font:700 13.5px Poppins,sans-serif;cursor:pointer}',
    '.m7d-principal:disabled{opacity:.55;cursor:default}',
    '.m7d-msg{font-size:12.5px;color:var(--text-muted)}.m7d-msg.ok{color:#34d399}.m7d-msg.erro{color:#ef4444}.m7d-msg.sujo{color:#fbbf24}',
    '@media (max-width:560px){.m7d-data{flex-basis:52px}.m7d-tag{display:none}.m7d-card{padding:16px 14px 8px}}'
  ].join('\n');
  document.head.appendChild(css);

  // ---- item no menu + página ----
  var n = nav.querySelectorAll('.nav-item').length + 1;
  var li = document.createElement('li');
  li.className = 'nav-item';
  li.setAttribute('data-page', ID);
  li.innerHTML = '<i class="fa-solid fa-calendar-days"></i> ' + n + '. ' + TITULO;
  nav.appendChild(li);

  var pagina = document.createElement('div');
  pagina.id = ID;
  pagina.className = 'view-page';
  main.appendChild(pagina);

  var tituloHtml = '<i class="fa-solid fa-calendar-days" style="color:var(--m7-orange)"></i> ' + TITULO;
  try { if (typeof headings === 'object' && headings) headings[ID] = { t: tituloHtml, s: esc(SUB) }; } catch (e) { /* dashboard sem headings */ }

  var anterior = window.switchPage;
  window.switchPage = function (id) {
    var bar = document.querySelector('.filter-bar');
    if (bar && id !== ID) bar.style.display = '';
    try { anterior(id); } catch (e) { if (id !== ID) throw e; }
    if (id !== ID) { li.classList.remove('active'); return; }
    document.querySelectorAll('.view-page').forEach(function (p) { p.classList.toggle('active', p.id === ID); });
    document.querySelectorAll('.nav-item').forEach(function (i) { i.classList.toggle('active', i === li); });
    var h = document.getElementById('page-heading'), s = document.getElementById('page-subheading');
    if (h) h.innerHTML = tituloHtml;
    if (s) s.textContent = SUB;
    if (bar) bar.style.display = 'none';
    if (document.body.classList.contains('nav-open')) { document.body.classList.remove('nav-open'); var o = document.getElementById('overlay'); if (o) o.classList.remove('show'); }
    window.scrollTo(0, 0);
  };
  li.addEventListener('click', function () { window.switchPage(ID); });

  // ---- render ----
  function total() { return Object.keys(escolhidas).length + proprias.length; }

  function msgSalvo() {
    if (sujo) return '<span class="m7d-msg sujo">Alterações ainda não salvas</span>';
    if (!salvoInfo) return '<span class="m7d-msg">Nada salvo ainda</span>';
    var d = new Date(salvoInfo.em);
    var quando = d.toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit' }) + ' às ' +
      d.toLocaleTimeString('pt-BR', { timeZone: 'America/Sao_Paulo', hour: '2-digit', minute: '2-digit' });
    return '<span class="m7d-msg ok">✓ Salvo em ' + esc(quando) + (salvoInfo.por ? ' por ' + esc(salvoInfo.por) : '') + '</span>';
  }

  function listaDatas() {
    var itens = D.catalogo.filter(function (o) {
      if (filtro === 'Todas') return true;
      if (filtro === 'Escolhidas') return escolhidas[o.id];
      return o.cat === filtro;
    });
    if (!itens.length) return '<div class="m7d-vazio">Nenhuma data ' + (filtro === 'Escolhidas' ? 'escolhida ainda.' : 'nessa categoria.') + '</div>';
    var h = '', mesAtual = '';
    itens.forEach(function (o) {
      var m = o.data.slice(0, 7);
      if (m !== mesAtual) { mesAtual = m; h += '<div class="m7d-mes">' + MESES[+m.slice(5) - 1] + ' · ' + m.slice(0, 4) + '</div>'; }
      var on = !!escolhidas[o.id];
      h += '<button type="button" class="m7d-item' + (on ? ' on' : '') + '" data-id="' + o.id + '" aria-pressed="' + on + '">' +
        '<span class="m7d-check">✓</span>' +
        '<span class="m7d-data">' + diaMes(o.data) + '<small>' + semana(o.data) + '</small></span>' +
        '<span class="m7d-nome">' + esc(o.nome) + (o.obs ? '<small>' + esc(o.obs) + '</small>' : '') + '</span>' +
        '<span class="m7d-tag">' + esc(o.cat) + '</span></button>';
    });
    return h;
  }

  function listaProprias() {
    if (!proprias.length) return '<div class="m7d-vazio">Aniversário da casa, eventos fixos, datas da cidade… adicione aqui.</div>';
    return proprias.slice().sort(function (a, b) { return proximaPropria(a.mmdd).localeCompare(proximaPropria(b.mmdd)); }).map(function (p) {
      var d = proximaPropria(p.mmdd);
      return '<div class="m7d-prop"><span><b>' + diaMes(d) + '</b>' + esc(p.nome) + '</span><button type="button" class="m7d-x" data-rm="' + esc(p.id) + '" aria-label="Remover ' + esc(p.nome) + '">×</button></div>';
    }).join('');
  }

  function render() {
    pagina.innerHTML =
      '<div class="m7d-top"><div class="m7d-chips">' + CATS.map(function (c) {
        return '<button type="button" class="m7d-chip' + (c === filtro ? ' on' : '') + '" data-f="' + c + '">' + c + '</button>';
      }).join('') + '</div><div class="m7d-cont"><b>' + total() + '</b> datas no calendário</div></div>' +
      '<div class="m7d-grid"><div class="m7d-card"><h3><i class="fa-solid fa-calendar-check"></i> Próximos 12 meses</h3>' + listaDatas() + '</div>' +
      '<div><div class="m7d-card"><h3><i class="fa-solid fa-house"></i> Datas da casa</h3>' + listaProprias() +
      '<div class="m7d-form"><input class="m7d-in" type="text" id="m7dNome" maxlength="80" placeholder="Ex.: Aniversário do Paçocas"><input class="m7d-in" type="date" id="m7dData" aria-label="Data"><button type="button" class="m7d-btn" id="m7dAdd">Adicionar</button></div></div>' +
      '<div class="m7d-card"><h3><i class="fa-solid fa-pen"></i> Recado para a equipe</h3><textarea class="m7d-in" id="m7dObs" maxlength="2000" placeholder="Ex.: queremos uma ação forte no Dia dos Pais; no Carnaval a casa fecha.">' + esc(obs) + '</textarea><div style="height:10px"></div></div></div></div>' +
      '<div class="m7d-salvar"><button type="button" class="m7d-principal" id="m7dSalvar">Salvar seleção</button><span id="m7dMsg">' + msgSalvo() + '</span></div>';
  }

  function marcarSujo() {
    sujo = true;
    var m = document.getElementById('m7dMsg');
    if (m) m.innerHTML = msgSalvo();
    var c = pagina.querySelector('.m7d-cont b');
    if (c) c.textContent = total();
  }

  pagina.addEventListener('click', function (e) {
    var t = e.target.closest('button');
    if (!t) return;
    if (t.dataset.id) {
      if (escolhidas[t.dataset.id]) delete escolhidas[t.dataset.id]; else escolhidas[t.dataset.id] = true;
      var on = !!escolhidas[t.dataset.id];
      t.classList.toggle('on', on);
      t.setAttribute('aria-pressed', on);
      marcarSujo();
      if (filtro === 'Escolhidas') { render(); }
    } else if (t.dataset.f) {
      filtro = t.dataset.f; render();
    } else if (t.dataset.rm) {
      proprias = proprias.filter(function (p) { return p.id !== t.dataset.rm; }); sujo = true; render();
    } else if (t.id === 'm7dAdd') {
      var nome = document.getElementById('m7dNome').value.trim(), data = document.getElementById('m7dData').value;
      if (!nome || !/^\d{4}-\d{2}-\d{2}$/.test(data)) { document.getElementById(nome ? 'm7dData' : 'm7dNome').focus(); return; }
      proprias.push({ id: 'p-' + Date.now().toString(36), nome: nome, mmdd: data.slice(5) });
      sujo = true; render();
    } else if (t.id === 'm7dSalvar') {
      salvar(t);
    }
  });
  pagina.addEventListener('input', function (e) { if (e.target.id === 'm7dObs') { obs = e.target.value; marcarSujo(); } });

  function salvar(btn) {
    btn.disabled = true; btn.textContent = 'Salvando…';
    fetch('../datas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ selecionadas: Object.keys(escolhidas), proprias: proprias, obs: obs })
    }).then(function (r) { return r.json().then(function (j) { if (!r.ok || !j.ok) throw new Error(j.erro || 'erro'); return j; }); })
      .then(function (j) { sujo = false; salvoInfo = { em: j.atualizadoEm, por: j.atualizadoPor }; })
      .catch(function () { var m = document.getElementById('m7dMsg'); if (m) m.innerHTML = '<span class="m7d-msg erro">Não consegui salvar. Confira a internet e tente de novo.</span>'; btn.disabled = false; btn.textContent = 'Salvar seleção'; throw 'x'; })
      .then(function () { btn.disabled = false; btn.textContent = 'Salvar seleção'; document.getElementById('m7dMsg').innerHTML = msgSalvo(); })
      .catch(function () {});
  }

  render();
  if (location.hash === '#datas') window.switchPage(ID);
})();
