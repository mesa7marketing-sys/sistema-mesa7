/* =========================================================
   Seguidores do Instagram em todos os dashboards.
   Lê window.M7_DADOS.instagram (coleta diária: scripts/instagram-seguidores.mjs)
   e preenche toda linha de tabela cujo rótulo é "Seguidores" ou "Novos Seguidores",
   no mês escolhido no filtro (ou no último mês, no período completo).
   ========================================================= */
(function () {
  var IG = (window.M7_DADOS && window.M7_DADOS.instagram) || {};
  var ids = Object.keys(IG).sort();
  if (!ids.length) return;

  var NOMES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  var int = function (v) { return Math.round(v || 0).toLocaleString('pt-BR'); };
  var dm = function (d) { var p = (d || '').split('-'); return p.length === 3 ? p[2] + '/' + p[1] : ''; };
  var mesAnterior = function (id) { var p = id.split('-'); var y = +p[0], m = +p[1] - 1; if (!m) { m = 12; y--; } return y + '-' + (m < 10 ? '0' : '') + m; };

  function mesEscolhido() {
    var s = document.getElementById('selPeriodo') || document.getElementById('selMes');
    var v = s ? s.value : '';
    return /^\d{4}-\d{2}$/.test(v) ? v : null;   // período completo → último mês
  }

  function ganho(id) {
    var m = IG[id]; if (!m) return null;
    var ant = IG[mesAnterior(id)];
    if (ant) return { n: m.seg - ant.seg, desde: null };
    if (m.ini != null && m.ini_em && m.ini_em !== m.em) return { n: m.seg - m.ini, desde: m.ini_em };
    return null;
  }

  function texto(novos) {
    var id = mesEscolhido() || ids[ids.length - 1];
    var m = IG[id];
    if (!m) {
      var p = id.split('-');
      return '<span class="wait">Sem leitura em ' + NOMES[+p[1] - 1] + '/' + p[0].slice(2) + ' — coleta desde ' + dm(IG[ids[0]].ini_em || IG[ids[0]].em) + '</span>';
    }
    var g = ganho(id);
    var sinal = g ? (g.n > 0 ? '+' : '') + int(g.n) : null;
    if (novos) return g ? '<strong>' + sinal + '</strong> <span class="m7-ig-sub">' + (g.desde ? 'desde ' + dm(g.desde) : 'no mês') + ' · total ' + int(m.seg) + '</span>' : '<strong>' + int(m.seg) + '</strong> <span class="m7-ig-sub">seguidores (1ª leitura)</span>';
    return '<strong>' + int(m.seg) + '</strong>' + (g ? ' <span class="m7-ig-sub">' + sinal + (g.desde ? ' desde ' + dm(g.desde) : ' no mês') + '</span>' : '') +
      (m.em ? ' <span class="m7-ig-sub">· em ' + dm(m.em) + '</span>' : '');
  }

  var aplicando = false, feitos = new WeakMap();
  function aplicar() {
    if (aplicando) return; aplicando = true;
    try {
      Array.prototype.slice.call(document.querySelectorAll('tr')).forEach(function (tr) {
        var c = tr.children; if (c.length < 2) return;
        var rot = (c[0].textContent || '').trim();
        if (!/^(novos\s+)?seguidores$/i.test(rot)) return;
        var html = '<span data-m7ig="1">' + texto(/^novos/i.test(rot)) + '</span>';
        // se a célula tem um elemento com id (o dashboard escreve nele), escreve dentro dele para não apagá-lo
        var alvo = c[1].querySelector('[id]') || c[1];
        var atual = alvo.querySelector('[data-m7ig]');
        if (atual && feitos.get(atual) === html) return;
        alvo.innerHTML = html;
        feitos.set(alvo.querySelector('[data-m7ig]'), html);
      });
    } finally { aplicando = false; }
  }

  var css = document.createElement('style');
  css.textContent = '.m7-ig-sub{font-size:11px;color:var(--text-muted,#9BAED9);font-weight:500;margin-left:4px}';
  document.head.appendChild(css);

  var t = null;
  var agendar = function () { clearTimeout(t); t = setTimeout(aplicar, 30); };
  function iniciar() {
    aplicar();
    new MutationObserver(function () { if (!aplicando) agendar(); }).observe(document.body, { childList: true, subtree: true, characterData: true });
    document.addEventListener('change', agendar, true);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
