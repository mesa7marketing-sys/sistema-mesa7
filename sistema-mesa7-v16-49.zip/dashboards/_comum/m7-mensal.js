/* =========================================================
   "Cardápio & ABC" e "Comportamento" mês a mês nos dashboards completos.
   O HTML de cada cliente tem um recorte fixo (ex.: Abr–Set/26 ou Agosto/2026).
   Este script segue o filtro de período:
   - no(s) período(s) do recorte original, mostra a página como sempre foi;
   - em qualquer outro mês, monta a página com os dados do mês que chegaram
     pelo sistema (window.M7_DADOS): itens vendidos (itens), pedidos por dia e
     hora (cardapio, ifood). Sem dado, mostra a estrutura com "Sem dados".
   Cada HTML pode dizer qual é o recorte original:
     window.M7_RECORTE = { abc: ['2026-08'] | 'full', comp: ['2026-08'] | 'full' }
   Padrão: 'full' (o original aparece em "Período completo").
   ========================================================= */
(function () {
  var D = window.M7_DADOS || {};
  var IT = D.itens || {}, CD = D.cardapio || {}, IF = D.ifood || {};
  var REC = window.M7_RECORTE || {};
  var MES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  var brl = function (v) { return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var int = function (v) { return Math.round(v || 0).toLocaleString('pt-BR'); };
  var pct = function (v) { return (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%'; };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var mesLbl = function (id) { var p = id.split('-'); return MES[+p[1] - 1] + '/' + p[0]; };
  var AX = { grid: { color: 'rgba(155,174,217,.12)' }, ticks: { color: '#9BAED9' }, border: { color: 'rgba(155,174,217,.12)' } };
  var WAIT = '<span class="wait" style="font-size:16px">Sem dados</span>';

  function pagina(re) {
    var navs = document.querySelectorAll('.nav-item');
    for (var i = 0; i < navs.length; i++) {
      if (!re.test(navs[i].textContent || '')) continue;
      var id = navs[i].getAttribute('data-page');
      if (!id) { var m = /switchPage\('([^']+)'\)/.exec(navs[i].getAttribute('onclick') || ''); id = m && m[1]; }
      var pg = id && document.getElementById(id);
      if (pg) return pg;
    }
    return null;
  }
  function periodo() { var s = document.getElementById('selPeriodo'); return s ? s.value : 'full'; }
  function ehOriginal(rec, per) {
    if (!rec || rec === 'full') return per === 'full' || !/^\d{4}-\d{2}$/.test(per);
    return per === 'full' || rec.indexOf(per) > -1;
  }
  function onde(rec) { return rec && rec !== 'full' ? 'O recorte anterior aparece ao escolher ' + rec.map(mesLbl).join(', ') + ' no filtro.' : 'O consolidado anterior continua em "Período completo".'; }
  function kpi(cls, rot, ic, v, sub) {
    return '<div class="kpi-card ' + cls + '"><div class="kpi-header"><span class="kpi-label">' + rot + '</span><i class="fa-solid ' + ic + ' kpi-icon"></i></div>' +
      '<div class="kpi-value" style="font-size:19px">' + (v == null ? WAIT : v) + '</div>' + (sub ? '<div class="kpi-sub neutral">' + sub + '</div>' : '') + '</div>';
  }

  /* Monta um "modo mês" numa página: guarda os filhos originais e alterna. */
  function modulo(re, rec, idBox, desenhar) {
    var pg = pagina(re);
    if (!pg) return null;
    var box = document.createElement('div');
    box.id = idBox;
    box.style.display = 'none';
    pg.appendChild(box);
    var orig = Array.prototype.slice.call(pg.children).filter(function (c) { return c !== box; });
    var charts = [];
    return function () {
      var per = periodo();
      var o = ehOriginal(rec, per);
      orig.forEach(function (c) { c.style.display = o ? '' : 'none'; });
      box.style.display = o ? 'none' : '';
      if (o) return;
      charts.forEach(function (c) { c.destroy(); });
      charts = [];
      box.innerHTML = '';
      desenhar(box, per, charts);
    };
  }

  /* ---------- Cardápio & ABC ---------- */
  var atABC = modulo(/Card[aá]pio\s*(&|e)\s*ABC/i, REC.abc || 'full', 'm7abcMes', function (box, per, charts) {
    var d = IT[per];
    var chip = '<div class="filter-chip"><i class="fa-solid fa-calendar-day"></i> ' + esc(mesLbl(per)) + (d ? ' — itens vendidos no mês' : ' — itens do mês ainda não lançados') + '</div>';
    if (!d || !d.itens || !d.itens.length) {
      box.innerHTML = chip + '<div class="kpi-grid">' + kpi('highlight', 'Maior Faturamento', 'fa-crown') + kpi('blue', 'Maior Volume', 'fa-ranking-star') +
        kpi('cream', 'Itens com Venda', 'fa-list') + kpi('deep', 'Concentração Top 5', 'fa-layer-group') + '</div>' +
        '<div class="chart-card"><div class="chart-header"><div class="chart-title"><i class="fa-solid fa-table-list"></i> Curva ABC — ' + esc(mesLbl(per)) + '</div></div>' +
        '<p class="chart-note" style="margin-top:6px">Sem dados de itens vendidos em ' + esc(mesLbl(per)) + '. O ranking aparece aqui assim que o relatório do mês for lançado. ' + onde(REC.abc) + '</p></div>';
      return;
    }
    var it = d.itens, tot = d.total || it.reduce(function (s, x) { return s + x.v; }, 0);
    var vol = it.slice().sort(function (a, b) { return b.q - a.q; })[0];
    var t5 = it.slice(0, 5).reduce(function (s, x) { return s + x.v; }, 0);
    box.innerHTML = chip + '<div class="kpi-grid">' +
      kpi('highlight', 'Maior Faturamento', 'fa-crown', esc(it[0].n), brl(it[0].v) + ' · ' + int(it[0].q) + ' unidades') +
      kpi('blue', 'Maior Volume', 'fa-ranking-star', esc(vol.n), int(vol.q) + ' unidades · ' + brl(vol.v)) +
      kpi('cream', 'Itens com Venda', 'fa-list', int(it.length), int(d.unidades) + ' unidades · ' + brl(tot)) +
      kpi('deep', 'Concentração Top 5', 'fa-layer-group', pct(tot ? t5 / tot * 100 : 0), brl(t5) + ' do faturamento de itens') + '</div>' +
      '<div class="chart-card"><div class="chart-header"><div class="chart-title"><i class="fa-solid fa-ranking-star"></i> Top 15 por Faturamento</div></div><div class="chart-container tall"><canvas id="m7abcChart"></canvas></div></div>' +
      '<div class="chart-card"><div class="chart-header"><div class="chart-title"><i class="fa-solid fa-table-list"></i> Curva ABC — Top 30</div></div><div style="overflow-x:auto"><table class="data-table">' +
      '<thead><tr><th>#</th><th>Item</th><th>Categoria</th><th>Qtd.</th><th>Faturamento</th><th>Preço Médio</th><th>% do Total</th><th>Acum.</th><th>Curva</th></tr></thead><tbody id="m7abcTab"></tbody></table></div>' +
      '<p class="chart-note">Curva A: itens que somam os primeiros 80% do faturamento; B: até 95%; C: o restante. Fonte: relatório de itens vendidos de ' + esc(mesLbl(per)) + '.</p></div>';
    var ac = 0, linhas = it.slice(0, 30).map(function (x, n) {
      ac += x.v; var pa = tot ? ac / tot * 100 : 0;
      return '<tr><td>' + (n + 1) + '</td><td><strong>' + esc(x.n) + '</strong></td><td>' + esc(x.c || '—') + '</td><td>' + int(x.q) + '</td><td>' + brl(x.v) + '</td><td>' + brl(x.q ? x.v / x.q : 0) + '</td><td>' + pct(tot ? x.v / tot * 100 : 0) + '</td><td>' + pct(pa) + '</td><td>' + (pa <= 80.0001 || n === 0 ? 'A' : pa <= 95 ? 'B' : 'C') + '</td></tr>';
    });
    if (it.length > 30) {
      var resto = it.slice(30), rv = resto.reduce(function (s, x) { return s + x.v; }, 0), rq = resto.reduce(function (s, x) { return s + x.q; }, 0);
      linhas.push('<tr><td>—</td><td><strong>Demais itens (' + resto.length + ')</strong></td><td>—</td><td>' + int(rq) + '</td><td>' + brl(rv) + '</td><td>—</td><td>' + pct(tot ? rv / tot * 100 : 0) + '</td><td>100,0%</td><td>C</td></tr>');
    }
    document.getElementById('m7abcTab').innerHTML = linhas.join('');
    if (typeof Chart !== 'undefined') {
      var t15 = it.slice(0, 15);
      charts.push(new Chart(document.getElementById('m7abcChart'), { type: 'bar',
        data: { labels: t15.map(function (x) { return x.n; }), datasets: [{ label: 'Faturamento', data: t15.map(function (x) { return x.v; }),
          backgroundColor: t15.map(function (_, i) { return i < 5 ? '#F98612' : i < 10 ? '#9BAED9' : '#F4F2EA'; }), borderRadius: 5 }] },
        options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false },
          tooltip: { callbacks: { label: function (c) { return brl(c.parsed.x) + ' · ' + int(t15[c.dataIndex].q) + ' unidades'; } } } },
          scales: { x: Object.assign({}, AX, { ticks: { color: '#9BAED9', callback: function (v) { return 'R$ ' + (v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v); } } }), y: Object.assign({}, AX, { ticks: { color: '#9BAED9', font: { size: 10 } } }) } } }));
    }
  });

  /* ---------- Comportamento ---------- */
  var SEM = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
  var atComp = modulo(/Comportamento/i, REC.comp || 'full', 'm7compMes', function (box, per, charts) {
    var c = CD[per], i = IF[per];
    var dias = {}, horas = {}, fontes = [];
    var soma = function (alvo, k, o, r) { var x = alvo[k] || (alvo[k] = { o: 0, r: 0 }); x.o += o; x.r += r || 0; };
    if (c && c.dias && Object.keys(c.dias).length) { for (var k in c.dias) soma(dias, k, c.dias[k].o, c.dias[k].r); fontes.push('cardápio próprio'); }
    if (c && c.horas) for (var h in c.horas) soma(horas, h, c.horas[h].o, c.horas[h].r);
    if (i && i.dias && Object.keys(i.dias).length) { for (var k2 in i.dias) soma(dias, k2.replace(/-feira/i, ''), i.dias[k2], 0); fontes.push('iFood'); }
    if (i && i.horas && !Object.keys(horas).length) ['semana', 'fds'].forEach(function (g) { var s = i.horas[g] || {}; for (var h2 in s) soma(horas, h2, s[h2], 0); });
    var chip = '<div class="filter-chip"><i class="fa-solid fa-calendar-day"></i> ' + esc(mesLbl(per)) + (fontes.length ? ' — pedidos de ' + fontes.join(' + ') : ' — sem dados de dia e horário no mês') + '</div>';
    var temD = Object.keys(dias).length, temH = Object.keys(horas).length;
    var melhor = null, tkt = null, tktV = 0, tot = 0, fds = 0, pico = null;
    for (var d in dias) { tot += dias[d].o; if (/sexta|s[áa]bado|domingo/i.test(d)) fds += dias[d].o; if (!melhor || dias[d].o > dias[melhor].o) melhor = d; if (dias[d].r && dias[d].o) { var t = dias[d].r / dias[d].o; if (t > tktV) { tktV = t; tkt = d; } } }
    for (var hh in horas) if (!pico || horas[hh].o > horas[pico].o) pico = hh;
    box.innerHTML = chip + '<div class="kpi-grid">' +
      kpi('highlight', 'Melhor Dia', 'fa-star', melhor ? esc(melhor) : null, melhor ? int(dias[melhor].o) + ' pedidos' + (dias[melhor].r ? ' · ' + brl(dias[melhor].r) : '') : '') +
      kpi('blue', 'Melhor Ticket', 'fa-receipt', tkt ? esc(tkt) : null, tkt ? brl(tktV) + ' por pedido' : '') +
      kpi('cream', 'Horário de Pico', 'fa-clock', pico ? esc(pico) : null, pico ? int(horas[pico].o) + ' pedidos' : '') +
      kpi('deep', 'Concentração Sex–Dom', 'fa-fire', tot ? pct(fds / tot * 100) : null, tot ? int(fds) + ' de ' + int(tot) + ' pedidos' : '') + '</div>' +
      '<div class="grid-2"><div class="chart-card"><div class="chart-header"><div class="chart-title"><i class="fa-solid fa-calendar-week"></i> Pedidos por Dia da Semana</div></div>' +
      (temD ? '<div class="chart-container"><canvas id="m7compDia"></canvas></div>' : '<p class="chart-note" style="margin-top:6px">Sem dados de pedidos por dia em ' + esc(mesLbl(per)) + '.</p>') + '</div>' +
      '<div class="chart-card"><div class="chart-header"><div class="chart-title"><i class="fa-solid fa-clock"></i> Pedidos por Horário</div></div>' +
      (temH ? '<div class="chart-container"><canvas id="m7compHora"></canvas></div>' : '<p class="chart-note" style="margin-top:6px">Sem dados de pedidos por horário em ' + esc(mesLbl(per)) + '.</p>') + '</div></div>' +
      '<p class="chart-note">' + onde(REC.comp) + '</p>';
    if (typeof Chart === 'undefined') return;
    if (temD) {
      var ld = SEM.filter(function (x) { return dias[x]; }).concat(Object.keys(dias).filter(function (x) { return SEM.indexOf(x) < 0; }));
      charts.push(new Chart(document.getElementById('m7compDia'), { type: 'bar', data: { labels: ld, datasets: [{ label: 'Pedidos', data: ld.map(function (x) { return dias[x].o; }),
        backgroundColor: ld.map(function (x) { return /sexta|s[áa]bado|domingo/i.test(x) ? '#F98612' : '#9BAED9'; }), borderRadius: 6 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (q) { var x = dias[ld[q.dataIndex]]; return int(x.o) + ' pedidos' + (x.r ? ' · ' + brl(x.r) : ''); } } } }, scales: { x: AX, y: AX } } }));
    }
    if (temH) {
      var lh = Object.keys(horas).sort();
      charts.push(new Chart(document.getElementById('m7compHora'), { type: 'bar', data: { labels: lh, datasets: [{ label: 'Pedidos', data: lh.map(function (x) { return horas[x].o; }),
        backgroundColor: lh.map(function (x) { return x === pico ? '#F98612' : '#9BAED9'; }), borderRadius: 6 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: AX, y: AX } } }));
    }
  });

  function atualizar() { try { if (atABC) atABC(); if (atComp) atComp(); } catch (e) { console.error('m7-mensal', e); } }
  if (typeof window.render === 'function') {
    var orig = window.render;
    window.render = function () { var r = orig.apply(this, arguments); atualizar(); return r; };
  }
  var sel = document.getElementById('selPeriodo');
  if (sel) sel.addEventListener('change', function () { setTimeout(atualizar, 0); });
  document.addEventListener('click', function (e) { if (e.target && /Limpar/i.test(e.target.textContent || '') && e.target.closest('button')) setTimeout(atualizar, 0); }, true);
  atualizar();
})();
