/* =========================================================
   Meta Ads nos dashboards "completos" que ainda não tinham mídia no HTML
   (Burguin, Duana Centro). Lê window.M7_DADOS.meta — vindo de
   dashboards/<pasta>/dados.json (integração Meta Ads) — e preenche, na página
   "Marketing 360°" (p5): o card "Meta Ads" do período escolhido e o gráfico
   + tabela dos últimos 12 meses. Para usar em outro cliente basta incluir
   <script defer src="m7-meta-ads.js"></script> e ter o card com o ícone fa-meta.
   ========================================================= */
(function () {
  var MT = (window.M7_DADOS && window.M7_DADOS.meta) || {};
  var ids = Object.keys(MT).sort();
  if (!ids.length) return;

  var NOMES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  var curto = function (id) { var p = id.split('-'); return NOMES[+p[1] - 1] + '/' + p[0].slice(2); };
  var brl = function (v) { return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var int = function (v) { return Math.round(v || 0).toLocaleString('pt-BR'); };
  var dec = function (v) { return (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var antes = function (id, n) { var p = id.split('-'); var t = (+p[0]) * 12 + (+p[1] - 1) - n; var m = t % 12 + 1; return Math.floor(t / 12) + '-' + (m < 10 ? '0' : '') + m; };
  var temCompras = ids.some(function (m) { return MT[m].cmp > 0; });
  var wait = function (t) { return '<span class="wait">' + t + '</span>'; };

  var tbody = null, canvas = null, tabela = null, chart = null;

  function mesesDoPainel() {
    try { if (typeof MESES !== 'undefined' && MESES.length) return MESES.map(function (m) { return m.id; }); } catch (e) { /* sem MESES */ }
    return ids;
  }

  function somar(lista) {
    var o = { gas: 0, alc: 0, imp: 0, clk: 0, vpd: 0, cmp: 0, fat: 0, n: 0 };
    lista.forEach(function (id) { var m = MT[id]; if (!m) return; o.n++; for (var k in o) if (k !== 'n') o[k] += m[k] || 0; });
    return o;
  }

  function preencherCard(periodo) {
    if (!tbody) return;
    var full = periodo === 'full' || !periodo;
    var lista = full ? mesesDoPainel().filter(function (id) { return MT[id]; }) : (MT[periodo] ? [periodo] : []);
    var s = somar(lista);
    var linhas;
    if (!s.n) {
      var t = wait('Sem anúncios no mês');
      linhas = [['Investimento', t], ['Alcance', t], ['Cliques no Link', t], ['Visualizações Pág. Destino', t], ['CPC Médio', t]];
    } else {
      linhas = [
        ['Investimento', '<strong>' + brl(s.gas) + '</strong>'],
        [full && s.n > 1 ? 'Alcance (soma dos meses)' : 'Alcance', int(s.alc)],
        ['Impressões', int(s.imp)],
        ['Cliques no Link', int(s.clk)],
        ['Visualizações Pág. Destino', int(s.vpd)],
        ['CPC Médio', s.clk ? brl(s.gas / s.clk) : '—']
      ];
      if (temCompras) {
        linhas.push(['Compras atribuídas', int(s.cmp)]);
        linhas.push(['Custo por compra', s.cmp ? brl(s.gas / s.cmp) : '—']);
      }
    }
    linhas.push(['Seguidores', wait('Aguardando dados')]);
    tbody.innerHTML = linhas.map(function (l) { return '<tr><td>' + l[0] + '</td><td>' + l[1] + '</td></tr>'; }).join('');
  }

  function janela(periodo) {
    var fim = (periodo && periodo !== 'full') ? periodo : ids[ids.length - 1];
    var j = [];
    for (var i = 11; i >= 0; i--) j.push(antes(fim, i));
    while (j.length && !MT[j[0]] && j[0] < ids[0]) j.shift();   // não começa antes da 1ª campanha
    return j;
  }

  function preencherHistorico(periodo) {
    var jan = janela(periodo);
    if (tabela) {
      var cab = '<thead><tr><th>Mês</th><th>Investimento</th><th>Alcance</th><th>Cliques</th><th>CPC</th>' + (temCompras ? '<th>Compras</th><th>Custo/compra</th>' : '') + '</tr></thead>';
      var corpo = jan.slice().reverse().map(function (id) {
        var m = MT[id];
        if (!m) return '<tr><td>' + curto(id) + '</td><td colspan="' + (temCompras ? 6 : 4) + '">' + wait('Sem anúncios') + '</td></tr>';
        return '<tr><td>' + curto(id) + '</td><td>' + brl(m.gas) + '</td><td>' + int(m.alc) + '</td><td>' + int(m.clk) + '</td><td>' + (m.clk ? brl(m.gas / m.clk) : '—') + '</td>' +
          (temCompras ? '<td>' + int(m.cmp) + '</td><td>' + (m.cmp ? brl(m.gas / m.cmp) : '—') + '</td>' : '') + '</tr>';
      }).join('');
      tabela.innerHTML = cab + '<tbody>' + corpo + '</tbody>';
    }
    if (!canvas || typeof Chart === 'undefined') return;
    var dados = jan.map(function (id) { return MT[id] ? MT[id].gas : 0; });
    if (!chart) {
      chart = new Chart(canvas, {
        type: 'line',
        data: { labels: [], datasets: [{ label: 'Investimento', data: [], borderColor: '#F98612', backgroundColor: 'rgba(249,134,18,.14)', fill: true, tension: .35, pointBackgroundColor: '#F98612', pointRadius: 4, borderWidth: 2 }] },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: { callbacks: {
              label: function (c) { return 'Investimento: ' + brl(c.parsed.y); },
              afterLabel: function (c) {
                var m = MT[chart.$ids[c.dataIndex]]; if (!m) return 'Sem anúncios no mês';
                var l = ['Alcance: ' + int(m.alc), 'Cliques no link: ' + int(m.clk) + (m.clk ? ' · CPC ' + brl(m.gas / m.clk) : '')];
                if (temCompras) l.push('Compras: ' + int(m.cmp) + (m.cmp ? ' · custo/compra ' + brl(m.gas / m.cmp) : ''));
                return l;
              }
            } }
          },
          scales: {
            x: { grid: { color: 'rgba(155,174,217,.08)' }, ticks: { color: '#9BAED9' } },
            y: { beginAtZero: true, grid: { color: 'rgba(155,174,217,.08)' }, ticks: { color: '#9BAED9', callback: function (v) { return 'R$ ' + (v >= 1000 ? (v / 1000).toFixed(1).replace('.', ',') + 'k' : v); } } }
          }
        }
      });
    }
    chart.$ids = jan;
    chart.data.labels = jan.map(curto);
    chart.data.datasets[0].data = dados;
    chart.update();
  }

  function atualizar() {
    var sel = document.getElementById('selPeriodo');
    var p = sel ? sel.value : null;
    preencherCard(p);
    preencherHistorico(p);
  }

  function iniciar() {
    var pg = document.getElementById('p5');
    if (!pg) return;
    var cardMeta = null, cardGraf = null;
    Array.prototype.slice.call(pg.querySelectorAll('.chart-card')).forEach(function (c) {
      var t = c.querySelector('.chart-title');
      if (!cardMeta && c.querySelector('.fa-meta')) cardMeta = c;
      else if (t && /Meta Ads/i.test(t.textContent) && !c.querySelector('.fa-meta')) cardGraf = c;
    });
    if (!cardMeta) return;
    tbody = cardMeta.querySelector('tbody');
    var html = '<div class="chart-header"><div class="chart-title"><i class="fa-solid fa-chart-line"></i> Meta Ads · últimos 12 meses</div></div>' +
      '<div class="chart-container"><canvas></canvas></div>' +
      '<div style="overflow-x:auto;margin-top:16px"><table class="data-table"></table></div>' +
      '<p class="chart-note">Fonte: integração Meta Ads da Mesa7. Alcance é medido por mês (pessoas únicas) — no período completo ele aparece como soma dos meses.</p>';
    if (!cardGraf) { cardGraf = document.createElement('div'); cardGraf.className = 'chart-card'; pg.appendChild(cardGraf); }
    cardGraf.innerHTML = html;
    canvas = cardGraf.querySelector('canvas');
    tabela = cardGraf.querySelector('table');

    if (typeof window.render === 'function') {
      var orig = window.render;
      window.render = function () { var r = orig.apply(this, arguments); try { atualizar(); } catch (e) { /* não derruba a página */ } return r; };
    }
    var sel = document.getElementById('selPeriodo');
    if (sel) sel.addEventListener('change', function () { setTimeout(atualizar, 0); });
    atualizar();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
