/* =========================================================
   Ajustes de menu iguais para todos os dashboards (injetado pelo sistema):
   - esconde a página "Metas 30/60/90" (decisão da Mesa7, out/2026 — volta
     quando a equipe quiser: basta tirar OCULTAR abaixo);
   - cria a página "Promoções", que lê window.M7_DADOS.promocoes
     ({ "AAAA-MM": [{titulo, canal, periodo, descricao, resultado}] });
   - renumera o menu.
   Roda depois de todos os outros scripts (DOMContentLoaded).
   ========================================================= */
(function () {
  var OCULTAR = [/Metas\s*30/i];
  var ID = 'm7promo', TITULO = 'Promoções', SUB = 'Promoções e ações comerciais do mês: o que foi feito, em qual canal e o resultado.';

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var MES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  function mesLbl(id) { var p = id.split('-'); return MES[+p[1] - 1] + '/' + p[0]; }

  function renumerar(nav) {
    var n = 0;
    Array.prototype.slice.call(nav.querySelectorAll('.nav-item')).forEach(function (el) {
      if (el.style.display === 'none') return;
      n++;
      Array.prototype.slice.call(el.childNodes).forEach(function (t) {
        if (t.nodeType === 3) { var s = t.nodeValue.replace(/^\s*(\d+\.\s*)?/, ''); if (s.trim()) t.nodeValue = ' ' + n + '. ' + s; }
      });
    });
  }

  function idDaPagina(li) {
    var id = li.getAttribute('data-page');
    if (!id) { var m = /switchPage\('([^']+)'\)/.exec(li.getAttribute('onclick') || ''); id = m && m[1]; }
    return id;
  }

  function promocoes() {
    var P = (window.M7_DADOS && window.M7_DADOS.promocoes) || {};
    var meses = Object.keys(P).filter(function (k) { return P[k] && P[k].length; }).sort().reverse();
    if (!meses.length) {
      var vazio = ['Promoção do mês', 'Canal', 'Período', 'Resultado'].map(function (t) {
        return '<div class="kpi-card"><div class="kpi-header"><span class="kpi-label">' + t + '</span><i class="fa-solid fa-tag kpi-icon"></i></div><div class="kpi-value"><span class="wait" style="font-size:16px">Sem dados</span></div></div>';
      }).join('');
      return '<div class="kpi-grid">' + vazio + '</div>' +
        '<div class="chart-card"><div class="chart-title"><i class="fa-solid fa-tags"></i> Promoções do mês</div>' +
        '<p class="chart-note" style="margin-top:10px">Nenhuma promoção registrada ainda. A equipe Mesa7 vai registrar aqui cada ação: o que foi oferecido, em qual canal (salão, delivery, iFood, Instagram…), o período e o resultado.</p></div>';
    }
    return meses.map(function (m) {
      return '<div class="chart-card"><div class="chart-title"><i class="fa-solid fa-tags"></i> ' + esc(mesLbl(m)) + '</div><div style="overflow-x:auto"><table class="data-table"><thead><tr><th>Promoção</th><th>Canal</th><th>Período</th><th>Resultado</th></tr></thead><tbody>' +
        P[m].map(function (x) {
          return '<tr><td><strong>' + esc(x.titulo) + '</strong>' + (x.descricao ? '<div style="font-size:12px;color:var(--text-muted);margin-top:3px">' + esc(x.descricao) + '</div>' : '') + '</td><td>' + esc(x.canal || '—') + '</td><td>' + esc(x.periodo || '—') + '</td><td>' + (x.resultado ? esc(x.resultado) : '<span class="wait">Sem dados</span>') + '</td></tr>';
        }).join('') + '</tbody></table></div></div>';
    }).join('');
  }

  function iniciar() {
    var nav = document.querySelector('.nav-menu') || (document.querySelector('.nav-item') || {}).parentNode;
    var main = document.querySelector('main');
    if (!nav || !main || typeof window.switchPage !== 'function') return;

    // 1) esconde Metas 30/60/90
    var ativaEscondida = false;
    Array.prototype.slice.call(nav.querySelectorAll('.nav-item')).forEach(function (li) {
      if (!OCULTAR.some(function (re) { return re.test(li.textContent || ''); })) return;
      li.style.display = 'none';
      if (li.classList.contains('active')) ativaEscondida = true;
      var pg = document.getElementById(idDaPagina(li) || '');
      if (pg) { pg.style.display = 'none'; pg.classList.remove('active'); }
    });

    // 2) página Promoções
    if (!document.getElementById(ID)) {
      var li = document.createElement('li');
      li.className = 'nav-item';
      li.setAttribute('data-page', ID);
      li.innerHTML = '<i class="fa-solid fa-tags"></i> ' + TITULO;
      var datas = nav.querySelector('[data-page="pdatas"]');
      if (datas) nav.insertBefore(li, datas); else nav.appendChild(li);
      var pagina = document.createElement('div');
      pagina.id = ID;
      pagina.className = 'view-page';
      pagina.innerHTML = promocoes();
      main.appendChild(pagina);
      var tituloHtml = '<i class="fa-solid fa-tags" style="color:var(--m7-orange)"></i> ' + TITULO;
      try { if (typeof headings === 'object' && headings) headings[ID] = { t: tituloHtml, s: SUB }; } catch (e) { /* sem headings */ }
      var anterior = window.switchPage;
      window.switchPage = function (id) {
        var bar = document.querySelector('.filter-bar');
        if (bar && id !== ID) bar.style.display = '';
        try { anterior(id); } catch (e) { if (id !== ID) throw e; }
        if (id !== ID) { li.classList.remove('active'); return; }
        document.querySelectorAll('.view-page').forEach(function (p) { p.classList.toggle('active', p.id === ID); });
        document.querySelectorAll('.nav-item').forEach(function (i) { i.classList.toggle('active', i === li); });
        var h = document.getElementById('page-heading'), s = document.getElementById('page-subheading');
        if (h) h.innerHTML = tituloHtml;
        if (s) s.textContent = SUB;
        if (bar) bar.style.display = 'none';
        if (document.body.classList.contains('nav-open')) { document.body.classList.remove('nav-open'); var o = document.getElementById('overlay'); if (o) o.classList.remove('show'); }
        window.scrollTo(0, 0);
      };
      li.addEventListener('click', function (ev) { ev.stopPropagation(); window.switchPage(ID); });
    }

    renumerar(nav);
    if (ativaEscondida) { var p1 = nav.querySelector('.nav-item'); if (p1) p1.click(); }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
