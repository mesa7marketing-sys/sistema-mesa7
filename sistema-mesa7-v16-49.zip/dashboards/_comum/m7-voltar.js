/* =========================================================
   Mesa7 — botão "Voltar" em todos os dashboards
   Injetado automaticamente pelo Sistema Mesa7 em cada dashboard servido.
   - Volta para a página anterior do próprio dashboard (Resumo, CVR, ...).
   - Na visão da equipe (?m=equipe), se não há página anterior, volta
     para a lista de Dashboards do sistema.
   - Na visão do cliente (link sem senha), se não há página anterior,
     leva ao Resumo Executivo; no Resumo, o botão some.
   ========================================================= */
(function () {
  var equipe = /(?:^|[?&])m=equipe(?:&|$)/.test(location.search);
  var original = window.switchPage;
  if (typeof original !== 'function') return;

  var pilha = [];
  var atual = (document.querySelector('.view-page.active') || {}).id || 'p1';

  var css = document.createElement('style');
  css.textContent =
    '.m7-voltar{display:inline-flex;align-items:center;gap:7px;flex:0 0 auto;height:40px;padding:0 14px;' +
    'border-radius:10px;background:transparent;border:1px solid rgba(155,174,217,.32);color:#9BAED9;' +
    'font-family:Poppins,sans-serif;font-size:12.5px;font-weight:600;cursor:pointer;transition:all .18s ease;white-space:nowrap}' +
    '.m7-voltar:hover{border-color:#F98612;color:#F98612}' +
    '.m7-voltar[hidden]{display:none}' +
    '.m7-voltar svg{width:15px;height:15px}';
  document.head.appendChild(css);

  var btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'm7-voltar';
  btn.setAttribute('aria-label', 'Voltar');
  btn.innerHTML =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg><span>Voltar</span>';

  function atualizar() {
    btn.hidden = !equipe && pilha.length === 0 && atual === 'p1';
  }

  window.switchPage = function (id) {
    if (id !== atual) { pilha.push(atual); atual = id; }
    atualizar();
    return original.apply(this, arguments);
  };

  btn.addEventListener('click', function () {
    if (pilha.length) {
      atual = pilha.pop();
      original(atual);
    } else if (equipe) {
      try { window.top.location.href = '/dashboards'; } catch (e) { history.back(); }
      return;
    } else if (atual !== 'p1') {
      atual = 'p1';
      original('p1');
    }
    atualizar();
    window.scrollTo(0, 0);
  });

  function inserir() {
    var titulo = document.querySelector('header.top-bar .page-title');
    if (!titulo) return false;
    titulo.parentNode.insertBefore(btn, titulo);
    atualizar();
    return true;
  }
  if (!inserir()) document.addEventListener('DOMContentLoaded', inserir);
})();
