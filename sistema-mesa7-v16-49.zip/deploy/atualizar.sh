#!/usr/bin/env bash
# =========================================================
# Atualização automática do Sistema Mesa7 (roda pelo cron a cada 5 minutos).
# 1) Lista os arquivos do repositório no GitHub e pega o zip de versão mais alta
#    (sistema-mesa7-vXX-YY.zip), ignorando os da lista "ignorar" e a última que falhou.
# 2) Se for diferente da versão no ar: baixa, confere, faz backup, instala, builda e reinicia.
# 3) Se o build falhar: volta o backup, builda de novo e não tenta mais essa versão.
# Registro: /opt/sistema-mesa7-deploy/deploy.log (build completo em build.log).
# =========================================================
set -uo pipefail
D=${M7_DEPLOY_DIR:-/opt/sistema-mesa7-deploy}
. "$D/config"                       # REPO, RAMO, APP, API, BIN
export PATH="$BIN:$PATH"
exec 9>"$D/.lock"; flock -n 9 || exit 0
log() { echo "$(date '+%d/%m/%Y %H:%M:%S') $*" >> "$D/deploy.log"; }
H=(-H "X-GitHub-Api-Version: 2022-11-28")
[ -s "$D/token" ] && H+=(-H "Authorization: Bearer $(cat "$D/token")")

lista=$(curl -fsSL --max-time 30 "${H[@]}" "$API/repos/$REPO/contents/?ref=$RAMO") || exit 0
alvo=$(printf '%s' "$lista" | IGN="$D/ignorar" FAL="$D/falhou" node -e '
  const fs=require("fs"); const ler=f=>{try{return fs.readFileSync(f,"utf8").split("\n").map(s=>s.trim()).filter(Boolean)}catch(e){return []}};
  const fora=new Set([...ler(process.env.IGN),...ler(process.env.FAL)]);
  let l=[]; try{l=JSON.parse(fs.readFileSync(0,"utf8"))}catch(e){process.exit(0)}
  const v=l.filter(x=>x.type==="file"&&!fora.has(x.name)).map(x=>{const m=/^sistema-mesa7-v(\d+)-(\d+)\D*?(\d*)\D*\.zip$/i.exec(x.name);return m&&{x,k:[+m[1],+m[2],+(m[3]||0)]}}).filter(Boolean)
    .sort((a,b)=>b.k[0]-a.k[0]||b.k[1]-a.k[1]||b.k[2]-a.k[2]);
  if(v.length){const x=v[0].x;console.log([x.name,x.sha,x.size,x.download_url].join("\t"))}') || exit 0
[ -n "$alvo" ] || exit 0
IFS=$'\t' read -r nome sha tam url <<< "$alvo"
[ "$nome" = "$(cat "$D/versao" 2>/dev/null)" ] && exit 0

log "Nova versão: $nome — baixando"
T="$D/tmp"; rm -rf "$T"; mkdir -p "$T"
curl -fsSL --max-time 300 "${H[@]}" -o "$T/s.zip" "$url" || { log "ERRO: não consegui baixar $nome (tento de novo em 5 min)"; exit 1; }
conf=$( { printf 'blob %s\0' "$(stat -c%s "$T/s.zip")"; cat "$T/s.zip"; } | sha1sum | cut -d' ' -f1 )
[ "$conf" = "$sha" ] || { log "ERRO: o arquivo baixado veio diferente do GitHub (tento de novo em 5 min)"; exit 1; }
unzip -q "$T/s.zip" -d "$T/x" || { log "ERRO: zip corrompido"; echo "$nome" > "$D/falhou"; exit 1; }
[ -d "$T/x/src" ] && [ -d "$T/x/dashboards" ] || { log "ERRO: $nome não tem src/ e dashboards/ (não é um zip do sistema)"; echo "$nome" > "$D/falhou"; exit 1; }

# backup do que está no ar (código e dashboards)
( cd "$APP" && tar -czf "$D/backup.tgz" src public scripts dashboards .gitignore 2>/dev/null ) || true

# instala igual ao processo manual
cp -r "$T/x/src" "$T/x/public" "$T/x/scripts" "$APP/" && cp -r "$T/x/dashboards/." "$APP/dashboards/" && cp "$T/x/.gitignore" "$APP/"
[ -d "$T/x/deploy" ] && cp "$T/x/deploy/atualizar.sh" "$D/atualizar.sh.novo"
log "Instalado, buildando…"
if ( cd "$APP" && npm run build ) > "$D/build.log" 2>&1; then
  pm2 restart sistema-mesa7 >> "$D/build.log" 2>&1
  echo "$nome" > "$D/versao"; rm -f "$D/falhou"
  log "PRONTO: $nome no ar"
  # a própria rotina de atualização vem junto no zip: troca para a próxima execução
  if [ -s "$D/atualizar.sh.novo" ] && bash -n "$D/atualizar.sh.novo"; then mv "$D/atualizar.sh.novo" "$D/atualizar.sh"; chmod 700 "$D/atualizar.sh"; fi
else
  log "ERRO no build de $nome — voltando a versão anterior (detalhes em build-erro.log)"
  cp "$D/build.log" "$D/build-erro.log"; rm -f "$D/atualizar.sh.novo"
  echo "$nome" > "$D/falhou"
  ( cd "$APP" && rm -rf src public scripts && tar -xzf "$D/backup.tgz" ) && \
  ( cd "$APP" && npm run build ) >> "$D/build.log" 2>&1 && pm2 restart sistema-mesa7 >> "$D/build.log" 2>&1 \
    && log "Versão anterior restaurada ($(cat "$D/versao" 2>/dev/null || echo 'a que estava no ar'))" \
    || log "ATENÇÃO: falhou também ao restaurar — chamar o Claude com o build.log"
fi
rm -rf "$T"
