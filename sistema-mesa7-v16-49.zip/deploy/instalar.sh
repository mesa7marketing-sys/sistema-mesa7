#!/usr/bin/env bash
# Instala a atualização automática do Sistema Mesa7 na VPS (rodar uma vez, de dentro do zip descompactado).
# V = zip que deve entrar no ar agora; os outros zips que já estão no GitHub ficam ignorados.
# T (opcional) = token só de leitura, se o repositório ficar privado. Fica só em /opt/sistema-mesa7-deploy/token.
set -e
D=${M7_DEPLOY_DIR:-/opt/sistema-mesa7-deploy}
AQUI=$(cd "$(dirname "$0")" && pwd)
REPO=mesa7marketing-sys/sistema-mesa7
API=${M7_API:-https://api.github.com}
APP=${M7_APP:-/opt/sistema-mesa7}
mkdir -p "$D"; chmod 700 "$D"
NPM=$(command -v npm) || { echo "ERRO: npm não encontrado"; exit 1; }
PM2=$(command -v pm2) || { echo "ERRO: pm2 não encontrado"; exit 1; }
NODE=$(command -v node) || { echo "ERRO: node não encontrado"; exit 1; }
for c in flock unzip sha1sum curl crontab; do command -v $c >/dev/null || { echo "ERRO: falta o comando $c"; exit 1; }; done
cat > "$D/config" <<CFG
REPO=$REPO
RAMO=main
APP=$APP
API=$API
BIN=$(dirname "$NODE"):$(dirname "$NPM"):$(dirname "$PM2"):/usr/local/bin:/usr/bin:/bin
CFG
if [ -n "${T:-}" ]; then ( umask 077; printf '%s' "$T" > "$D/token" ); fi
cp "$AQUI/atualizar.sh" "$D/atualizar.sh"; chmod 700 "$D/atualizar.sh"
# zips antigos que já estão no GitHub não entram no ar sozinhos
H=(-H "X-GitHub-Api-Version: 2022-11-28"); [ -s "$D/token" ] && H+=(-H "Authorization: Bearer $(cat "$D/token")")
curl -fsSL "${H[@]}" "$API/repos/$REPO/contents/?ref=main" | node -e '
  const l=JSON.parse(require("fs").readFileSync(0,"utf8"));
  l.filter(x=>x.type==="file"&&/\.zip$/i.test(x.name)&&x.name!==process.env.V).forEach(x=>console.log(x.name));' > "$D/ignorar"
rm -f "$D/versao" "$D/falhou"
{ crontab -l 2>/dev/null | grep -v 'sistema-mesa7-deploy/atualizar.sh' || true; echo "*/5 * * * * $D/atualizar.sh"; } | crontab -
crontab -l | grep -q 'sistema-mesa7-deploy/atualizar.sh' || { echo "ERRO: não consegui agendar no cron"; exit 1; }
touch "$D/deploy.log"
echo "Instalado. A VPS confere o GitHub a cada 5 minutos ($(wc -l < "$D/ignorar") zips antigos ignorados)."
echo "Instalando agora ${V:-a versão mais nova}… acompanhe com: tail -5 $D/deploy.log"
nohup "$D/atualizar.sh" >/dev/null 2>&1 &
