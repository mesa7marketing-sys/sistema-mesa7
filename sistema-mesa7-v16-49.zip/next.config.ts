import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    // Upload de resultados dos clientes (tela /arquivos): até 25 MB por envio.
    serverActions: { bodySizeLimit: "30mb" },
    proxyClientMaxBodySize: "30mb",
  },
};

export default nextConfig;
