#!/usr/bin/env node
// Seguidores do Instagram de cada cliente, todo dia, para os dashboards.
//
//   node scripts/instagram-seguidores.mjs conectar <TOKEN>   (uma vez: guarda o acesso aos perfis)
//   node scripts/instagram-seguidores.mjs coletar             (todo dia, pelo cron)
//   node scripts/instagram-seguidores.mjs status              (mostra o que está ligado)
//
// <TOKEN> = token de usuário de longa duração do Meta (Graph API Explorer → "Estender token"),
// com as permissões instagram_basic, pages_show_list, pages_read_engagement, business_management
// e ads_read (esta última para o top 5 de anúncios, scripts/meta-anuncios.mjs).
// O "conectar" troca esse token pelos tokens das páginas do Facebook ligadas a cada Instagram,
// que não expiram, e guarda em .instagram-contas.json (fora do Git, só leitura do root).
//
// A coleta grava <ARQUIVOS_DIR>/<pasta>/_dados/instagram.json, um registro por mês:
//   { "2026-10": { "seg": 12345, "em": "2026-10-31", "ini": 12000, "ini_em": "2026-10-03" } }
// seg = última leitura do mês (fim do mês), ini = primeira leitura do mês.
// O Instagram só informa o número atual — o histórico começa no dia em que a coleta for ligada.
import { promises as fs } from "node:fs";
import path from "node:path";
import dotenv from "dotenv";

const RAIZ = process.cwd();
dotenv.config({ path: [path.join(RAIZ, ".env.local"), path.join(RAIZ, ".env")], quiet: true });

const VERSAO = process.env.META_GRAPH_VERSION || "v23.0";
const GRAPH = `https://graph.facebook.com/${VERSAO}`;
const ARQ_CONTAS = process.env.INSTAGRAM_CONTAS || path.join(RAIZ, ".instagram-contas.json");
const ARQ_PERFIS = path.join(RAIZ, "scripts", "instagram-perfis.json");
const ARQ_ACESSO = process.env.META_ACESSO || path.join(RAIZ, ".meta-acesso.json");
const ARQUIVOS = process.env.ARQUIVOS_DIR || path.resolve(RAIZ, "..", "sistema-mesa7-arquivos");

const hoje = () => new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" }).format(new Date()); // AAAA-MM-DD

async function lerJson(arq, padrao) {
  try { return JSON.parse(await fs.readFile(arq, "utf8")); } catch { return padrao; }
}

async function graph(caminho, params) {
  const u = new URL(caminho.startsWith("http") ? caminho : GRAPH + caminho);
  for (const [k, v] of Object.entries(params || {})) u.searchParams.set(k, v);
  const r = await fetch(u);
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) throw new Error(j.error ? `${j.error.message} (código ${j.error.code})` : `HTTP ${r.status}`);
  return j;
}

async function todasAsPaginas(caminho, params) {
  const itens = [];
  let j = await graph(caminho, params);
  for (;;) {
    itens.push(...(j.data || []));
    if (!j.paging || !j.paging.next) break;
    j = await graph(j.paging.next);
  }
  return itens;
}

const CAMPOS_PAGINA = "id,name,access_token,instagram_business_account{id,username,followers_count}";

async function conectar(token) {
  if (!token) throw new Error("Falta o token. Uso: node scripts/instagram-seguidores.mjs conectar <TOKEN>");
  const paginas = new Map();
  const juntar = (lista) => lista.forEach((p) => { if (p.access_token && p.instagram_business_account) paginas.set(p.id, p); });
  // páginas em que a pessoa tem função direta
  juntar(await todasAsPaginas("/me/accounts", { fields: CAMPOS_PAGINA, limit: "100", access_token: token }));
  // páginas que chegam pelos Business Managers (próprias e de clientes)
  try {
    const bms = await todasAsPaginas("/me/businesses", { fields: "id,name", limit: "100", access_token: token });
    for (const bm of bms) {
      for (const borda of ["owned_pages", "client_pages"]) {
        try { juntar(await todasAsPaginas(`/${bm.id}/${borda}`, { fields: CAMPOS_PAGINA, limit: "100", access_token: token })); }
        catch { /* sem permissão nesse BM: segue */ }
      }
    }
  } catch { /* token sem business_management: fica só com /me/accounts */ }

  const contas = [...paginas.values()].map((p) => ({
    pagina: p.name, pagina_id: p.id, token: p.access_token,
    ig_id: p.instagram_business_account.id, usuario: (p.instagram_business_account.username || "").toLowerCase(),
  }));
  if (!contas.length) throw new Error("Nenhum Instagram profissional encontrado com esse token. Confira as permissões.");
  await fs.writeFile(ARQ_CONTAS, JSON.stringify({ conectado_em: new Date().toISOString(), contas }, null, 2), { mode: 0o600 });
  await fs.chmod(ARQ_CONTAS, 0o600).catch(() => {});
  // o mesmo token serve para o top 5 de anúncios (scripts/meta-anuncios.mjs), se tiver ads_read
  await fs.writeFile(ARQ_ACESSO, JSON.stringify({ token, guardado_em: new Date().toISOString() }, null, 2), { mode: 0o600 });
  await fs.chmod(ARQ_ACESSO, 0o600).catch(() => {});
  console.log(`Conectado: ${contas.length} perfil(is) do Instagram.`);
  await status();
}

async function status() {
  const perfis = await lerJson(ARQ_PERFIS, {});
  const { contas = [], conectado_em } = await lerJson(ARQ_CONTAS, {});
  console.log(conectado_em ? `Acesso guardado em ${conectado_em.slice(0, 10)}.` : "Ainda não conectado (rode o 'conectar').");
  for (const [pasta, usuario] of Object.entries(perfis)) {
    if (pasta.startsWith("_")) continue;
    if (!usuario) { console.log(`  ${pasta}: sem perfil definido em scripts/instagram-perfis.json`); continue; }
    const ok = contas.some((c) => c.usuario === usuario.toLowerCase());
    console.log(`  ${pasta}: @${usuario} ${ok ? "OK" : "— sem acesso (a página do Facebook dele não veio no token)"}`);
  }
}

async function coletar() {
  const perfis = await lerJson(ARQ_PERFIS, {});
  const { contas = [] } = await lerJson(ARQ_CONTAS, {});
  if (!contas.length) throw new Error("Ainda não conectado. Rode: node scripts/instagram-seguidores.mjs conectar <TOKEN>");
  const dia = hoje(), mes = dia.slice(0, 7);
  let ok = 0, falhas = 0;
  for (const [pasta, usuario] of Object.entries(perfis)) {
    if (pasta.startsWith("_") || !usuario) continue;
    const conta = contas.find((c) => c.usuario === usuario.toLowerCase());
    if (!conta) { console.log(`${pasta}: @${usuario} sem acesso`); falhas++; continue; }
    try {
      const j = await graph(`/${conta.ig_id}`, { fields: "followers_count,username", access_token: conta.token });
      const arq = path.join(ARQUIVOS, pasta, "_dados", "instagram.json");
      const dados = await lerJson(arq, {});
      const atual = dados[mes] || {};
      dados[mes] = {
        seg: j.followers_count, em: dia,
        ini: atual.ini ?? j.followers_count, ini_em: atual.ini_em ?? dia,
      };
      await fs.mkdir(path.dirname(arq), { recursive: true });
      await fs.writeFile(arq, JSON.stringify(dados, null, 2));
      console.log(`${pasta}: @${j.username} ${j.followers_count} seguidores`);
      ok++;
    } catch (e) {
      console.log(`${pasta}: @${usuario} erro — ${e.message}`);
      falhas++;
    }
  }
  console.log(`${dia}: ${ok} ok, ${falhas} com problema.`);
  if (!ok && falhas) process.exitCode = 1;
}

const [cmd, arg] = process.argv.slice(2);
const acoes = { conectar: () => conectar(arg), coletar, status };
if (!acoes[cmd]) {
  console.log("Uso: node scripts/instagram-seguidores.mjs conectar <TOKEN> | coletar | status");
  process.exit(1);
}
acoes[cmd]().catch((e) => { console.error("Erro:", e.message); process.exit(1); });
