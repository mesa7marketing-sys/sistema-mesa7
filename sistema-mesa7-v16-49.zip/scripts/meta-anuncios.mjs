#!/usr/bin/env node
// Top 5 anúncios do mês de cada cliente (Meta Ads), com miniatura, para a página Marketing 360°.
//
//   node scripts/meta-anuncios.mjs coletar            (todo dia, pelo cron: mês passado + mês atual)
//   node scripts/meta-anuncios.mjs coletar 2026-09    (um mês específico)
//
// Usa o token guardado pelo "conectar" do scripts/instagram-seguidores.mjs (.meta-acesso.json),
// que precisa da permissão ads_read. As contas de cada cliente ficam em scripts/meta-contas.json.
//
// Regra do ranking (definida pelo Lucas, out/2026):
//  - só entram anúncios que investiram pelo menos a média por anúncio da conta no mês
//    (média calculada sobre os anúncios com R$ 5 ou mais);
//  - ordem pelo menor custo por resultado, comparado à média da conta para o mesmo tipo de
//    resultado (custo por visita ao cardápio, por compra, por conversa…);
//  - sem ROAS.
// Grava <ARQUIVOS_DIR>/<pasta>/_dados/anuncios.json e as miniaturas anuncio-AAAA-MM-N.jpg.
import { promises as fs } from "node:fs";
import path from "node:path";
import dotenv from "dotenv";

const RAIZ = process.cwd();
dotenv.config({ path: [path.join(RAIZ, ".env.local"), path.join(RAIZ, ".env")], quiet: true });

const VERSAO = process.env.META_GRAPH_VERSION || "v23.0";
const GRAPH = `https://graph.facebook.com/${VERSAO}`;
const ARQ_ACESSO = process.env.META_ACESSO || path.join(RAIZ, ".meta-acesso.json");
const ARQ_CONTAS = path.join(RAIZ, "scripts", "meta-contas.json");
const ARQUIVOS = process.env.ARQUIVOS_DIR || path.resolve(RAIZ, "..", "sistema-mesa7-arquivos");

async function lerJson(arq, padrao) {
  try { return JSON.parse(await fs.readFile(arq, "utf8")); } catch { return padrao; }
}

async function graph(caminho, params, token) {
  const u = new URL(caminho.startsWith("http") ? caminho : GRAPH + caminho);
  for (const [k, v] of Object.entries(params || {})) u.searchParams.set(k, typeof v === "string" ? v : JSON.stringify(v));
  if (token && !u.searchParams.has("access_token")) u.searchParams.set("access_token", token);
  const r = await fetch(u);
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) throw new Error(j.error ? `${j.error.message} (código ${j.error.code})` : `HTTP ${r.status}`);
  return j;
}

async function todas(caminho, params, token) {
  const itens = [];
  let j = await graph(caminho, params, token);
  for (;;) {
    itens.push(...(j.data || []));
    if (!j.paging || !j.paging.next) break;
    j = await graph(j.paging.next);
  }
  return itens;
}

// indicador do Meta → código usado no dashboard
function tipoDe(indicador) {
  const s = String(indicador || "");
  if (/landing_page_view/.test(s)) return "LPV";
  if (/purchase/.test(s)) return "PUR";
  if (/initiate_checkout/.test(s)) return "CHK";
  if (/messaging_conversation_started/.test(s)) return "MSG";
  if (/profile_visit/.test(s)) return "PRF";
  if (/link_click/.test(s)) return "LNK";
  if (/post_interaction/.test(s)) return "INT";
  if (/post_engagement/.test(s)) return "ENG";
  if (/^reach$/.test(s)) return "RCH";
  return null;
}

// quando o "results" não vem, deduz pelo objetivo da campanha
const PELO_OBJETIVO = {
  OUTCOME_SALES: ["offsite_conversion.fb_pixel_purchase", "omni_purchase"],
  CONVERSIONS: ["offsite_conversion.fb_pixel_purchase", "omni_purchase"],
  OUTCOME_TRAFFIC: ["landing_page_view", "link_click"],
  LINK_CLICKS: ["landing_page_view", "link_click"],
  OUTCOME_ENGAGEMENT: ["onsite_conversion.messaging_conversation_started_7d", "post_engagement"],
  MESSAGES: ["onsite_conversion.messaging_conversation_started_7d"],
  POST_ENGAGEMENT: ["post_engagement"],
};

function resultadoDe(l) {
  const r = Array.isArray(l.results) ? l.results[0] : null;
  if (r) {
    const v = Number((r.values && r.values[0] && r.values[0].value) || 0);
    const tipo = tipoDe(String(r.indicator || "").replace(/^actions:/, ""));
    if (tipo === "RCH") return { tipo, res: Number(l.reach || 0) };
    if (tipo) return { tipo, res: v };
  }
  if (["OUTCOME_AWARENESS", "REACH", "BRAND_AWARENESS"].includes(l.objective)) return { tipo: "RCH", res: Number(l.reach || 0) };
  for (const at of PELO_OBJETIVO[l.objective] || []) {
    const a = (l.actions || []).find((x) => x.action_type === at);
    if (a) return { tipo: tipoDe(at), res: Number(a.value) };
  }
  return null;
}

/** Mesma regra do ranking usado na carga inicial (ver cabeçalho). */
export function ranquear(ads) {
  const lista = ads.filter((a) => a.gas >= 5 && a.tipo);
  if (!lista.length) return { minimo: 0, top: [] };
  const minimo = lista.reduce((s, a) => s + a.gas, 0) / lista.length;
  const porTipo = {};
  for (const a of lista) { const t = (porTipo[a.tipo] ||= [0, 0]); t[0] += a.gas; t[1] += a.res; }
  const mil = (t) => (t === "RCH" ? 1000 : 1);
  for (const a of lista) {
    const [g, r] = porTipo[a.tipo];
    a.custo = a.res ? (a.gas / a.res) * mil(a.tipo) : null;
    a.media = r ? (g / r) * mil(a.tipo) : null;
    a.indice = a.custo && a.media ? a.custo / a.media : null;
  }
  const ok = lista.filter((a) => a.gas >= minimo && a.indice != null);
  ok.sort((x, y) => x.indice - y.indice || y.gas - x.gas);
  return { minimo: Math.round(minimo * 100) / 100, top: ok.slice(0, 5) };
}

async function anunciosDaConta(c, mes, token) {
  const [y, m] = mes.split("-").map(Number);
  const fim = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
  const ontem = new Date(Date.now() - 864e5 - 3 * 36e5).toISOString().slice(0, 10); // horário de Brasília
  const ate = fim < ontem ? fim : ontem;
  const params = (comResults) => ({
    level: "ad",
    time_range: { since: `${mes}-01`, until: ate },
    fields: "ad_id,ad_name,campaign_name,objective,spend,reach,inline_link_clicks,actions" + (comResults ? ",results" : ""),
    filtering: [{ field: "ad.effective_status", operator: "IN", value: ["ACTIVE", "PAUSED", "DELETED", "ARCHIVED", "CAMPAIGN_PAUSED", "ADSET_PAUSED", "WITH_ISSUES", "DISAPPROVED", "IN_PROCESS"] }],
    limit: "500",
  });
  let linhas;
  try {
    linhas = await todas(`/act_${c.conta}/insights`, params(true), token);
  } catch (e) {
    // versões da API sem o campo "results": deduz o resultado pelo objetivo da campanha
    if (!/results/i.test(e.message)) throw e;
    linhas = await todas(`/act_${c.conta}/insights`, params(false), token);
  }
  return {
    ate,
    ads: linhas
      .filter((l) => (!c.campanha_contem || (l.campaign_name || "").includes(c.campanha_contem)) &&
                     (!c.campanha_nao_contem || !(l.campaign_name || "").includes(c.campanha_nao_contem)))
      .map((l) => {
        const r = resultadoDe(l);
        return { id: l.ad_id, nome: l.ad_name, gas: Number(l.spend || 0), alc: Number(l.reach || 0), clk: Number(l.inline_link_clicks || 0), tipo: r && r.tipo, res: r ? r.res : 0 };
      }),
  };
}

async function baixarMiniatura(adId, destino, token) {
  try {
    const ad = await graph(`/${adId}`, { fields: "creative{id}" }, token);
    const cr = await graph(`/${ad.creative.id}`, { fields: "image_url,thumbnail_url", thumbnail_width: "480", thumbnail_height: "480" }, token);
    const url = cr.image_url || cr.thumbnail_url;
    if (!url) return false;
    const r = await fetch(url);
    if (!r.ok) return false;
    let buf = Buffer.from(await r.arrayBuffer());
    try {
      const { default: sharp } = await import("sharp");
      buf = await sharp(buf).resize(240, 240, { fit: "cover" }).jpeg({ quality: 82 }).toBuffer();
    } catch { /* sem sharp: guarda como veio */ }
    await fs.writeFile(destino, buf);
    return true;
  } catch {
    return false;
  }
}

const ymd = (d) => d.toISOString().slice(0, 7);

async function coletar(mesPedido) {
  const { token } = await lerJson(ARQ_ACESSO, {});
  if (!token) throw new Error("Sem token. Rode antes: node scripts/instagram-seguidores.mjs conectar <TOKEN> (com ads_read).");
  const contas = await lerJson(ARQ_CONTAS, {});
  const agora = new Date(Date.now() - 3 * 36e5);
  const meses = mesPedido ? [mesPedido] : [ymd(new Date(Date.UTC(agora.getUTCFullYear(), agora.getUTCMonth() - 1, 1))), ymd(agora)];
  let ok = 0, falhas = 0;
  for (const [pasta, lista] of Object.entries(contas)) {
    if (pasta.startsWith("_")) continue;
    const dir = path.join(ARQUIVOS, pasta, "_dados");
    const arq = path.join(dir, "anuncios.json");
    const dados = await lerJson(arq, {});
    for (const mes of meses) {
      if (mes === ymd(agora) && agora.getUTCDate() === 1) continue; // dia 1: mês atual ainda vazio
      try {
        const ads = [];
        let ate = null;
        for (const c of lista) { const r = await anunciosDaConta(c, mes, token); ads.push(...r.ads); ate = r.ate; }
        const { minimo, top } = ranquear(ads);
        await fs.mkdir(dir, { recursive: true });
        const saida = [];
        for (let i = 0; i < top.length; i++) {
          const a = top[i];
          const nomeImg = `anuncio-${mes}-${i + 1}.jpg`;
          const temImg = await baixarMiniatura(a.id, path.join(dir, nomeImg), token);
          saida.push({ nome: a.nome, gas: a.gas, alc: a.alc, clk: a.clk, res: a.res, tipo: a.tipo,
            custo: Math.round(a.custo * 100) / 100, media: Math.round(a.media * 100) / 100, ...(temImg ? { img: nomeImg } : {}) });
        }
        const fimMes = new Date(Date.UTC(+mes.slice(0, 4), +mes.slice(5, 7), 0)).toISOString().slice(0, 10);
        dados[mes] = { minimo, top: saida, ...(ate && ate < fimMes ? { ate } : {}) };
        console.log(`${pasta} ${mes}: ${saida.length} anúncio(s), mínimo R$ ${minimo}`);
        ok++;
      } catch (e) {
        console.log(`${pasta} ${mes}: erro — ${e.message}`);
        falhas++;
      }
    }
    await fs.mkdir(dir, { recursive: true });
    await fs.writeFile(arq, JSON.stringify(dados, null, 2));
  }
  console.log(`${ok} ok, ${falhas} com problema.`);
  if (!ok && falhas) process.exitCode = 1;
}

const [cmd, arg] = process.argv.slice(2);
if (cmd === "coletar") coletar(arg && /^\d{4}-\d{2}$/.test(arg) ? arg : null).catch((e) => { console.error("Erro:", e.message); process.exit(1); });
else if (import.meta.url === `file://${process.argv[1]}`) { console.log("Uso: node scripts/meta-anuncios.mjs coletar [AAAA-MM]"); process.exit(1); }
