import Link from "next/link";
import { requireSession } from "@/lib/access";
import { db } from "@/db";
import { clients, clientHealth, actionItems } from "@/db/schema";
import { eq, ne, asc } from "drizzle-orm";
import { PageHead, KpiCard, SectionCard } from "@/components/ui";
import { FarolBadge } from "@/components/farol-badge";
import { DASHBOARDS } from "@/lib/dashboards";
import { listarArquivos } from "@/lib/arquivos";

export const dynamic = "force-dynamic";

// Painel de Customer Success: saúde da carteira inteira numa tela só.
// Tudo vem de dados que o sistema já tem — Farol do Cliente (ClickUp, tabela
// client_health), Plano de Ação (action_items) e os envios de resultados em
// Arquivos. Uso interno da equipe (login de cliente é redirecionado no layout).

type Tom = "good" | "warn" | "bad" | "muted";

const ROTULOS: Record<string, { label: string; tom: Tom }> = {
  // risco de churn
  baixo: { label: "Baixo", tom: "good" },
  medio: { label: "Médio", tom: "warn" },
  alto: { label: "Alto", tom: "bad" },
  // percepção de resultado
  bom: { label: "Bom", tom: "good" },
  atencao: { label: "Atenção", tom: "warn" },
  risco: { label: "Risco", tom: "bad" },
  // percepção de faturamento
  percebe: { label: "Percebe", tom: "good" },
  percebe_pouco: { label: "Percebe pouco", tom: "warn" },
  nao_percebe: { label: "Não percebe", tom: "bad" },
  // performance por canal
  excelente: { label: "Excelente", tom: "good" },
  boa: { label: "Boa", tom: "good" },
  media: { label: "Média", tom: "warn" },
  neutro: { label: "Neutro", tom: "warn" },
  ruim: { label: "Ruim", tom: "bad" },
  negativo: { label: "Negativo", tom: "bad" },
};

const COR: Record<Tom, string> = {
  good: "var(--status-good)",
  warn: "var(--status-warning)",
  bad: "var(--status-critical)",
  muted: "var(--text-muted)",
};

function Status({ valor }: { valor: string | null | undefined }) {
  const r = valor ? ROTULOS[valor] : null;
  if (!r) return <span style={{ color: "var(--text-muted)" }}>—</span>;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 5, color: COR[r.tom], fontWeight: 700 }}>
      <span aria-hidden style={{ width: 6, height: 6, borderRadius: "50%", background: COR[r.tom] }} />
      {r.label}
    </span>
  );
}

const CANAIS = [
  ["ifood", "iFood"],
  ["trafego", "Tráfego"],
  ["repediu", "RePediu"],
  ["social", "Social"],
] as const;

function Canais({ l }: { l: Pick<Linha, (typeof CANAIS)[number][0]> }) {
  const preenchidos = CANAIS.filter(([k]) => l[k]);
  if (preenchidos.length === 0) return <span style={{ color: "var(--text-muted)" }}>—</span>;
  return (
    <span style={{ display: "flex", flexDirection: "column", gap: 3 }}>
      {preenchidos.map(([k, nome]) => (
        <span key={k}>
          <span style={{ color: "var(--text-muted)" }}>{nome}: </span>
          <Status valor={l[k]} />
        </span>
      ))}
    </span>
  );
}

const SAUDE_ORDEM = ["excelente", "boa", "media", "ruim"] as const;
const SAUDE_LABEL: Record<string, string> = { excelente: "Excelente", boa: "Boa", media: "Média", ruim: "Ruim" };
const SAUDE_COR: Record<string, string> = {
  excelente: "var(--status-good)",
  boa: "var(--status-good)",
  media: "var(--status-warning)",
  ruim: "var(--status-critical)",
};

/** Data (ISO) de 30 dias atrás: envio de resultados mais antigo que isso fica em alerta. */
function limiteEnvio() {
  return new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
}

function dataCurta(iso: string | Date | null | undefined) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", timeZone: "America/Sao_Paulo" });
}

type Linha = {
  chave: string;
  nome: string;
  href: string;
  saude: string | null;
  risco: string | null;
  percResultado: string | null;
  percFaturamento: string | null;
  ifood: string | null;
  trafego: string | null;
  repediu: string | null;
  social: string | null;
  temFarol: boolean;
  farolEm: Date | null;
  acoesAbertas: number;
  acoesAtrasadas: number;
  arquivosPendentes: number;
  ultimoEnvio: string | null;
  envioVelho: boolean;
  motivos: string[];
  pontos: number;
};

export default async function CSPage() {
  await requireSession();

  const [listaClientes, farois, acoes, arquivos] = await Promise.all([
    db.select().from(clients).where(eq(clients.active, true)).orderBy(asc(clients.name)),
    db.select().from(clientHealth),
    db
      .select({ clientId: actionItems.clientId, status: actionItems.status, dueDate: actionItems.dueDate })
      .from(actionItems)
      .where(ne(actionItems.status, "concluido")),
    listarArquivos(),
  ]);

  const farolPorCliente = new Map(farois.map((f) => [f.clientId, f]));
  const hoje = new Date().toISOString().slice(0, 10);
  const limite = limiteEnvio();

  const acoesPorCliente = new Map<string, { abertas: number; atrasadas: number }>();
  for (const a of acoes) {
    const c = acoesPorCliente.get(a.clientId) ?? { abertas: 0, atrasadas: 0 };
    c.abertas++;
    if (a.status === "atrasado" || (a.dueDate && a.dueDate < hoje)) c.atrasadas++;
    acoesPorCliente.set(a.clientId, c);
  }

  const envioPorPasta = new Map<string, { pendentes: number; ultimo: string | null }>();
  for (const a of arquivos) {
    const e = envioPorPasta.get(a.pasta) ?? { pendentes: 0, ultimo: null };
    if (a.status === "pendente") e.pendentes++;
    if (!e.ultimo || a.enviadoEm > e.ultimo) e.ultimo = a.enviadoEm;
    envioPorPasta.set(a.pasta, e);
  }

  // Carteira = clientes ativos do sistema + dashboards que ainda não têm cliente
  // cadastrado (o slug do cliente é o nome da pasta do dashboard).
  const linhas: Linha[] = [];
  const slugs = new Set<string>();
  const montar = (chave: string, nome: string, href: string, clientId: string | null) => {
    const f = clientId ? farolPorCliente.get(clientId) : undefined;
    const ac = (clientId && acoesPorCliente.get(clientId)) || { abertas: 0, atrasadas: 0 };
    const env = envioPorPasta.get(chave) ?? { pendentes: 0, ultimo: null };
    const motivos: string[] = [];
    let pontos = 0;
    const alerta = (cond: boolean, motivo: string, peso: number) => {
      if (!cond) return;
      motivos.push(motivo);
      pontos += peso;
    };
    alerta(f?.riscoChurn === "alto", "Risco de churn alto", 5);
    alerta(f?.saudeConta === "ruim", "Saúde da conta ruim", 4);
    alerta(f?.percepcaoResultado === "risco", "Percepção de resultado em risco", 3);
    alerta(f?.percepcaoFaturamento === "nao_percebe", "Não percebe aumento de faturamento", 2);
    alerta(f?.riscoChurn === "medio", "Risco de churn médio", 2);
    alerta(f?.saudeConta === "media", "Saúde da conta média", 1);
    alerta(ac.atrasadas > 0, `${ac.atrasadas} ação(ões) atrasada(s)`, 1);
    linhas.push({
      chave,
      nome,
      href,
      saude: f?.saudeConta ?? null,
      risco: f?.riscoChurn ?? null,
      percResultado: f?.percepcaoResultado ?? null,
      percFaturamento: f?.percepcaoFaturamento ?? null,
      ifood: f?.performanceIfood ?? null,
      trafego: f?.performanceTrafego ?? null,
      repediu: f?.performanceRepediu ?? null,
      social: f?.performanceSocialMedia ?? null,
      temFarol: !!f && !!(f.saudeConta || f.riscoChurn || f.percepcaoResultado || f.percepcaoFaturamento),
      farolEm: f?.syncedAt ?? null,
      acoesAbertas: ac.abertas,
      acoesAtrasadas: ac.atrasadas,
      arquivosPendentes: env.pendentes,
      ultimoEnvio: env.ultimo,
      envioVelho: !env.ultimo || env.ultimo < limite,
      motivos,
      pontos,
    });
  };
  for (const c of listaClientes) {
    slugs.add(c.slug);
    montar(c.slug, c.name, `/c/${c.slug}/resumo`, c.id);
  }
  for (const d of DASHBOARDS) {
    if (!slugs.has(d.pasta)) montar(d.pasta, d.nome, `/dashboards/${d.pasta}`, null);
  }

  linhas.sort((a, b) => b.pontos - a.pontos || a.nome.localeCompare(b.nome, "pt-BR"));

  const total = linhas.length;
  const comFarol = linhas.filter((l) => l.temFarol).length;
  const churnAlto = linhas.filter((l) => l.risco === "alto").length;
  const atencao = linhas.filter((l) => l.pontos >= 3);
  const acoesAbertas = linhas.reduce((s, l) => s + l.acoesAbertas, 0);
  const acoesAtrasadas = linhas.reduce((s, l) => s + l.acoesAtrasadas, 0);
  const arquivosPendentes = linhas.reduce((s, l) => s + l.arquivosPendentes, 0);
  const semEnvio30 = linhas.filter((l) => l.envioVelho);
  const farolMaisAntigo = farois.reduce<Date | null>((m, f) => (!m || f.syncedAt < m ? f.syncedAt : m), null);

  const contagemSaude = SAUDE_ORDEM.map((s) => ({ s, n: linhas.filter((l) => l.saude === s).length }));
  const semSaude = total - contagemSaude.reduce((s, c) => s + c.n, 0);

  const th: React.CSSProperties = {
    textAlign: "left",
    fontSize: 10.5,
    textTransform: "uppercase",
    letterSpacing: "0.06em",
    color: "var(--text-muted)",
    fontWeight: 800,
    padding: "0 8px 10px",
    borderBottom: "1px solid var(--border-strong)",
    whiteSpace: "nowrap",
  };
  const td: React.CSSProperties = { padding: "10px 8px", fontSize: 12.5, whiteSpace: "nowrap", color: "var(--text-secondary)" };

  return (
    <div style={{ padding: "40px", maxWidth: 1240 }}>
      <PageHead
        kicker="Time"
        title="Customer Success"
        description="Saúde da carteira, risco de churn, pendências e atualização dos resultados de cada cliente — tudo numa tela, ordenado por quem precisa de atenção primeiro."
      />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))",
          gap: 12,
          marginBottom: 22,
        }}
      >
        <KpiCard icon="store" label="Clientes na carteira" value={String(total)} caption={`${comFarol} com Farol preenchido`} />
        <KpiCard
          icon="target"
          label="Risco de churn alto"
          value={String(churnAlto)}
          deltaLabel={churnAlto > 0 ? "Agir esta semana" : "Nenhum"}
          deltaTone={churnAlto > 0 ? "bad" : "good"}
        />
        <KpiCard
          icon="megaphone"
          accent="accent-2"
          label="Precisam de atenção"
          value={String(atencao.length)}
          caption="Churn, saúde ou percepção em alerta"
        />
        <KpiCard
          icon="layers"
          accent="accent-2"
          label="Ações em aberto"
          value={String(acoesAbertas)}
          deltaLabel={acoesAtrasadas > 0 ? `${acoesAtrasadas} atrasada${acoesAtrasadas === 1 ? "" : "s"}` : undefined}
          deltaTone="bad"
          caption="Plano de Ação de todos os clientes"
        />
        <KpiCard
          icon="upload"
          label="Arquivos a lançar"
          value={String(arquivosPendentes)}
          caption={`${semEnvio30.length} cliente${semEnvio30.length === 1 ? "" : "s"} sem envio há 30+ dias`}
        />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))", gap: 14 }}>
        <SectionCard
          icon="chart"
          title="Saúde da conta"
          subtitle={`Farol do Cliente (ClickUp)${farolMaisAntigo ? ` · sincronizado desde ${dataCurta(farolMaisAntigo)}` : ""}`}
        >
          <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
            {[...contagemSaude, { s: "sem", n: semSaude }].map(({ s, n }) => (
              <div key={s} style={{ display: "grid", gridTemplateColumns: "92px 1fr 28px", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 12.5, color: "var(--text-secondary)", fontWeight: 700 }}>
                  {SAUDE_LABEL[s] ?? "Sem farol"}
                </span>
                <div style={{ background: "var(--surface-2)", borderRadius: 4, height: 10, overflow: "hidden" }}>
                  <div
                    style={{
                      width: total ? `${(n / total) * 100}%` : 0,
                      height: "100%",
                      background: SAUDE_COR[s] ?? "var(--border-strong)",
                      borderRadius: 4,
                    }}
                  />
                </div>
                <span className="num" style={{ fontSize: 13, fontWeight: 700, textAlign: "right" }}>
                  {n}
                </span>
              </div>
            ))}
          </div>
          {comFarol < total && (
            <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 12 }}>
              {total - comFarol} cliente{total - comFarol === 1 ? "" : "s"} ainda sem Farol — preencher no ClickUp (lista
              Clientes Ativos) para entrar no painel.
            </div>
          )}
        </SectionCard>

        <SectionCard icon="target" accent="var(--status-critical)" title="Prioridade de atenção" subtitle="Quem o CS deve procurar primeiro">
          {atencao.length === 0 ? (
            <div style={{ fontSize: 13, color: "var(--text-muted)" }}>Nenhum cliente em alerta no Farol. 👏</div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column" }}>
              {atencao.slice(0, 8).map((l, i) => (
                <Link
                  key={l.chave}
                  href={l.href}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: 10,
                    padding: "9px 0",
                    borderBottom: i < Math.min(atencao.length, 8) - 1 ? "1px solid var(--border)" : "none",
                    textDecoration: "none",
                  }}
                >
                  <span style={{ minWidth: 0 }}>
                    <span style={{ display: "block", fontWeight: 700, fontSize: 13.5, color: "var(--text-primary)" }}>{l.nome}</span>
                    <span style={{ display: "block", fontSize: 11.5, color: "var(--text-muted)", marginTop: 2 }}>
                      {l.motivos.join(" · ")}
                    </span>
                  </span>
                  <FarolBadge saudeConta={l.saude} />
                </Link>
              ))}
            </div>
          )}
        </SectionCard>
      </div>

      <SectionCard icon="grid" title="Carteira completa" subtitle="Ordenada por prioridade · clique no nome para abrir o cliente">
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <th style={th}>Cliente</th>
                <th style={th}>Saúde</th>
                <th style={th}>Churn</th>
                <th style={th}>Percepção resultado</th>
                <th style={th}>Percebe faturamento</th>
                <th style={th}>Performance por canal</th>
                <th style={{ ...th, textAlign: "right" }}>Ações abertas</th>
                <th style={{ ...th, textAlign: "right" }}>A lançar</th>
                <th style={{ ...th, textAlign: "right" }}>Último envio</th>
              </tr>
            </thead>
            <tbody>
              {linhas.map((l, i) => {
                const velho = l.envioVelho;
                return (
                  <tr key={l.chave} style={{ borderBottom: i < linhas.length - 1 ? "1px solid var(--border)" : "none" }}>
                    <td style={{ ...td, fontWeight: 700 }}>
                      <Link href={l.href} style={{ color: "var(--text-primary)", textDecoration: "none" }}>
                        {l.nome}
                      </Link>
                    </td>
                    <td style={td}>
                      <FarolBadge saudeConta={l.saude} />
                    </td>
                    <td style={td}><Status valor={l.risco} /></td>
                    <td style={td}><Status valor={l.percResultado} /></td>
                    <td style={td}><Status valor={l.percFaturamento} /></td>
                    <td style={{ ...td, whiteSpace: "normal", minWidth: 150 }}>
                      <Canais l={l} />
                    </td>
                    <td className="num" style={{ ...td, textAlign: "right" }}>
                      {l.acoesAbertas}
                      {l.acoesAtrasadas > 0 && (
                        <span style={{ color: "var(--status-critical)", fontWeight: 700 }}> ({l.acoesAtrasadas} atras.)</span>
                      )}
                    </td>
                    <td className="num" style={{ ...td, textAlign: "right" }}>
                      {l.arquivosPendentes > 0 ? (
                        <Link
                          href={`/arquivos?cliente=${l.chave}&status=pendente`}
                          style={{ color: "var(--status-warning)", fontWeight: 700, textDecoration: "none" }}
                        >
                          {l.arquivosPendentes}
                        </Link>
                      ) : (
                        0
                      )}
                    </td>
                    <td
                      className="num"
                      style={{ ...td, textAlign: "right", color: velho ? "var(--status-warning)" : td.color, fontWeight: velho ? 700 : 400 }}
                    >
                      {l.ultimoEnvio ? dataCurta(l.ultimoEnvio) : "Nunca"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 12, lineHeight: 1.5 }}>
          Farol: ClickUp → Clientes Ativos. Ações: Plano de Ação de cada cliente (não concluídas; atrasada = status
          “Atrasado” ou prazo vencido). Último envio: data do último arquivo em Subir resultados — em laranja quando passa
          de 30 dias.
        </div>
      </SectionCard>
    </div>
  );
}
