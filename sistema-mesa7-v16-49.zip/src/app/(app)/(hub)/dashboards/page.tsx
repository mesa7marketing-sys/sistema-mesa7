import Link from "next/link";
import { requireSession } from "@/lib/access";
import { PageHead } from "@/components/ui";
import { DASHBOARDS } from "@/lib/dashboards";
import { CopiarLinkDashboard } from "@/components/CopiarLinkDashboard";
import { listarArquivos } from "@/lib/arquivos";

export const dynamic = "force-dynamic";

// Área de Dashboards: todos os dashboards de cliente no padrão Mesa7.
// Só equipe chega aqui (login de cliente é redirecionado no layout do hub).
export default async function DashboardsPage() {
  await requireSession();

  const ordenados = [...DASHBOARDS].sort(
    (a, b) => (a.status === b.status ? a.nome.localeCompare(b.nome, "pt-BR") : a.status === "completo" ? -1 : 1),
  );
  const pendentesPorCliente = new Map<string, number>();
  for (const a of await listarArquivos()) {
    if (a.status === "pendente") pendentesPorCliente.set(a.pasta, (pendentesPorCliente.get(a.pasta) ?? 0) + 1);
  }

  return (
    <div style={{ padding: "40px", maxWidth: 1120 }}>
      <PageHead
        kicker="Clientes"
        title="Dashboards"
        description={`${DASHBOARDS.length} dashboards no padrão Mesa7, todos com dados. Clique para abrir; use "Copiar link do cliente" para mandar o acesso sem senha.`}
      />

      <Link
        href="/arquivos"
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 8,
          background: "var(--accent)",
          color: "var(--accent-ink)",
          borderRadius: 10,
          padding: "10px 18px",
          fontSize: 14,
          fontWeight: 800,
          textDecoration: "none",
        }}
      >
        ↑ Subir resultados dos clientes
      </Link>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
          gap: 12,
          marginTop: 24,
        }}
      >
        {ordenados.map((d) => (
          <div
            key={d.pasta}
            style={{
              background: "var(--surface)",
              border: "1px solid var(--border)",
              borderRadius: 14,
              padding: 16,
              display: "flex",
              flexDirection: "column",
              gap: 12,
            }}
          >
            <Link href={`/dashboards/${d.pasta}`} style={{ textDecoration: "none", color: "inherit" }}>
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8 }}>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 15, color: "var(--text-primary)" }}>{d.nome}</div>
                  <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 2 }}>{d.segmento}</div>
                </div>
                <span
                  style={{
                    flex: "none",
                    fontSize: 10,
                    fontWeight: 800,
                    textTransform: "uppercase",
                    letterSpacing: "0.05em",
                    borderRadius: 99,
                    padding: "3px 8px",
                    color: "var(--status-good)",
                    background: "var(--status-good-bg)",
                    border: "1px solid var(--border-strong)",
                  }}
                >
                  Com dados
                </span>
              </div>
            </Link>
            {(pendentesPorCliente.get(d.pasta) ?? 0) > 0 && (
              <Link
                href={`/arquivos?cliente=${d.pasta}&status=pendente`}
                style={{ fontSize: 12, fontWeight: 700, color: "var(--status-warning)", textDecoration: "none" }}
              >
                ● {pendentesPorCliente.get(d.pasta)} arquivo{pendentesPorCliente.get(d.pasta) === 1 ? "" : "s"} pendente
                {pendentesPorCliente.get(d.pasta) === 1 ? "" : "s"} de lançar
              </Link>
            )}
            <div style={{ display: "flex", gap: 8, marginTop: "auto", flexWrap: "wrap" }}>
              <Link
                href={`/dashboards/${d.pasta}`}
                style={{
                  flex: 1,
                  textAlign: "center",
                  background: "var(--accent)",
                  color: "var(--accent-ink)",
                  borderRadius: 9,
                  padding: "7px 10px",
                  fontSize: 12.5,
                  fontWeight: 800,
                  textDecoration: "none",
                }}
              >
                Abrir
              </Link>
              <Link
                href={`/arquivos?cliente=${d.pasta}`}
                title="Subir PDF, CSV, planilha ou print com resultados deste cliente"
                style={{
                  border: "1px solid var(--border-strong)",
                  color: "var(--text-secondary)",
                  borderRadius: 9,
                  padding: "6px 10px",
                  fontSize: 12,
                  fontWeight: 700,
                  textDecoration: "none",
                  whiteSpace: "nowrap",
                }}
              >
                ↑ Subir arquivo
              </Link>
              <CopiarLinkDashboard token={d.token} compacto />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
