import Link from "next/link";
import { requireSession } from "@/lib/access";
import { PageHead } from "@/components/ui";
import { DASHBOARDS } from "@/lib/dashboards";
import { calendarioDoCliente, type ItemCalendario } from "@/lib/datas-cliente";
import { hojeSP } from "@/lib/datas-comemorativas";

export const dynamic = "force-dynamic";

const MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
const SEMANA = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];
const diaMes = (iso: string) => `${iso.slice(8, 10)}/${iso.slice(5, 7)}`;
const diaSemana = (iso: string) => SEMANA[new Date(`${iso}T12:00:00Z`).getUTCDay()];
const quando = (iso?: string) =>
  iso
    ? new Intl.DateTimeFormat("pt-BR", { timeZone: "America/Sao_Paulo", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(iso))
    : "";

// Datas comemorativas escolhidas pelos clientes (no dashboard de cada um).
// Para a equipe montar o calendário individual e o geral de conteúdo/campanhas.
export default async function DatasClientesPage() {
  await requireSession();
  const hoje = hojeSP();

  const clientes = (
    await Promise.all(
      DASHBOARDS.filter((d) => d.datas).map(async (d) => ({ d, ...(await calendarioDoCliente(d.pasta, hoje)) })),
    )
  ).sort((a, b) => a.d.nome.localeCompare(b.d.nome, "pt-BR"));

  const responderam = clientes.filter((c) => c.sel.atualizadoEm);

  // Calendário geral: data+nome -> clientes que escolheram.
  type Linha = { chave: string; data: string; nome: string; cat: string; propria: boolean; clientes: string[] };
  const mapa = new Map<string, Linha>();
  for (const c of clientes) {
    for (const i of c.itens as ItemCalendario[]) {
      const chave = i.propria ? `${i.data}|p|${i.nome.toLowerCase()}` : i.id;
      const l = mapa.get(chave) ?? { chave, data: i.data, nome: i.nome, cat: i.cat, propria: i.propria, clientes: [] };
      l.clientes.push(c.d.nome);
      mapa.set(chave, l);
    }
  }
  const linhas = [...mapa.values()].sort((a, b) => a.data.localeCompare(b.data) || a.nome.localeCompare(b.nome, "pt-BR"));
  const porMes = new Map<string, Linha[]>();
  for (const l of linhas) porMes.set(l.data.slice(0, 7), [...(porMes.get(l.data.slice(0, 7)) ?? []), l]);

  const card: React.CSSProperties = { background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, padding: 16 };
  const chip: React.CSSProperties = {
    fontSize: 11.5,
    fontWeight: 700,
    color: "var(--text-secondary)",
    background: "var(--surface-2)",
    border: "1px solid var(--border-strong)",
    borderRadius: 99,
    padding: "3px 9px",
    whiteSpace: "nowrap",
  };

  return (
    <div style={{ padding: "40px", maxWidth: 1120 }}>
      <PageHead
        kicker="Clientes"
        title="Datas dos clientes"
        description={`${responderam.length} de ${clientes.length} clientes já escolheram as datas. Cada cliente marca no próprio dashboard (página 8); aqui ficam as escolhas de todos para montar o calendário de conteúdo e campanhas.`}
      />

      <h2 style={{ fontSize: 17, fontWeight: 800, margin: "28px 0 12px" }}>Calendário geral</h2>
      {linhas.length === 0 ? (
        <div style={{ ...card, color: "var(--text-muted)", fontSize: 14 }}>
          Nenhum cliente escolheu datas ainda. Assim que alguém salvar no dashboard, aparece aqui.
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {[...porMes.entries()].map(([mes, itens]) => (
            <div key={mes} style={card}>
              <div style={{ fontSize: 11.5, textTransform: "uppercase", letterSpacing: "0.1em", color: "var(--text-muted)", fontWeight: 800, marginBottom: 10 }}>
                {MESES[Number(mes.slice(5)) - 1]} · {mes.slice(0, 4)}
              </div>
              {itens.map((l) => (
                <div key={l.chave} style={{ display: "flex", gap: 14, alignItems: "flex-start", padding: "9px 0", borderTop: "1px solid var(--border)", flexWrap: "wrap" }}>
                  <div style={{ flex: "0 0 62px", fontWeight: 800, fontSize: 14 }}>
                    {diaMes(l.data)}
                    <div style={{ fontSize: 11, fontWeight: 500, color: "var(--text-muted)" }}>{diaSemana(l.data)}</div>
                  </div>
                  <div style={{ flex: "1 1 200px", minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{l.nome}</div>
                    <div style={{ fontSize: 11.5, color: "var(--text-muted)" }}>{l.propria ? "Data da casa" : l.cat}</div>
                  </div>
                  <div style={{ flex: "2 1 260px", display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {l.clientes.map((n) => (
                      <span key={n} style={chip}>{n}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      <h2 style={{ fontSize: 17, fontWeight: 800, margin: "32px 0 12px" }}>Por cliente</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
        {clientes.map(({ d, sel, itens }) => (
          <div key={d.pasta} style={{ ...card, display: "flex", flexDirection: "column", gap: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 15 }}>{d.nome}</div>
                <div style={{ fontSize: 12, color: sel.atualizadoEm ? "var(--status-good)" : "var(--status-warning)", fontWeight: 700, marginTop: 2 }}>
                  {sel.atualizadoEm ? `✓ ${itens.length} data${itens.length === 1 ? "" : "s"} · ${quando(sel.atualizadoEm)} por ${sel.atualizadoPor ?? "Cliente"}` : "● Ainda não escolheu"}
                </div>
              </div>
              <Link href={`/dashboards/${d.pasta}`} style={{ fontSize: 12, fontWeight: 700, color: "var(--accent)", textDecoration: "none", whiteSpace: "nowrap" }}>
                Abrir dashboard
              </Link>
            </div>
            {itens.length > 0 && (
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {itens.map((i) => (
                  <span key={`${i.id}${i.data}`} style={chip} title={i.propria ? "Data da casa" : i.cat}>
                    {diaMes(i.data)} · {i.nome}
                  </span>
                ))}
              </div>
            )}
            {sel.obs && (
              <div style={{ fontSize: 13, color: "var(--text-secondary)", background: "var(--surface-2)", borderRadius: 9, padding: "9px 11px", whiteSpace: "pre-wrap" }}>
                <b style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--text-muted)" }}>Recado</b>
                <br />
                {sel.obs}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
