"use server";

import { revalidatePath } from "next/cache";
import { requireAdmin, requireSession } from "@/lib/access";
import { FUNCOES, alterarMembro, criarMembro, novaSenha, trocarPropriaSenha, type RoleEquipe } from "@/lib/equipe";

export type EstadoEquipe = { ok: boolean; mensagem: string; senha?: string; para?: string } | null;

function roleValida(v: FormDataEntryValue | null): RoleEquipe | null {
  const r = String(v || "");
  return FUNCOES.some((f) => f.role === r) ? (r as RoleEquipe) : null;
}

export async function acaoEquipe(_prev: EstadoEquipe, fd: FormData): Promise<EstadoEquipe> {
  const session = await requireAdmin();
  const acao = String(fd.get("acao") || "");
  const id = String(fd.get("id") || "");
  const nome = String(fd.get("nome") || "").trim();
  try {
    if (acao === "criar") {
      const email = String(fd.get("email") || "").trim();
      const role = roleValida(fd.get("role"));
      if (!nome) return { ok: false, mensagem: "Informe o nome." };
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false, mensagem: "E-mail inválido." };
      if (!role) return { ok: false, mensagem: "Escolha a função." };
      const senha = await criarMembro({ nome, email, role });
      revalidatePath("/equipe");
      return { ok: true, mensagem: `Login de ${nome} criado (${email.toLowerCase()}).`, senha, para: nome };
    }
    if (acao === "senha") {
      const senha = await novaSenha(id);
      return { ok: true, mensagem: `Nova senha gerada para ${nome}. A senha antiga deixou de funcionar.`, senha, para: nome };
    }
    if (acao === "funcao") {
      const role = roleValida(fd.get("role"));
      if (!role) return { ok: false, mensagem: "Função inválida." };
      await alterarMembro(id, { role }, session.user.id);
      revalidatePath("/equipe");
      return { ok: true, mensagem: `Função de ${nome} atualizada.` };
    }
    if (acao === "desativar" || acao === "reativar") {
      await alterarMembro(id, { active: acao === "reativar" }, session.user.id);
      revalidatePath("/equipe");
      return {
        ok: true,
        mensagem: acao === "reativar" ? `${nome} voltou a ter acesso.` : `${nome} não consegue mais entrar no sistema.`,
      };
    }
    return { ok: false, mensagem: "Ação desconhecida." };
  } catch (e) {
    return { ok: false, mensagem: e instanceof Error ? e.message : "Não deu certo. Tente de novo." };
  }
}

export async function acaoMinhaSenha(_prev: EstadoEquipe, fd: FormData): Promise<EstadoEquipe> {
  const session = await requireSession();
  const atual = String(fd.get("atual") || "");
  const nova = String(fd.get("nova") || "");
  const confirma = String(fd.get("confirma") || "");
  if (nova !== confirma) return { ok: false, mensagem: "A confirmação não bate com a nova senha." };
  try {
    await trocarPropriaSenha(session.user.id, atual, nova);
    return { ok: true, mensagem: "Senha trocada. Use a nova no próximo login." };
  } catch (e) {
    return { ok: false, mensagem: e instanceof Error ? e.message : "Não deu certo. Tente de novo." };
  }
}
