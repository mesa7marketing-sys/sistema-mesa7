import { requireAdmin } from "@/lib/access";
import { PageHead } from "@/components/ui";
import { FUNCOES, listarEquipe } from "@/lib/equipe";
import { PainelEquipe } from "@/components/PainelEquipe";

export const dynamic = "force-dynamic";

// Logins da equipe Mesa7 — só administração vê esta tela.
export default async function EquipePage() {
  const session = await requireAdmin();
  const equipe = await listarEquipe();
  const membros = equipe
    .sort((a, b) => Number(b.active) - Number(a.active) || a.name.localeCompare(b.name, "pt-BR"))
    .map((u) => ({ id: u.id, nome: u.name, email: u.email, role: u.role, ativo: u.active, voce: u.id === session.user.id }));

  return (
    <div style={{ padding: "40px", maxWidth: 1000 }}>
      <PageHead
        kicker="Administração"
        title="Equipe"
        description="Crie o login de quem entra na Mesa7, gere uma senha nova quando alguém esquecer e desative quem saiu. Cada pessoa troca a própria senha em Minha senha, no rodapé do menu."
      />
      <PainelEquipe membros={membros} funcoes={FUNCOES} />
    </div>
  );
}
