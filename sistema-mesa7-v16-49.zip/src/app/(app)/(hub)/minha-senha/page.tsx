import { requireSession } from "@/lib/access";
import { PageHead } from "@/components/ui";
import { FormMinhaSenha } from "@/components/FormMinhaSenha";

export default async function MinhaSenhaPage() {
  const session = await requireSession();
  return (
    <div style={{ padding: "40px", maxWidth: 700 }}>
      <PageHead
        kicker={session.user.email ?? "Sua conta"}
        title="Minha senha"
        description="Troque a senha que você recebeu por uma sua. Ninguém da equipe consegue ver a senha que você escolher."
      />
      <FormMinhaSenha />
    </div>
  );
}
