"use server";

import { redirect } from "next/navigation";
import { dashboardPorToken } from "@/lib/dashboards";
import { gravarAcesso, senhaConfere } from "@/lib/acesso-cliente";

export type EstadoSenha = { erro: string } | null;

// Pequena pausa em toda tentativa: deixa chute em massa lento sem incomodar quem digita.
const pausa = () => new Promise((r) => setTimeout(r, 600));

export async function entrarComSenha(_prev: EstadoSenha, fd: FormData): Promise<EstadoSenha> {
  const token = String(fd.get("token") || "");
  const senha = String(fd.get("senha") || "");
  const d = dashboardPorToken(token);
  await pausa();
  if (!d) return { erro: "Link inválido." };
  if (!senhaConfere(senha)) return { erro: "Senha incorreta. Confira com a equipe da Mesa7." };
  await gravarAcesso();
  redirect(`/d/${d.token}`);
}
