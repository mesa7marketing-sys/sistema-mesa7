import { signOut } from "@/auth";

// Encerra a sessão (usado quando um login é desativado na tela Equipe).
export async function GET(req: Request) {
  const desativado = new URL(req.url).searchParams.has("desativado");
  await signOut({ redirectTo: desativado ? "/login?desativado=1" : "/login" });
}
