"use client";

import { useState } from "react";

/** Copia o link sem senha do dashboard (/d/<token>) para mandar ao cliente. */
export function CopiarLinkDashboard({ token, compacto }: { token: string; compacto?: boolean }) {
  const [copiado, setCopiado] = useState(false);

  async function copiar() {
    const url = `${window.location.origin}/d/${token}`;
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      window.prompt("Copie o link do cliente:", url);
    }
    setCopiado(true);
    setTimeout(() => setCopiado(false), 2200);
  }

  return (
    <button
      type="button"
      onClick={copiar}
      style={{
        background: copiado ? "var(--accent-soft)" : "transparent",
        color: copiado ? "var(--accent)" : "var(--text-secondary)",
        border: `1px solid ${copiado ? "rgba(249,115,22,0.45)" : "var(--border-strong)"}`,
        borderRadius: 9,
        padding: compacto ? "6px 10px" : "8px 14px",
        fontSize: compacto ? 12 : 13,
        fontWeight: 700,
        cursor: "pointer",
        fontFamily: "inherit",
        whiteSpace: "nowrap",
      }}
    >
      {copiado ? "Link copiado ✓" : "Copiar link do cliente"}
    </button>
  );
}
