"use client";

import { useActionState } from "react";
import { acaoMinhaSenha, type EstadoEquipe } from "@/app/(app)/(hub)/equipe/actions";

const campo: React.CSSProperties = {
  background: "var(--surface-2)",
  border: "1px solid var(--border-strong)",
  borderRadius: 9,
  padding: "10px 12px",
  color: "var(--text-primary)",
  fontSize: 14,
  fontFamily: "inherit",
};
const rotulo: React.CSSProperties = { display: "flex", flexDirection: "column", gap: 6, fontSize: 12, fontWeight: 700, color: "var(--text-secondary)" };

export function FormMinhaSenha() {
  const [estado, acao, rodando] = useActionState<EstadoEquipe, FormData>(acaoMinhaSenha, null);
  return (
    <form key={estado?.ok ? "ok" : "form"} action={acao} style={{ display: "flex", flexDirection: "column", gap: 14, maxWidth: 380 }}>
      <label style={rotulo}>
        Senha atual
        <input name="atual" type="password" required autoComplete="current-password" style={campo} />
      </label>
      <label style={rotulo}>
        Nova senha (mínimo 8 caracteres)
        <input name="nova" type="password" required minLength={8} autoComplete="new-password" style={campo} />
      </label>
      <label style={rotulo}>
        Repita a nova senha
        <input name="confirma" type="password" required minLength={8} autoComplete="new-password" style={campo} />
      </label>
      <button
        type="submit"
        disabled={rodando}
        style={{
          background: "var(--accent)",
          color: "var(--accent-ink)",
          border: "none",
          borderRadius: 9,
          padding: "11px 18px",
          fontWeight: 800,
          fontSize: 14,
          cursor: "pointer",
          fontFamily: "inherit",
          alignSelf: "flex-start",
          opacity: rodando ? 0.6 : 1,
        }}
      >
        Trocar senha
      </button>
      {estado && (
        <div role="status" style={{ fontSize: 13, fontWeight: 700, color: estado.ok ? "var(--status-good)" : "var(--status-critical)" }}>
          {estado.ok ? "✓ " : ""}
          {estado.mensagem}
        </div>
      )}
    </form>
  );
}
