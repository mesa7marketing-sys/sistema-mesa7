"use client";

import { useActionState } from "react";
import { entrarComSenha, type EstadoSenha } from "@/app/d/[token]/actions";

export function FormSenhaCliente({ token, nome }: { token: string; nome: string }) {
  const [estado, enviar, enviando] = useActionState<EstadoSenha, FormData>(entrarComSenha, null);
  return (
    <main style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: "#000", padding: 16, fontFamily: "Poppins, system-ui, sans-serif" }}>
      <form
        action={enviar}
        style={{ width: "100%", maxWidth: 360, background: "#0b0b0e", border: "1px solid rgba(155,174,217,.18)", borderRadius: 18, padding: "32px 26px", color: "#f4f2ea" }}
      >
        <img src="/marca/mesa7-logo.png" alt="Mesa7" style={{ height: 38, display: "block", marginBottom: 22 }} />
        <h1 style={{ fontFamily: "Quicksand, Poppins, sans-serif", fontSize: 21, fontWeight: 700, margin: "0 0 6px" }}>Dashboard {nome}</h1>
        <p style={{ color: "#9baed9", fontSize: 13.5, margin: "0 0 20px" }}>Digite a senha de acesso enviada pela Mesa7.</p>
        <input type="hidden" name="token" value={token} />
        <label htmlFor="senha" style={{ fontSize: 12, fontWeight: 700, letterSpacing: ".08em", textTransform: "uppercase", color: "#9baed9" }}>Senha</label>
        <input
          id="senha" name="senha" type="password" required autoFocus autoComplete="current-password"
          style={{ width: "100%", marginTop: 8, padding: "12px 14px", borderRadius: 12, border: "1px solid rgba(155,174,217,.32)", background: "#000", color: "#f4f2ea", fontSize: 15 }}
        />
        {estado?.erro && <p role="alert" style={{ color: "#ff8a7a", fontSize: 13, margin: "10px 0 0" }}>{estado.erro}</p>}
        <button
          type="submit" disabled={enviando}
          style={{ width: "100%", marginTop: 18, padding: "12px 14px", borderRadius: 12, border: 0, background: "#f98612", color: "#0b0b0e", fontWeight: 800, fontSize: 15, cursor: "pointer", opacity: enviando ? 0.6 : 1 }}
        >
          {enviando ? "Entrando…" : "Entrar"}
        </button>
      </form>
    </main>
  );
}
