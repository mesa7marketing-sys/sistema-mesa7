// Logo da Mesa7 (wordmark off-white sobre preto) com a legenda em laranja.
export function LogoMesa7({ legenda = "Intelligence", largura = 118 }: { legenda?: string; largura?: number }) {
  return (
    <div style={{ padding: "2px 8px 4px" }}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/marca/mesa7-logo.png"
        alt="Mesa7"
        width={largura}
        height={Math.round((largura * 209) / 640)}
        style={{ display: "block" }}
      />
      <div
        style={{
          marginTop: 7,
          fontSize: 9.5,
          fontWeight: 700,
          letterSpacing: "0.28em",
          textTransform: "uppercase",
          color: "var(--accent)",
        }}
      >
        {legenda}
      </div>
    </div>
  );
}
