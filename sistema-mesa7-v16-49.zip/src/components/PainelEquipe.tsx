"use client";

import { useActionState, useState } from "react";
import { acaoEquipe, type EstadoEquipe } from "@/app/(app)/(hub)/equipe/actions";

type Membro = { id: string; nome: string; email: string; role: string; ativo: boolean; voce: boolean };
type Funcao = { role: string; label: string };

const campo: React.CSSProperties = {
  background: "var(--surface-2)",
  border: "1px solid var(--border-strong)",
  borderRadius: 9,
  padding: "9px 11px",
  color: "var(--text-primary)",
  fontSize: 14,
  fontFamily: "inherit",
  width: "100%",
};
const rotulo: React.CSSProperties = { display: "flex", flexDirection: "column", gap: 6, fontSize: 12, fontWeight: 700, color: "var(--text-secondary)" };
const botao: React.CSSProperties = {
  background: "transparent",
  border: "1px solid var(--border-strong)",
  borderRadius: 8,
  padding: "6px 10px",
  fontSize: 12,
  fontWeight: 700,
  color: "var(--text-secondary)",
  cursor: "pointer",
  fontFamily: "inherit",
  whiteSpace: "nowrap",
};

function SenhaGerada({ estado }: { estado: EstadoEquipe }) {
  const [copiado, setCopiado] = useState(false);
  if (!estado?.senha) return null;
  return (
    <div
      role="status"
      style={{
        background: "var(--accent-soft)",
        border: "1px solid rgba(249,115,22,0.45)",
        borderRadius: 12,
        padding: "14px 16px",
        display: "flex",
        flexWrap: "wrap",
        alignItems: "center",
        gap: 12,
        marginBottom: 16,
      }}
    >
      <div style={{ flex: "1 1 260px" }}>
        <div style={{ fontSize: 13, fontWeight: 700 }}>{estado.mensagem}</div>
        <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 4 }}>
          Senha de {estado.para}: mande para a pessoa agora. Ela não aparece de novo; se perder, é só gerar outra.
        </div>
      </div>
      <code
        style={{
          fontSize: 18,
          fontWeight: 800,
          letterSpacing: "0.04em",
          background: "var(--surface-2)",
          border: "1px solid var(--border-strong)",
          borderRadius: 9,
          padding: "8px 12px",
        }}
      >
        {estado.senha}
      </code>
      <button
        type="button"
        style={{ ...botao, color: "var(--accent)", borderColor: "rgba(249,115,22,0.45)" }}
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(estado.senha!);
          } catch {
            window.prompt("Copie a senha:", estado.senha);
          }
          setCopiado(true);
        }}
      >
        {copiado ? "Copiada ✓" : "Copiar senha"}
      </button>
    </div>
  );
}

export function PainelEquipe({ membros, funcoes }: { membros: Membro[]; funcoes: Funcao[] }) {
  const [estado, acao, rodando] = useActionState<EstadoEquipe, FormData>(acaoEquipe, null);
  const labelDe = (r: string) => funcoes.find((f) => f.role === r)?.label ?? r;

  return (
    <div>
      <SenhaGerada estado={estado} />
      {estado && !estado.senha && (
        <div
          role="status"
          style={{
            fontSize: 13,
            fontWeight: 700,
            marginBottom: 14,
            color: estado.ok ? "var(--status-good)" : "var(--status-critical)",
          }}
        >
          {estado.ok ? "✓ " : ""}
          {estado.mensagem}
        </div>
      )}

      <div
        style={{
          background: "var(--surface)",
          border: "1px solid var(--border)",
          borderRadius: 16,
          padding: "18px 20px",
          marginBottom: 14,
        }}
      >
        <div style={{ fontSize: 14.5, fontWeight: 800, marginBottom: 12 }}>Adicionar pessoa</div>
        <form action={acao} style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12, alignItems: "end" }}>
          <input type="hidden" name="acao" value="criar" />
          <label style={rotulo}>
            Nome
            <input name="nome" required placeholder="Ex.: Larissa" style={campo} />
          </label>
          <label style={rotulo}>
            E-mail de login
            <input name="email" type="email" required placeholder="larissa@mesa7.com" style={campo} />
          </label>
          <label style={rotulo}>
            Função
            <select name="role" required defaultValue="" style={campo}>
              <option value="" disabled>
                Escolha…
              </option>
              {funcoes.map((f) => (
                <option key={f.role} value={f.role}>
                  {f.label}
                </option>
              ))}
            </select>
          </label>
          <button
            type="submit"
            disabled={rodando}
            style={{
              background: "var(--accent)",
              color: "var(--accent-ink)",
              border: "none",
              borderRadius: 9,
              padding: "11px 18px",
              fontWeight: 800,
              fontSize: 14,
              cursor: "pointer",
              fontFamily: "inherit",
              opacity: rodando ? 0.6 : 1,
            }}
          >
            Criar login
          </button>
        </form>
      </div>

      <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 16, padding: "18px 20px" }}>
        <div style={{ fontSize: 14.5, fontWeight: 800, marginBottom: 4 }}>Quem tem acesso</div>
        <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 12 }}>
          Desativar corta o acesso na hora, sem apagar o histórico do que a pessoa fez.
        </div>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ textAlign: "left", color: "var(--text-muted)", fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em" }}>
                <th style={{ padding: "8px 8px 8px 0" }}>Pessoa</th>
                <th style={{ padding: 8 }}>Função</th>
                <th style={{ padding: 8 }}>Status</th>
                <th style={{ padding: "8px 0 8px 8px" }} />
              </tr>
            </thead>
            <tbody>
              {membros.map((m) => (
                <tr key={m.id} style={{ borderTop: "1px solid var(--border)", opacity: m.ativo ? 1 : 0.55 }}>
                  <td style={{ padding: "10px 8px 10px 0" }}>
                    <div style={{ fontWeight: 700 }}>
                      {m.nome}
                      {m.voce && <span style={{ color: "var(--text-muted)", fontWeight: 600 }}> (você)</span>}
                    </div>
                    <div style={{ color: "var(--text-muted)", fontSize: 12 }}>{m.email}</div>
                  </td>
                  <td style={{ padding: "10px 8px" }}>
                    <form action={acao} style={{ display: "flex", gap: 6 }}>
                      <input type="hidden" name="acao" value="funcao" />
                      <input type="hidden" name="id" value={m.id} />
                      <input type="hidden" name="nome" value={m.nome} />
                      <select
                        name="role"
                        defaultValue={m.role}
                        aria-label={`Função de ${m.nome}`}
                        onChange={(e) => e.currentTarget.form?.requestSubmit()}
                        style={{ ...campo, padding: "6px 8px", fontSize: 13, width: "auto" }}
                      >
                        {funcoes.map((f) => (
                          <option key={f.role} value={f.role}>
                            {f.label}
                          </option>
                        ))}
                        {!funcoes.some((f) => f.role === m.role) && <option value={m.role}>{labelDe(m.role)}</option>}
                      </select>
                    </form>
                  </td>
                  <td style={{ padding: "10px 8px", whiteSpace: "nowrap" }}>
                    <span
                      style={{
                        fontSize: 11,
                        fontWeight: 800,
                        borderRadius: 99,
                        padding: "3px 9px",
                        color: m.ativo ? "var(--status-good)" : "var(--text-muted)",
                        background: m.ativo ? "var(--status-good-bg)" : "var(--surface-2)",
                      }}
                    >
                      {m.ativo ? "Ativo" : "Desativado"}
                    </span>
                  </td>
                  <td style={{ padding: "10px 0 10px 8px" }}>
                    <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                      {m.ativo && (
                        <form action={acao}>
                          <input type="hidden" name="acao" value="senha" />
                          <input type="hidden" name="id" value={m.id} />
                          <input type="hidden" name="nome" value={m.nome} />
                          <button type="submit" disabled={rodando} style={botao}>
                            Gerar nova senha
                          </button>
                        </form>
                      )}
                      {!m.voce && (
                        <form action={acao}>
                          <input type="hidden" name="acao" value={m.ativo ? "desativar" : "reativar"} />
                          <input type="hidden" name="id" value={m.id} />
                          <input type="hidden" name="nome" value={m.nome} />
                          <button type="submit" disabled={rodando} style={{ ...botao, color: m.ativo ? "var(--text-muted)" : "var(--status-good)" }}>
                            {m.ativo ? "Desativar" : "Reativar"}
                          </button>
                        </form>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
