import { LogoMesa7 } from "@/components/LogoMesa7";
import { SignOutButton } from "@/components/SignOutButton";
import { NavLinks } from "@/components/NavLinks";
import { dashboardPorPasta } from "@/lib/dashboards";

export function Sidebar({
  clientSlug,
  userName,
  userRole,
  showEntrada,
}: {
  clientSlug: string;
  userName: string;
  userRole: string;
  showEntrada?: boolean;
}) {
  return (
    <aside
      style={{
        background: "var(--surface)",
        borderRight: "1px solid var(--border)",
        padding: "22px 14px 18px",
        display: "flex",
        flexDirection: "column",
        gap: 20,
        position: "sticky",
        top: 0,
        height: "100vh",
        overflowY: "auto",
      }}
    >
      <LogoMesa7 legenda="Sistema de relatórios" />

      <NavLinks clientSlug={clientSlug} />

      {dashboardPorPasta(clientSlug) && (
        <div style={{ padding: "0 2px" }}>
          <a
            href={`/dashboards/${clientSlug}`}
            style={{
              display: "block",
              textAlign: "center",
              background: "transparent",
              color: "var(--text-secondary)",
              border: "1px solid var(--border-strong)",
              borderRadius: 9,
              padding: "9px 12px",
              fontSize: 13,
              fontWeight: 700,
              textDecoration: "none",
            }}
          >
            Abrir dashboard do cliente
          </a>
        </div>
      )}

      {showEntrada && (
        <div style={{ padding: "0 2px" }}>
          <a
            href={`/c/${clientSlug}/entrada`}
            style={{
              display: "block",
              textAlign: "center",
              background: "var(--accent-soft)",
              color: "var(--accent)",
              border: "1px solid rgba(249,115,22,0.35)",
              borderRadius: 9,
              padding: "9px 12px",
              fontSize: 13,
              fontWeight: 700,
              textDecoration: "none",
            }}
          >
            + Lançar dados do mês
          </a>
        </div>
      )}

      <div
        style={{
          marginTop: "auto",
          padding: 12,
          borderTop: "1px solid var(--border)",
          fontSize: 11,
          color: "var(--text-muted)",
          lineHeight: 1.5,
        }}
      >
        <div style={{ color: "var(--text-secondary)", fontWeight: 700 }}>{userName}</div>
        <div>{userRole}</div>
        <SignOutButton />
      </div>
    </aside>
  );
}
