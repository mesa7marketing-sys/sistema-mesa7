import { auth } from "@/auth";
import { db } from "@/db";
import { clients, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound, redirect } from "next/navigation";

export const TEAM_ROLES = [
  "admin",
  "cs",
  "trafego",
  "social",
  "cardapio",
  "crm",
  "design",
  "google",
] as const;

export type Role = (typeof TEAM_ROLES)[number] | "client";

export async function requireSession() {
  const session = await auth();
  if (!session?.user) redirect("/login");
  // A sessão é um token assinado: confere no banco se o login continua ativo,
  // para que "Desativar" na tela Equipe corte o acesso na hora.
  const [u] = await db
    .select({ active: users.active, role: users.role, name: users.name })
    .from(users)
    .where(eq(users.id, session.user.id))
    .limit(1);
  if (!u || !u.active) redirect("/sair?desativado=1");
  session.user.role = u.role;
  session.user.name = u.name;
  return session;
}

export async function requireAdmin() {
  const session = await requireSession();
  if (session.user.role !== "admin") notFound();
  return session;
}

/**
 * Garante que o usuário logado pode ver o cliente identificado por `slug`.
 * Equipe Mesa7 (qualquer role != 'client') pode ver qualquer cliente ativo.
 * Usuário de cliente só pode ver o próprio cliente.
 */
export async function requireClientAccess(slug: string) {
  const session = await requireSession();

  const [client] = await db.select().from(clients).where(eq(clients.slug, slug)).limit(1);
  if (!client || !client.active) notFound();

  const isTeam = session.user.role !== "client";
  const ownsClient = session.user.clientId === client.id;

  if (!isTeam && !ownsClient) {
    notFound();
  }

  return { session, client };
}
