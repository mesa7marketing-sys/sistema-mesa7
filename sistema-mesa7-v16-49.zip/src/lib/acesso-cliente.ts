// Senha dos links de cliente (/d/<token>). Uma senha só para todos os clientes.
// A senha fica no .env (CLIENTE_SENHA). Sem ela, vale a senha padrão definida
// pela Mesa7 — guardada aqui só como hash, nunca em texto.
// Depois de acertar a senha, o navegador recebe um cookie que vale 180 dias;
// trocar a senha (ou o AUTH_SECRET) derruba todos os acessos antigos.
import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { auth } from "@/auth";

const HASH_PADRAO = "d2dae2003517ee0fb662fe45bdb0ddec59ac8d6ebb9253f8ec0e4bdc699ce337";
export const COOKIE_CLIENTE = "m7_cliente";
export const DIAS_COOKIE = 180;

const sha = (s: string) => createHash("sha256").update(s).digest("hex");

function hashSenha() {
  const env = process.env.CLIENTE_SENHA?.trim();
  return env ? sha(env) : HASH_PADRAO;
}

function valorCookie() {
  return createHmac("sha256", process.env.AUTH_SECRET || "m7").update(`cliente:${hashSenha()}`).digest("hex");
}

function iguais(a: string, b: string) {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

export function senhaConfere(digitada: string) {
  return iguais(sha(digitada.trim()), hashSenha());
}

/** Libera quem já digitou a senha neste navegador ou quem está logado no sistema. */
export async function acessoLiberado() {
  const c = (await cookies()).get(COOKIE_CLIENTE)?.value;
  if (c && iguais(c, valorCookie())) return true;
  const session = await auth();
  return !!session?.user;
}

export async function gravarAcesso() {
  (await cookies()).set(COOKIE_CLIENTE, valorCookie(), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/d",
    maxAge: DIAS_COOKIE * 24 * 3600,
  });
}
