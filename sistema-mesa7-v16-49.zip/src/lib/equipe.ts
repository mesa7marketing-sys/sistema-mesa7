// Logins da equipe Mesa7: criar, trocar função, gerar nova senha e desativar.
import bcrypt from "bcryptjs";
import { randomInt } from "node:crypto";
import { and, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { TEAM_ROLES } from "@/lib/access";

export type RoleEquipe = (typeof TEAM_ROLES)[number];

export const FUNCOES: { role: RoleEquipe; label: string }[] = [
  { role: "admin", label: "Administração" },
  { role: "cs", label: "Customer Success" },
  { role: "trafego", label: "Tráfego" },
  { role: "social", label: "Social Media" },
  { role: "design", label: "Design" },
  { role: "cardapio", label: "Cardápio, iFood e RePediu" },
  { role: "crm", label: "CRM" },
  { role: "google", label: "Google" },
];

export function funcaoLabel(role: string) {
  return FUNCOES.find((f) => f.role === role)?.label ?? role;
}

/** Senha temporária fácil de ditar: Mesa7-XXXX-XXXX (sem 0/O, 1/I/L). */
export function gerarSenha() {
  const letras = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  const bloco = () => Array.from({ length: 4 }, () => letras[randomInt(letras.length)]).join("");
  return `Mesa7-${bloco()}-${bloco()}`;
}

export async function listarEquipe() {
  const todos = await db.select().from(users).orderBy(users.name);
  return todos.filter((u) => u.role !== "client");
}

export async function criarMembro(dados: { nome: string; email: string; role: RoleEquipe }) {
  const email = dados.email.toLowerCase().trim();
  const [existe] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existe) throw new Error("Já existe um login com esse e-mail.");
  const senha = gerarSenha();
  await db.insert(users).values({
    name: dados.nome.trim(),
    email,
    role: dados.role,
    passwordHash: await bcrypt.hash(senha, 10),
    active: true,
  });
  return senha;
}

export async function novaSenha(id: string) {
  const senha = gerarSenha();
  const r = await db
    .update(users)
    .set({ passwordHash: await bcrypt.hash(senha, 10) })
    .where(and(eq(users.id, id), ne(users.role, "client")))
    .returning({ id: users.id });
  if (!r.length) throw new Error("Pessoa não encontrada.");
  return senha;
}

async function adminsAtivos(excetoId: string) {
  const admins = await db
    .select({ id: users.id })
    .from(users)
    .where(and(eq(users.role, "admin"), eq(users.active, true), ne(users.id, excetoId)));
  return admins.length;
}

export async function alterarMembro(id: string, dados: { nome?: string; role?: RoleEquipe; active?: boolean }, quemId: string) {
  const [u] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!u || u.role === "client") throw new Error("Pessoa não encontrada.");
  const perdeAdmin = u.role === "admin" && ((dados.role && dados.role !== "admin") || dados.active === false);
  if (perdeAdmin && id === quemId) throw new Error("Você não pode tirar o seu próprio acesso de administração.");
  if (perdeAdmin && (await adminsAtivos(id)) === 0) throw new Error("Precisa ficar pelo menos um administrador ativo.");
  await db
    .update(users)
    .set({
      ...(dados.nome ? { name: dados.nome.trim() } : {}),
      ...(dados.role ? { role: dados.role } : {}),
      ...(dados.active !== undefined ? { active: dados.active } : {}),
    })
    .where(eq(users.id, id));
}

export async function trocarPropriaSenha(id: string, atual: string, nova: string) {
  const [u] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!u) throw new Error("Login não encontrado.");
  if (!(await bcrypt.compare(atual, u.passwordHash))) throw new Error("A senha atual não confere.");
  if (nova.length < 8) throw new Error("A nova senha precisa ter pelo menos 8 caracteres.");
  await db.update(users).set({ passwordHash: await bcrypt.hash(nova, 10) }).where(eq(users.id, id));
}
