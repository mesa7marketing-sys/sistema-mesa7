// Leitura automática do cardápio próprio (delivery próprio).
// Aceita dois formatos, em .csv ou .xlsx:
//  1. "Relatório de Pedidos" do Cardápio Web — um pedido por linha (Número do
//     Pedido, Origem, Retirada, Valor do frete, Valor total, Data, Status...).
//  2. Resumo mensal (cliente, mes, faturamento_brl, pedidos, delivery_brl...),
//     o formato dos arquivos cardapio_web_<cliente>_AAAA-MM.csv.
//  3. "Relatório de Pedidos Detalhado" de app/site próprio (N°/pedido, Canal,
//     Data Pedido, Detalhes, Total, Taxa de entrega, Status) — ex.: Duana Serra.
//     Desse sai também o ranking de itens e de sabores de pizza (por quantidade).
//     Dados do cliente final (nome, CPF, e-mail, telefone) não são guardados.
// Pedido cancelado não entra no faturamento (fica contado à parte).
import { abasDoXlsx, linhasDoCsv, norm, numero } from "@/lib/leitor-ifood";

type Parte = { o: number; r: number };

export type CardapioMes = {
  mes: string;
  /** Pedidos, faturamento (R$, com frete) e ticket médio — sem cancelados. */
  o: number;
  r: number;
  t: number;
  frete: number;
  /** Por tipo de pedido. */
  del: Parte;
  ret: Parte;
  mesa: Parte;
  local: Parte;
  /** Por origem (Site, WhatsApp, Compartilhamento do menu...) e forma de pagamento. */
  orig: Record<string, Parte>;
  pg: Record<string, number>;
  canc: Parte;
  /** Primeiro e último dia com pedido (AAAA-MM-DD), quando o relatório tem data. */
  de?: string;
  ate?: string;
  formato: "pedidos" | "resumo" | "detalhado";
  /** Itens mais pedidos (quantidade) e sabores de pizza (soma das frações), quando o relatório traz. */
  itens?: { nome: string; qtd: number }[];
  /** Pedidos e faturamento por dia da semana e (quando o relatório traz a hora) por hora. */
  dias?: Record<string, Parte>;
  horas?: Record<string, Parte>;
  sabores?: { nome: string; qtd: number }[];
};

const vazio = (mes: string, formato: CardapioMes["formato"]): CardapioMes => ({
  mes, o: 0, r: 0, t: 0, frete: 0,
  del: { o: 0, r: 0 }, ret: { o: 0, r: 0 }, mesa: { o: 0, r: 0 }, local: { o: 0, r: 0 },
  orig: {}, pg: {}, canc: { o: 0, r: 0 }, formato,
});

function tipoDe(v: unknown): "del" | "ret" | "mesa" | "local" {
  const s = norm(v);
  if (/mesa|comanda/.test(s)) return "mesa";
  if (/consumo|local|salao/.test(s)) return "local";
  if (/retir|balcao|busca/.test(s)) return "ret";
  return "del";
}

function dataIso(v: unknown): string | null {
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  const m = String(v ?? "").match(/(\d{2})\/(\d{2})\/(\d{4})/);
  if (m) return `${m[3]}-${m[2]}-${m[1]}`;
  const iso = String(v ?? "").match(/(\d{4})-(\d{2})-(\d{2})/);
  return iso ? `${iso[1]}-${iso[2]}-${iso[3]}` : null;
}

const r2 = (n: number) => Math.round(n * 100) / 100;
const SEMANA = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];

/** Soma o pedido no dia da semana e, se houver hora (dd/mm/aaaa hh:mm), na hora. */
function marcarDiaHora(m: CardapioMes, dia: string, bruto: unknown, r: number) {
  const [y, mo, d] = dia.split("-").map(Number);
  const nome = SEMANA[new Date(y, mo - 1, d).getDay()];
  const ds = (m.dias ||= {});
  const x = (ds[nome] ||= { o: 0, r: 0 }); x.o++; x.r += r;
  const h = bruto instanceof Date ? bruto.getUTCHours() : Number((String(bruto ?? "").match(/\s(\d{1,2}):\d{2}/) || [])[1]);
  if (Number.isFinite(h) && !(bruto instanceof Date && h === 0 && bruto.getUTCMinutes() === 0)) {
    const hs = (m.horas ||= {});
    const k = `${String(h).padStart(2, "0")}h`;
    const y2 = (hs[k] ||= { o: 0, r: 0 }); y2.o++; y2.r += r;
  }
}

function fechar(m: CardapioMes): CardapioMes {
  const arred = (p: Parte) => ({ o: p.o, r: r2(p.r) });
  return {
    ...m, r: r2(m.r), frete: r2(m.frete), t: m.o ? r2(m.r / m.o) : 0,
    del: arred(m.del), ret: arred(m.ret), mesa: arred(m.mesa), local: arred(m.local), canc: arred(m.canc),
    orig: Object.fromEntries(Object.entries(m.orig).map(([k, p]) => [k, arred(p)])),
    ...(m.dias ? { dias: Object.fromEntries(Object.entries(m.dias).map(([k, p]) => [k, arred(p)])) } : {}),
    ...(m.horas ? { horas: Object.fromEntries(Object.entries(m.horas).sort().map(([k, p]) => [k, arred(p)])) } : {}),
  };
}

function acharCabecalho(linhas: unknown[][], teste: (cab: string[]) => boolean) {
  const i = linhas.findIndex((l) => teste(l.map(norm)));
  return i < 0 ? null : { cab: linhas[i].map(norm), dados: linhas.slice(i + 1).filter((l) => l.some((c) => String(c ?? "").trim() !== "")) };
}

function lerPedidos(cab: string[], dados: unknown[][]): CardapioMes[] {
  const c = (...p: string[]) => cab.findIndex((h) => p.every((x) => h.includes(x)));
  const iTot = cab.findIndex((h) => h === "valor total");
  const iData = c("data"), iStatus = c("status"), iRet = c("retirada"), iOrig = c("origem");
  const iFrete = c("valor do frete"), iPg = c("condicao de pagamento");
  const meses = new Map<string, CardapioMes>();
  for (const l of dados) {
    const dia = dataIso(l[iData]);
    if (!dia) continue;
    const mes = dia.slice(0, 7);
    const m = meses.get(mes) ?? vazio(mes, "pedidos");
    meses.set(mes, m);
    const r = numero(l[iTot]);
    if (iStatus >= 0 && /cancel|recus|estorn/.test(norm(l[iStatus]))) {
      m.canc.o++; m.canc.r += r;
      continue;
    }
    m.o++; m.r += r;
    if (iFrete >= 0) m.frete += numero(l[iFrete]);
    marcarDiaHora(m, dia, l[iData], r);
    const t = m[tipoDe(iRet >= 0 ? l[iRet] : "")];
    t.o++; t.r += r;
    const origem = iOrig >= 0 ? String(l[iOrig] ?? "").trim() || "Outros" : "Cardápio próprio";
    const o = (m.orig[origem] ||= { o: 0, r: 0 });
    o.o++; o.r += r;
    if (iPg >= 0) {
      const pg = String(l[iPg] ?? "").trim() || "Outros";
      m.pg[pg] = (m.pg[pg] ?? 0) + 1;
    }
    if (!m.de || dia < m.de) m.de = dia;
    if (!m.ate || dia > m.ate) m.ate = dia;
  }
  return [...meses.values()].map(fechar);
}

function lerResumo(cab: string[], dados: unknown[][]): CardapioMes[] {
  const i = (n: string) => cab.indexOf(n);
  const v = (l: unknown[], n: string) => (i(n) >= 0 ? numero(l[i(n)]) : 0);
  const saida: CardapioMes[] = [];
  for (const l of dados) {
    const mes = String(l[i("mes")] ?? "").trim().slice(0, 7);
    if (!/^\d{4}-\d{2}$/.test(mes)) continue;
    const m = vazio(mes, "resumo");
    m.o = v(l, "pedidos"); m.r = v(l, "faturamento_brl");
    m.del = { o: v(l, "delivery_pedidos"), r: v(l, "delivery_brl") };
    m.ret = { o: v(l, "retirada_pedidos"), r: v(l, "retirada_brl") };
    m.mesa = { o: v(l, "mesa_comanda_pedidos"), r: v(l, "mesa_comanda_brl") };
    m.local = { o: v(l, "consumo_local_pedidos"), r: v(l, "consumo_local_brl") };
    saida.push(fechar(m));
  }
  return saida;
}

const limparNome = (s: string) => {
  const t = s.replace(/\s*\(item\)\s*$/i, "").replace(/\s+/g, " ").trim();
  const m = t.match(/^(.*?)\s*\((.*)\)$/);
  if (m && norm(m[1]) === norm(m[2])) return m[1];
  return t;
};

function topo(mapa: Map<string, number>, n: number) {
  return [...mapa.entries()].map(([nome, qtd]) => ({ nome, qtd: Math.round(qtd * 100) / 100 }))
    .sort((a, b) => b.qtd - a.qtd).slice(0, n);
}

function lerDetalhado(cab: string[], dados: unknown[][]): CardapioMes[] {
  const c = (...p: string[]) => cab.findIndex((h) => p.every((x) => h.includes(x)));
  const iData = c("data pedido"), iTot = cab.findIndex((h) => h === "total"), iTaxa = c("taxa de entrega cobrad");
  const iCanal = c("canal"), iStatus = c("status"), iPg = c("forma de pagamento"), iEnd = c("endereco"), iDet = c("detalhes");
  const meses = new Map<string, CardapioMes & { _it: Map<string, number>; _sab: Map<string, number> }>();
  for (const l of dados) {
    const dia = dataIso(l[iData]);
    if (!dia) continue;
    const mes = dia.slice(0, 7);
    const m = meses.get(mes) ?? { ...vazio(mes, "detalhado"), _it: new Map(), _sab: new Map() };
    meses.set(mes, m);
    const r = numero(l[iTot]);
    if (iStatus >= 0 && /cancel|recus|estorn|rejeit/.test(norm(l[iStatus]))) { m.canc.o++; m.canc.r += r; continue; }
    m.o++; m.r += r;
    marcarDiaHora(m, dia, l[iData], r);
    const taxa = iTaxa >= 0 ? numero(l[iTaxa]) : 0;
    m.frete += taxa;
    const temEnd = iEnd >= 0 && /[a-z]/i.test(String(l[iEnd] ?? ""));
    const t = temEnd || taxa > 0 ? m.del : m.ret;
    t.o++; t.r += r;
    const origem = iCanal >= 0 ? String(l[iCanal] ?? "").trim() || "Outros" : "Cardápio próprio";
    const o = (m.orig[origem] ||= { o: 0, r: 0 }); o.o++; o.r += r;
    if (iPg >= 0) { const pg = String(l[iPg] ?? "").trim() || "Outros"; m.pg[pg] = (m.pg[pg] ?? 0) + 1; }
    if (!m.de || dia < m.de) m.de = dia;
    if (!m.ate || dia > m.ate) m.ate = dia;
    for (const bruta of String(iDet >= 0 ? l[iDet] ?? "" : "").split(/\r?\n/)) {
      const lin = bruta.trim();
      const sab = lin.match(/^(\d+)\/(\d+)\s+(?:pizza\s*-\s*)?(.+)$/i);
      if (sab) { const nome = limparNome(sab[3]); m._sab.set(nome, (m._sab.get(nome) ?? 0) + Number(sab[1]) / Number(sab[2])); continue; }
      const it = lin.match(/^(\d+)\s+(.+)$/);
      if (it && !bruta.startsWith(" -")) { const nome = limparNome(it[2]); m._it.set(nome, (m._it.get(nome) ?? 0) + Number(it[1])); }
    }
  }
  return [...meses.values()].map(({ _it, _sab, ...m }) => ({ ...fechar(m), itens: topo(_it, 15), sabores: topo(_sab, 15) }));
}

/** Lê o relatório e devolve um resumo por mês. Erro com mensagem amigável quando não reconhece. */
export async function lerRelatorioCardapio(nomeArquivo: string, buf: Buffer): Promise<CardapioMes[]> {
  const ext = nomeArquivo.toLowerCase().split(".").pop();
  let tabelas: unknown[][][];
  if (ext === "xlsx") tabelas = Object.values(await abasDoXlsx(buf));
  else if (ext === "csv") {
    let texto = buf.toString("utf8");
    if (texto.includes("�")) texto = buf.toString("latin1");
    tabelas = [linhasDoCsv(texto)];
  } else throw new Error("A leitura automática do cardápio próprio aceita .csv ou .xlsx.");

  for (const linhas of tabelas) {
    const ped = acharCabecalho(linhas, (c) => c.includes("valor total") && c.some((h) => h.startsWith("data")));
    if (ped) {
      const meses = lerPedidos(ped.cab, ped.dados);
      if (!meses.length) throw new Error("O relatório de pedidos não tem nenhuma linha com data.");
      return meses.sort((a, b) => a.mes.localeCompare(b.mes));
    }
    const det = acharCabecalho(linhas, (c) => c.includes("total") && c.some((h) => h.startsWith("data pedido")));
    if (det) {
      const meses = lerDetalhado(det.cab, det.dados);
      if (!meses.length) throw new Error("O relatório de pedidos não tem nenhuma linha com data.");
      return meses.sort((a, b) => a.mes.localeCompare(b.mes));
    }
    const res = acharCabecalho(linhas, (c) => c.includes("mes") && c.includes("faturamento_brl") && c.includes("pedidos"));
    if (res) {
      const meses = lerResumo(res.cab, res.dados);
      if (meses.length) return meses.sort((a, b) => a.mes.localeCompare(b.mes));
    }
  }
  throw new Error('Não reconheci o formato. Use o "Relatório de Pedidos" do Cardápio Web (CSV ou Excel), com as colunas Valor total, Data e Status.');
}
