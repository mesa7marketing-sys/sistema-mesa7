// Relatório de itens/produtos vendidos (Cardápio Web, SAIPOS, PDV…), para a
// Curva ABC mensal. Formato livre: uma linha por item, com nome, quantidade e
// valor; categoria é opcional. O relatório não precisa ter data — vale o mês
// escolhido no envio.
import { abasDoXlsx, linhasDoCsv, norm, numero } from "@/lib/leitor-ifood";

export type ItemVendido = { n: string; c: string; q: number; v: number };
export type ItensMes = { mes: string; itens: ItemVendido[]; total: number; unidades: number };

const NOME = /^(produto|item|nome do produto|nome do item|descricao|nome|produto\/servico)$/;
const QTD = /(quantidade|qtd|qtde|vendidos|unidades)/;
const VAL = /(valor total|total vendido|faturamento|valor|total)/;
const CAT = /(categoria|grupo|secao|departamento)/;

/** Lê o relatório; mês = o escolhido no envio. Erro amigável se não reconhecer. */
export async function lerRelatorioItens(nomeArquivo: string, buf: Buffer, mes: string): Promise<ItensMes> {
  const ext = nomeArquivo.toLowerCase().split(".").pop();
  let tabelas: unknown[][][];
  if (ext === "xlsx") tabelas = Object.values(await abasDoXlsx(buf));
  else if (ext === "csv") {
    let t = buf.toString("utf8");
    if (t.includes("�")) t = buf.toString("latin1");
    tabelas = [linhasDoCsv(t)];
  } else throw new Error("O relatório de itens precisa ser .csv ou .xlsx.");

  for (const linhas of tabelas) {
    const iCab = linhas.findIndex((l) => {
      const c = l.map(norm);
      return c.some((h) => NOME.test(h)) && c.some((h) => QTD.test(h)) && c.some((h) => VAL.test(h) && !QTD.test(h));
    });
    if (iCab < 0) continue;
    const cab = linhas[iCab].map(norm);
    const iN = cab.findIndex((h) => NOME.test(h));
    const iQ = cab.findIndex((h) => QTD.test(h));
    // prefere "valor total"/"faturamento" a "valor unitário"
    const cands = cab.map((h, i) => ({ h, i })).filter((x) => VAL.test(x.h) && !QTD.test(x.h) && !/unit|medio|preco/.test(x.h));
    const iV = (cands.find((x) => /total|faturamento/.test(x.h)) ?? cands[0])?.i ?? -1;
    const iC = cab.findIndex((h) => CAT.test(h));
    if (iV < 0) continue;
    const mapa = new Map<string, ItemVendido>();
    for (const l of linhas.slice(iCab + 1)) {
      const n = String(l[iN] ?? "").replace(/\s+/g, " ").trim();
      if (!n || /^(total|totais|subtotal)\b/i.test(n)) continue;
      const q = numero(l[iQ]), v = numero(l[iV]);
      if (!q && !v) continue;
      const c = iC >= 0 ? String(l[iC] ?? "").trim() : "";
      const x = mapa.get(n) ?? { n, c, q: 0, v: 0 };
      x.q += q; x.v += v; if (!x.c && c) x.c = c;
      mapa.set(n, x);
    }
    const itens = [...mapa.values()].map((x) => ({ ...x, v: Math.round(x.v * 100) / 100 })).sort((a, b) => b.v - a.v || b.q - a.q);
    if (!itens.length) continue;
    return {
      mes,
      itens,
      total: Math.round(itens.reduce((s, x) => s + x.v, 0) * 100) / 100,
      unidades: itens.reduce((s, x) => s + x.q, 0),
    };
  }
  throw new Error("Não reconheci o relatório de itens. Ele precisa ter uma coluna com o nome do produto, uma com a quantidade e uma com o valor.");
}
