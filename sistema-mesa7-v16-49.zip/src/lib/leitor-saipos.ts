// Leitura automática do relatório "Acompanhamento de vendas" do SAIPOS.
//
// O PDF que o SAIPOS exporta é uma captura da tela (só imagem, sem texto), então
// a leitura é por OCR (tesseract). Aceita o PDF ou um print (png/jpg/webp).
// Como OCR pode errar um dígito, nada entra no dashboard sem passar na conferência:
//   soma dos canais = soma dos tipos (sem cancelados) = total do relatório.
// Se não fechar, o arquivo fica "Pendente" com a explicação do que não bateu.
//
// Requer no servidor: tesseract-ocr e poppler-utils (pdftoppm).
import { execFile } from "node:child_process";
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";

const exec = promisify(execFile);

export type SaiposLinha = { nome: string; o: number; r: number; t: number };

export type SaiposMes = {
  /** AAAA-MM do início do período. */
  mes: string;
  periodo: string;
  /** Último dia considerado, quando o período não é o mês inteiro (AAAA-MM-DD). */
  ate?: string;
  /** Pedidos e valor de venda totais (sem cancelados). */
  o: number;
  r: number;
  t: number;
  tipos: SaiposLinha[];
  canais: SaiposLinha[];
  cancelados: { o: number; r: number };
};

function semAcento(s: string) {
  return s.normalize("NFD").replace(/[̀-ͯ]/g, "");
}

const arred = (n: number) => Math.round(n * 100) / 100;

/** "93.756,26" ou "93756.26" → número. */
function dinheiro(s: string) {
  let v = s.replace(/[R$\s]/g, "");
  if (/,\d{2}$/.test(v)) v = v.replace(/\./g, "").replace(",", ".");
  return Number(v);
}

// Número com centavos que não é percentual: 31207.60, 1.234,56 ...
const RE_VALOR = /(?<![\d.,])\d{1,3}(?:\.\d{3})*,\d{2}(?![\d%])|(?<![\d.,])\d+\.\d{2}(?![\d%])/g;

function valores(texto: string) {
  return (texto.match(RE_VALOR) ?? []).map(dinheiro);
}

function linhaDeTabela(linha: string): { nome: string; o: number; r: number; t: number } | null {
  // "Salao 694 Ga 0.14% Salao 62212.84 Ga 6.55% Salao 89.64 ..." → nome = texto antes do 1º inteiro
  const m = linha.match(/^\s*(.*?[A-Za-z)])\s+(\d{1,6})(?=\s|$)/);
  if (!m) return null;
  const nome = m[1].replace(/^[^A-Za-z0-9]+/, "").trim();
  const resto = linha.slice(m[0].length);
  const v = valores(resto);
  if (v.length < 2) return null;
  return { nome, o: Number(m[2]), r: v[0], t: v[1] };
}

function secao(linhas: string[], inicio: RegExp) {
  const i = linhas.findIndex((l) => inicio.test(semAcento(l)));
  if (i < 0) return [];
  const out: string[] = [];
  for (let j = i + 1; j < linhas.length; j++) {
    if (/^\s*\d+\s*linhas/i.test(linhas[j])) break;
    out.push(linhas[j]);
  }
  return out;
}

function parseCabecalho(texto: string) {
  const t = semAcento(texto);
  const ped = t.match(/N\S{0,2}\s*de\s*pedidos\s*:?\s*(\d[\d.]*)/i);
  const val = t.match(/Valor\s*venda\s*:?\s*R?\$?\s*([\d.]+,\d{2})/i);
  const ini = t.match(/Data\s*Inicial\s*:?\s*(\d{1,2})\/(\d{1,2})\/(\d{4})/i);
  const fim = t.match(/Data\s*Final\s*:?\s*(\d{1,2})\/(\d{1,2})\/(\d{4})/i);
  return { ped, val, ini, fim };
}

const p2 = (n: string | number) => String(n).padStart(2, "0");

/** Interpreta o texto lido e confere os totais. Lança erro explicando o que não fechou. */
export function interpretarSaipos(texto: string): SaiposMes {
  const { ped, val, ini, fim } = parseCabecalho(texto);
  if (!ped || !val || !ini || !fim) {
    throw new Error('Não reconheci o relatório. Envie o "Acompanhamento de vendas" do SAIPOS, completo (print ou PDF da tela inteira).');
  }
  const totalO = Number(ped[1].replace(/\./g, ""));
  const totalR = dinheiro(val[1]);
  const periodo = `${p2(ini[1])}/${p2(ini[2])}/${ini[3]} a ${p2(fim[1])}/${p2(fim[2])}/${fim[3]}`;
  const mes = `${ini[3]}-${p2(ini[2])}`;
  const fimMes = `${fim[3]}-${p2(fim[2])}`;
  if (mes !== fimMes) throw new Error(`O período (${periodo}) passa de um mês. Exporte um mês por vez.`);

  const linhas = texto.split("\n").map((l) => l.trim()).filter(Boolean);
  const tiposBrutos = secao(linhas, /^tipo venda.*qtde/i).map(linhaDeTabela).filter((x): x is SaiposLinha => !!x);
  const canaisBrutos = secao(linhas, /^canal de venda.*qtde/i).map(linhaDeTabela).filter((x): x is SaiposLinha => !!x);
  if (!tiposBrutos.length || !canaisBrutos.length) {
    throw new Error("Não achei as tabelas de tipo de venda e de canal de venda no relatório.");
  }

  // Corrige a quantidade quando o OCR errou um dígito: valor ÷ ticket tem que bater.
  const corrigir = (l: SaiposLinha): SaiposLinha => {
    if (l.t > 0) {
      const est = Math.round(l.r / l.t);
      if (est > 0 && Math.abs(l.o - est) / est > 0.005 && Math.abs(l.r / est - l.t) < 0.02) return { ...l, o: est };
    }
    return l;
  };
  const tipos = tiposBrutos.map(corrigir);
  const canais = canaisBrutos.map(corrigir);

  const ehCancelado = (l: SaiposLinha) => /cancel/i.test(l.nome);
  const canc = tipos.find(ehCancelado);
  const tiposOk = tipos.filter((l) => !ehCancelado(l));

  const soma = (ls: SaiposLinha[], k: "o" | "r") => ls.reduce((s, l) => s + l[k], 0);
  const erros: string[] = [];
  const bate = (a: number, b: number) => Math.abs(a - b) < 0.06;
  if (soma(canais, "o") !== totalO) erros.push(`canais somam ${soma(canais, "o")} pedidos, o total é ${totalO}`);
  if (!bate(soma(canais, "r"), totalR)) erros.push(`canais somam R$ ${soma(canais, "r").toFixed(2)}, o total é R$ ${totalR.toFixed(2)}`);
  if (soma(tiposOk, "o") !== totalO) erros.push(`tipos de venda somam ${soma(tiposOk, "o")} pedidos, o total é ${totalO}`);
  if (!bate(soma(tiposOk, "r"), totalR)) erros.push(`tipos de venda somam R$ ${soma(tiposOk, "r").toFixed(2)}, o total é R$ ${totalR.toFixed(2)}`);
  if (erros.length) {
    throw new Error(`Leitura não passou na conferência (${erros.join("; ")}). Envie um print mais nítido ou lance manualmente.`);
  }

  const fimDia = new Date(Number(fim[3]), Number(fim[2]), 0).getDate();
  const completo = Number(ini[1]) === 1 && Number(fim[1]) >= fimDia;
  return {
    mes,
    periodo,
    ...(completo ? {} : { ate: `${fim[3]}-${p2(fim[2])}-${p2(fim[1])}` }),
    o: totalO,
    r: totalR,
    t: arred(totalR / totalO),
    tipos: tiposOk,
    canais,
    cancelados: { o: canc?.o ?? 0, r: canc?.r ?? 0 },
  };
}

/** Amplia a imagem (prints de tela vêm pequenos demais para o OCR). Sem o sharp, devolve a original. */
async function ampliar(origem: string, destino: string, fator: number) {
  try {
    const { default: sharp } = await import("sharp");
    const meta = await sharp(origem).metadata();
    const largura = Math.min(Math.round((meta.width ?? 1500) * fator), 5000);
    await sharp(origem).resize({ width: largura, kernel: "lanczos3" }).grayscale().normalize().png().toFile(destino);
    return destino;
  } catch {
    return origem;
  }
}

async function ocr(imagem: string) {
  const { stdout } = await exec("tesseract", [imagem, "-", "--psm", "6", "-l", "eng"], {
    maxBuffer: 32 * 1024 * 1024,
    timeout: 120_000,
  });
  return stdout;
}

/** Lê o arquivo (PDF ou imagem) e devolve os números do mês. */
export async function lerRelatorioSaipos(nome: string, buf: Buffer): Promise<SaiposMes> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), "saipos-"));
  try {
    const ext = (nome.match(/\.([a-z0-9]+)$/i)?.[1] ?? "").toLowerCase();
    const arq = path.join(dir, `entrada.${ext || "bin"}`);
    await fs.writeFile(arq, buf);
    const textos: string[] = [];
    try {
      if (ext === "pdf") {
        // PDF com texto de verdade: tenta primeiro, é exato.
        try {
          const { stdout } = await exec("pdftotext", ["-layout", arq, "-"], { maxBuffer: 16 * 1024 * 1024, timeout: 60_000 });
          if (/Data\s*Inicial/i.test(stdout)) return interpretarSaipos(stdout);
        } catch {
          /* cai no OCR */
        }
        await exec("pdftoppm", ["-r", "300", "-png", arq, path.join(dir, "p")], { timeout: 120_000 });
        const pags = (await fs.readdir(dir)).filter((f) => /^p-\d+\.png$/.test(f)).sort();
        for (const p of pags) textos.push(await ocr(path.join(dir, p)));
      } else {
        // Print de tela: tenta no tamanho original e, se a conferência falhar, amplia.
        let ultimo: unknown = null;
        for (const fator of [1, 2, 3]) {
          const img = fator === 1 ? arq : await ampliar(arq, path.join(dir, `x${fator}.png`), fator);
          try {
            return interpretarSaipos(await ocr(img));
          } catch (e) {
            ultimo = e;
            if (e instanceof Error && /ENOENT/.test(e.message)) throw e;
          }
        }
        throw ultimo;
      }
    } catch (e) {
      const m = e instanceof Error ? e.message : String(e);
      if (/ENOENT/.test(m)) throw new Error("O servidor ainda não tem o leitor de imagens instalado (tesseract-ocr e poppler-utils).");
      throw e;
    }
    return interpretarSaipos(textos.join("\n"));
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
}
