"use server";

import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/access";
import { trocarSenha } from "@/lib/acesso-cliente";

/** Gera uma senha nova para o cliente. Quem já entrou com a senha antiga perde o acesso. */
export async function gerarNovaSenha(fd: FormData) {
  await requireAdmin();
  await trocarSenha(String(fd.get("pasta") || ""));
  revalidatePath("/dashboards");
}
