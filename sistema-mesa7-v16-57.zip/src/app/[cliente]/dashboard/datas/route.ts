import { auth } from "@/auth";
import { dashboardPorPasta } from "@/lib/dashboards";
import { acessoLiberado } from "@/lib/acesso-cliente";
import { limparSelecao, salvarSelecao } from "@/lib/datas-cliente";

// Salva as datas comemorativas escolhidas no dashboard. Mesmo acesso do
// dashboard: link do cliente + senha do cliente. Se quem salva estiver
// logado na equipe, fica registrado o nome; senão, "Cliente".
export async function POST(req: Request, ctx: RouteContext<"/[cliente]/dashboard/datas">) {
  const { cliente } = await ctx.params;
  const d = dashboardPorPasta(cliente);
  if (!d || !d.datas) return Response.json({ ok: false, erro: "Não encontrado" }, { status: 404 });
  if (!(await acessoLiberado(d.pasta))) return Response.json({ ok: false, erro: "Acesso com senha" }, { status: 401 });

  const texto = await req.text();
  if (texto.length > 50_000) return Response.json({ ok: false, erro: "Seleção grande demais." }, { status: 413 });
  let bruto: unknown;
  try {
    bruto = JSON.parse(texto);
  } catch {
    return Response.json({ ok: false, erro: "Formato inválido." }, { status: 400 });
  }

  const session = await auth();
  const quem = session?.user && session.user.role !== "client" ? `${session.user.name ?? "Equipe"} (Mesa7)` : "Cliente";
  const salvo = await salvarSelecao(d.pasta, limparSelecao(bruto), quem);
  return Response.json({ ok: true, atualizadoEm: salvo.atualizadoEm, atualizadoPor: salvo.atualizadoPor }, { headers: { "Cache-Control": "no-store" } });
}
