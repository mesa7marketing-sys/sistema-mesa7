import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { dashboardPorPasta } from "@/lib/dashboards";
import { acessoLiberado } from "@/lib/acesso-cliente";
import { FormSenhaCliente } from "@/components/FormSenhaCliente";

// Link do cliente: painel.mesa7.tech/<pasta>/dashboard, protegido pela senha do cliente
// (src/lib/acesso-cliente.ts). Mostra só o dashboard, em tela cheia.
export async function generateMetadata({ params }: PageProps<"/[cliente]/dashboard">): Promise<Metadata> {
  const { cliente } = await params;
  const d = dashboardPorPasta(cliente);
  return {
    title: d ? `Mesa7 — Dashboard ${d.nome}` : "Mesa7",
    robots: { index: false, follow: false },
    referrer: "no-referrer",
  };
}

export default async function DashboardClientePage({ params }: PageProps<"/[cliente]/dashboard">) {
  const { cliente } = await params;
  const d = dashboardPorPasta(cliente);
  if (!d) notFound();
  if (!(await acessoLiberado(d.pasta))) return <FormSenhaCliente cliente={d.pasta} nome={d.nome} />;

  return (
    <iframe
      src={`/${d.pasta}/dashboard/arquivo/index.html`}
      title={`Dashboard ${d.nome}`}
      style={{ position: "fixed", inset: 0, width: "100%", height: "100%", border: 0, background: "#000" }}
    />
  );
}
