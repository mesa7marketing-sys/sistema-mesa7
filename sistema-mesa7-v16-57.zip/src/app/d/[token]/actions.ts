"use server";

// Link antigo do cliente (/d/<token>), desativado — ver src/app/[cliente]/dashboard/actions.ts.
export async function entrarComSenha(): Promise<{ erro: string }> {
  return { erro: "Este link foi desativado. Peça o link novo à equipe da Mesa7." };
}
