// Link antigo do cliente (/d/<token>), desativado — ver src/app/[cliente]/dashboard.
export function GET() {
  return new Response("Não encontrado", { status: 404 });
}
