// Link antigo do cliente (/d/<token>), desativado — ver src/app/[cliente]/dashboard/datas.
export function POST() {
  return Response.json({ ok: false, erro: "Link desativado" }, { status: 404 });
}
