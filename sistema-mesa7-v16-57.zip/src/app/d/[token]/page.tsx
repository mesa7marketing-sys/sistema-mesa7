import { notFound } from "next/navigation";

// Link antigo do cliente (/d/<token>), desativado em out/2026: os clientes agora acessam
// painel.mesa7.tech/<cliente>/dashboard com senha própria (src/app/[cliente]/dashboard).
export default function LinkAntigo() {
  notFound();
}
