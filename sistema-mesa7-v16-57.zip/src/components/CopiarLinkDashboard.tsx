"use client";

import { useState } from "react";

/** Copia o link do cliente (painel.mesa7.tech/<pasta>/dashboard) junto com a senha dele, pronto para mandar. */
export function CopiarLinkDashboard({ pasta, nome, senha, compacto }: { pasta: string; nome: string; senha: string; compacto?: boolean }) {
  const [copiado, setCopiado] = useState(false);

  async function copiar() {
    const url = `${window.location.origin}/${pasta}/dashboard`;
    const texto = `Dashboard ${nome} — Mesa7\n${url}\nSenha: ${senha}`;
    try {
      await navigator.clipboard.writeText(texto);
    } catch {
      window.prompt("Copie o link e a senha do cliente:", `${url}  ·  senha: ${senha}`);
    }
    setCopiado(true);
    setTimeout(() => setCopiado(false), 2200);
  }

  return (
    <button
      type="button"
      onClick={copiar}
      title="Copia o link e a senha do cliente"
      style={{
        background: copiado ? "var(--accent-soft)" : "transparent",
        color: copiado ? "var(--accent)" : "var(--text-secondary)",
        border: `1px solid ${copiado ? "rgba(249,115,22,0.45)" : "var(--border-strong)"}`,
        borderRadius: 9,
        padding: compacto ? "6px 10px" : "8px 14px",
        fontSize: compacto ? 12 : 13,
        fontWeight: 700,
        cursor: "pointer",
        fontFamily: "inherit",
        whiteSpace: "nowrap",
      }}
    >
      {copiado ? "Link e senha copiados ✓" : "Copiar link + senha"}
    </button>
  );
}
