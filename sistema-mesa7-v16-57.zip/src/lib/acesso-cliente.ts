// Acesso do cliente ao próprio dashboard: painel.mesa7.tech/<pasta>/dashboard + senha do cliente.
//
// Cada cliente tem a sua senha (nome + 4 números, ex.: bionatural4821). Elas ficam no servidor,
// em <pasta de arquivos>/_acessos/senhas.json — fora do código e do GitHub. A senha de um
// cliente é criada na primeira vez que alguém precisa dela (tela Dashboards ou link do cliente).
// A equipe vê e troca as senhas na tela Dashboards.
//
// Depois de acertar a senha, o navegador recebe um cookie só daquele cliente, que vale 180 dias.
// Trocar a senha de um cliente derruba os acessos antigos só dele. Login da equipe abre todos.
import { promises as fs } from "node:fs";
import path from "node:path";
import { createHash, createHmac, randomInt, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { auth } from "@/auth";
import { raizArquivos } from "@/lib/arquivos";
import { dashboardPorPasta } from "@/lib/dashboards";
import { db } from "@/db";
import { clients } from "@/db/schema";
import { eq } from "drizzle-orm";

export const DIAS_COOKIE = 180;

const sha = (s: string) => createHash("sha256").update(s).digest("hex");
const arqSenhas = () => path.join(raizArquivos(), "_acessos", "senhas.json");

async function lerSenhas(): Promise<Record<string, string>> {
  try {
    return JSON.parse(await fs.readFile(arqSenhas(), "utf8")) as Record<string, string>;
  } catch {
    return {};
  }
}

async function gravarSenhas(s: Record<string, string>) {
  await fs.mkdir(path.dirname(arqSenhas()), { recursive: true });
  await fs.writeFile(arqSenhas(), JSON.stringify(s, null, 2), { mode: 0o600 });
}

/** Nome do cliente sem acento/hífen + 4 números: fácil de digitar, difícil de adivinhar. */
function novaSenha(pasta: string) {
  const base = pasta.split("-")[0].replace(/[^a-z0-9]/g, "") || "mesa7";
  return `${base}${randomInt(1000, 10000)}`;
}

/** Senha atual do cliente (cria uma, se ainda não existir). */
export async function senhaDoCliente(pasta: string) {
  if (!dashboardPorPasta(pasta)) throw new Error("Cliente inválido.");
  const s = await lerSenhas();
  if (!s[pasta]) {
    s[pasta] = novaSenha(pasta);
    await gravarSenhas(s);
  }
  return s[pasta];
}

/** Senhas de todos os clientes (cria as que faltarem) — para a tela Dashboards da equipe. */
export async function senhasDosClientes(pastas: string[]) {
  const s = await lerSenhas();
  let mudou = false;
  for (const p of pastas) {
    if (!s[p] && dashboardPorPasta(p)) {
      s[p] = novaSenha(p);
      mudou = true;
    }
  }
  if (mudou) await gravarSenhas(s);
  return s;
}

/** Gera uma senha nova para o cliente (derruba os acessos antigos dele). */
export async function trocarSenha(pasta: string) {
  if (!dashboardPorPasta(pasta)) throw new Error("Cliente inválido.");
  const s = await lerSenhas();
  s[pasta] = novaSenha(pasta);
  await gravarSenhas(s);
  return s[pasta];
}

const nomeCookie = (pasta: string) => `m7_cli_${pasta.replace(/[^a-z0-9-]/g, "")}`;
const valorCookie = (pasta: string, senha: string) =>
  createHmac("sha256", process.env.AUTH_SECRET || "m7").update(`cliente:${pasta}:${sha(senha)}`).digest("hex");

function iguais(a: string, b: string) {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

export async function senhaConfere(pasta: string, digitada: string) {
  const certa = await senhaDoCliente(pasta);
  return iguais(sha(digitada.trim().toLowerCase()), sha(certa.toLowerCase()));
}

/** Libera quem digitou a senha deste cliente neste navegador, quem está logado como equipe
 *  e o login de cliente do próprio restaurante. */
export async function acessoLiberado(pasta: string) {
  if (!dashboardPorPasta(pasta)) return false;
  const session = await auth();
  if (session?.user && session.user.role !== "client") return true;
  if (session?.user?.clientId) {
    const [c] = await db.select({ slug: clients.slug }).from(clients).where(eq(clients.id, session.user.clientId)).limit(1);
    if (c?.slug === pasta) return true;
  }
  const c = (await cookies()).get(nomeCookie(pasta))?.value;
  return !!c && iguais(c, valorCookie(pasta, await senhaDoCliente(pasta)));
}

export async function gravarAcesso(pasta: string) {
  (await cookies()).set(nomeCookie(pasta), valorCookie(pasta, await senhaDoCliente(pasta)), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: `/${pasta}/dashboard`,
    maxAge: DIAS_COOKIE * 24 * 3600,
  });
}
