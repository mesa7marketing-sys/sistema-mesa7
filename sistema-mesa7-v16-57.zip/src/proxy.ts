import { auth } from "@/auth";
import { NextResponse } from "next/server";

export default auth((req) => {
  const isLoggedIn = !!req.auth;
  const { pathname } = req.nextUrl;

  // /<cliente>/dashboard é o link do dashboard para o cliente; a senha do cliente é conferida na
  // própria página (src/lib/acesso-cliente.ts). /d/ é o link antigo, desativado (responde 404).
  const isPublic =
    /^\/[a-z0-9-]+\/dashboard(\/|$)/.test(pathname) ||
    pathname.startsWith("/login") ||
    pathname.startsWith("/api/auth") ||
    pathname.startsWith("/d/") ||
    pathname.startsWith("/marca/"); // logo da Mesa7 (aparece já na tela de login)

  if (!isLoggedIn && !isPublic) {
    const loginUrl = new URL("/login", req.nextUrl.origin);
    loginUrl.searchParams.set("callbackUrl", pathname);
    return NextResponse.redirect(loginUrl);
  }

  if (isLoggedIn && pathname.startsWith("/login")) {
    return NextResponse.redirect(new URL("/", req.nextUrl.origin));
  }

  return NextResponse.next();
});

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
