/* =========================================================
   Quadro "Campanha de Vendas · semana" na página Marketing 360°.
   Lê window.M7_DADOS.vendas_semana (dashboards/<pasta>/dados.json):
   custo por compra das campanhas de vendas do Meta Ads nos últimos 7 dias
   contra os 7 dias anteriores, com um sinalizador de performance
   (custo por compra menor = melhorou). Serve para dashboards completos e
   para os do esqueleto: basta incluir <script defer src="m7-vendas-semana.js">.
   ========================================================= */
(function () {
  var V = window.M7_DADOS && window.M7_DADOS.vendas_semana;
  if (!V || !V.atual || !V.anterior) return;

  var brl = function (v) { return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var int = function (v) { return Math.round(v || 0).toLocaleString('pt-BR'); };
  var dia = function (s) { var p = String(s).split('-'); return p[2] + '/' + p[1]; };
  var periodo = function (x) { return dia(x.ini) + ' a ' + dia(x.fim); };
  var cpa = function (x) { return x.cmp ? x.gas / x.cmp : null; };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  var css = '.m7vs-grid{display:grid;grid-template-columns:1.1fr 1fr 1fr;gap:16px;align-items:stretch}' +
    '.m7vs-box{background:rgba(155,174,217,.05);border:1px solid rgba(155,174,217,.14);border-radius:12px;padding:16px}' +
    '.m7vs-l{font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#9BAED9}' +
    '.m7vs-v{font-size:30px;font-weight:700;color:#F4F2EA;margin:6px 0 2px;font-family:Quicksand,Poppins,sans-serif}' +
    '.m7vs-s{font-size:12.5px;color:#9BAED9;line-height:1.5}' +
    '.m7vs-sinal{display:inline-flex;align-items:center;gap:8px;padding:8px 14px;border-radius:999px;font-weight:700;font-size:14px;margin-top:4px}' +
    '.m7vs-sinal.bom{background:rgba(46,204,113,.14);color:#4ADE80;border:1px solid rgba(74,222,128,.35)}' +
    '.m7vs-sinal.ruim{background:rgba(239,68,68,.12);color:#F87171;border:1px solid rgba(248,113,113,.35)}' +
    '.m7vs-sinal.neutro{background:rgba(155,174,217,.10);color:#C9D3EE;border:1px solid rgba(155,174,217,.3)}' +
    '.m7vs-dot{width:10px;height:10px;border-radius:50%;background:currentColor;box-shadow:0 0 0 4px rgba(255,255,255,.04)}' +
    '.m7vs-camp{font-size:11.5px;color:#7E8DB3;margin-top:12px}' +
    '@media(max-width:900px){.m7vs-grid{grid-template-columns:1fr}}';

  function sinal() {
    var a = cpa(V.atual), b = cpa(V.anterior);
    if (a == null && b == null) return { c: 'neutro', t: 'Sem compras nas duas semanas', d: '' };
    if (a == null) return { c: 'ruim', t: 'Sem compras nesta semana', d: 'semana anterior: ' + brl(b) + ' por compra' };
    if (b == null) return { c: 'bom', t: 'Voltou a vender', d: 'semana anterior sem compras' };
    var d = (a - b) / b * 100, txt = (d > 0 ? '+' : '') + d.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%';
    if (d <= -5) return { c: 'bom', t: 'Melhorou · custo ' + txt, d: 'cada compra saiu ' + brl(b - a) + ' mais barata' };
    if (d >= 5) return { c: 'ruim', t: 'Piorou · custo ' + txt, d: 'cada compra saiu ' + brl(a - b) + ' mais cara' };
    return { c: 'neutro', t: 'Estável · custo ' + txt, d: 'variação abaixo de 5%' };
  }

  function html() {
    var titulo = '<div class="chart-header"><div class="chart-title"><i class="fa-solid fa-cart-shopping"></i> Campanha de Vendas · Custo por Compra na Semana</div></div>';
    if (!V.campanhas || !V.campanhas.length) {
      return '<div class="chart-card m7vs">' + titulo + '<p class="m7vs-s" style="margin:4px 0 0">Nenhuma campanha de vendas rodando no Meta Ads entre ' + dia(V.anterior.ini) + ' e ' + dia(V.atual.fim) + '. As campanhas ativas são de tráfego e reconhecimento, que não otimizam para compra.</p></div>';
    }
    var a = V.atual, b = V.anterior, s = sinal(), ca = cpa(a), cb = cpa(b);
    var roas = function (x) { return x.gas && x.fat ? ' · retorno ' + (x.fat / x.gas).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + 'x' : ''; };
    return '<div class="chart-card m7vs">' + titulo +
      '<div class="m7vs-grid">' +
      '<div class="m7vs-box"><div class="m7vs-l">Últimos 7 dias · ' + periodo(a) + '</div><div class="m7vs-v">' + (ca == null ? '—' : brl(ca)) + '</div>' +
      '<div class="m7vs-s">por compra · ' + int(a.cmp) + ' compras · investido ' + brl(a.gas) + '<br>vendas atribuídas ' + brl(a.fat) + roas(a) + '</div></div>' +
      '<div class="m7vs-box"><div class="m7vs-l">Semana anterior · ' + periodo(b) + '</div><div class="m7vs-v" style="color:#C9D3EE">' + (cb == null ? '—' : brl(cb)) + '</div>' +
      '<div class="m7vs-s">por compra · ' + int(b.cmp) + ' compras · investido ' + brl(b.gas) + '<br>vendas atribuídas ' + brl(b.fat) + roas(b) + '</div></div>' +
      '<div class="m7vs-box"><div class="m7vs-l">Performance vs semana anterior</div>' +
      '<div class="m7vs-sinal ' + s.c + '"><span class="m7vs-dot"></span>' + esc(s.t) + '</div>' +
      '<div class="m7vs-s" style="margin-top:10px">' + esc(s.d) + '</div></div>' +
      '</div>' +
      '<div class="m7vs-camp">Custo por compra = investimento ÷ compras atribuídas pelo pixel. Campanha' + (V.campanhas.length > 1 ? 's' : '') + ': ' + V.campanhas.map(esc).join(' + ') + ' · atualizado em ' + dia(V.atualizado) + '/' + String(V.atualizado).slice(0, 4) + '</div>' +
      '</div>';
  }

  // Página do Marketing 360°: item do menu com esse nome (switchPage('pX') ou data-page="pX").
  function pagina() {
    var itens = document.querySelectorAll('.nav-item');
    for (var i = 0; i < itens.length; i++) {
      if (!/Marketing 360/i.test(itens[i].textContent)) continue;
      var id = itens[i].getAttribute('data-page') || ((itens[i].getAttribute('onclick') || '').match(/switchPage\('([^']+)'\)/) || [])[1];
      if (id) return document.getElementById(id);
    }
    return null;
  }

  var pronto = false;
  function inserir() {
    var p = pagina();
    if (!p || p.querySelector('.m7vs')) return;
    if (!pronto) { var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st); pronto = true; }
    // Entra logo no topo da página, antes dos cards (depois de filtros/cabeçalho, se houver).
    var alvo = p.querySelector('.kpi-grid, .grid-2, .chart-card');
    var box = document.createElement('div'); box.innerHTML = html();
    var el = box.firstChild;
    if (alvo && alvo.parentNode === p) p.insertBefore(el, alvo); else p.insertBefore(el, p.firstChild);
  }

  function iniciar() {
    inserir();
    // Os dashboards do esqueleto redesenham as páginas ao trocar o mês: recoloca o quadro.
    var raiz = document.getElementById('paginas');
    if (raiz && window.MutationObserver) new MutationObserver(inserir).observe(raiz, { childList: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
