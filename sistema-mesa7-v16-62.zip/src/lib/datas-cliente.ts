// Datas comemorativas escolhidas por cada cliente (no próprio dashboard).
// Fica em <pasta de arquivos>/<pasta>/_dados/datas.json — fora do código,
// sobrevive a atualizações de versão.
import { promises as fs } from "node:fs";
import path from "node:path";
import { raizArquivos } from "@/lib/arquivos";
import { dashboardPorPasta } from "@/lib/dashboards";
import { idValido, MARCADAS_PARA_TODOS, proximaDataPropria, proximos12Meses, hojeSP } from "@/lib/datas-comemorativas";

export type DataPropria = { id: string; nome: string; mmdd: string };

export type SelecaoDatas = {
  selecionadas: string[];
  /** Datas de MARCADAS_PARA_TODOS que o cliente desmarcou (não voltam a ser marcadas). */
  desmarcadas?: string[];
  proprias: DataPropria[];
  obs: string;
  atualizadoEm?: string;
  atualizadoPor?: string;
};

const VAZIA: SelecaoDatas = { selecionadas: [], proprias: [], obs: "" };

function arquivo(pasta: string) {
  return path.join(raizArquivos(), pasta, "_dados", "datas.json");
}

async function lerArquivo(pasta: string): Promise<SelecaoDatas> {
  try {
    return { ...VAZIA, ...JSON.parse(await fs.readFile(arquivo(pasta), "utf8")) };
  } catch {
    return { ...VAZIA };
  }
}

/** Seleção do cliente + as datas que a Mesa7 marca para todos (menos as que ele desmarcou). */
export async function lerSelecao(pasta: string): Promise<SelecaoDatas> {
  const sel = await lerArquivo(pasta);
  const fora = new Set(sel.desmarcadas ?? []);
  const padrao = MARCADAS_PARA_TODOS.filter((id) => !fora.has(id));
  return { ...sel, selecionadas: [...new Set([...sel.selecionadas, ...padrao])] };
}

/** Valida e limpa o que veio do navegador antes de gravar. */
export function limparSelecao(bruto: unknown): SelecaoDatas {
  const b = (bruto ?? {}) as Partial<Record<keyof SelecaoDatas, unknown>>;
  const selecionadas = Array.isArray(b.selecionadas)
    ? [...new Set(b.selecionadas.map(String).filter(idValido))]
    : [];
  const proprias: DataPropria[] = Array.isArray(b.proprias)
    ? b.proprias
        .slice(0, 40)
        .map((p) => {
          const x = (p ?? {}) as Record<string, unknown>;
          const nome = String(x.nome ?? "").trim().slice(0, 80);
          const mmdd = String(x.mmdd ?? "");
          const ok = /^(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/.test(mmdd);
          const id = /^[a-z0-9-]{1,40}$/.test(String(x.id)) ? String(x.id) : `p-${Math.random().toString(36).slice(2, 10)}`;
          return ok && nome ? { id, nome, mmdd } : null;
        })
        .filter((p): p is DataPropria => !!p)
    : [];
  const obs = String(b.obs ?? "").slice(0, 2000);
  const desmarcadas = MARCADAS_PARA_TODOS.filter((id) => !selecionadas.includes(id));
  return { selecionadas, desmarcadas, proprias, obs };
}

export async function salvarSelecao(pasta: string, sel: SelecaoDatas, quem: string) {
  if (!dashboardPorPasta(pasta)) throw new Error("Cliente inválido.");
  const dados: SelecaoDatas = { ...sel, atualizadoEm: new Date().toISOString(), atualizadoPor: quem };
  await fs.mkdir(path.dirname(arquivo(pasta)), { recursive: true });
  await fs.writeFile(arquivo(pasta), JSON.stringify(dados, null, 2));
  return dados;
}

export type ItemCalendario = { id: string; nome: string; data: string; cat: string; propria: boolean; obs?: string };

/** Calendário do cliente: datas escolhidas + datas da casa, próximos 12 meses. */
export async function calendarioDoCliente(pasta: string, hoje = hojeSP()) {
  const sel = await lerSelecao(pasta);
  const escolhidas = new Set(sel.selecionadas);
  const itens: ItemCalendario[] = [
    ...proximos12Meses(hoje)
      .filter((o) => escolhidas.has(o.id))
      .map((o) => ({ ...o, propria: false })),
    ...sel.proprias.map((p) => ({ id: p.id, nome: p.nome, data: proximaDataPropria(p.mmdd, hoje), cat: "Da casa", propria: true })),
  ].sort((a, b) => a.data.localeCompare(b.data));
  return { sel, itens };
}

/** Script injetado no dashboard com o catálogo e a seleção atual. */
export async function scriptDatas(pasta: string, nome: string) {
  const dados = { cliente: nome, catalogo: proximos12Meses(), selecao: await lerSelecao(pasta) };
  return `<script>window.M7_DATAS=${JSON.stringify(dados).replace(/</g, "\\u003c")};</script><script defer src="m7-datas.js"></script>`;
}
