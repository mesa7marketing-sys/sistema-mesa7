// Catálogo de datas comemorativas usadas no planejamento de conteúdo e
// campanhas dos restaurantes. As móveis (Carnaval, Páscoa, Dia das Mães...)
// são calculadas para cada ano.

export type Categoria = "Feriado" | "Comercial" | "Gastronomia" | "Temática";

type Regra =
  | { tipo: "fixa"; mes: number; dia: number }
  | { tipo: "pascoa"; offset: number }
  | { tipo: "enesimo"; mes: number; semana: number; n: number } // n-ésimo dia da semana (0=domingo) do mês
  | { tipo: "blackfriday" }
  | { tipo: "mensal"; dia: number }; // todo mês, no mesmo dia (mostra a próxima ocorrência)

export type DataCatalogo = { id: string; nome: string; cat: Categoria; regra: Regra; obs?: string };

const fixa = (mes: number, dia: number): Regra => ({ tipo: "fixa", mes, dia });

export const CATALOGO: DataCatalogo[] = [
  { id: "ano-novo", nome: "Ano Novo", cat: "Feriado", regra: fixa(1, 1) },
  { id: "dia-do-queijo", nome: "Dia Mundial do Queijo", cat: "Gastronomia", regra: fixa(1, 20) },
  { id: "carnaval", nome: "Carnaval", cat: "Feriado", regra: { tipo: "pascoa", offset: -47 }, obs: "terça-feira de Carnaval" },
  { id: "dia-da-mulher", nome: "Dia Internacional da Mulher", cat: "Comercial", regra: fixa(3, 8) },
  { id: "dia-do-consumidor", nome: "Dia do Consumidor", cat: "Comercial", regra: fixa(3, 15) },
  { id: "sexta-santa", nome: "Sexta-feira Santa", cat: "Feriado", regra: { tipo: "pascoa", offset: -2 } },
  { id: "pascoa", nome: "Páscoa", cat: "Comercial", regra: { tipo: "pascoa", offset: 0 } },
  { id: "tiradentes", nome: "Tiradentes", cat: "Feriado", regra: fixa(4, 21) },
  { id: "dia-do-churrasco", nome: "Dia do Churrasco", cat: "Gastronomia", regra: fixa(4, 24) },
  { id: "dia-do-trabalhador", nome: "Dia do Trabalhador", cat: "Feriado", regra: fixa(5, 1) },
  { id: "dia-das-maes", nome: "Dia das Mães", cat: "Comercial", regra: { tipo: "enesimo", mes: 5, semana: 0, n: 2 } },
  { id: "dia-do-hamburguer", nome: "Dia do Hambúrguer", cat: "Gastronomia", regra: fixa(5, 28) },
  { id: "corpus-christi", nome: "Corpus Christi", cat: "Feriado", regra: { tipo: "pascoa", offset: 60 } },
  { id: "dia-dos-namorados", nome: "Dia dos Namorados", cat: "Comercial", regra: fixa(6, 12) },
  { id: "dia-do-sushi", nome: "Dia Internacional do Sushi", cat: "Gastronomia", regra: fixa(6, 18) },
  { id: "sao-joao", nome: "São João / Festa Junina", cat: "Temática", regra: fixa(6, 24) },
  { id: "dia-do-chocolate", nome: "Dia Mundial do Chocolate", cat: "Gastronomia", regra: fixa(7, 7) },
  { id: "dia-da-pizza", nome: "Dia da Pizza", cat: "Gastronomia", regra: fixa(7, 10) },
  { id: "dia-do-rock", nome: "Dia Mundial do Rock", cat: "Temática", regra: fixa(7, 13) },
  { id: "dia-do-amigo", nome: "Dia do Amigo", cat: "Comercial", regra: fixa(7, 20) },
  { id: "dia-dos-avos", nome: "Dia dos Avós", cat: "Comercial", regra: fixa(7, 26) },
  { id: "dia-da-cerveja", nome: "Dia Internacional da Cerveja", cat: "Gastronomia", regra: { tipo: "enesimo", mes: 8, semana: 5, n: 1 }, obs: "1ª sexta-feira de agosto" },
  { id: "dia-dos-pais", nome: "Dia dos Pais", cat: "Comercial", regra: { tipo: "enesimo", mes: 8, semana: 0, n: 2 } },
  { id: "dia-do-garcom", nome: "Dia do Garçom", cat: "Temática", regra: fixa(8, 11) },
  { id: "dia-do-nutricionista", nome: "Dia do Nutricionista", cat: "Temática", regra: fixa(8, 31) },
  { id: "independencia", nome: "Independência do Brasil", cat: "Feriado", regra: fixa(9, 7) },
  { id: "dia-do-cliente", nome: "Dia do Cliente", cat: "Comercial", regra: fixa(9, 15) },
  { id: "dia-do-sorvete", nome: "Dia do Sorvete", cat: "Gastronomia", regra: fixa(9, 23) },
  { id: "dia-do-cafe", nome: "Dia Internacional do Café", cat: "Gastronomia", regra: fixa(10, 1) },
  { id: "dia-do-vegetarianismo", nome: "Dia Mundial do Vegetarianismo", cat: "Gastronomia", regra: fixa(10, 1) },
  { id: "dia-das-criancas", nome: "Dia das Crianças", cat: "Comercial", regra: fixa(10, 12), obs: "feriado de Nossa Senhora Aparecida" },
  { id: "dia-da-alimentacao", nome: "Dia Mundial da Alimentação", cat: "Gastronomia", regra: fixa(10, 16) },
  { id: "halloween", nome: "Halloween", cat: "Temática", regra: fixa(10, 31) },
  { id: "dia-do-veganismo", nome: "Dia Mundial do Veganismo", cat: "Gastronomia", regra: fixa(11, 1) },
  { id: "dia-do-sushi-brasil", nome: "Dia do Sushi (Brasil)", cat: "Gastronomia", regra: fixa(11, 1) },
  { id: "dia-do-sanduiche", nome: "Dia Mundial do Sanduíche", cat: "Gastronomia", regra: fixa(11, 3) },
  { id: "dia-do-trigo", nome: "Dia Nacional do Trigo", cat: "Gastronomia", regra: fixa(11, 10) },
  { id: "dia-do-supermercado", nome: "Dia do Supermercado", cat: "Comercial", regra: fixa(11, 12) },
  { id: "finados", nome: "Finados", cat: "Feriado", regra: fixa(11, 2) },
  { id: "proclamacao", nome: "Proclamação da República", cat: "Feriado", regra: fixa(11, 15) },
  { id: "consciencia-negra", nome: "Dia da Consciência Negra", cat: "Feriado", regra: fixa(11, 20) },
  { id: "black-friday", nome: "Black Friday", cat: "Comercial", regra: { tipo: "blackfriday" } },
  { id: "dia-do-samba", nome: "Dia Nacional do Samba", cat: "Temática", regra: fixa(12, 2) },
  { id: "dia-do-cookie", nome: "Dia do Cookie", cat: "Gastronomia", regra: fixa(12, 4) },
  { id: "dia-do-brownie", nome: "Dia do Brownie", cat: "Gastronomia", regra: fixa(12, 8) },
  { id: "dia-do-profissional-de-culinaria", nome: "Dia do Profissional de Culinária", cat: "Temática", regra: fixa(12, 9) },
  { id: "inicio-do-verao", nome: "Início do Verão", cat: "Temática", regra: fixa(12, 21), obs: "bom para cardápios mais leves e sazonais" },
  { id: "vespera-natal", nome: "Véspera de Natal", cat: "Comercial", regra: fixa(12, 24) },
  { id: "natal", nome: "Natal", cat: "Feriado", regra: fixa(12, 25), obs: "ceias e menus especiais" },
  { id: "reveillon", nome: "Véspera de Ano Novo / Réveillon", cat: "Comercial", regra: fixa(12, 31) },
  { id: "nhoque-da-fortuna", nome: "Dia do Nhoque da Fortuna", cat: "Gastronomia", regra: { tipo: "mensal", dia: 29 }, obs: "todo dia 29" },
];

/** Datas que a Mesa7 já deixa marcadas para todos os clientes (novembro e dezembro).
 *  O cliente pode desmarcar; o que ele desmarcou fica guardado e não volta. */
export const MARCADAS_PARA_TODOS = [
  "dia-do-veganismo", "dia-do-sushi-brasil", "dia-do-sanduiche", "dia-do-trigo", "dia-do-supermercado", "black-friday",
  "dia-do-cookie", "dia-do-brownie", "dia-do-profissional-de-culinaria", "inicio-do-verao", "natal", "reveillon", "nhoque-da-fortuna",
];

const IDS = new Set(CATALOGO.map((d) => d.id));
export const idValido = (id: string) => IDS.has(id);

/** Domingo de Páscoa (algoritmo de Meeus/Jones/Butcher). */
function pascoa(ano: number) {
  const a = ano % 19, b = Math.floor(ano / 100), c = ano % 100;
  const d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const mes = Math.floor((h + l - 7 * m + 114) / 31), dia = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(Date.UTC(ano, mes - 1, dia));
}

function enesimo(ano: number, mes: number, semana: number, n: number) {
  const primeiro = new Date(Date.UTC(ano, mes - 1, 1));
  const desloc = (semana - primeiro.getUTCDay() + 7) % 7;
  return new Date(Date.UTC(ano, mes - 1, 1 + desloc + (n - 1) * 7));
}

function naData(regra: Regra, ano: number) {
  switch (regra.tipo) {
    case "fixa":
      return new Date(Date.UTC(ano, regra.mes - 1, regra.dia));
    case "pascoa": {
      const p = pascoa(ano);
      p.setUTCDate(p.getUTCDate() + regra.offset);
      return p;
    }
    case "enesimo":
      return enesimo(ano, regra.mes, regra.semana, regra.n);
    case "mensal":
      return new Date(Date.UTC(ano, 0, regra.dia));
    case "blackfriday": {
      const quinta = enesimo(ano, 11, 4, 4);
      quinta.setUTCDate(quinta.getUTCDate() + 1);
      return quinta;
    }
  }
}

const iso = (d: Date) => d.toISOString().slice(0, 10);

/** Hoje no fuso de São Paulo, como AAAA-MM-DD. */
export function hojeSP(agora = new Date()) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" }).format(agora);
}

/** Próximo dia N (a partir de hoje); pula meses que não têm esse dia (ex.: 29 em fevereiro). */
function proximoDiaDoMes(dia: number, hoje: string) {
  let ano = Number(hoje.slice(0, 4)), mes = Number(hoje.slice(5, 7)) - 1;
  for (;;) {
    const d = new Date(Date.UTC(ano, mes, dia));
    if (d.getUTCMonth() === mes && iso(d) >= hoje) return iso(d);
    if (++mes > 11) { mes = 0; ano++; }
  }
}

export type Ocorrencia = { id: string; nome: string; cat: Categoria; data: string; obs?: string };

/** Próxima ocorrência de cada data (a partir de hoje), em ordem cronológica — 12 meses. */
export function proximos12Meses(hoje = hojeSP()): Ocorrencia[] {
  const ano = Number(hoje.slice(0, 4));
  const limite = `${ano + 1}${hoje.slice(4)}`;
  return CATALOGO.map((d) => {
    let data = d.regra.tipo === "mensal" ? proximoDiaDoMes(d.regra.dia, hoje) : iso(naData(d.regra, ano));
    if (data < hoje) data = iso(naData(d.regra, ano + 1));
    return { id: d.id, nome: d.nome, cat: d.cat, data, ...(d.obs ? { obs: d.obs } : {}) };
  })
    .filter((o) => o.data < limite)
    .sort((a, b) => a.data.localeCompare(b.data) || a.nome.localeCompare(b.nome, "pt-BR"));
}

/** Próxima ocorrência de uma data da casa guardada como MM-DD. */
export function proximaDataPropria(mmdd: string, hoje = hojeSP()) {
  const ano = Number(hoje.slice(0, 4));
  const deste = `${ano}-${mmdd}`;
  return deste >= hoje ? deste : `${ano + 1}-${mmdd}`;
}
