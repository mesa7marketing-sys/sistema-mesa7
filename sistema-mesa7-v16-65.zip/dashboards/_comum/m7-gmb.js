/* =========================================================
   Google Meu Negócio lançado em "Subir resultados" nos dashboards completos
   que só têm os cards fixos com "Aguardando dados" (Burguin, Duana Centro).
   Lê window.M7_DADOS.gmb e preenche as linhas desses cards conforme o
   período escolhido em #selPeriodo (um mês ou o período completo, somado).
   Só mexe em linhas que estavam "Aguardando dados" — os dashboards que já
   montam o GMN pelo MESES (m7MesclarGmb) não são alterados.
   ========================================================= */
(function () {
  var G = (window.M7_DADOS && window.M7_DADOS.gmb) || {};
  if (!Object.keys(G).length) return;

  var CAMPOS = [
    [/Visualiza[çc][õo]es do Perfil/i, 'v'],
    [/Solicita[çc][õo]es de Rota/i, 'rt'],
    [/Chamadas Telef/i, 'ch'],
    [/Cliques no Site/i, 'st']
  ];
  var int = function (v) { return Math.round(v || 0).toLocaleString('pt-BR'); };

  function mesesDoPeriodo() {
    var sel = document.getElementById('selPeriodo');
    if (!sel) return [];
    if (sel.value !== 'full') return [sel.value];
    return Array.prototype.map.call(sel.options, function (o) { return o.value; }).filter(function (v) { return v !== 'full'; });
  }

  function soma(meses, k) {
    var t = 0, achou = false;
    meses.forEach(function (m) { var g = G[m]; if (g && typeof g[k] === 'number') { t += g[k]; achou = true; } });
    return achou ? t : null;
  }

  // Linhas candidatas: rótulo de GMN e valor "Aguardando dados" (ou já preenchido por este script).
  var linhas = [];
  function coletar() {
    Array.prototype.forEach.call(document.querySelectorAll('.data-table tr'), function (tr) {
      if (tr.cells.length !== 2) return;
      var rot = tr.cells[0].textContent || '';
      if (/Google Ads/i.test(rot)) return;
      for (var i = 0; i < CAMPOS.length; i++) {
        if (!CAMPOS[i][0].test(rot)) continue;
        if (tr.cells[1].querySelector('.wait')) linhas.push({ td: tr.cells[1], k: CAMPOS[i][1], vazio: tr.cells[1].innerHTML });
        return;
      }
    });
  }

  function preencher() {
    var meses = mesesDoPeriodo();
    linhas.forEach(function (l) {
      var v = soma(meses, l.k);
      l.td.innerHTML = v == null ? l.vazio : '<strong>' + int(v) + '</strong>';
    });
  }

  function iniciar() {
    coletar();
    if (!linhas.length) return;
    preencher();
    var sel = document.getElementById('selPeriodo');
    if (sel) sel.addEventListener('change', function () { setTimeout(preencher, 0); });
    var limpar = document.querySelector('[onclick*="resetFiltros"]');
    if (limpar) limpar.addEventListener('click', function () { setTimeout(preencher, 0); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
