import { dashboardPorPasta, lerArquivoDashboard } from "@/lib/dashboards";
import { acessoLiberado } from "@/lib/acesso-cliente";
import { scriptDados } from "@/lib/dados-clientes";
import { scriptDatas } from "@/lib/datas-cliente";

// Serve os arquivos do dashboard (HTML, scripts comuns e logos). Precisa da senha do
// cliente já digitada (ou estar logado como equipe).
export async function GET(_: Request, ctx: RouteContext<"/[cliente]/dashboard/arquivo/[...arquivo]">) {
  const { cliente, arquivo } = await ctx.params;
  const dashboard = dashboardPorPasta(cliente);
  if (!dashboard) return new Response("Não encontrado", { status: 404 });
  if (!(await acessoLiberado(dashboard.pasta))) return new Response("Acesso com senha", { status: 401 });

  const lido = await lerArquivoDashboard(dashboard, arquivo);
  if (!lido) return new Response("Não encontrado", { status: 404 });

  // Os dados enviados pela equipe / integrações entram antes de qualquer script do dashboard.
  if (typeof lido.corpo === "string") {
    const dados = await scriptDados(dashboard.pasta);
    lido.corpo = lido.corpo.includes("<head>") ? lido.corpo.replace("<head>", `<head>${dados}`) : dados + lido.corpo;
    // Tema preto da Mesa7 (logo + fontes), seguidores do Instagram e top 5 anúncios em todos os dashboards.
    const tema = '<link rel="stylesheet" href="m7-tema.css">\n<script defer src="m7-instagram.js"></script>\n<script defer src="m7-anuncios.js"></script>';
    lido.corpo = lido.corpo.includes("</head>") ? lido.corpo.replace("</head>", `${tema}\n</head>`) : lido.corpo + tema;
    if (dashboard.status === "completo") {
      // Plataformas (gráficos de 12 meses e, se faltar, a página) — antes das datas, para a numeração
      // do menu contar a página — e o destaque do Resumo Executivo (faturamento grande + pílulas).
      const plat = '<script defer src="m7-plataformas.js"></script>\n<script defer src="m7-hero.js"></script>\n<script defer src="m7-mensal.js"></script>\n<script defer src="m7-gmb.js"></script>';
      lido.corpo = lido.corpo.includes("</head>") ? lido.corpo.replace("</head>", `${plat}\n</head>`) : lido.corpo + plat;
    }
    // Página de datas comemorativas (liga por cliente em src/lib/dashboards.ts). Vem depois do "Voltar".
    if (dashboard.datas) {
      const datas = await scriptDatas(dashboard.pasta, dashboard.nome);
      lido.corpo = lido.corpo.includes("</head>") ? lido.corpo.replace("</head>", `${datas}\n</head>`) : lido.corpo + datas;
    }
    // Menu igual para todos: esconde Metas 30/60/90, cria Promoções e renumera (roda por último).
    const paginas = '<script defer src="m7-paginas.js"></script>';
    lido.corpo = lido.corpo.includes("</head>") ? lido.corpo.replace("</head>", `${paginas}\n</head>`) : lido.corpo + paginas;
  }

  return new Response(new Uint8Array(typeof lido.corpo === "string" ? Buffer.from(lido.corpo) : lido.corpo), {
    headers: {
      "Content-Type": lido.tipo,
      "Cache-Control": "no-store",
      "X-Robots-Tag": "noindex, nofollow",
      "Referrer-Policy": "no-referrer",
    },
  });
}
