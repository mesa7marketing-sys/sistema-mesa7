import { promises as fs } from "node:fs";
import path from "node:path";
import { ImageResponse } from "next/og";
import { dashboardPorPasta } from "@/lib/dashboards";

// Imagem da prévia do link (WhatsApp, Instagram...): logo do cliente + nome, no preto da Mesa7.
// É pública de propósito — o WhatsApp busca a prévia sem senha — e não mostra nenhum dado.
const RAIZ = path.join(process.cwd(), "dashboards");

async function dataUrl(arquivo: string) {
  try {
    const buf = await fs.readFile(arquivo);
    const tipo = arquivo.endsWith(".jpg") || arquivo.endsWith(".jpeg") ? "image/jpeg" : "image/png";
    return `data:${tipo};base64,${buf.toString("base64")}`;
  } catch {
    return null;
  }
}

/** Logo do cliente: o arquivo *-logo.png/jpg da pasta dele (ex.: arcoiris-logo.png). */
async function logoDoCliente(pasta: string) {
  try {
    const nomes = await fs.readdir(path.join(RAIZ, pasta));
    const logo = nomes.find((n) => /logo\.(png|jpe?g)$/i.test(n) && !/mesa7/i.test(n));
    return logo ? dataUrl(path.join(RAIZ, pasta, logo)) : null;
  } catch {
    return null;
  }
}

export async function GET(_: Request, ctx: RouteContext<"/[cliente]/dashboard/capa">) {
  const { cliente } = await ctx.params;
  const d = dashboardPorPasta(cliente);
  if (!d) return new Response("Não encontrado", { status: 404 });

  const [logo, mesa7] = await Promise.all([logoDoCliente(d.pasta), dataUrl(path.join(RAIZ, "_comum", "mesa7-logo.png"))]);

  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "#000", color: "#F4F2EA", gap: 34 }}>
        {logo ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logo} width={300} height={300} alt="" style={{ borderRadius: 48, objectFit: "contain" }} />
        ) : mesa7 ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={mesa7} width={420} height={137} alt="" />
        ) : null}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
          <div style={{ fontSize: 46, fontWeight: 700, textAlign: "center", maxWidth: 540 }}>{d.nome}</div>
          <div style={{ display: "flex", alignItems: "center", gap: 14, fontSize: 24, color: "#F98612", letterSpacing: 4, textTransform: "uppercase" }}>
            Dashboard
            {logo && mesa7 ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={mesa7} width={110} height={36} alt="" />
            ) : null}
          </div>
        </div>
      </div>
    ),
    { width: 600, height: 600, headers: { "Cache-Control": "public, max-age=3600" } },
  );
}
