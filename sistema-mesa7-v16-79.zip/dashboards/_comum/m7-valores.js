/* =========================================================
   Valor escrito em cada ponto do gráfico "Evolução de Faturamento"
   (canvas #chartEvolucao) dos dashboards completos. Plugin do Chart.js,
   registrado antes de o dashboard criar os gráficos (no evento load).
   ========================================================= */
(function () {
  if (typeof Chart === 'undefined' || !Chart.register) return;
  var ALVOS = ['chartEvolucao'];
  function curto(v) {
    var a = Math.abs(v);
    if (a >= 1e6) return 'R$ ' + (v / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + ' mi';
    if (a >= 1e3) return 'R$ ' + (v / 1e3).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + 'k';
    return 'R$ ' + Math.round(v).toLocaleString('pt-BR');
  }
  Chart.register({
    id: 'm7Valores',
    beforeInit: function (chart) {
      if (ALVOS.indexOf(chart.canvas.id) < 0) return;
      var lay = chart.options.layout || (chart.options.layout = {});
      var pad = lay.padding;
      lay.padding = typeof pad === 'object' && pad ? Object.assign({}, pad, { top: Math.max(pad.top || 0, 26) }) : { top: 26, left: pad || 0, right: (pad || 0) + 8, bottom: pad || 0 };
    },
    afterDatasetsDraw: function (chart) {
      if (ALVOS.indexOf(chart.canvas.id) < 0) return;
      var ctx = chart.ctx;
      ctx.save();
      ctx.font = '600 11px Poppins, system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      chart.data.datasets.forEach(function (ds, i) {
        var meta = chart.getDatasetMeta(i);
        if (meta.hidden || meta.type !== 'line') return;
        var ant = null;   // caixa do rótulo anterior: se encostar, este sobe uma linha
        meta.data.forEach(function (pt, j) {
          var v = ds.data[j];
          if (v == null || isNaN(v) || pt.skip) return;
          var x = Math.min(Math.max(pt.x, chart.chartArea.left + 26), chart.chartArea.right - 26);
          var y = pt.y - 9, txt = curto(+v), w = ctx.measureText(txt).width;
          if (ant && x - w / 2 - 4 < ant.x2 + 2 && Math.abs(y - ant.y) < 17) y = ant.y - 18;
          ant = { x2: x + w / 2 + 4, y: y };
          ctx.fillStyle = 'rgba(13,13,16,.85)';
          ctx.fillRect(x - w / 2 - 4, y - 15, w + 8, 16);
          ctx.fillStyle = '#F4F2EA';
          ctx.fillText(txt, x, y);
        });
      });
      ctx.restore();
    }
  });
})();
