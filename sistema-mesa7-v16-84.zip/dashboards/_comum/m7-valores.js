/* =========================================================
   Valor escrito em cada ponto do gráfico "Evolução de Faturamento"
   (canvas #chartEvolucao) dos dashboards completos. Plugin do Chart.js,
   registrado antes de o dashboard criar os gráficos (no evento load).
   ========================================================= */
(function () {
  if (typeof Chart === 'undefined' || !Chart.register) return;
  var ALVOS = ['chartEvolucao'];
  function curto(v) {
    var a = Math.abs(v);
    if (a >= 1e6) return 'R$ ' + (v / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + ' mi';
    if (a >= 1e3) return 'R$ ' + (v / 1e3).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + 'k';
    return 'R$ ' + Math.round(v).toLocaleString('pt-BR');
  }
  Chart.register({
    id: 'm7Valores',
    beforeInit: function (chart) {
      if (ALVOS.indexOf(chart.canvas.id) < 0) return;
      var lay = chart.options.layout || (chart.options.layout = {});
      var pad = lay.padding;
      lay.padding = typeof pad === 'object' && pad ? Object.assign({}, pad, { top: Math.max(pad.top || 0, 40) }) : { top: 40, left: pad || 0, right: (pad || 0) + 8, bottom: pad || 0 };
    },
    afterDatasetsDraw: function (chart) {
      if (ALVOS.indexOf(chart.canvas.id) < 0) return;
      var ctx = chart.ctx;
      ctx.save();
      ctx.font = '600 11px Poppins, system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      chart.data.datasets.forEach(function (ds, i) {
        var meta = chart.getDatasetMeta(i);
        if (meta.hidden || meta.type !== 'line') return;
        var ant = null;   // caixa do rótulo anterior: se encostar, este sobe uma linha
        meta.data.forEach(function (pt, j) {
          var v = ds.data[j];
          if (v == null || isNaN(v) || pt.skip) return;
          var x = Math.min(Math.max(pt.x, chart.chartArea.left + 26), chart.chartArea.right - 26);
          // Comparativo com o mês anterior (só quando o ponto anterior existe).
          var p = j > 0 ? ds.data[j - 1] : null, d = p != null && !isNaN(p) && +p ? (+v - p) / p * 100 : null;
          var dt = d == null ? '' : (d > 0 ? '▲ +' : d < 0 ? '▼ ' : '') + d.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%';
          var txt = curto(+v), w = ctx.measureText(txt).width;
          ctx.font = '600 10px Poppins, system-ui, sans-serif'; var w2 = dt ? ctx.measureText(dt).width : 0; ctx.font = '600 11px Poppins, system-ui, sans-serif';
          var bw = Math.max(w, w2), h = dt ? 29 : 16, y = pt.y - 9;
          if (ant && x - bw / 2 - 4 < ant.x2 + 2 && Math.abs(y - ant.y) < Math.max(h, ant.h) + 1) y = ant.y - ant.h - 2;
          if (y - h < 2) y = pt.y + 12 + h;   // sem espaço em cima: vai para baixo do ponto
          if (ant && x - bw / 2 - 4 < ant.x2 + 2 && Math.abs(y - ant.y) < Math.max(h, ant.h) + 1) y = ant.y + ant.h + 2;
          ant = { x2: x + bw / 2 + 4, y: y, h: h };
          ctx.fillStyle = 'rgba(13,13,16,.88)';
          ctx.fillRect(x - bw / 2 - 4, y - h + 1, bw + 8, h);
          ctx.fillStyle = '#F4F2EA';
          ctx.fillText(txt, x, dt ? y - 13 : y);
          if (dt) { ctx.font = '600 10px Poppins, system-ui, sans-serif'; ctx.fillStyle = d >= 0 ? '#9BAED9' : '#F98612'; ctx.fillText(dt, x, y); ctx.font = '600 11px Poppins, system-ui, sans-serif'; }
        });
      });
      ctx.restore();
    }
  });
})();
