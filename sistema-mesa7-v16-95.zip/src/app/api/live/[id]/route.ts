import { NextResponse } from "next/server";
import { receber } from "@/lib/live";
import { usuarioEquipe } from "@/lib/live-acesso";

export const dynamic = "force-dynamic";

// Um pedaço (~1 s) do vídeo WebM gravado no navegador. Cabeçalho x-seq = número do pedaço (0, 1, 2…).
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  if (!(await usuarioEquipe())) return NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
  const { id } = await ctx.params;
  const seq = Number(req.headers.get("x-seq"));
  if (!Number.isInteger(seq) || seq < 0) return NextResponse.json({ erro: "x-seq inválido." }, { status: 400 });
  const dados = Buffer.from(await req.arrayBuffer());
  if (dados.length > 4 * 1024 * 1024) return NextResponse.json({ erro: "Pedaço grande demais." }, { status: 413 });
  try {
    return NextResponse.json({ live: await receber(id, seq, dados) });
  } catch (e) {
    return NextResponse.json({ erro: e instanceof Error ? e.message : String(e) }, { status: 409 });
  }
}
