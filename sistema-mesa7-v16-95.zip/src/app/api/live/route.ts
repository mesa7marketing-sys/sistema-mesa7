import { NextResponse } from "next/server";
import { usuarioEquipe } from "@/lib/live-acesso";
import { dashboardPorPasta } from "@/lib/dashboards";
import { encerrar, estado, iniciar, liveAtiva, type Destino } from "@/lib/live";

export const dynamic = "force-dynamic";

// GET: situação da live (?id=...) ou a que estiver no ar.
export async function GET(req: Request) {
  if (!(await usuarioEquipe())) return NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
  const id = new URL(req.url).searchParams.get("id");
  const s = id ? estado(id) : (() => { const a = liveAtiva(); return a ? estado(a.id) : null; })();
  return NextResponse.json({ live: s });
}

// POST { acao: "iniciar", pasta, destinos: [{ nome, servidor, chave }] } | { acao: "encerrar", id }
export async function POST(req: Request) {
  const usuario = await usuarioEquipe();
  if (!usuario) return NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
  let b: { acao?: string; id?: string; pasta?: string; destinos?: Destino[] };
  try { b = await req.json(); } catch { return NextResponse.json({ erro: "Pedido inválido." }, { status: 400 }); }
  try {
    if (b.acao === "encerrar" && b.id) return NextResponse.json({ live: encerrar(b.id) });
    if (b.acao === "iniciar") {
      const pasta = String(b.pasta || "");
      if (!dashboardPorPasta(pasta)) throw new Error("Escolha o cliente.");
      const destinos = (Array.isArray(b.destinos) ? b.destinos : [])
        .filter((d) => d && String(d.chave || "").trim())
        .slice(0, 3)
        .map((d) => ({ nome: String(d.nome || "Destino").slice(0, 30), servidor: String(d.servidor || ""), chave: String(d.chave || "") }));
      const id = iniciar(pasta, usuario, destinos);
      return NextResponse.json({ live: estado(id) });
    }
    return NextResponse.json({ erro: "Ação desconhecida." }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ erro: e instanceof Error ? e.message : String(e) }, { status: 400 });
  }
}
