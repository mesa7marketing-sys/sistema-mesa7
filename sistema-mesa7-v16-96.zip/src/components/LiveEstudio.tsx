"use client";

// Estúdio de live da Mesa7: câmera (ou tela) + logo do cliente + letreiro, desenhados num canvas,
// gravados em pedaços de 1 s (MediaRecorder) e enviados para a VPS, que repassa ao Instagram
// pela chave de transmissão (src/lib/live.ts).
import { useCallback, useEffect, useRef, useState } from "react";

type Cliente = { pasta: string; nome: string };
type Estado = {
  id: string; noAr: boolean; segundos: number; recebidoMB: number; pedacos: number;
  fps: number | null; bitrate: string | null; velocidade: string | null; avisos: string[]; motivo: string | null;
};
type Fonte = "camera" | "tela" | "tela+camera";

const IG_SERVIDOR = "rtmps://live-upload.instagram.com:443/rtmp/";
const FB_SERVIDOR = "rtmps://live-api-s.facebook.com:443/rtmp/";
const MIMES = ["video/webm;codecs=h264,opus", "video/webm;codecs=vp8,opus", "video/webm"];
const FPS = 30;

const caixa: React.CSSProperties = { background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14, padding: 16 };
const rotulo: React.CSSProperties = { fontSize: 11, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--text-muted)", fontWeight: 700, display: "block", marginBottom: 5 };
const campo: React.CSSProperties = { width: "100%", background: "var(--page)", color: "var(--text-primary)", border: "1px solid var(--border-strong)", borderRadius: 9, padding: "9px 11px", fontSize: 13.5 };
const botao = (cor: string, ativo = true): React.CSSProperties => ({
  background: ativo ? cor : "var(--surface-raised)", color: ativo ? "#fff" : "var(--text-muted)", border: "none", borderRadius: 10,
  padding: "11px 18px", fontWeight: 800, fontSize: 14, cursor: ativo ? "pointer" : "not-allowed",
});
const tempo = (s: number) => `${String(Math.floor(s / 3600)).padStart(2, "0")}:${String(Math.floor((s % 3600) / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

export function LiveEstudio({ clientes }: { clientes: Cliente[] }) {
  const [pasta, setPasta] = useState("");
  const [vertical, setVertical] = useState(true);
  const [fonte, setFonte] = useState<Fonte>("camera");
  const [cams, setCams] = useState<MediaDeviceInfo[]>([]);
  const [mics, setMics] = useState<MediaDeviceInfo[]>([]);
  const [camId, setCamId] = useState("");
  const [micId, setMicId] = useState("");
  const [comLogo, setComLogo] = useState(true);
  const [letreiro, setLetreiro] = useState("");
  const [igChave, setIgChave] = useState("");
  const [igServidor, setIgServidor] = useState(IG_SERVIDOR);
  const [fbChave, setFbChave] = useState("");
  const [estado, setEstado] = useState<Estado | null>(null);
  const [erro, setErro] = useState("");
  const [fila, setFila] = useState(0);
  const [enviando, setEnviando] = useState(false);
  const [servidor, setServidor] = useState<string | null | undefined>(undefined);   // versão do ffmpeg na VPS (null = falta)
  const [verificacao, setVerificacao] = useState(0);

  const canvas = useRef<HTMLCanvasElement>(null);
  const vCam = useRef<HTMLVideoElement | null>(null);
  const vTela = useRef<HTMLVideoElement | null>(null);
  const sCam = useRef<MediaStream | null>(null);
  const sTela = useRef<MediaStream | null>(null);
  const logo = useRef<HTMLImageElement | null>(null);
  const audio = useRef<{ ctx: AudioContext; dest: MediaStreamAudioDestinationNode; fontes: MediaStreamAudioSourceNode[] } | null>(null);
  const rec = useRef<MediaRecorder | null>(null);
  const liveId = useRef<string | null>(null);
  const filaRef = useRef<Blob[]>([]);
  const seq = useRef(0);
  const enviandoRef = useRef(false);
  const parar = useRef(false);
  const opc = useRef({ vertical, fonte, comLogo, letreiro, noAr: false });
  useEffect(() => { opc.current = { vertical, fonte, comLogo, letreiro, noAr: !!estado?.noAr }; }, [vertical, fonte, comLogo, letreiro, estado?.noAr]);

  // ---------- a VPS tem o ffmpeg? ----------
  useEffect(() => {
    let vivo = true;
    fetch("/api/live?verificar=1").then((r) => r.json()).then((j) => { if (vivo) setServidor(j.ffmpeg ?? null); }).catch(() => { if (vivo) setServidor(null); });
    return () => { vivo = false; };
  }, [verificacao]);

  // ---------- dispositivos ----------
  const listar = useCallback(async () => {
    const l = await navigator.mediaDevices.enumerateDevices();
    setCams(l.filter((d) => d.kind === "videoinput"));
    setMics(l.filter((d) => d.kind === "audioinput"));
  }, []);

  // Áudio da live = microfone (+ som da tela, se compartilhado), sempre numa trilha só.
  const ligarAudio = useCallback(() => {
    if (!audio.current) {
      const ctx = new AudioContext({ sampleRate: 48000 });
      audio.current = { ctx, dest: ctx.createMediaStreamDestination(), fontes: [] };
    }
    const a = audio.current;
    a.fontes.forEach((f) => f.disconnect());
    a.fontes = [sCam.current, sTela.current]
      .filter((s): s is MediaStream => !!s && s.getAudioTracks().length > 0)
      .map((s) => { const f = a.ctx.createMediaStreamSource(new MediaStream(s.getAudioTracks())); f.connect(a.dest); return f; });
  }, []);

  const abrirCamera = useCallback(async () => {
    sCam.current?.getTracks().forEach((t) => t.stop());
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { deviceId: camId ? { exact: camId } : undefined, width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: FPS } },
        audio: { deviceId: micId ? { exact: micId } : undefined, echoCancellation: true, noiseSuppression: true },
      });
      sCam.current = s;
      if (!vCam.current) { vCam.current = document.createElement("video"); vCam.current.muted = true; vCam.current.playsInline = true; }
      vCam.current.srcObject = s;
      await vCam.current.play().catch(() => {});
      ligarAudio();
      await listar();
      setErro("");
    } catch (e) {
      setErro("Não consegui abrir a câmera/microfone: " + (e instanceof Error ? e.message : String(e)) + ". Libere o acesso no cadeado da barra de endereço.");
    }
  }, [camId, micId, listar, ligarAudio]);

  async function abrirTela() {
    try {
      const s = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: { ideal: FPS } }, audio: true });
      sTela.current?.getTracks().forEach((t) => t.stop());
      sTela.current = s;
      if (!vTela.current) { vTela.current = document.createElement("video"); vTela.current.muted = true; vTela.current.playsInline = true; }
      vTela.current.srcObject = s;
      await vTela.current.play().catch(() => {});
      s.getVideoTracks()[0]?.addEventListener("ended", () => { sTela.current = null; setFonte("camera"); });
      ligarAudio();
    } catch { setFonte("camera"); }
  }

  useEffect(() => { const t = setTimeout(() => void abrirCamera(), 0); return () => clearTimeout(t); }, [abrirCamera]);
  useEffect(() => {
    if (fonte === "camera" || sTela.current) return;
    const t = setTimeout(() => void abrirTela(), 0);
    return () => clearTimeout(t);
  }, [fonte]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    logo.current = null;
    if (!pasta) return;
    const img = new Image();
    img.onload = () => { logo.current = img; };
    img.src = `/api/live/logo/${pasta}`;
  }, [pasta]);

  // ---------- desenho (por um Worker: continua desenhando com a aba em segundo plano) ----------
  useEffect(() => {
    const cv = canvas.current!;
    const ctx = cv.getContext("2d")!;
    const cobrir = (v: HTMLVideoElement, x: number, y: number, w: number, h: number) => {
      if (!v.videoWidth) return;
      const r = Math.max(w / v.videoWidth, h / v.videoHeight), vw = v.videoWidth * r, vh = v.videoHeight * r;
      ctx.drawImage(v, x + (w - vw) / 2, y + (h - vh) / 2, vw, vh);
    };
    const desenhar = () => {
      const o = opc.current, W = o.vertical ? 720 : 1280, H = o.vertical ? 1280 : 720;
      if (cv.width !== W) { cv.width = W; cv.height = H; }
      ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H);
      const cam = vCam.current, tela = vTela.current && sTela.current ? vTela.current : null;
      if (o.fonte !== "camera" && tela) {
        if (o.vertical) { ctx.save(); const r = Math.min(W / tela.videoWidth, H / tela.videoHeight) || 1; const tw = tela.videoWidth * r, th = tela.videoHeight * r; ctx.drawImage(tela, (W - tw) / 2, (H - th) / 2, tw, th); ctx.restore(); }
        else cobrir(tela, 0, 0, W, H);
        if (o.fonte === "tela+camera" && cam) {
          const d = Math.round(Math.min(W, H) * 0.3), cx = W - d / 2 - 28, cy = H - d / 2 - (o.letreiro ? 170 : 40);
          ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, d / 2, 0, Math.PI * 2); ctx.clip(); cobrir(cam, cx - d / 2, cy - d / 2, d, d); ctx.restore();
          ctx.lineWidth = 5; ctx.strokeStyle = "#F98612"; ctx.beginPath(); ctx.arc(cx, cy, d / 2, 0, Math.PI * 2); ctx.stroke();
        }
      } else if (cam) cobrir(cam, 0, 0, W, H);
      if (o.comLogo && logo.current) {
        const s = o.vertical ? 120 : 110;
        ctx.save(); ctx.globalAlpha = 0.95; ctx.beginPath(); ctx.roundRect(28, 28, s, s, 22); ctx.clip();
        ctx.fillStyle = "#fff"; ctx.fillRect(28, 28, s, s); ctx.drawImage(logo.current, 28, 28, s, s); ctx.restore();
      }
      if (o.noAr) {
        ctx.font = "800 22px Poppins, system-ui, sans-serif"; const bw = ctx.measureText("● AO VIVO").width + 28;
        ctx.fillStyle = "#E5484D"; ctx.beginPath(); ctx.roundRect(W - bw - 28, 34, bw, 42, 10); ctx.fill();
        ctx.fillStyle = "#fff"; ctx.textBaseline = "middle"; ctx.fillText("● AO VIVO", W - bw - 14, 56);
      }
      if (o.letreiro) {
        const bh = o.vertical ? 110 : 84, y = H - bh - (o.vertical ? 60 : 30);
        ctx.fillStyle = "rgba(13,13,16,.88)"; ctx.fillRect(0, y, W, bh);
        ctx.fillStyle = "#F98612"; ctx.fillRect(0, y, 12, bh);
        ctx.fillStyle = "#F4F2EA"; ctx.font = `700 ${o.vertical ? 38 : 32}px Poppins, system-ui, sans-serif`; ctx.textBaseline = "middle";
        let t = o.letreiro; while (ctx.measureText(t).width > W - 60 && t.length > 4) t = t.slice(0, -2);
        ctx.fillText(t === o.letreiro ? t : t + "…", 34, y + bh / 2);
      }
    };
    const w = new Worker(URL.createObjectURL(new Blob([`setInterval(()=>postMessage(0),${Math.round(1000 / FPS)})`], { type: "text/javascript" })));
    w.onmessage = desenhar;
    return () => w.terminate();
  }, []);

  // ---------- envio ----------
  async function mandarFila() {
    if (enviandoRef.current) return;
    enviandoRef.current = true;
    try {
      while (filaRef.current.length && liveId.current) {
        const b = filaRef.current[0];
        let ok = false, msg = "";
        for (let t = 0; t < 4 && !ok; t++) {
          try {
            const r = await fetch(`/api/live/${liveId.current}`, { method: "POST", headers: { "x-seq": String(seq.current), "content-type": "application/octet-stream" }, body: b });
            const j = await r.json().catch(() => ({}));
            if (r.ok) { ok = true; if (j.live) setEstado(j.live); }
            else { msg = j.erro || `erro ${r.status}`; if (r.status === 409 || r.status === 401) break; }
          } catch (e) { msg = e instanceof Error ? e.message : String(e); }
          if (!ok) await new Promise((r) => setTimeout(r, 800));
        }
        if (!ok) { setErro("A transmissão parou: " + msg); await encerrar(true); break; }
        filaRef.current.shift(); seq.current++; setFila(filaRef.current.length);
      }
    } finally { enviandoRef.current = false; }
  }

  async function iniciar() {
    setErro("");
    if (!pasta) return setErro("Escolha o cliente.");
    if (!igChave.trim() && !fbChave.trim()) return setErro("Cole a chave de transmissão do Instagram (ou do Facebook).");
    if (!sCam.current && !sTela.current) return setErro("Câmera não está aberta.");
    setEnviando(true);
    try {
      await audio.current?.ctx.resume();
      const destinos = [
        igChave.trim() && { nome: "Instagram", servidor: igServidor, chave: igChave },
        fbChave.trim() && { nome: "Facebook", servidor: FB_SERVIDOR, chave: fbChave },
      ].filter(Boolean);
      const r = await fetch("/api/live", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ acao: "iniciar", pasta, destinos }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.erro || `erro ${r.status}`);
      liveId.current = j.live.id; seq.current = 0; filaRef.current = []; parar.current = false; setEstado(j.live);
      const trilhas = [...canvas.current!.captureStream(FPS).getVideoTracks(), ...(audio.current?.dest.stream.getAudioTracks() ?? [])];
      const mime = MIMES.find((m) => MediaRecorder.isTypeSupported(m)) ?? "";
      const mr = new MediaRecorder(new MediaStream(trilhas), { mimeType: mime || undefined, videoBitsPerSecond: 3_000_000, audioBitsPerSecond: 128_000 });
      mr.ondataavailable = (ev) => { if (ev.data.size) { filaRef.current.push(ev.data); setFila(filaRef.current.length); void mandarFila(); } };
      mr.start(1000);
      rec.current = mr;
    } catch (e) {
      setErro("Não consegui iniciar: " + (e instanceof Error ? e.message : String(e)));
    } finally { setEnviando(false); }
  }

  async function encerrar(porErro = false) {
    parar.current = true;
    const mr = rec.current; rec.current = null;
    if (mr && mr.state !== "inactive") { await new Promise<void>((ok) => { mr.onstop = () => ok(); mr.stop(); }); }
    if (!porErro) { for (let i = 0; i < 20 && filaRef.current.length; i++) { void mandarFila(); await new Promise((r) => setTimeout(r, 300)); } }
    const id = liveId.current; liveId.current = null;
    if (id) {
      const r = await fetch("/api/live", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ acao: "encerrar", id }) }).catch(() => null);
      const j = r ? await r.json().catch(() => ({})) : {};
      if (j.live) setEstado(j.live); else setEstado((s) => (s ? { ...s, noAr: false } : s));
    }
  }

  // situação do servidor a cada 3 s + aviso ao fechar a aba no ar
  useEffect(() => {
    if (!estado?.noAr) return;
    const t = setInterval(async () => {
      if (!liveId.current) return;
      const r = await fetch(`/api/live?id=${liveId.current}`).catch(() => null);
      const j = r ? await r.json().catch(() => ({})) : {};
      if (j.live) { setEstado(j.live); if (!j.live.noAr && liveId.current) { setErro("A transmissão caiu no servidor: " + (j.live.motivo || "")); void encerrar(true); } }
    }, 3000);
    const sair = (e: BeforeUnloadEvent) => { e.preventDefault(); };
    window.addEventListener("beforeunload", sair);
    return () => { clearInterval(t); window.removeEventListener("beforeunload", sair); };
  }, [estado?.noAr]); // eslint-disable-line react-hooks/exhaustive-deps

  const noAr = !!estado?.noAr;
  const atraso = fila > 3;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "minmax(280px, 420px) 1fr", gap: 18, alignItems: "start" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={caixa}>
          <label style={rotulo}>Cliente</label>
          <select style={campo} value={pasta} onChange={(e) => setPasta(e.target.value)} disabled={noAr}>
            <option value="">Escolha…</option>
            {clientes.map((c) => <option key={c.pasta} value={c.pasta}>{c.nome}</option>)}
          </select>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 10 }}>
            <div><label style={rotulo}>Formato</label>
              <select style={campo} value={vertical ? "v" : "h"} onChange={(e) => setVertical(e.target.value === "v")} disabled={noAr}>
                <option value="v">Stories 9:16 (Instagram)</option><option value="h">Horizontal 16:9 (Facebook/YouTube)</option>
              </select></div>
            <div><label style={rotulo}>Imagem</label>
              <select style={campo} value={fonte} onChange={(e) => setFonte(e.target.value as Fonte)}>
                <option value="camera">Câmera</option><option value="tela">Tela</option><option value="tela+camera">Tela + câmera</option>
              </select></div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 10 }}>
            <div><label style={rotulo}>Câmera</label>
              <select style={campo} value={camId} onChange={(e) => setCamId(e.target.value)}>
                <option value="">Padrão</option>{cams.map((d, i) => <option key={d.deviceId || i} value={d.deviceId}>{d.label || `Câmera ${i + 1}`}</option>)}
              </select></div>
            <div><label style={rotulo}>Microfone</label>
              <select style={campo} value={micId} onChange={(e) => setMicId(e.target.value)}>
                <option value="">Padrão</option>{mics.map((d, i) => <option key={d.deviceId || i} value={d.deviceId}>{d.label || `Microfone ${i + 1}`}</option>)}
              </select></div>
          </div>
        </div>

        <div style={caixa}>
          <label style={{ ...rotulo, display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }}>
            <input type="checkbox" checked={comLogo} onChange={(e) => setComLogo(e.target.checked)} /> Logo do cliente no canto
          </label>
          <label style={{ ...rotulo, marginTop: 10 }}>Letreiro (pode trocar durante a live)</label>
          <input style={campo} value={letreiro} maxLength={70} onChange={(e) => setLetreiro(e.target.value)} placeholder="Ex.: Peça pelo link da bio · Rodízio hoje R$ 59,90" />
        </div>

        <div style={caixa}>
          <label style={rotulo}>Instagram · chave de transmissão</label>
          <input style={campo} type="password" autoComplete="off" value={igChave} onChange={(e) => setIgChave(e.target.value)} disabled={noAr} placeholder="Cole a chave do instagram.com → Criar → Vídeo ao vivo" />
          <details style={{ marginTop: 6 }}>
            <summary style={{ fontSize: 11.5, color: "var(--text-muted)", cursor: "pointer" }}>Servidor (só se o Instagram mostrar outro)</summary>
            <input style={{ ...campo, marginTop: 6 }} value={igServidor} onChange={(e) => setIgServidor(e.target.value)} disabled={noAr} />
          </details>
          <label style={{ ...rotulo, marginTop: 12 }}>Facebook · chave (opcional, ao mesmo tempo)</label>
          <input style={campo} type="password" autoComplete="off" value={fbChave} onChange={(e) => setFbChave(e.target.value)} disabled={noAr} placeholder="Chave do Live Producer do Facebook" />
          <p style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 8, lineHeight: 1.5 }}>
            A chave não fica salva no sistema. O Instagram gera uma nova a cada live.
          </p>
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          {!noAr
            ? <button style={botao("#E5484D", !enviando)} disabled={enviando} onClick={() => void iniciar()}>{enviando ? "Conectando…" : "● Iniciar transmissão"}</button>
            : <button style={botao("#3a3a44")} onClick={() => void encerrar()}>■ Encerrar</button>}
          <button style={botao("var(--surface-raised)")} onClick={() => void abrirCamera()} disabled={noAr}>Reabrir câmera</button>
        </div>
        {servidor === null && (
          <div style={{ ...caixa, borderColor: "var(--status-warning)", fontSize: 13, lineHeight: 1.55 }}>
            <b style={{ color: "var(--status-warning)" }}>A VPS ainda não tem o ffmpeg</b> (o programa que envia a live para o Instagram).
            A atualização automática instala sozinha em alguns minutos. Se não instalar, rode no terminal da VPS: <code>apt install -y ffmpeg</code>.{" "}
            <button onClick={() => setVerificacao((n) => n + 1)} style={{ background: "none", border: "none", color: "var(--accent)", cursor: "pointer", padding: 0, fontSize: 13, textDecoration: "underline" }}>Verificar de novo</button>
          </div>
        )}
        {servidor && <div style={{ fontSize: 11.5, color: "var(--text-muted)" }}>Servidor de live pronto · ffmpeg {servidor}</div>}
        {erro && <div style={{ ...caixa, borderColor: "var(--status-critical)", color: "var(--status-critical)", fontSize: 13 }}>{erro}</div>}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ ...caixa, padding: 10, display: "flex", justifyContent: "center", background: "#000" }}>
          <canvas ref={canvas} width={720} height={1280} style={{ maxHeight: "68vh", maxWidth: "100%", borderRadius: 10 }} />
        </div>
        <div style={{ ...caixa, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, fontSize: 13 }}>
          <div><span style={rotulo}>Situação</span><b style={{ color: noAr ? "#E5484D" : "var(--text-secondary)" }}>{noAr ? "Transmitindo" : estado ? "Encerrada" : "Pronto"}</b></div>
          <div><span style={rotulo}>Tempo</span><b>{estado ? tempo(estado.segundos) : "—"}</b></div>
          <div><span style={rotulo}>Servidor</span><b>{estado?.velocidade ? (estado.velocidade + (estado.bitrate ? ` · ${estado.bitrate}` : "") + (parseFloat(estado.velocidade) < 0.9 && estado.segundos > 20 ? " (VPS lenta)" : "")) : noAr ? "aguardando…" : "—"}</b></div>
          <div><span style={rotulo}>Internet</span><b style={{ color: atraso ? "var(--status-warning)" : undefined }}>{noAr ? (atraso ? `atrasando (${fila}s na fila)` : "ok") : "—"}</b></div>
          {estado?.motivo && !noAr && <div style={{ gridColumn: "1 / -1", color: "var(--text-muted)" }}>Fim: {estado.motivo}.</div>}
          {!!estado?.avisos?.length && <div style={{ gridColumn: "1 / -1", color: "var(--text-muted)", fontSize: 11.5, fontFamily: "monospace", whiteSpace: "pre-wrap" }}>{estado.avisos.join("\n")}</div>}
        </div>
        <div style={{ ...caixa, fontSize: 13, lineHeight: 1.65, color: "var(--text-secondary)" }}>
          <b style={{ color: "var(--text-primary)" }}>Passo a passo</b>
          <ol style={{ margin: "6px 0 0 18px", padding: 0 }}>
            <li>No instagram.com (conta do cliente): <b>Criar → Vídeo ao vivo</b>, título e público → copie a <b>chave de transmissão</b>.</li>
            <li>Cole aqui, confira a imagem e clique <b>Iniciar transmissão</b>.</li>
            <li>Volte ao Instagram: quando a prévia aparecer, clique <b>Entrar ao vivo</b>.</li>
            <li>Deixe esta janela aberta e visível (use outra janela para o Instagram). Para terminar: <b>Encerrar</b> aqui e no Instagram.</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
