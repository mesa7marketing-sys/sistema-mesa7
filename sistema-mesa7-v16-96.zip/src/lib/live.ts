// Live no Instagram (e Facebook/YouTube) pelo painel da Mesa7.
//
// O navegador (página /live) monta o vídeo com câmera, logo e letreiro e manda pedaços de
// ~1 segundo (WebM) para /api/live/<id>. Aqui, um ffmpeg por live recebe esses pedaços,
// converte para o formato que o Instagram pede (H.264 + AAC, quadro-chave a cada 2 s) e envia
// por RTMPS para o servidor + chave de transmissão que o Instagram gerou (Criar → Vídeo ao vivo).
//
// O Instagram não deixa abrir a live por API: a chave muda a cada live e, depois que o vídeo
// começa a chegar, alguém clica "Entrar ao vivo" no instagram.com.
//
// Uma live por vez (a VPS tem 2 núcleos). Enquanto houver live no ar, o arquivo .live-no-ar na
// raiz do app é tocado a cada pedaço e a atualização automática (deploy/atualizar.sh) espera.
import { execFile, spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { promises as fs } from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";

export type Destino = { nome: string; servidor: string; chave: string };

type Sessao = {
  id: string;
  pasta: string;
  usuario: string;
  destinos: string[];        // só os nomes (a chave nunca sai daqui)
  segredos: string[];        // chaves, para apagar dos registros do ffmpeg
  ff: ChildProcessWithoutNullStreams;
  inicio: number;
  ultimoPedaco: number;
  seq: number;
  bytes: number;
  progresso: string;         // última linha "frame= ... bitrate= ... speed=" do ffmpeg
  avisos: string[];
  encerrada: boolean;
  motivo?: string;
};

const g = globalThis as unknown as { __m7lives?: Map<string, Sessao>; __m7liveTimer?: NodeJS.Timeout };
const LIVES = (g.__m7lives ??= new Map());
const MARCA = path.join(process.cwd(), ".live-no-ar");
const SEM_PEDACO_MS = 25_000;  // sem vídeo chegando por 25 s: encerra (aba fechada, internet caiu)

let cacheFfmpeg: { v: string | null; em: number } | null = null;

/** Versão do ffmpeg instalado na VPS (null = não instalado). Guarda o resultado por um tempo. */
export function ffmpegVersao(): Promise<string | null> {
  if (cacheFfmpeg && Date.now() - cacheFfmpeg.em < (cacheFfmpeg.v ? 10 * 60_000 : 15_000)) return Promise.resolve(cacheFfmpeg.v);
  return new Promise((ok) => {
    execFile("ffmpeg", ["-hide_banner", "-version"], { timeout: 5_000 }, (err, saida) => {
      const v = err ? null : (/ffmpeg version (\S+)/.exec(String(saida))?.[1] ?? "instalado");
      cacheFfmpeg = { v, em: Date.now() };
      ok(v);
    });
  });
}

/** Monta a URL completa de envio. Aceita só rtmp:// e rtmps://. */
export function urlDestino(d: Destino): string {
  const servidor = d.servidor.trim(), chave = d.chave.trim();
  if (!/^rtmps?:\/\/[^\s/]+(\/\S*)?$/i.test(servidor)) throw new Error(`Servidor de ${d.nome} inválido: precisa começar com rtmps://`);
  if (!chave || /\s/.test(chave)) throw new Error(`Chave de transmissão de ${d.nome} vazia ou com espaço.`);
  return servidor.replace(/\/+$/, "") + "/" + chave;
}

function limpar(s: string, segredos: string[]) {
  let t = s;
  for (const k of segredos) if (k) t = t.split(k).join("***");
  return t;
}

function argsFfmpeg(urls: string[]) {
  // Entrada: WebM do navegador pelo stdin. Saída: H.264 720p/30 com quadro-chave a cada 2 s
  // (exigência do Instagram/Facebook) + AAC 44,1 kHz, em FLV para cada destino.
  const saida = urls.length === 1
    ? ["-f", "flv", urls[0]]
    : ["-f", "tee", urls.map((u) => `[f=flv:onfail=ignore]${u.replace(/([\\|[\]])/g, "\\$1")}`).join("|")];
  return [
    "-hide_banner", "-loglevel", "warning", "-stats",
    "-fflags", "+genpts", "-thread_queue_size", "1024", "-i", "pipe:0",
    "-map", "0:v:0", "-map", "0:a:0",
    "-c:v", "libx264", "-preset", "veryfast", "-tune", "zerolatency", "-profile:v", "main", "-pix_fmt", "yuv420p",
    "-r", "30", "-g", "60", "-keyint_min", "60", "-sc_threshold", "0",
    "-b:v", "2500k", "-maxrate", "2500k", "-bufsize", "5000k",
    "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
    ...saida,
  ];
}

async function tocarMarca() {
  try { await fs.writeFile(MARCA, new Date().toISOString()); } catch { /* sem permissão: segue sem a marca */ }
}

function vigiar() {
  if (g.__m7liveTimer) return;
  g.__m7liveTimer = setInterval(() => {
    const agora = Date.now();
    for (const s of LIVES.values()) {
      if (!s.encerrada && agora - s.ultimoPedaco > SEM_PEDACO_MS) encerrar(s.id, "parou de chegar vídeo do navegador");
      if (s.encerrada && agora - s.ultimoPedaco > 10 * 60_000) LIVES.delete(s.id);
    }
    if (![...LIVES.values()].some((s) => !s.encerrada)) fs.rm(MARCA, { force: true }).catch(() => {});
  }, 5_000);
  g.__m7liveTimer.unref?.();
}

export function liveAtiva() {
  return [...LIVES.values()].find((s) => !s.encerrada) ?? null;
}

export function iniciar(pasta: string, usuario: string, destinos: Destino[]) {
  const ativa = liveAtiva();
  if (ativa) throw new Error(`Já tem uma live no ar (${ativa.pasta}, por ${ativa.usuario}). Encerre antes de começar outra.`);
  if (!destinos.length) throw new Error("Informe pelo menos um destino (servidor e chave do Instagram).");
  const urls = destinos.map(urlDestino);
  const segredos = destinos.map((d) => d.chave.trim());
  const ff = spawn("ffmpeg", argsFfmpeg(urls), { stdio: ["pipe", "pipe", "pipe"] });
  const s: Sessao = {
    id: randomUUID(), pasta, usuario, destinos: destinos.map((d) => d.nome), segredos, ff,
    inicio: Date.now(), ultimoPedaco: Date.now(), seq: -1, bytes: 0, progresso: "", avisos: [], encerrada: false,
  };
  let resto = "";
  ff.stderr.setEncoding("utf8");
  ff.stderr.on("data", (txt: string) => {
    const linhas = (resto + txt).split(/[\r\n]+/);
    resto = linhas.pop() ?? "";
    for (const l of linhas) {
      if (!l.trim()) continue;
      if (/^frame=/.test(l.trim())) s.progresso = l.trim();
      else { s.avisos.push(limpar(l.trim(), segredos).slice(0, 300)); if (s.avisos.length > 12) s.avisos.shift(); }
    }
  });
  ff.stdin.on("error", () => { /* ffmpeg fechou: o "close" abaixo registra o motivo */ });
  ff.on("error", (e) => { s.avisos.push(`Não consegui iniciar o ffmpeg: ${e.message}`); encerrar(s.id, "ffmpeg não encontrado na VPS"); });
  ff.on("close", (codigo) => {
    if (!s.encerrada) { s.encerrada = true; s.motivo = `a transmissão caiu (ffmpeg saiu com código ${codigo})`; }
  });
  LIVES.set(s.id, s);
  vigiar();
  void tocarMarca();
  return s.id;
}

/** Recebe o pedaço `seq` (em ordem). Pedaço repetido (reenvio) é ignorado. */
export async function receber(id: string, seq: number, dados: Buffer) {
  const s = LIVES.get(id);
  if (!s) throw new Error("Live não encontrada (o servidor pode ter reiniciado).");
  if (s.encerrada) throw new Error(`Live encerrada: ${s.motivo ?? "encerrada"}.`);
  if (seq <= s.seq) return estado(id);
  if (seq !== s.seq + 1) throw new Error(`Pedaço fora de ordem (esperava ${s.seq + 1}, chegou ${seq}).`);
  s.seq = seq;
  s.ultimoPedaco = Date.now();
  s.bytes += dados.length;
  if (!s.ff.stdin.write(dados)) await new Promise((ok) => s.ff.stdin.once("drain", ok));
  if (seq % 5 === 0) void tocarMarca();
  return estado(id);
}

export function encerrar(id: string, motivo = "encerrada pelo painel") {
  const s = LIVES.get(id);
  if (!s) return null;
  if (!s.encerrada) {
    s.encerrada = true;
    s.motivo = motivo;
    try { s.ff.stdin.end(); } catch { /* já fechado */ }
    const ff = s.ff;
    setTimeout(() => { if (ff.exitCode === null) ff.kill("SIGKILL"); }, 8_000).unref?.();
  }
  if (!liveAtiva()) fs.rm(MARCA, { force: true }).catch(() => {});
  return estado(id);
}

export function estado(id: string) {
  const s = LIVES.get(id);
  if (!s) return null;
  const pega = (re: RegExp) => re.exec(s.progresso)?.[1] ?? null;
  const fps = pega(/fps=\s*([\d.]+)/), bitrate = pega(/bitrate=\s*([\d.]+\s*kbits\/s)/), velocidade = pega(/speed=\s*([\d.]+x)/);
  return {
    id: s.id, pasta: s.pasta, destinos: s.destinos, noAr: !s.encerrada,
    segundos: Math.round((Date.now() - s.inicio) / 1000),
    recebidoMB: +(s.bytes / 1048576).toFixed(1), pedacos: s.seq + 1,
    fps: fps ? +fps : null, bitrate, velocidade,
    avisos: s.avisos.slice(-5), motivo: s.motivo ?? null,
  };
}
