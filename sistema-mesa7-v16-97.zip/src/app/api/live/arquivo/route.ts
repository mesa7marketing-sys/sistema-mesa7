import { NextResponse } from "next/server";
import { usuarioEquipe } from "@/lib/live-acesso";
import { arquivoEmUso } from "@/lib/live";
import { descartar, lerArquivo, limparAntigos, receberPedaco, type Enquadramento } from "@/lib/live-arquivo";

export const dynamic = "force-dynamic";

// POST (corpo = pedaço do arquivo): ?id=&nome=&pos=&total=&fim=0|1&enquadramento=auto|cobrir|inteiro
export async function POST(req: Request) {
  const usuario = await usuarioEquipe();
  if (!usuario) return NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
  const q = new URL(req.url).searchParams;
  const dados = Buffer.from(await req.arrayBuffer());
  if (dados.length > 8 * 1024 * 1024) return NextResponse.json({ erro: "Pedaço grande demais." }, { status: 413 });
  const enq = q.get("enquadramento");
  try {
    const pos = Number(q.get("pos"));
    if (pos === 0) await limparAntigos(arquivoEmUso);
    const a = await receberPedaco({
      id: String(q.get("id") || ""), nome: String(q.get("nome") || ""), pos, total: Number(q.get("total")), fim: q.get("fim") === "1",
      enquadramento: (enq === "cobrir" || enq === "inteiro" ? enq : "auto") as Enquadramento, usuario, dados,
    });
    return NextResponse.json({ ok: true, arquivo: a });
  } catch (e) {
    return NextResponse.json({ erro: e instanceof Error ? e.message : String(e) }, { status: 409 });
  }
}

// GET ?id= : situação do arquivo (analisando, convertendo x%, pronto, erro)
export async function GET(req: Request) {
  if (!(await usuarioEquipe())) return NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
  const a = await lerArquivo(String(new URL(req.url).searchParams.get("id") || ""));
  return NextResponse.json({ arquivo: a });
}

// DELETE ?id= : descarta o arquivo (trocar de arquivo / desistir da live)
export async function DELETE(req: Request) {
  if (!(await usuarioEquipe())) return NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
  const id = String(new URL(req.url).searchParams.get("id") || "");
  if (arquivoEmUso(id)) return NextResponse.json({ erro: "Esse arquivo está no ar agora. Encerre a live antes." }, { status: 409 });
  await descartar(id);
  return NextResponse.json({ ok: true });
}
