import { NextResponse } from "next/server";
import { usuarioEquipe } from "@/lib/live-acesso";
import { dashboardPorPasta } from "@/lib/dashboards";
import { encerrar, estado, ffmpegVersao, iniciar, liveAtiva, trocarLetreiro, type Destino, type Modo } from "@/lib/live";
import { espacoLivreGB, lerArquivo } from "@/lib/live-arquivo";

export const dynamic = "force-dynamic";

// GET: a live que estiver no ar (ou ?id=…); ?verificar=1 diz se a VPS tem o ffmpeg e quanto espaço sobra.
export async function GET(req: Request) {
  if (!(await usuarioEquipe())) return NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
  const q = new URL(req.url).searchParams;
  if (q.has("verificar")) return NextResponse.json({ ffmpeg: await ffmpegVersao(), livreGB: await espacoLivreGB() });
  const id = q.get("id");
  const s = id ? estado(id) : (() => { const a = liveAtiva(); return a ? estado(a.id) : null; })();
  return NextResponse.json({ live: s });
}

const MODOS: Modo[] = ["uma", "30", "60", "120", "max"];

// POST { acao: "iniciar", pasta, arquivo, modo, logo (PNG em data URL ou null), letreiro, destinos }
//      { acao: "letreiro", id, texto } | { acao: "encerrar", id }
export async function POST(req: Request) {
  const usuario = await usuarioEquipe();
  if (!usuario) return NextResponse.json({ erro: "Sem acesso." }, { status: 401 });
  let b: { acao?: string; id?: string; pasta?: string; arquivo?: string; modo?: string; logo?: string | null; letreiro?: string; texto?: string; destinos?: Destino[] };
  try { b = await req.json(); } catch { return NextResponse.json({ erro: "Pedido inválido." }, { status: 400 }); }
  try {
    if (b.acao === "encerrar" && b.id) return NextResponse.json({ live: encerrar(b.id) });
    if (b.acao === "letreiro" && b.id) return NextResponse.json({ live: await trocarLetreiro(b.id, String(b.texto ?? "")) });
    if (b.acao === "iniciar") {
      const pasta = String(b.pasta || "");
      if (!dashboardPorPasta(pasta)) throw new Error("Escolha o cliente.");
      if (!(await ffmpegVersao())) throw new Error("A VPS ainda não tem o ffmpeg (o programa que envia a live). A atualização automática instala sozinha em alguns minutos; se não instalar, rode no terminal da VPS: apt install -y ffmpeg");
      const a = await lerArquivo(String(b.arquivo || ""));
      if (!a) throw new Error("Envie o vídeo ou a imagem da live.");
      const modo = (MODOS.includes(b.modo as Modo) ? b.modo : "uma") as Modo;
      let logoPng: Buffer | null = null;
      if (b.logo) {
        const m = /^data:image\/png;base64,([A-Za-z0-9+/=]+)$/.exec(b.logo);
        const buf = m ? Buffer.from(m[1], "base64") : null;
        if (buf && buf.length < 600_000 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) logoPng = buf;
      }
      const destinos = (Array.isArray(b.destinos) ? b.destinos : [])
        .filter((d) => d && String(d.chave || "").trim())
        .slice(0, 3)
        .map((d) => ({ nome: String(d.nome || "Destino").slice(0, 30), servidor: String(d.servidor || ""), chave: String(d.chave || "") }));
      const id = await iniciar({ pasta, usuario, a, modo, logoPng, letreiro: String(b.letreiro ?? "").slice(0, 80), destinos });
      return NextResponse.json({ live: estado(id) });
    }
    return NextResponse.json({ erro: "Ação desconhecida." }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ erro: e instanceof Error ? e.message : String(e) }, { status: 400 });
  }
}
