import { auth } from "@/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

/** Só a equipe Mesa7 (login ativo, não cliente) transmite. */
export async function usuarioEquipe() {
  const session = await auth();
  if (!session?.user?.id) return null;
  const [u] = await db.select({ active: users.active, role: users.role, name: users.name }).from(users).where(eq(users.id, session.user.id)).limit(1);
  if (!u || !u.active || u.role === "client") return null;
  return u.name || "Equipe";
}

