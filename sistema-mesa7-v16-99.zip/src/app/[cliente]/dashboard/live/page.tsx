import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { dashboardPorPasta } from "@/lib/dashboards";
import { acessoLiberado } from "@/lib/acesso-cliente";
import { clientesLiberados } from "@/lib/live-acesso";
import { FormSenhaCliente } from "@/components/FormSenhaCliente";
import { LiveEstudio } from "@/components/LiveEstudio";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Mesa7 — Live", robots: { index: false, follow: false }, referrer: "no-referrer" };

// Live no Instagram feita pelo próprio cliente: painel.mesa7.tech/<cliente>/dashboard/live (senha do cliente).
// Só abre se a equipe liberou o cliente na tela Live.
export default async function LiveClientePage({ params }: { params: Promise<{ cliente: string }> }) {
  const { cliente } = await params;
  const d = dashboardPorPasta(cliente);
  if (!d) notFound();
  if (!(await acessoLiberado(d.pasta))) return <FormSenhaCliente cliente={d.pasta} nome={d.nome} />;
  if (!(await clientesLiberados()).includes(d.pasta)) notFound();
  return (
    <div style={{ minHeight: "100vh", background: "var(--page)", color: "var(--text-primary)", padding: "20px 16px 40px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <a href={`/${d.pasta}/dashboard`} style={{ fontSize: 13, color: "var(--accent)", textDecoration: "none" }}>← Voltar ao dashboard</a>
        <h1 style={{ fontSize: 22, margin: "10px 0 4px" }}>Live no Instagram — {d.nome}</h1>
        <p style={{ fontSize: 13.5, color: "var(--text-secondary)", margin: "0 0 16px", maxWidth: 720 }}>
          Envie um vídeo ou uma imagem, cole a chave de transmissão do Instagram e inicie. A live roda em nossos servidores: você pode fechar esta página. O arquivo é apagado quando a live termina.
        </p>
        <LiveEstudio clientes={[{ pasta: d.pasta, nome: d.nome }]} pastaFixa={d.pasta} base={`/${d.pasta}/dashboard/live-api`} />
      </div>
    </div>
  );
}
