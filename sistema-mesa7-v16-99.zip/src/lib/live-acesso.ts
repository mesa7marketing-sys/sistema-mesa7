import { promises as fs } from "node:fs";
import path from "node:path";
import { auth } from "@/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { raizArquivos } from "@/lib/arquivos";
import { acessoLiberado } from "@/lib/acesso-cliente";
import { dashboardPorPasta } from "@/lib/dashboards";

/** Só a equipe Mesa7 (login ativo, não cliente) transmite. */
export async function usuarioEquipe() {
  const session = await auth();
  if (!session?.user?.id) return null;
  const [u] = await db.select({ active: users.active, role: users.role, name: users.name }).from(users).where(eq(users.id, session.user.id)).limit(1);
  if (!u || !u.active || u.role === "client") return null;
  return u.name || "Equipe";
}

// Clientes que a equipe liberou para transmitir pelo próprio link: <pasta de arquivos>/_acessos/live-clientes.json
const arqLiberados = () => path.join(raizArquivos(), "_acessos", "live-clientes.json");

export async function clientesLiberados(): Promise<string[]> {
  try {
    const l = JSON.parse(await fs.readFile(arqLiberados(), "utf8"));
    return Array.isArray(l) ? l.filter((x) => typeof x === "string") : [];
  } catch {
    return [];
  }
}

export async function liberarCliente(pasta: string, ligado: boolean) {
  if (!dashboardPorPasta(pasta)) throw new Error("Cliente inválido.");
  const l = new Set(await clientesLiberados());
  if (ligado) l.add(pasta); else l.delete(pasta);
  await fs.mkdir(path.dirname(arqLiberados()), { recursive: true });
  await fs.writeFile(arqLiberados(), JSON.stringify([...l].sort(), null, 2), { mode: 0o600 });
}

export type Quem = { usuario: string; pastaFixa: string | null };

/** Quem está pedindo: a equipe (qualquer cliente) ou o cliente da pasta (senha dele + liberação da equipe). */
export async function quemTransmite(pastaCliente?: string): Promise<Quem | null> {
  if (!pastaCliente) {
    const u = await usuarioEquipe();
    return u ? { usuario: u, pastaFixa: null } : null;
  }
  const d = dashboardPorPasta(pastaCliente);
  if (!d || !(await acessoLiberado(d.pasta)) || !(await clientesLiberados()).includes(d.pasta)) return null;
  return { usuario: `Cliente ${d.nome}`, pastaFixa: d.pasta };
}
